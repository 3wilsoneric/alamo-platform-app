/** @returns {Record<string, any>} */
export function reportObject(value: any, required: any, optional?: any[]): Record<string, any>;
export function reportId(value: any): string;
export function reportSubject(value: any): string;
export function reportText(value: any, max?: number): string;
export function reportJson(value: any, max?: number): any;
export function validateReportScope(input: any): {
    communityIds: any[];
    from: any;
    through: any;
};
export function validateReportCreate(input: any): {
    requestId: string;
    objective: string;
    scope: {
        communityIds: any[];
        from: any;
        through: any;
    };
};
export function validateReportCommand(input: any): any;
export function validateReportPlan(input: any, catalog: any): {
    steps: {
        id: string;
        capability: any;
        input: any;
    }[];
    gaps: string[];
};
export function validateReportEvidence(input: any, step: any, scope: any): any;
export function isReportBlobPath(value: any): boolean;
export const EXECUTIVE_REPORT_PATH: "/api/agent/v1/reports";
export const EXECUTIVE_REPORT_SOURCE_PATH: "/api/platform/ally-source/v1";
export const REPORT_TERMINAL: Set<string>;
export const REPORT_CACHE_VERSION: "executive-report-cache-v2";
export function reportHash(value: any): string;
