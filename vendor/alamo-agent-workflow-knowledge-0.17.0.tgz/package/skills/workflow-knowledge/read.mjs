import { validateKnowledgeRequest, validateKnowledgeResponse, WORKFLOW_KNOWLEDGE_SKILL } from "../../shared/workflow-knowledge-contracts.mjs";

export { WORKFLOW_KNOWLEDGE_SKILL };
// One read capability, not a new chat executor or background responsibility.
// The owning source reauthorizes and versions evidence on each invocation.
export async function readWorkflowKnowledge({ request, source }) {
  const input = validateKnowledgeRequest(request);
  return validateKnowledgeResponse(await source.read(input), input);
}
