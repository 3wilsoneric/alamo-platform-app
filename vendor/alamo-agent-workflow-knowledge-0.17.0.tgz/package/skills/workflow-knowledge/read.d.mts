import type { KnowledgeRequest, KnowledgeResponse } from '../../shared/workflow-knowledge-contracts.mjs';
export { WORKFLOW_KNOWLEDGE_SKILL } from '../../shared/workflow-knowledge-contracts.mjs';
export function readWorkflowKnowledge(options:{request:KnowledgeRequest;source:{read(request:KnowledgeRequest):Promise<KnowledgeResponse>}}):Promise<KnowledgeResponse>;
