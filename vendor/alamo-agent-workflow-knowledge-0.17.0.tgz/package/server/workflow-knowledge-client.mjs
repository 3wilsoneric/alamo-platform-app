import { validateKnowledgeRequest, validateKnowledgeResponse, WORKFLOW_KNOWLEDGE_PATH, WORKFLOW_KNOWLEDGE_MAX_BYTES } from "../shared/workflow-knowledge-contracts.mjs";
export { readWorkflowKnowledge, WORKFLOW_KNOWLEDGE_SKILL } from "../skills/workflow-knowledge/read.mjs";

// The host supplies an API-audience delegated token. The endpoint never accepts
// a caller-chosen subject, role or URL. Workload access is not enabled implicitly.
export function createWorkflowKnowledgeClient({ origin, getToken, fetchImpl = fetch, now = Date.now }) {
  const base = new URL(origin);
  if (base.protocol !== "https:" || base.origin !== origin || typeof getToken !== "function") throw new Error("Configure an exact Workflow HTTPS origin and token provider.");
  return { async read(request) {
    const input = validateKnowledgeRequest(request), token = await getToken();
    if (!token || typeof token.token !== "string" || !token.token || token.token.length > 16000 || !Number.isFinite(token.expiresOnTimestamp) || token.expiresOnTimestamp <= now()) throw new Error("Workflow sign-in is unavailable.");
    const response = await fetchImpl(new URL(WORKFLOW_KNOWLEDGE_PATH, base), { method: "POST", redirect: "error", cache: "no-store", signal: AbortSignal.timeout(12000),
      headers: { Authorization: `Bearer ${token.token}`, "Content-Type": "application/json" }, body: JSON.stringify(input) });
    try {
      if (!response.ok || !/^application\/json\b/i.test(response.headers.get("content-type") ?? "") || Number(response.headers.get("content-length")) > WORKFLOW_KNOWLEDGE_MAX_BYTES) throw new Error("Workflow source access could not be verified.");
      const chunks = []; let size = 0;
      for await (const bytes of response.body ?? []) { size += bytes.length; if (size > WORKFLOW_KNOWLEDGE_MAX_BYTES) throw new Error("Workflow response exceeded its limit."); chunks.push(Buffer.from(bytes)); }
      return validateKnowledgeResponse(JSON.parse(Buffer.concat(chunks).toString("utf8")), input);
    } finally { await response.body?.cancel().catch(() => {}); }
  } };
}

export { hasEveryAgentAccess } from "../shared/everyagent-identity.mjs";
