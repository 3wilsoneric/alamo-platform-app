import type { KnowledgeRequest, KnowledgeResponse } from '../shared/workflow-knowledge-contracts.mjs';
export { readWorkflowKnowledge, WORKFLOW_KNOWLEDGE_SKILL } from '../skills/workflow-knowledge/read.mjs';
export function createWorkflowKnowledgeClient(options:{origin:string;getToken:()=>Promise<{token:string;expiresOnTimestamp:number}>;fetchImpl?:typeof fetch;now?:()=>number}):{read(request:KnowledgeRequest):Promise<KnowledgeResponse>};

export function hasEveryAgentAccess(claims:unknown):boolean;
