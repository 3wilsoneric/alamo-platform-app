export const WORKFLOW_KNOWLEDGE_PATH = "/api/platform/workflow-knowledge";
export const WORKFLOW_KNOWLEDGE_MAX_BYTES = 96_000;
export const WORKFLOW_KNOWLEDGE_CAPABILITY = Object.freeze({ id: "workflow.knowledge.read", version: 1,
  operation: "read", scope: "source-user", protocol: { id: "workflow-knowledge", version: 1 }, resourceKinds: ["role", "workflow", "procedure", "skill-reference"] });
export const WORKFLOW_KNOWLEDGE_SKILL = Object.freeze({ id: "workflow-knowledge", version: 1, title: "Read Workflow knowledge",
  sourceApplication: "workflow", capability: WORKFLOW_KNOWLEDGE_CAPABILITY.id, scope: "source-user", sourceProtocol: 1,
  execution: "on-demand-read", authority: "read", output: "Source excerpts and version-bound citations; no generated clinical advice or actions." });
const fail = () => { throw new Error("Invalid Workflow knowledge contract."); };
function object(value, keys) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !keys.includes(key)) || keys.some(key => !(key in value))) fail();
  return value;
}
function text(value, maximum) { if (typeof value !== "string" || !value.trim() || value.length > maximum) fail(); return value; }
export function knowledgeDocumentId(value) { if (typeof value !== "string" || !/^(role|workflow|procedure|skill):[A-Za-z0-9_-]{1,100}$/.test(value)) fail(); return value; }
export function knowledgeRevision(value) { if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) fail(); return value; }
export function knowledgeHref(id, revision) { return `/workflow?document=${encodeURIComponent(knowledgeDocumentId(id))}&revision=${knowledgeRevision(revision)}`; }
export function validateKnowledgeRequest(value) {
  const keys = value?.operation === "search" ? ["version", "operation", "query"] : ["version", "operation", "documentId", "expectedRevision"];
  const v = object(value, keys);
  if (v.version !== 1) fail();
  if (v.operation === "search") return { version: 1, operation: "search", query: text(v.query, 500).trim() };
  if (v.operation !== "read") fail();
  return { version: 1, operation: "read", documentId: knowledgeDocumentId(v.documentId), expectedRevision: knowledgeRevision(v.expectedRevision) };
}
export function validateKnowledgeResponse(value, request) {
  const input = validateKnowledgeRequest(request);
  const v = object(value, ["version", "application", "capability", "sourceRevision", "observedAt", "operation", "query", "documents", "matchedCount", "limited", "notice"]);
  if (new TextEncoder().encode(JSON.stringify(v)).length > WORKFLOW_KNOWLEDGE_MAX_BYTES || v.version !== 1 || v.application !== "workflow" || v.capability !== WORKFLOW_KNOWLEDGE_CAPABILITY.id || v.operation !== input.operation) fail();
  knowledgeRevision(v.sourceRevision);
  if (typeof v.observedAt !== "string" || !Number.isFinite(Date.parse(v.observedAt))) fail();
  if (v.query !== (input.operation === "search" ? input.query : null)) fail();
  if (!Array.isArray(v.documents) || v.documents.length > (input.operation === "search" ? 5 : 1) || !Number.isSafeInteger(v.matchedCount) || v.matchedCount < v.documents.length || v.matchedCount > 1000 || v.limited !== (v.matchedCount > v.documents.length)) fail();
  text(v.notice, 700);
  const ids = new Set();
  for (const doc of v.documents) {
    object(doc, ["id", "title", "kind", "ownerApplication", "reviewStatus", "version", "updated", "revision", "href", "summary", "excerpts", "body"]);
    knowledgeDocumentId(doc.id); knowledgeRevision(doc.revision);
    if (ids.has(doc.id)) fail(); ids.add(doc.id);
    if (input.operation === "read" && (doc.id !== input.documentId || doc.revision !== input.expectedRevision)) fail();
    if (doc.href !== knowledgeHref(doc.id, doc.revision)) fail();
    text(doc.title, 240); text(doc.version, 60); text(doc.updated, 60); text(doc.summary, 2000);
    if (!["role", "workflow", "procedure", "skill"].includes(doc.kind) || doc.id.split(":")[0] !== doc.kind || doc.ownerApplication !== (doc.kind === "skill" ? "alamoagent" : "workflow") || doc.reviewStatus !== (doc.kind === "procedure" ? "review" : "draft")) fail();
    if (!Array.isArray(doc.excerpts) || doc.excerpts.length < 1 || doc.excerpts.length > 3) fail();
    for (const excerpt of doc.excerpts) { object(excerpt, ["heading", "text", "truncated"]); text(excerpt.heading, 240); text(excerpt.text, 1800); if (typeof excerpt.truncated !== "boolean") fail(); }
    if (input.operation === "search" ? doc.body !== null : typeof doc.body !== "string" || doc.body.length > 40_000 || !doc.body) fail();
  }
  if (input.operation === "read" && v.documents.length !== 1) fail();
  return structuredClone(v);
}
