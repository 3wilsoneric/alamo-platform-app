export type KnowledgeRequest = { version: 1; operation: 'search'; query: string } | { version: 1; operation: 'read'; documentId: string; expectedRevision: string };
export interface KnowledgeDocument { id: string; title: string; kind: 'role'|'workflow'|'procedure'|'skill'; ownerApplication:'workflow'|'alamoagent'; reviewStatus:'draft'|'review'; version:string; updated:string; revision:string; href:string; summary:string; excerpts:{heading:string;text:string;truncated:boolean}[]; body:string|null }
export interface KnowledgeResponse { version:1; application:'workflow'; capability:'workflow.knowledge.read'; sourceRevision:string; observedAt:string; operation:'search'|'read'; query:string|null; documents:KnowledgeDocument[]; matchedCount:number; limited:boolean; notice:string }
export const WORKFLOW_KNOWLEDGE_PATH: '/api/platform/workflow-knowledge';
export const WORKFLOW_KNOWLEDGE_MAX_BYTES: number;
export const WORKFLOW_KNOWLEDGE_CAPABILITY: {id:string;version:number;operation:'read';scope:'source-user';protocol:{id:'workflow-knowledge';version:number};resourceKinds:string[]};
export const WORKFLOW_KNOWLEDGE_SKILL: {id:string;version:number;title:string;sourceApplication:'workflow';capability:string;scope:'source-user';sourceProtocol:number;execution:'on-demand-read';authority:'read';output:string};
export function knowledgeDocumentId(value:unknown):string;
export function knowledgeRevision(value:unknown):string;
export function knowledgeHref(id:string,revision:string):string;
export function validateKnowledgeRequest(value:unknown):KnowledgeRequest;
export function validateKnowledgeResponse(value:unknown,request:KnowledgeRequest):KnowledgeResponse;
