import { validateProFormaSourceConfig } from './proforma-source-config.mjs';
import { createProFormaDelegatedIdentity } from './proforma-delegated-identity.mjs';
import { createProFormaAutomationClient } from './proforma-automation-client.mjs';
import { createProFormaGuidanceService, PROFORMA_GUIDANCE_PATH } from './proforma-guidance-service.mjs';
import { maintenanceObject as object } from '../shared/proforma-maintenance-contracts.mjs';
import { AGENT_CONVERSATIONS_PATH } from '../shared/everyagent-conversations.mjs';

/** @param {any} options */
export function createProFormaGuidanceRuntime({ env = process.env, authorize, credentialFor, managedIdentityFor, fetchImpl = fetch, now = Date.now }) {
  const raw = env.ALAMOAGENT_PROFORMA_GUIDANCE_JSON;
  if (raw === undefined) return { authorize, guidance: null };
  let config;
  try {
    if (typeof raw !== 'string' || Buffer.byteLength(raw) > 128000) throw new Error('Invalid configuration');
    const value = object(JSON.parse(raw), ['schemaVersion','identity','sourceScope','bindings']);
    config = validateProFormaSourceConfig(value, env);
  } catch { throw new Error('Configure a valid read-only ProForma guidance connection.'); }
  const identity = createProFormaDelegatedIdentity({ config, authorize, now, ...(credentialFor ? { credentialFor } : {}), ...(managedIdentityFor ? { managedIdentityFor } : {}) });
  const guidance = createProFormaGuidanceService({ bindingsFor: async () => config.bindings, now,
    sourceFor: (binding, auth) => createProFormaAutomationClient({ binding, getToken: () => identity.getToken(auth), fetchImpl, now }) });
  return { guidance, authorize: req => [PROFORMA_GUIDANCE_PATH, AGENT_CONVERSATIONS_PATH].includes(String(req.url ?? '').split('?', 1)[0] ?? '') ? identity.authorize(req) : authorize(req) };
}
