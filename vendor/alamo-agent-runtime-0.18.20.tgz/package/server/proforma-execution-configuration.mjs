import {maintenanceHash as hash,maintenanceObject as object,maintenanceId as id,maintenanceDigest as digest,maintenanceInteger as integer} from '../shared/proforma-maintenance-contracts.mjs';
import {validateAutomationBinding,validateAutomationDefinition} from '../shared/proforma-automation-contracts.mjs';
import {validateExecutionCandidate,executionDefinitionHash} from '../shared/proforma-execution-contracts.mjs';
import {createProFormaExecution,proformaReferralCapability} from './proforma-execution.mjs';
import {everyAgentActor} from './everyagent-access.mjs';
import {createHttpError} from './http-error-contract.mjs';
import {guidanceRequest,validateGuidanceDiscovery} from '../shared/proforma-guidance-contracts.mjs';

export const PROCESS_CONFIGURATION_ACTIONS=['find_processes','discover_process','read_process_configuration','propose_process','review_process','set_process_enabled'];
const hidden=()=>createHttpError(404,'process_configuration_unavailable','Process configuration is unavailable.');
const changed=()=>createHttpError(409,'process_configuration_changed','The plan or its source changed. Refresh before continuing.');
const invalid=()=>createHttpError(400,'process_configuration_invalid','Use a valid process configuration command.');
const last=record=>record.events.at(-1);

// Source connections and model/evaluation policy come from the host. Commands can
// propose and explicitly review mappings, never supply tokens, URLs or source data.
export function createProFormaConfiguredExecution({store,bindingsFor,sourceFor,getPolicy,now=Date.now}){
  if(!store||![bindingsFor,sourceFor,getPolicy].every(f=>typeof f==='function'))throw new Error('Explicit configuration storage, source identity and policy are required.');
  function owner(auth){const user=everyAgentActor(auth);if(!Number.isFinite(auth.claims.exp)||auth.claims.exp*1000<=now())throw hidden();id(auth.claims.azp);return {actorId:`entra:${auth.claims.tid}:${user}`,clientId:auth.claims.azp};}
  async function bindings(auth){const a=owner(auth),raw=await bindingsFor(auth);if(!Array.isArray(raw)||raw.length>50)throw hidden();const values=raw.map(v=>/** @type {Record<string,any>} */(validateAutomationBinding(v)));if(new Set(values.map(v=>v.id)).size!==values.length)throw hidden();return values.filter(v=>v.actorId===a.actorId);}
  async function source(auth,sourceBindingId,expected){
    const b=(await bindings(auth)).find(b=>b.id===sourceBindingId);if(!b||!b.documentIds.includes(expected.documentId))throw hidden();
    let envelope;
    try{envelope=validateAutomationDefinition(await sourceFor(b,auth).read(expected),b,expected);}catch{throw changed();}
    const after=(await bindings(auth)).find(v=>v.id===sourceBindingId);if(!after||hash(after)!==hash(b))throw changed();
    return {binding:b,envelope};
  }
  function expected(v){object(v,['documentId','publicationId','fingerprint']);id(v.documentId);id(v.publicationId);digest(v.fingerprint);return v;}
  async function policy(){const p=object(await getPolicy(),['models','evaluationDigest']);object(p.models,['quality','selection']);digest(p.evaluationDigest);for(const value of Object.values(p.models))if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value))throw hidden();return structuredClone(p);}
  function checkCandidate(candidate,binding,envelope,p){
    const macro=envelope.definition.requests.find(r=>r.id===candidate.source.macroId);
    if(hash(binding)!==hash(candidate.sourceBinding)||envelope.definitionHash!==candidate.source.definitionHash||!macro||hash(macro)!==candidate.source.macroHash||candidate.stepBindings.length!==macro.request.steps.length||hash(p.models)!==hash(candidate.models)||p.evaluationDigest!==candidate.evaluationDigest||candidate.capability.revision!==proformaReferralCapability.revision)throw changed();
    return macro;
  }
  async function current(auth,candidate){
    const {binding,envelope}=await source(auth,candidate.sourceBinding.id,{documentId:candidate.source.documentId,publicationId:candidate.source.publicationId,fingerprint:candidate.source.fingerprint});
    const macro=checkCandidate(candidate,binding,envelope,await policy());owner(auth);return macro;
  }
  async function view(auth,record){
    if(!record||record.actorId!==owner(auth).actorId)throw hidden();const e=last(record),base={id:record.id,revision:e.revision,proposalHash:e.candidateHash,status:e.status,enabled:e.enabled,mode:'synthetic-only',
      source:{documentId:e.candidate.source.documentId,publicationId:e.candidate.source.publicationId,fingerprint:e.candidate.source.fingerprint}};
    let macro;try{macro=await current(auth,e.candidate);}catch{owner(auth);return {...base,available:false};}
    return {...base,available:true,proposalHash:e.candidateHash,source:e.candidate.source,macro:macro.request,stepBindings:e.candidate.stepBindings,capability:proformaReferralCapability,models:e.candidate.models,evaluationDigest:e.candidate.evaluationDigest,
      review:e.review,history:record.events.map(event=>({revision:event.revision,requestId:event.requestId,at:event.at,status:event.status,enabled:event.enabled,proposalHash:event.candidateHash,actorId:event.actorId}))};
  }
  async function discover(auth,input){
    const ref=expected(input),choices=(await bindings(auth)).filter(b=>b.documentIds.includes(ref.documentId)),chosen=choices[0];if(choices.length!==1||!chosen)throw hidden();
    const {binding,envelope}=await source(auth,chosen.id,ref);const a=owner(auth),records=(await store.read()).value.records.filter(r=>r.actorId===a.actorId&&last(r).candidate.source.documentId===ref.documentId);
    const configurations=[],p=await policy();for(const record of records){const e=last(record);let available=true;try{checkCandidate(e.candidate,binding,envelope,p);}catch{available=false;}
      configurations.push({id:record.id,revision:e.revision,status:e.status,enabled:e.enabled,available,...(available?{proposalHash:e.candidateHash,macroId:e.candidate.source.macroId}:{}),mode:'synthetic-only'});}
    return {sourceBindingId:binding.id,source:ref,macros:envelope.definition.requests,capability:proformaReferralCapability,configurations,mode:'synthetic-only'};
  }
  async function command(auth,raw){
    const a=owner(auth);let c;
    try{
      const fields={find_processes:['sourceBindingId','query','limit'],discover_process:['source'],read_process_configuration:['executionId'],propose_process:['requestId','executionId','expectedRevision','source','stepBindings'],review_process:['requestId','executionId','expectedRevision','proposalHash','decision','activate'],set_process_enabled:['requestId','executionId','expectedRevision','proposalHash','enabled']};
      if(!fields[raw?.action])throw invalid();c=object(raw,['action',...fields[raw.action]]);
      if(c.action==='find_processes'){id(c.sourceBindingId);guidanceRequest({documentIds:[]},c.query,c.limit);}
      else if(c.action==='discover_process')expected(c.source);
      else if(c.action!=='propose_process'||c.executionId!==null)id(c.executionId);
      if(c.requestId!==undefined){id(c.requestId);integer(c.expectedRevision);}
      if(c.action==='review_process'&&(!['approve','reject'].includes(c.decision)||typeof c.activate!=='boolean'||c.decision==='reject'&&c.activate))throw invalid();
      if(c.action==='set_process_enabled'&&typeof c.enabled!=='boolean')throw invalid();
      if(c.proposalHash!==undefined)digest(c.proposalHash);
      if(c.action==='propose_process'){object(c.source,['sourceBindingId','documentId','publicationId','fingerprint','macroId']);id(c.source.sourceBindingId);id(c.source.macroId);expected({documentId:c.source.documentId,publicationId:c.source.publicationId,fingerprint:c.source.fingerprint});}
    }catch{throw invalid();}
    if(c.action==='find_processes'){
      const binding=(await bindings(auth)).find(b=>b.id===c.sourceBindingId);if(!binding)throw hidden();
      const client=sourceFor(binding,auth);if(typeof client.discover!=='function')throw hidden();
      const request=guidanceRequest(binding,c.query,c.limit);
      const guidance=validateGuidanceDiscovery(await client.discover({query:c.query,limit:c.limit}),binding,request);
      const after=(await bindings(auth)).find(b=>b.id===binding.id);if(!after||hash(after)!==hash(binding))throw changed();
      owner(auth);return {sourceBindingId:binding.id,guidance};
    }
    if(c.action==='discover_process')return discover(auth,c.source);
    if(c.action==='read_process_configuration')return {configuration:await view(auth,(await store.read()).value.records.find(r=>r.id===c.executionId))};
    const executionId=c.executionId??c.requestId,commandHash=hash(c);let receipt;
    const state=await store.update(async state=>{
      owner(auth);
      const prior=state.records.filter(r=>r.actorId===a.actorId).flatMap(r=>r.events.map(e=>({record:r,event:e}))).find(v=>v.event.requestId===c.requestId);
      if(prior){if(prior.event.commandHash!==commandHash||prior.event.clientId!==a.clientId)throw changed();receipt={id:c.requestId,configurationId:prior.record.id,revision:prior.event.revision,commandHash};return false;}
      let record=state.records.find(r=>r.id===executionId);if(record&&record.actorId!==a.actorId)throw hidden();
      const old=record?last(record):null;if((old?.revision??0)!==c.expectedRevision)throw changed();
      const at=new Date(now()).toISOString();let candidate,status,enabled,review;
      if(c.action==='propose_process'){
        const {binding,envelope}=await source(auth,c.source.sourceBindingId,{documentId:c.source.documentId,publicationId:c.source.publicationId,fingerprint:c.source.fingerprint}),macro=envelope.definition.requests.find(r=>r.id===c.source.macroId),p=await policy();
        if(!macro||!Array.isArray(c.stepBindings)||c.stepBindings.length!==macro.request.steps.length)throw changed();
        try{candidate=validateExecutionCandidate({schemaVersion:1,id:executionId,sourceBinding:binding,source:{documentId:c.source.documentId,publicationId:c.source.publicationId,fingerprint:c.source.fingerprint,definitionHash:envelope.definitionHash,macroId:macro.id,macroHash:hash(macro)},capability:{id:proformaReferralCapability.id,revision:proformaReferralCapability.revision},...p,stepBindings:c.stepBindings});}catch{throw invalid();}
        status='pending';enabled=false;review=null;
      }else{
        if(!old||old.candidateHash!==c.proposalHash)throw changed();candidate=old.candidate;
        if(c.action==='review_process'){
          if(old.status!=='pending')throw changed();await current(auth,candidate);
          status=c.decision==='approve'?'approved':'rejected';enabled=c.activate;review=status==='approved'?{actorId:a.actorId,definitionHash:executionDefinitionHash(candidate),at}:null;
        }else{
          if(old.status!=='approved')throw changed();if(c.enabled)await current(auth,candidate);status=old.status;enabled=c.enabled;review=old.review;
        }
      }
      owner(auth);const event={revision:(old?.revision??0)+1,requestId:c.requestId,commandHash,clientId:a.clientId,actorId:a.actorId,at,candidate,candidateHash:hash(candidate),status,enabled,review};
      if(!record){record={id:executionId,actorId:a.actorId,events:[]};state.records.push(record);}record.events.push(event);
      receipt={id:c.requestId,configurationId:record.id,revision:event.revision,commandHash};return true;
    });
    return {configuration:await view(auth,state.records.find(r=>r.id===receipt.configurationId)),receipt};
  }
  async function definitions(auth){
    const p=await policy(),active=await bindings(auth);
    return (await store.read()).value.records.map(last).filter(e=>e.status==='approved'&&e.actorId===owner(auth).actorId).map(e=>({...e.candidate,
      enabled:e.enabled&&hash(p.models)===hash(e.candidate.models)&&p.evaluationDigest===e.candidate.evaluationDigest&&active.some(b=>hash(b)===hash(e.candidate.sourceBinding)),review:e.review}));
  }
  const execution=createProFormaExecution({definitions,sourceFor});
  return {...execution,configurationCommand:command};
}
