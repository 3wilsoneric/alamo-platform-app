import { everyAgentActor } from './everyagent-access.mjs';
import { createHttpError } from './http-error-contract.mjs';
import { validateAutomationBinding, validateAutomationDefinition } from '../shared/proforma-automation-contracts.mjs';
import { guidanceRequest, validateGuidanceDiscovery, PROFORMA_GUIDANCE_CAPABILITY } from '../shared/proforma-guidance-contracts.mjs';
import { maintenanceObject as object, maintenanceId as id, maintenanceDigest as digest, maintenanceHash as hash } from '../shared/proforma-maintenance-contracts.mjs';

export const PROFORMA_GUIDANCE_PATH = '/api/agent/v1/guidance';
const unavailable = () => createHttpError(404, 'guidance_unavailable', 'That guidance connection is unavailable.');

/** Read-only app capability. Uses the same identity and source client as the
 * execution adapter without instantiating a model, task runner or sandbox. */
export function createProFormaGuidanceService({ bindingsFor, sourceFor, now = Date.now }) {
  function actor(auth) {
    const user = everyAgentActor(auth);
    if (!Number.isFinite(auth.claims.exp) || auth.claims.exp * 1000 <= now()) throw unavailable();
    return `entra:${auth.claims.tid}:${user}`;
  }
  async function bindings(auth) {
    const actorId = actor(auth), values = await bindingsFor(auth);
    if (!Array.isArray(values) || values.length > 50) throw unavailable();
    return values.map(value => /** @type {import('./proforma-source-config.mjs').SourceBinding} */ (validateAutomationBinding(value))).filter(value => value.actorId === actorId && value.scope.tenantId === auth.claims.tid);
  }
  return {
    async describe(auth) {
      const values = await bindings(auth); actor(auth);
      return { schemaVersion: 1, application: 'workflow', product: 'ProForma',
        capabilities: [PROFORMA_GUIDANCE_CAPABILITY, { id: 'proforma.guidance.read', version: 1, operation: 'read', scope: 'source-user', protocol: { id: 'proforma.automation-definition', version: 1 }, resourceKinds: ['published-guide'] }],
        connections: values.map(value => ({ id: value.id, purpose: value.purpose, configured: true, access: 'checked-on-use' })),
        modules: [{ id: 'proforma.publication-reader', version: 1, application: 'workflow', inputs: ['publicationId','fingerprint'] }], canExecute: false };
    },
    async command(auth, raw) {
      actor(auth); let command;
      try {
        if (!['find','read'].includes(raw?.action)) throw new Error('Unknown command');
        command = object(raw, raw.action === 'find' ? ['action','sourceBindingId','query','limit'] : ['action','sourceBindingId','source']);
        id(command.sourceBindingId);
        if (command.action === 'find') guidanceRequest({ documentIds: [] }, command.query, command.limit);
        else { object(command.source, ['documentId','publicationId','fingerprint']); id(command.source.documentId); id(command.source.publicationId); digest(command.source.fingerprint); }
      } catch { throw createHttpError(400, 'guidance_input', 'Use a valid guidance read or search.'); }
      const binding = (await bindings(auth)).find(value => value.id === command.sourceBindingId);
      if (!binding || (command.action === 'read' && !binding.documentIds.includes(command.source.documentId))) throw unavailable();
      const source = sourceFor(binding, auth);
      const result = command.action === 'find'
        ? validateGuidanceDiscovery(await source.discover({ query: command.query, limit: command.limit }), binding, guidanceRequest(binding, command.query, command.limit))
        : validateAutomationDefinition(await source.read(command.source), binding, command.source);
      const after = (await bindings(auth)).find(value => value.id === binding.id);
      if (!after || hash(after) !== hash(binding)) throw unavailable();
      actor(auth);
      return { schemaVersion: 1, sourceBindingId: binding.id, result };
    },
  };
}
