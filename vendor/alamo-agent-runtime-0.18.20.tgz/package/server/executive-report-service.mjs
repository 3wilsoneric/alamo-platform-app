import { randomUUID } from 'node:crypto';
import { buildReportDocument, inspectCitedReportFindings, validateCitedReportFindings } from '../packages/ally-core/dist/index.js';
import { EVERYAGENT_TENANT } from '../shared/everyagent-identity.mjs';
import { REPORT_TERMINAL, REPORT_CACHE_VERSION, reportHash, reportId, reportSubject, reportText, validateReportCreate, validateReportCommand, validateReportScope, validateReportPlan, validateReportEvidence } from '../shared/executive-report-contracts.mjs';
import { createHttpError } from './http-error-contract.mjs';
import { reportViewContext, reportViewPlan } from '../shared/executive-report-views.mjs';

const hidden = () => createHttpError(404, 'report_not_found', 'Report not found.');
const conflict = () => createHttpError(409, 'report_changed', 'The report changed. Refresh and try again.');
const last = report => report.runs.at(-1);
const readDefinition = ({ capability, input, scope }) => ({ capability, input, ...(scope !== undefined ? { scope } : {}) });
// Independent read-only work is bounded to three concurrent entries per batch.
// Scope checks precede capability checks; no authorization result is cached.
async function readInBatches(entries, read) {
  const values = [];
  for (let start = 0; start < entries.length; start += 3) {
    values.push(...await Promise.all(entries.slice(start, start + 3).map(read)));
  }
  return values.filter(value => value !== null);
}
const visibleStatus = (run, now) => run.status === 'queued' && run.lease?.until > now ? 'planning' : run.status;
const summary = (report, now = Date.now()) => ({ id: report.id, ownerId: report.ownerId, title: last(report).objective,
  createdAt: report.createdAt, updatedAt: last(report).updatedAt, version: report.runs.length, revision: report.revision,
  status: visibleStatus(last(report), now), completedSources: last(report).evidence.length, totalSources: last(report).plan?.steps.length ?? 0 });

/** A checkpointed read-only investigation. Source owns authorization and facts;
 * model owns proposals. A worker advances one bounded phase per activity. */
export function createExecutiveReportService({ store, source, model, allowedSubjects, now = Date.now, leaseMs = 90_000, deadlineMs = 20 * 60_000 }) {
  if (!Array.isArray(allowedSubjects) || !allowedSubjects.length || new Set(allowedSubjects).size !== allowedSubjects.length) throw new Error('Configure explicit report participants.');
  allowedSubjects.forEach(reportSubject);
  function actor(auth) {
    if (auth?.authenticated !== true || auth.mode !== 'entra-delegated' || auth.claims?.tid !== EVERYAGENT_TENANT ||
        !allowedSubjects.includes(auth.claims?.oid)) throw hidden();
    return reportSubject(auth.claims.oid);
  }
  // One phase can inspect several saved turns. Deduplicate only within that
  // phase, then let the source authorize the batch against one current registry.
  // Nothing is retained across phases, reads, publication or user requests.
  async function authorizeRuns(subject, runs, scope = runs[0]?.scope) {
    if(!runs.length)return [];
    const unique=[], indexes=new Map();
    const groups=runs.map(run=>[null,...(run.plan?.steps ?? [])].map(step=>{
      const check={scope:step?.scope ?? run.scope,step}, key=reportHash({scope:check.scope,step:step?{capability:step.capability,input:step.input}:null});
      if(!indexes.has(key)){indexes.set(key,unique.length);unique.push(check);}
      return indexes.get(key);
    }));
    const grants=[];
    if(source.authorizeMany){
      for(let start=0;start<unique.length;start+=32){
        const batch=unique.slice(start,start+32), results=await source.authorizeMany(subject,batch,scope);
        if(!Array.isArray(results)||results.length!==batch.length)throw Error('Incomplete source authorization batch.');
        grants.push(...results);
      }
    } else {
      // In-process connectors retain the same check contract. HTTP sources use
      // the batch operation; this is not an error fallback for a denied batch.
      for(const check of unique){
        try{grants.push(await source.authorize(subject,check.scope,check.step));}
        catch(error){if(error && typeof error==='object' && 'statusCode' in error && [401,403,404].includes(Number(error.statusCode)))grants.push(null);else throw error;}
      }
    }
    return groups.map(group=>group.map(index=>grants[index]));
  }
  async function allowed(subject, run, verifyCollectedGrant = false, grants = null) {
    // Even a queued report rechecks the scope: knowing its identifier is no grant.
    try {
      const checked=grants ?? (await authorizeRuns(subject,[run]))[0];
      if (!checked[0]) throw hidden();
      for (const [index,step] of (run.plan?.steps ?? []).entries()) {
        const grant = checked[index+1];
        const evidence = run.evidence?.find(entry => entry.sourceId === step.id)?.value;
        if (!grant || evidence && (typeof evidence.requiresDetail !== 'boolean' ||
            evidence.requiresDetail && grant.detail !== true ||
            verifyCollectedGrant && grant.revision !== evidence.grantRevision)) throw hidden();
      }
    } catch (error) {
      if (error && typeof error === 'object' && 'statusCode' in error && [401,403,404].includes(Number(error.statusCode))) throw hidden();
      throw error;
    }
  }
  async function locate(subject, ownerId, id) {
    reportSubject(ownerId); reportId(id);
    const report = (await store.read(ownerId, id)).value;
    if (!report || report.tenantId !== EVERYAGENT_TENANT || !allowedSubjects.includes(ownerId) ||
        subject !== ownerId && !report.readers.includes(subject)) throw hidden();
    await allowed(subject, last(report)); return report;
  }
  async function conversationContext(ownerId, report, run) {
    const earlier=report.runs.slice(0,report.runs.indexOf(run));
    const grants=await authorizeRuns(ownerId,earlier,run.scope);
    const turns=await readInBatches(earlier,async item=>{
      try { await allowed(ownerId,item,false,grants[earlier.indexOf(item)]); }
      catch(error) { if(error && typeof error==='object' && 'statusCode' in error && error.statusCode===404)return null; throw error; }
      return {question:item.objective,scope:item.scope,status:item.status,answeredAt:item.artifact ? item.updatedAt : null,
        findings:item.artifact?.findings ?? [],gaps:item.artifact?.gaps ?? [],
        // A failed answer is still a user turn. Keep its actual query scope so
        // 'those months' cannot silently revert to the page's wider date range.
        reads:(item.plan?.steps ?? []).map(readDefinition)};
    });
    // Preserve every user question in the bounded conversation. Trim older
    // evidence context first; dropping a failed/old request loses pronouns,
    // corrections and the exact provenance of scenario assumptions.
    for (const turn of turns) {
      if (JSON.stringify(turns).length <= 20_000) break;
      turn.findings=[]; turn.gaps=[]; turn.reads=[];
    }
    return turns;
  }
  function newRun(requestId, objective, scope, previous, action = 'create') {
    const at = new Date(now()).toISOString();
    return { id: randomUUID(), requestId, requestHash: reportHash({ objective, scope }), objective, scope,
      createdAt: at, updatedAt: at, deadline: now() + deadlineMs, status: 'queued', plan: null,
      evidence: [], artifact: null, lease: null, error: null, model: null, modelCalls: 0, attempt: 0,
      // Follow-up context is saved evidence, not client-provided assistant text.
      previousVersion: previous ?? null, action };
  }
  async function create(auth, input) {
    const subject = actor(auth), v = validateReportCreate(input);
    reportSubject(v.requestId); reportText(v.objective);
    const scope = validateReportScope(v.scope), id = reportHash([subject, v.requestId]);
    await allowed(subject, { scope, plan: null });
    // Reserve discovery before saving work: an interrupted or full index must
    // never leave paid work running without an accessible report entry.
    if (!(await store.read(subject,id)).value) await store.reserveExecution(subject, reportHash(['create',id]), now());
    await store.index(subject, subject, id);
    const initial = newRun(v.requestId, v.objective, scope, null);
    const report = await store.update(subject, id, state => {
      if (state) {
        if (state.runs[0].requestHash !== initial.requestHash) throw conflict();
        return null;
      }
      return { schemaVersion: 1, revision: 0, id, ownerId: subject, tenantId: EVERYAGENT_TENANT,
        createdAt: initial.createdAt, readers: [], runs: [initial] };
    });
    // Retrying the same create repairs an interrupted index write.
    await store.index(subject, subject, id);
    await allowed(subject, last(report)); return summary(report);
  }
  async function get(auth, ownerId, id, version = null) {
    const subject = actor(auth), report = await locate(subject, ownerId, id);
    const n = version ?? report.runs.length;
    if (!Number.isSafeInteger(n) || n < 1 || n > report.runs.length) throw hidden();
    const run = report.runs[n - 1];
    // locate already checked this exact latest run. Historical selections need
    // their own scope and capability checks, in addition to current visibility.
    if (n !== report.runs.length) await allowed(subject, run);
    // Never expose leases, private traces, or earlier unselected versions.
    return { ...summary(report), selectedVersion: n, canEdit: subject === ownerId,
      scope: run.scope, objective: run.objective, status: visibleStatus(run, now()), error: run.error,
      artifact: run.artifact, view: run.view ?? null, readers: subject === ownerId ? report.readers : [], sourceProgress: run.evidence.map(e => ({ id: e.sourceId, title: e.value.title, status: e.value.status })),
      versions: report.runs.map((r, i) => ({ version: i + 1, createdAt: r.createdAt, status: r.status })) };
  }
  async function list(auth) {
    const subject = actor(auth), entries = (await store.read(subject, 'index')).value?.entries ?? [];
    const reports = await readInBatches(entries, async entry => {
      try { return summary(await locate(subject, entry.ownerId, entry.id)); }
      catch (error) { if (!(error && typeof error === 'object' && 'statusCode' in error && error.statusCode === 404)) throw error; return null; }
    });
    return reports.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  async function command(auth, input) {
    const subject = actor(auth), v = validateReportCommand(input);
    const report = await locate(subject, v.ownerId, v.id);
    if (subject !== report.ownerId) throw hidden();
    if (!['refresh', 'followup', 'resume', 'cancel', 'share', 'unshare'].includes(v.action)) throw createHttpError(400, 'report_action_invalid', 'Choose a report action.');
    let next = null;
    if (['refresh', 'followup'].includes(v.action)) {
      reportSubject(v.requestId);
      const current = last(report), objective = v.action === 'refresh' ? current.objective : reportText(v.objective),
        scope = v.action === 'refresh' ? current.scope : validateReportScope(v.scope);
      await allowed(subject, { scope, plan: null });
      next = newRun(v.requestId, objective, scope, report.runs.length, v.action);
      if (!report.runs.some(r => r.requestId === next.requestId)) await store.reserveExecution(subject, reportHash([v.id, next.requestId]), now());
    }
    if (['share', 'unshare'].includes(v.action)) {
      reportSubject(v.readerId);
      if (v.readerId === subject || !allowedSubjects.includes(v.readerId)) throw hidden();
      if (v.action === 'share') {
        for (const run of report.runs) await allowed(v.readerId, run);
      }
    }
    const updated = await store.update(subject, v.id, state => {
      if (!state) throw hidden();
      if (next) {
        const prior = state.runs.find(r => r.requestId === next.requestId);
        if (prior) { if (prior.requestHash !== next.requestHash) throw conflict(); return null; }
      }
      // An acknowledged share can be retried to repair an interrupted index
      // write. The authoritative ACL and recipient's grants were checked above.
      if (v.action === 'share' && state.readers.includes(v.readerId)) return null;
      if (v.action === 'unshare' && !state.readers.includes(v.readerId)) return null;
      if (state.revision !== v.revision) throw conflict();
      const run = last(state);
      if (next) {
        if (!REPORT_TERMINAL.has(run.status) || state.runs.length >= 12) throw conflict();
        state.runs.push(next);
      } else if (v.action === 'cancel') {
        if (REPORT_TERMINAL.has(run.status)) return null;
        run.status = 'cancelled'; run.lease = null;
      } else if (v.action === 'resume') {
        if (!['paused', 'failed'].includes(run.status) || run.attempt >= 3) throw conflict();
        run.status = run.plan ? 'reading' : 'queued'; run.error = null; run.failure = null; run.lease = null; run.deadline = now() + deadlineMs; run.attempt++;
      } else if (v.action === 'share') {
        if (!state.readers.includes(v.readerId)) state.readers.push(v.readerId);
      } else if (v.action === 'unshare') state.readers = state.readers.filter(id => id !== v.readerId);
      last(state).updatedAt = new Date(now()).toISOString(); return state;
    });
    if (v.action === 'share') await store.index(v.readerId, subject, v.id);
    return summary(updated);
  }
  async function pending() {
    const keys = [];
    for (const ownerId of allowedSubjects) {
      const entries = ((await store.read(ownerId, 'index')).value?.entries ?? []).filter(entry => entry.ownerId === ownerId);
      keys.push(...await readInBatches(entries, async entry => {
        const report = (await store.read(ownerId, entry.id)).value;
        return report && !REPORT_TERMINAL.has(last(report).status) ? { ownerId, id: entry.id, runId: last(report).id, attempt: last(report).attempt } : null;
      }));
    }
    return keys;
  }
  async function advance({ ownerId, id, runId = null, attempt = null }) {
    if (!allowedSubjects.includes(ownerId)) throw hidden();
    const leaseId = randomUUID();
    const claimed = await store.update(ownerId, id, state => {
      if (!state) throw hidden();
      const run = last(state);
      if (runId !== null && (run.id !== runId || run.attempt !== attempt)) return null;
      if (REPORT_TERMINAL.has(run.status) || run.lease?.until > now()) return null;
      if (run.deadline <= now()) { run.status = 'paused'; run.error = 'This investigation timed out. Resume to continue.'; run.lease = null; return state; }
      run.lease = { id: leaseId, until: now() + leaseMs }; return state;
    });
    const run = last(claimed);
    if (run.lease?.id !== leaseId) return { status: run.status, claimed: false };
    async function checkpoint(apply) {
      return store.update(ownerId, id, state => {
        const current = last(state);
        if (current.id !== run.id || current.lease?.id !== leaseId || REPORT_TERMINAL.has(current.status)) return null;
        if (current.lease.until <= now()) return null;
        apply(current); current.lease = null; current.updatedAt = new Date(now()).toISOString(); return state;
      });
    }
    async function retain(apply) {
      let retained = false;
      const state = await store.update(ownerId, id, state => {
        retained = false;
        const current = last(state);
        if (current.id !== run.id || current.lease?.id !== leaseId || current.lease.until <= now() || REPORT_TERMINAL.has(current.status)) return null;
        apply(current); current.updatedAt = new Date(now()).toISOString(); retained = true; return state;
      });
      if (!retained) throw conflict();
      Object.assign(run, last(state));
    }
    let phase = 'source';
    async function modelCall(call) {
      const token = randomUUID();
      if (!await store.claimModel(ownerId, token, now(), leaseMs)) throw createHttpError(429, 'report_model_busy', 'Report model work is queued.');
      try {
        let reserved = false;
        await store.update(ownerId, id, state => {
          reserved = false;
          const current = last(state);
          if (current.id !== run.id || current.lease?.id !== leaseId || current.lease.until <= now() || REPORT_TERMINAL.has(current.status)) return null;
          if ((current.modelCalls ?? 0) >= 4) {
            current.status = 'paused'; current.error = 'This version reached its model limit. Start a narrower investigation.'; current.lease = null; return state;
          }
          current.modelCalls = (current.modelCalls ?? 0) + 1;
          current.lease.until = now() + leaseMs; run.modelCalls = current.modelCalls; reserved = true; return state;
        });
        if (!reserved) throw createHttpError(409, 'report_model_obsolete', 'Report execution changed.');
        phase = 'model';
        const result = await call();
        phase = 'validation';
        return result;
      } finally { await store.releaseModel(token); }
    }
    try {
      // Advancing cached evidence requires the original, still-current grant.
      await allowed(ownerId, run, true);
      if (!run.plan) {
        const previous = run.previousVersion ? claimed.runs[run.previousVersion - 1] : null;
        const [prepared, conversation] = await Promise.all([
          (!previous || run.action === 'refresh') && source.prepare ? source.prepare(ownerId, run.scope) : source.catalog(ownerId, run.scope).then(catalog => ({ catalog, prepared: [] })), conversationContext(ownerId, claimed, run)
        ]);
        const { catalog } = prepared;
        // Follow-ups start in the same inspect/answer/read loop as prepared
        // snapshots. A formatting or arithmetic turn needs no separate planner.
        // Keep room for four new queries; larger prior investigations use the
        // normal planner so their old reads cannot exhaust the next turn.
        if (run.action === 'followup' && source.prepare && previous?.artifact && previous.plan?.steps.length <= 2 && reportHash(previous.scope) === reportHash(run.scope)) {
          await allowed(ownerId, previous, true);
          const plan=validateReportPlan({steps:previous.plan.steps.map(readDefinition),gaps:[]},catalog);
          return summary(await checkpoint(current=>{current.plan=plan;current.evidence=structuredClone(previous.evidence);current.reusedFromVersion=run.previousVersion;current.status='analyzing';}));
        }
        if (prepared.prepared.length) {
          const plan = validateReportPlan({ steps: prepared.prepared.map(({step}) => ({ capability: step.capability, input: step.input })), gaps: [] }, catalog);
          const evidence = plan.steps.map((step, index) => ({ sourceId: step.id, value: validateReportEvidence(prepared.prepared[index].value, step, run.scope) }));
          if (evidence.some(item => item.value.status !== 'verified' || item.value.coverage !== 'complete')) throw Error('Prepared facts are incomplete.');
          await allowed(ownerId, { ...run, plan, evidence }, true);
          return summary(await checkpoint(current => { current.plan = plan; current.evidence = evidence; current.preparedSnapshot = true; current.status = 'analyzing'; }));
        }
        if (model.investigate) {
          const plan = validateReportPlan({ steps: [], gaps: [] }, catalog);
          return summary(await checkpoint(current => { current.plan = plan; current.status = 'analyzing'; }));
        }
        const proposed = await modelCall(() => model.plan({ objective: run.objective, scope: run.scope, catalog,conversation,
          previous: previous ? { objective: previous.objective, scope: previous.scope, findings: previous.artifact?.findings ?? [], evidence:previous.evidence.map(e=>({sourceId:e.sourceId,title:e.value.title,period:e.value.period,observedAt:e.value.observedAt,status:e.value.status})) } : null }));
        if(proposed.reusePreviousEvidence === true) {
          if(run.action !== 'followup' || !previous?.artifact || !previous.plan || proposed.plan.steps.length || reportHash(previous.scope)!==reportHash(run.scope)) throw Error('Saved evidence cannot answer this scope.');
          await allowed(ownerId,previous,true);
          const plan=validateReportPlan({steps:previous.plan.steps.map(readDefinition),gaps:previous.plan.gaps},catalog);
          return summary(await checkpoint(current=>{current.plan=plan;current.evidence=structuredClone(previous.evidence);current.reusedFromVersion=run.previousVersion;current.model=proposed.metadata??null;current.status='analyzing';}));
        }
        const plan = validateReportPlan(proposed.plan, catalog);
        await allowed(ownerId, { ...run, plan });
        return summary(await checkpoint(current => { current.plan = plan; current.model = proposed.metadata ?? null; current.status = 'reading'; }));
      }
      const steps = run.plan.steps.slice(run.evidence.length, run.evidence.length + 3);
      if (steps.length) {
        // Plan inputs are independent, validated source queries. Join at most
        // three; all values and current grants must pass before checkpointing.
        const collected = await Promise.all(steps.map(async step => {
          const value = validateReportEvidence(await source.read(ownerId, step.scope ?? run.scope, step), step, run.scope);
          const grant = await source.authorize(ownerId, step.scope ?? run.scope, step);
          if (!grant || grant.revision !== value.grantRevision || value.requiresDetail && grant.detail !== true) throw hidden();
          return { sourceId: step.id, value };
        }));
        await allowed(ownerId, { ...run, evidence: [...run.evidence, ...collected] }, true);
        return summary(await checkpoint(current => {
          current.evidence.push(...collected);
          current.status = current.evidence.length === current.plan.steps.length ? 'analyzing' : 'reading';
        }));
      }
      let viewContext = reportViewContext(run.evidence, reportHash(run.scope), run.objective);
      const [catalog, conversation] = await Promise.all([
        source.catalog(ownerId, run.scope), conversationContext(ownerId, claimed, run)
      ]);
      const context = { objective: run.objective, scope: run.scope,
        evidence:run.evidence.map(e=>({...e,value:Object.fromEntries(Object.entries(e.value).filter(([key])=>key!=='dataset'))})),
        views: viewContext,catalog,conversation,
        remainingReads:6-run.plan.steps.length,remainingInvestigations:Math.max(0,3-(run.modelCalls??0)),
        evidenceReused:run.reusedFromVersion!==undefined, preparedSnapshot:run.preparedSnapshot === true,
        ...(run.validationRepair ? {validationRepair:run.validationRepair} : {}) };
      const previous = run.previousVersion ? claimed.runs[run.previousVersion - 1] : null;
      if (previous) await allowed(ownerId, previous);
      const cachePlanHash = reportHash(run.plan);
      const cacheKey = model?.cacheIdentity ? reportHash({ policy: REPORT_CACHE_VERSION, tenant: EVERYAGENT_TENANT, ownerId,
        model: model.cacheIdentity, context, plan: run.plan,
        previous: previous ? { objective: previous.objective, scope: previous.scope, findings: previous.artifact?.findings ?? [] } : null }) : null;
      const userStatements=[...conversation.map(turn=>turn.question),run.objective];
      let cached = cacheKey ? await store.cachedSynthesis(ownerId, cacheKey, now()) : null;
      if (cached) {
        const checked = validateCitedReportFindings(cached.proposal, run.evidence, userStatements);
        try { reportViewPlan(cached.proposal.views, viewContext); }
        catch { cached = null; }
        if (!checked || checked.rejectedCount) cached = null;
      }
      const reportAuth = { authenticated: true, mode: 'entra-delegated', claims: { tid: EVERYAGENT_TENANT, oid: ownerId } };
      const synthesis = cached?.proposal ?? (model.investigate ? await model.investigate(context, {
        modelCall, remainingModelCalls: 4 - (run.modelCalls ?? 0),
        read: async reads => {
          phase = 'source';
          const existing = run.plan.steps.map(readDefinition);
          const seen = new Set(existing.map(reportHash));
          const fresh = reads.map(read => read.scope && reportHash(read.scope) === reportHash(run.scope) ? { capability: read.capability, input: read.input } : read)
            .filter(read => { const key = reportHash(read); if (seen.has(key)) return false; seen.add(key); return true; });
          let plan;
          try { plan = validateReportPlan({ steps: [...existing, ...fresh], gaps: run.plan.gaps }, catalog); }
          catch { return { error: 'Use registered capabilities and valid query objects within the remaining read budget.', remainingReads: 6 - existing.length }; }
          await allowed(ownerId, { ...run, plan }, true);
          await retain(current => { current.plan = plan; });
          const pending = plan.steps.slice(run.evidence.length);
          const collected = await readInBatches(pending, async step => {
            const value = validateReportEvidence(await source.read(ownerId, step.scope ?? run.scope, step), step, run.scope);
            return { sourceId: step.id, value };
          });
          await allowed(ownerId, { ...run, evidence: [...run.evidence, ...collected] }, true);
          await retain(current => { current.evidence.push(...collected); });
          viewContext = reportViewContext(run.evidence, reportHash(run.scope), run.objective);
          return { evidence: run.evidence.map(e => ({ ...e, value: Object.fromEntries(Object.entries(e.value).filter(([key]) => key !== 'dataset')) })), views: viewContext, remainingReads: 6 - run.plan.steps.length };
        },
        findReports: async query => {
          await retain(() => {});
          const words = reportText(query, 200).toLowerCase().split(/\s+/).filter(Boolean);
          const reports = await list(reportAuth);
          return reports.filter(report => report.id !== id && words.every(word => report.title.toLowerCase().includes(word))).slice(0, 10);
        },
        openReport: async ({ ownerId: savedOwner, reportId: savedId, version }) => {
          await retain(() => {});
          const report = await get(reportAuth, savedOwner, savedId, version);
          return { id: report.id, version: report.selectedVersion, objective: report.objective, scope: report.scope,
            status: report.status, findings: report.artifact?.findings ?? [], gaps: report.artifact?.gaps ?? [],
            notice: 'Saved report context. Query the source again to establish current facts or a different cohort.' };
        }
      }) : await modelCall(() => model.synthesize(context)));
      if(synthesis.additionalReads?.length) {
        if(!context.remainingInvestigations || synthesis.additionalReads.length>context.remainingReads) throw Error('Investigation limit reached.');
        const plan=validateReportPlan({steps:[...run.plan.steps.map(readDefinition),...synthesis.additionalReads],gaps:run.plan.gaps},catalog);
        await allowed(ownerId,{...run,plan},true);
        return summary(await checkpoint(current=>{current.plan=plan;current.investigationModels=[...(current.investigationModels??[]),synthesis.metadata??null];current.status='reading';}));
      }
      const inspection = inspectCitedReportFindings(synthesis, run.evidence, userStatements);
      const verified = inspection.result;
      if(synthesis.unanswered!==undefined && (!Array.isArray(synthesis.unanswered) || synthesis.unanswered.length>8))throw Error('Invalid answer coverage.');
      let view, validView = true;
      try { view = reportViewPlan(synthesis.views, viewContext); }
      catch { validView = false; view = reportViewPlan(null, viewContext); }
      // Repair the proof once within the same paid-call budget. A failed
      // proposal is not an answer or conversational evidence, and cannot be
      // published unless the normal source and arithmetic checks pass again.
      if ((inspection.issues.length || !validView) && !run.validationRepair && (run.modelCalls ?? 0) < 4) {
        await allowed(ownerId,run,true);
        return summary(await checkpoint(current=>{
          current.validationRepair={proposal:{findings:synthesis.findings ?? [],views:synthesis.views ?? null},issues:[...inspection.issues,...(!validView?[{index:-1,reason:'The view cannot bind to the authorized dataset/columns. Use the supplied view descriptors and computed-column contract.'}]:[])]};
          current.status='analyzing';
        }));
      }
      const used=new Set([...(verified?.findings.flatMap(f=>f.sourceIds)??[]),...(view?.blocks??[]).map(block=>block.datasetId)]);
      const selectedEvidence=verified && synthesis.unanswered!==undefined ? run.evidence.filter(e=>used.has(e.sourceId)) : run.evidence;
      const gaps = [...(synthesis.unanswered?.map(gap=>reportText(gap,400)) ?? run.plan.gaps), ...selectedEvidence.filter(e => e.value.coverage === 'partial').map(e => `${e.value.title}: ${e.value.note}`), ...(verified?.rejectedCount ? [`${verified.rejectedCount} unsupported findings withheld.`] : []),
        ...(!verified ? ['No analytical finding passed evidence checks. The source results remain available.'] : [])];
      if (!validView) gaps.push('The requested visualization could not be verified. Exact source tables are shown.');
      const artifact = buildReportDocument({ id: `${id}-${claimed.runs.length}`, title: run.objective,
        generatedAt: new Date(now()).toISOString(), filename: 'Ally report.html',
        sections: selectedEvidence.map(e => ({ id: e.sourceId, ...e.value })), gaps, findings: verified?.findings ?? [] });
      // The model call can outlive a grant revision. A still-authorized query
      // does not prove that evidence collected under the old grant is current.
      await allowed(ownerId, run, true);
      return summary(await checkpoint(current => {
        current.artifact = artifact; current.view = view;
        current.synthesisModel = cached ? { cacheHit: true, sourceReportId: cached.reportId, sourceRunId: cached.runId, inputTokens: 0, outputTokens: 0, latencyMs: 0 } : synthesis.metadata ?? null;
        current.status = artifact.coverage === 'partial' ? 'partial' : 'ready';
        if (!cached && cacheKey && reportHash(run.plan) === cachePlanHash && current.status === 'ready' && verified && !verified.rejectedCount && validView &&
            !run.plan.gaps.length && run.evidence.every(e => e.value.status === 'verified' && e.value.coverage !== 'partial')) {
          current.synthesisCache = { key: cacheKey, proposal: { findings: synthesis.findings, views: synthesis.views ?? null,...(synthesis.unanswered!==undefined?{unanswered:synthesis.unanswered}:{}) }, createdAt: now() };
        }
      }));
    } catch (error) {
      if (error && typeof error === 'object' && 'code' in error && error.code === 'report_model_busy') {
        const result = await checkpoint(() => {});
        return { ...summary(result), claimed: false };
      }
      const statusCode = error && typeof error === 'object' && 'statusCode' in error ? Number(error.statusCode) : null;
      const access = error && typeof error === 'object' && 'statusCode' in error && [401, 403, 404].includes(Number(error.statusCode));
      return summary(await checkpoint(current => {
        // Persist only a bounded diagnostic category, never provider/source bodies.
        current.failure = { phase, statusCode: statusCode !== null && Number.isInteger(statusCode) && statusCode >= 400 && statusCode <= 599 ? statusCode : null };
        current.status = 'paused'; current.error = error && typeof error === 'object' && 'code' in error && error.code === 'report_credit_limit' ? 'The prepaid Ally allowance is exhausted or expired. Saved reports remain available.' : error && typeof error === 'object' && 'code' in error && error.code === 'report_spend_limit' ? 'The daily Ally model budget is reached. Saved reports remain available; resume tomorrow.' : access ? 'Source access changed. Refresh the report after access is restored.' : phase === 'source' ? 'Platform data could not be read. Resume to retry.' : phase === 'model' ? 'The model could not complete this answer. Resume to retry.' : 'The answer could not be verified. Resume to retry.';
      }));
    }
  }
  async function pause({ ownerId, id, runId, attempt }) {
    if (!allowedSubjects.includes(ownerId)) throw hidden();
    await store.update(ownerId, id, state => {
      if (!state) return null;
      const run = last(state);
      if (run.id !== runId || run.attempt !== attempt || REPORT_TERMINAL.has(run.status)) return null;
      run.status = 'paused'; run.error = 'The report worker was interrupted. Resume to continue.'; run.lease = null; return state;
    });
  }
  return { create, get, list, command, pending, advance, pause };
}
