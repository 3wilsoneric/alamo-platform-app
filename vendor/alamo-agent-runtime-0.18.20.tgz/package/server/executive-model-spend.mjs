import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {EVERYAGENT_TENANT} from '../shared/everyagent-identity.mjs';
import {executiveModelCost,executiveModelPricing} from '../shared/executive-model-cost.mjs';
import {reportObject} from '../shared/executive-report-contracts.mjs';
import {createHttpError} from './http-error-contract.mjs';

// One shared, durable allowance. Existing UTC-day ledgers stay readable; a
// prepaid allowance never resets at midnight. No prompts are stored.
export function createExecutiveModelSpend({store,limitMicrodollars=/** @type {number | undefined} */ (undefined),creditAllowance=/** @type {{id:string;limitMicrodollars:number;validFrom:string;expiresAt:string} | null} */ (null),now=Date.now}) {
  if (creditAllowance) {
    reportObject(creditAllowance,['id','limitMicrodollars','validFrom','expiresAt']);
    assert(limitMicrodollars===undefined && /^credits-20\d{6}$/.test(creditAllowance.id),'Choose one authorized report allowance.');
    assert(Number.isSafeInteger(creditAllowance.limitMicrodollars) && creditAllowance.limitMicrodollars>0);
    assert(Number.isFinite(Date.parse(creditAllowance.validFrom)) && Date.parse(creditAllowance.expiresAt)>Date.parse(creditAllowance.validFrom));
    creditAllowance=Object.freeze({...creditAllowance});
  } else assert(typeof limitMicrodollars==='number' && Number.isSafeInteger(limitMicrodollars) && limitMicrodollars > 0 && limitMicrodollars <= 500000,'Configure the authorized daily report budget.');
  const ceiling=creditAllowance?.limitMicrodollars??limitMicrodollars;
  assert(typeof ceiling==='number');
  return {
    async reserve(inputTokens,maxOutputTokens) {
      const time=now(),at=new Date(time).toISOString(),id=creditAllowance?.id??'spend-'+at.slice(0,10),token=randomUUID();
      const denied=()=>createHttpError(429,creditAllowance?'report_credit_limit':'report_spend_limit',creditAllowance?'The prepaid Ally allowance is exhausted or expired. Saved reports remain available.':'The daily Ally model budget is reached. Saved reports remain available.');
      if(creditAllowance && (time<Date.parse(creditAllowance.validFrom)||time>=Date.parse(creditAllowance.expiresAt)))throw denied();
      const reserved=executiveModelCost(inputTokens+256,maxOutputTokens);
      await store.update(EVERYAGENT_TENANT,id,state=>{
        state??={schemaVersion:1,revision:0,ownerId:EVERYAGENT_TENANT,id,pricing:executiveModelPricing,...(creditAllowance?{creditAllowance}:{}),requests:[]};
        assert.deepEqual(state.pricing,executiveModelPricing);
        if(creditAllowance)assert.deepEqual(state.creditAllowance,creditAllowance);
        const used=state.requests.reduce((sum,r)=>sum+(r.actualMicrodollars??r.reservedMicrodollars),0);
        if(used+reserved>ceiling || state.requests.length>=(creditAllowance?20000:1000))throw denied();
        state.requests.push({token,at,inputTokens,maxOutputTokens,reservedMicrodollars:reserved,actualMicrodollars:null});return state;
      });
      // Only a verified usage receipt releases the unused reservation. Network,
      // storage and ambiguous provider failures retain the full reservation.
      return async usage=>{
        assert(Number.isSafeInteger(usage?.input_tokens)&&usage.input_tokens>=0&&usage.input_tokens<=inputTokens+256);
        assert(Number.isSafeInteger(usage?.output_tokens)&&usage.output_tokens>=0&&usage.output_tokens<=maxOutputTokens);
        const actual=executiveModelCost(usage.input_tokens,usage.output_tokens);
        await store.update(EVERYAGENT_TENANT,id,state=>{
          assert(state);const entry=state.requests.find(r=>r.token===token);assert(entry);
          if(entry.actualMicrodollars!==null){assert.equal(entry.actualMicrodollars,actual);return null;}
          entry.actualMicrodollars=actual;return state;
        });
      };
    }
  };
}

// Counting includes instructions and the function schema. It generates no text.
export async function countExecutiveModelInput({request,headers,fetchImpl}) {
  assert.equal(request.model,executiveModelPricing.model);
  const response=await fetchImpl('https://api.openai.com/v1/responses/input_tokens',{
    method:'POST',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(10000),headers,
    body:JSON.stringify({model:request.model,instructions:request.instructions,input:request.input,tools:request.tools,tool_choice:request.tool_choice,parallel_tool_calls:false})
  });
  const chunks=[];let size=0;
  try {
    if(!response.ok)throw Error('Model token count unavailable.');
    for await(const chunk of response.body??[]){size+=chunk.length;assert(size<=4096);chunks.push(Buffer.from(chunk));}
    const result=JSON.parse(Buffer.concat(chunks).toString('utf8'));
    assert.equal(result.object,'response.input_tokens');
    assert(Number.isSafeInteger(result.input_tokens)&&result.input_tokens>=0&&result.input_tokens<=200000);
    return result.input_tokens;
  } finally {await response.body?.cancel().catch(()=>{});}
}
