import { createSourceTransport } from './everyagent-source-client.mjs';
import { EXECUTIVE_REPORT_SOURCE_PATH, reportSubject, reportId, reportJson, reportHash, validateReportScope } from '../shared/executive-report-contracts.mjs';

export function createExecutiveReportSource({ origin, getToken, fetchImpl = fetch, now = Date.now }) {
  const transport = createSourceTransport({ origin, getToken, fetchImpl, now, endpoint: EXECUTIVE_REPORT_SOURCE_PATH, maximumBytes: 200_000, timeoutMs: 40_000 });
  async function request(operation, subjectId, scope, step = null, checks = /** @type {any[] | undefined} */ (undefined)) {
    reportSubject(subjectId); validateReportScope(scope);
    // Per-query scope belongs in the source request's existing scope envelope.
    // Do not introduce a second, potentially conflicting scope in the wire step.
    const wireStep = (selected, selectedScope) => {
      if (!selected) return null;
      if (selected.scope && reportHash(validateReportScope(selected.scope)) !== reportHash(selectedScope)) throw Error('Source query scope mismatch.');
      return { id: selected.id, capability: selected.capability, input: selected.input };
    };
    const input = { version: 1, operation, subjectId, scope, step: wireStep(step, scope),
      ...(checks ? {checks: checks.map(check => ({scope: check.scope, step: wireStep(check.step, check.scope)}))} : {}) };
    const result = await transport(input);
    if (result.version !== 1 || result.requestHash !== reportHash(input) || result.subjectId !== subjectId || !result.grant || typeof result.grant.detail !== 'boolean' ||
        Date.parse(result.grant.expiresAt) <= now() || !Number.isFinite(Date.parse(result.grant.expiresAt))) throw new Error('Report source authority could not be verified.');
    reportId(result.grant.revision); reportJson(result, 200_000);
    return result;
  }
  return {
    async authorize(subject, scope, step) { return (await request('authorize', subject, scope, step)).grant; },
    async authorizeMany(subject, checks, scope = checks[0]?.scope) {
      if (!Array.isArray(checks) || !checks.length || checks.length > 32) throw Error('Choose a bounded authorization batch.');
      for(const check of checks){ validateReportScope(check.scope); reportJson(check,9000); }
      const batches=[];let batch=[];
      for(const check of checks){
        if(batch.length && Buffer.byteLength(JSON.stringify([...batch,check]),'utf8')>12_000){batches.push(batch);batch=[];}
        batch.push(check);
      }
      if(batch.length)batches.push(batch);
      const grants=[];
      for(const selected of batches){
        const result=await request('authorize-batch',subject,scope,null,selected);
        if(!Array.isArray(result.grants) || result.grants.length!==selected.length || result.grants.some(grant=>grant!==null &&
          (grant.revision!==result.grant.revision || grant.expiresAt!==result.grant.expiresAt || grant.detail!==result.grant.detail)))throw Error('Report source batch authority could not be verified.');
        grants.push(...result.grants);
      }
      return grants;
    },
    async prepare(subject, scope) {
      const result = await request('prepare', subject, scope);
      validateCatalog(result.catalog);
      if (!Array.isArray(result.prepared) || result.prepared.length > 2 || result.prepared.some(item => item.value?.grantRevision !== result.grant.revision)) throw new Error('Prepared source authority could not be verified.');
      return { catalog: result.catalog, prepared: result.prepared };
    },
    async catalog(subject, scope) {
      const result = await request('catalog', subject, scope);
      validateCatalog(result.catalog);
      return result.catalog;
    },
    async read(subject, scope, step) { const result = await request('read', subject, scope, step); if (result.evidence?.grantRevision !== result.grant.revision) throw new Error('Report source grant changed.'); return result.evidence; }
  };
}
function validateCatalog(catalog) {
  if (!Array.isArray(catalog) || !catalog.length || catalog.length > 40 || new Set(catalog.map(c => c.id)).size !== catalog.length ||
      catalog.some(c => !/^[a-z][a-z0-9-]{0,79}$/.test(c.id) || typeof c.title !== 'string' || !c.inputSchema)) throw new Error('Report source catalog is unavailable.');
}
