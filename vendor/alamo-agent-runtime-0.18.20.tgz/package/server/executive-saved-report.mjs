import { reportHash, reportObject, reportSubject, reportId, validateReportEvidence } from '../shared/executive-report-contracts.mjs';

// A frozen report is evidence of what that report said, not a current source
// observation. The service rechecks both the report ACL and its source grants.
export function savedReportEvidence(report, version) {
  const prior=report.runs[version-1];
  if(!prior?.artifact || !['ready','partial'].includes(prior.status))throw Error('Choose a completed saved report version.');
  const reference={ownerId:report.ownerId,reportId:report.id,version};
  const answer=JSON.stringify({id:report.id,ownerId:report.ownerId,version,objective:prior.objective,scope:prior.scope,
    createdAt:prior.createdAt,status:prior.status,findings:prior.artifact.findings,gaps:prior.artifact.gaps,
    href:`https://www.alamoplatform.com/admissions?allyReport=${report.ownerId}/${report.id}&allyVersion=${version}`});
  if(Buffer.byteLength(answer)>16_000)throw Error('This saved version is too large to quote in one read; open its report link for the complete document.');
  const revision=reportHash({reference,answer}),sourceId=`report-${reportHash(reference).slice(0,12)}`;
  const value=validateReportEvidence({capability:'saved-report',inputHash:reportHash(reference),scope:prior.scope,revision,
    grantRevision:reportHash(prior.evidence.map(e=>e.value.grantRevision)),requiresDetail:prior.evidence.some(e=>e.value.requiresDetail),
    observedAt:prior.artifact.generatedAt,period:'Saved report version; original scope is retained',grain:'Historical answer, not current source data',
    status:'verified',coverage:'complete',title:prior.objective.slice(0,240),answer,
    note:'Evidence of this saved version only. Its findings retain their original source dates and limitations; read current sources for new facts.'},
  {capability:'saved-report',input:reference},prior.scope);
  return {sourceId,reference,value};
}

export function validateSavedReportEvidence(item) {
  reportObject(item,['sourceId','reference','value']);
  reportObject(item.reference,['ownerId','reportId','version']);
  reportSubject(item.reference.ownerId);reportId(item.reference.reportId);
  if(!Number.isSafeInteger(item.reference.version)||item.reference.version<1||item.reference.version>12 ||
      item.sourceId!==`report-${reportHash(item.reference).slice(0,12)}` ||
      item.value.revision!==reportHash({reference:item.reference,answer:item.value.answer}))throw Error('Invalid saved report evidence.');
  validateReportEvidence(item.value,{capability:'saved-report',input:item.reference},item.value.scope);
}
