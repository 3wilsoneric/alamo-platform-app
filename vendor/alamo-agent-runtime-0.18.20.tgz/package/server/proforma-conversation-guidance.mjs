import { createHttpError } from './http-error-contract.mjs';
import { maintenanceHash as hash } from '../shared/proforma-maintenance-contracts.mjs';
import { proformaSourceFailure } from './proforma-source-transport.mjs';

export const PROFORMA_CONVERSATION_SKILL = 'proforma-guidance';
const denied = () => createHttpError(403, 'conversation_source_unavailable', 'This chat’s guidance changed or is no longer available. Start a new chat to read the current source.');
const hasScope = chat => chat.scope.some(scope => scope.skillId === PROFORMA_CONVERSATION_SKILL);
const reference = value => ({ sourceBindingId: value.sourceBindingId, source: value.source });
const unavailable = error => {
  const failure = proformaSourceFailure(error);
  // Only trusted transport failures can mean temporary unavailability. A denied
  // or changed source still fails closed, even if its response was malformed.
  if (failure && (failure.status === undefined || failure.status === 429 || failure.status >= 500)
    && ['timeout', 'network', 'http', 'response'].includes(failure.reason)) {
    return createHttpError(503, 'conversation_source_temporarily_unavailable',
      'The source check is temporarily unavailable. Try opening this saved chat again.');
  }
  return denied();
};

// Request-scoped source tools. User assertions live in the delegated identity
// adapter, never in transcripts, model context or saved source receipts.
export function createConversationGuidance(guidance) {
  const inFlight = new WeakMap();
  function check(auth, receipt) {
    let checks = inFlight.get(auth);
    if (!checks) { checks = new Map(); inFlight.set(auth, checks); }
    const key = hash(receipt);
    if (!checks.has(key)) {
      const requestChecks = checks;
      const pending = Promise.resolve().then(() => guidance.command(auth, { action: 'read', ...receipt }))
        .catch(error => { throw unavailable(error); })
        .finally(() => {
          requestChecks.delete(key);
          if (!requestChecks.size) inFlight.delete(auth);
        });
      checks.set(key, pending);
    }
    return checks.get(key);
  }
  async function recheck(auth, receipts) {
    if (!guidance) throw denied();
    const unique = [...new Map(receipts.map(value => [hash(reference(value)), reference(value)])).values()];
    if (unique.length > 120) throw denied();
    for (let start = 0; start < unique.length; start += 3) {
      // The host creates a distinct auth object for each HTTP request. Share only
      // simultaneous exact-source checks within it; never cache source authority
      // across requests or reuse a completed check after model generation.
      await Promise.all(unique.slice(start, start + 3).map(receipt => check(auth, receipt)));
    }
  }
  async function authorize(auth, chat) {
    if (!hasScope(chat)) return;
    if (!guidance || !(await guidance.describe(auth)).connections.length) throw denied();
    await recheck(auth, chat.turns.flatMap(turn => turn.guidanceReceipts ?? []));
  }
  function session(auth, chat, evidence, saveReceipts) {
    if (!hasScope(chat) || !guidance) return null;
    const matches = new Map(), receipts = [], evidenceByGuide = new Map();
    let searches = 0, reads = 0;
    return {
      async find(query) {
        if (++searches > 2 || typeof query !== 'string' || query.length > 500) throw new Error('Guidance search limit reached.');
        const connections = (await guidance.describe(auth)).connections;
        if (!connections.length || connections.length > 5) throw denied();
        const results = await Promise.all(connections.map(async connection => {
          const { result } = await guidance.command(auth, { action: 'find', sourceBindingId: connection.id, query, limit: 5 });
          for (const document of result.documents) {
            const item = { sourceBindingId: connection.id, source: document.source, document };
            matches.set(hash(reference(item)), item);
          }
          return { connectionId: connection.id, matchedCount: result.matchedCount, limited: result.limited,
            unavailableCount: result.unavailableDocumentIds.length,
            guides: result.documents.map(document => ({ guideId: hash({ sourceBindingId: connection.id, source: document.source }),
              title: document.title, kind: document.kind, publicationRevision: document.publicationRevision })) };
        }));
        return { results, instruction: 'Read selected guide IDs before answering from their content. Unavailable or unmatched guidance is not evidence of policy.' };
      },
      async read(guideIds) {
        if (!Array.isArray(guideIds) || !guideIds.length || guideIds.length > 3 || reads + guideIds.length > 3 || new Set(guideIds).size !== guideIds.length) throw new Error('Choose up to three discovered guides.');
        reads += guideIds.length;
        const output = [];
        for (const guideId of guideIds) {
          const match = matches.get(guideId); if (!match) throw new Error('Read a guide returned by this turn’s search.');
          if (evidenceByGuide.has(guideId)) { output.push(evidenceByGuide.get(guideId)); continue; }
          const { result } = await guidance.command(auth, { action: 'read', ...reference(match) });
          const { content, source } = result.definition;
          const full = JSON.stringify({ title: content.title, kind: content.kind, audience: content.audience, purpose: content.purpose,
            sourceReference: content.sourceReference, body: content.body, ...(content.sop ? { sop: content.sop } : {}) });
          const clipped = full.length > 16000;
          const item = { id: `g${evidenceByGuide.size + 1}`, skillId: PROFORMA_CONVERSATION_SKILL, title: content.title,
            text: `Published guide; publication revision ${source.publicationRevision}. ${clipped ? 'Partial excerpt; do not claim complete coverage. ' : ''}${full.slice(0, 16000)}`,
            observedAt: new Date().toISOString(),
            links: [{ id: source.publicationId, kind: 'procedure', label: content.title,
              href: `https://www.alamoplatform.com${match.document.view.href}`, observedAt: new Date().toISOString() }] };
          const receipt = reference(match); receipts.push(receipt);
          // Retain the authority reference before a model can receive the text.
          await saveReceipts(structuredClone(receipts));
          evidence.push(item); evidenceByGuide.set(guideId, item); output.push(item);
        }
        return { evidence: output };
      },
      recheck: () => recheck(auth, receipts),
    };
  }
  return { authorize, session };
}
