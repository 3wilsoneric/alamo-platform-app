import { PROFORMA_MAINTENANCE_PATH, validateMaintenanceSession } from '../shared/proforma-maintenance-contracts.mjs';

const operations = new Set(['identity', 'session', 'discovery', 'read', 'source']);
const reasons = new Set(['identity', 'authorization', 'timeout', 'network', 'http', 'response']);
class ProFormaSourceError extends Error {
  constructor(operation, reason, elapsedMs, status) {
    super(reason === 'identity' ? 'ProForma sign-in is unavailable.' : 'ProForma source access failed.');
    this.code = `proforma_source_${reason}`;
    this.status = status;
    this.statusCode = /** @type {number | undefined} */ (undefined);
    this.diagnostic = Object.freeze({
      operation: operations.has(operation) ? operation : 'source',
      reason: reasons.has(reason) ? reason : 'response',
      elapsedMs: Math.max(0, Math.min(300000, Math.round(elapsedMs) || 0)),
      ...(Number.isInteger(status) && status >= 400 && status <= 599 ? { status } : {}),
    });
  }
}

// Never retain upstream messages, URLs, bodies, headers, assertions or claims.
// Only errors constructed here may contribute private diagnostics.
export function proformaSourceFailure(error) {
  return error instanceof ProFormaSourceError ? { ...error.diagnostic } : null;
}

// Shared delegated transport for ProForma source contracts; bindings never grant access.
export function createProFormaSourceTransport({ binding, getToken, fetchImpl = fetch, now = Date.now,
  onFailure = diagnostic => console.warn(JSON.stringify({ event: 'proforma_source_failure', ...diagnostic })) }) {
  const origin = new URL(binding.origin);
  if (typeof getToken !== 'function') throw new Error('A delegated ProForma token provider is required.');
  function failure(operation, reason, started, status = /** @type {number | undefined} */ (undefined)) {
    const error = new ProFormaSourceError(operation, reason, now() - started, status);
    try { onFailure(error.diagnostic); } catch { /* Logging cannot change source authority. */ }
    return error;
  }
  function validated(operation, validate) {
    const started = now();
    try { return validate(); } catch { throw failure(operation, 'response', started); }
  }
  /** @param {string} token @param {string} suffix @param {Record<string, any> | null} [command] */
  async function request(token, suffix, command = null) {
    const started = now(), operation = suffix === '/session' ? 'session' : suffix === '/processes/guidance' ? 'discovery' : suffix.startsWith('/processes/handoff?') ? 'read' : 'source';
    const signal = AbortSignal.timeout(12000);
    let response;
    try {
      response = await fetchImpl(new URL(PROFORMA_MAINTENANCE_PATH + suffix, origin), {
        method: command ? 'POST' : 'GET', redirect: 'error', cache: 'no-store', signal,
        headers: { Authorization: `Bearer ${token}`, ...(command ? { 'Content-Type': 'application/json' } : {}) }, ...(command ? { body: JSON.stringify(command) } : {}),
      });
    } catch (error) {
      throw failure(operation, signal.aborted || (error instanceof Error && error.name === 'TimeoutError') ? 'timeout' : 'network', started);
    }
    try {
      const limit = suffix.includes('/commands') || suffix === '/session' ? 16000 : 524288;
      if (!/^application\/json\b/i.test(response.headers.get('content-type') ?? '') || Number(response.headers.get('content-length')) > limit) throw new Error('Invalid ProForma response.');
      const chunks = []; let size = 0;
      for await (const bytes of response.body ?? []) { size += bytes.length; if (size > limit) throw new Error('ProForma response exceeded its limit.'); chunks.push(Buffer.from(bytes)); }
      const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (!response.ok) {
        const error = failure(operation, 'http', started, response.status);
        // Existing command recovery relies on source conflict/missing codes.
        error.code = typeof data.error?.code === 'string' ? data.error.code : 'source_unavailable';
        throw error;
      }
      return data;
    } catch (error) {
      if (error instanceof ProFormaSourceError) throw error;
      throw failure(operation, signal.aborted ? 'timeout' : 'response', started, response.ok ? undefined : response.status);
    } finally { await response.body?.cancel().catch(() => {}); }
  }
  async function authorized(permission) {
    const started = now(); let value;
    try { value = await getToken(); } catch (cause) {
      const error = failure('identity', 'identity', started);
      if (cause && typeof cause === 'object' && 'statusCode' in cause && typeof cause.statusCode === 'number' && Number.isInteger(cause.statusCode) && cause.statusCode >= 400 && cause.statusCode <= 599) error.statusCode = cause.statusCode;
      throw error;
    }
    if (!value || typeof value.token !== 'string' || !value.token || value.token.length > 16000 || !Number.isFinite(value.expiresOnTimestamp) || value.expiresOnTimestamp <= now()) throw failure('identity', 'identity', started);
    const session = await request(value.token, '/session');
    try { validateMaintenanceSession(session, binding, permission); } catch { throw failure('session', 'authorization', started); }
    if (value.expiresOnTimestamp <= now()) throw failure('identity', 'identity', started);
    return value.token;
  }
  return { request, authorized, validated };
}
