import {maintenanceObject as object,maintenanceDigest as digest} from '../shared/proforma-maintenance-contracts.mjs';
import {validateProFormaSourceConfig} from './proforma-source-config.mjs';

/** @typedef {{schemaVersion:1,id:string,origin:string,scope:{tenantId:string,workspace:'workflow'},actorId:string,documentIds:string[],purpose:string,policyVersion:string}} SourceBinding */
/** @typedef {{schemaVersion:1,identity:{tenantId:string,clientId:string,credential:{kind:'certificate',path:string}|{kind:'managed-identity',clientId:string}},sourceScope:string,bindings:SourceBinding[],models:{quality:string,selection:string},evaluationDigest:string}} RuntimeConfig */
/** @returns {never} */
const invalid=()=>{throw new Error('Configure a valid ProForma execution registry and delegated identity.');};
// Deployment-owned metadata only. Credentials, tokens and source records are
// forbidden here; reviewing a mapping cannot alter this connection registry.
/** @returns {RuntimeConfig|null} */
export function readProFormaRuntimeConfig(env=process.env){
  if(env.ALAMOAGENT_PROFORMA_EXECUTION_JSON===undefined)return null;
  try{
    if(env.ALAMOAGENT_ASSESSOR_SANDBOX!=='true'||env.ALAMOAGENT_DEPLOYMENT_KIND!=='sandbox')return invalid();
    const raw=env.ALAMOAGENT_PROFORMA_EXECUTION_JSON;if(typeof raw!=='string'||Buffer.byteLength(raw)>128000)return invalid();
    const v=object(JSON.parse(raw),['schemaVersion','identity','sourceScope','bindings','models','evaluationDigest']);
    if(v.schemaVersion!==1)return invalid();
    const source=validateProFormaSourceConfig({schemaVersion:v.schemaVersion,identity:v.identity,sourceScope:v.sourceScope,bindings:v.bindings},env);
    object(v.models,['quality','selection']);for(const model of Object.values(v.models))if(typeof model!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(model))return invalid();digest(v.evaluationDigest);
    return structuredClone(/** @type {RuntimeConfig} */({...v,...source}));
  }catch{return invalid();}
}
