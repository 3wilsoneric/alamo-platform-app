import { app } from "@azure/functions";
import * as df from "durable-functions";
import { everyAgentMonitorV1 } from "./everyagent-orchestrator.mjs";
import { proformaMaintenanceV1 } from "./proforma-maintenance-orchestrator.mjs";
import { executiveReportV1 } from "./executive-report-orchestrator.mjs";

// Independent responsibility families share one timer; an unavailable source in
// one must not starve another. Durable instance state is never inferred from logs.
/** @param {{service:any,maintenance?:any,client:any,reports?:any}} options */
export async function dispatchEveryAgentSchedules({service,maintenance,client,reports=null}) {
  const dispatch=async(host,name,keyFor,idFor)=>{
    for(const task of await host.prepare()){
      const id=idFor(task),input=keyFor(task);
      const status=await client.getStatus(id).catch(error=>{
        if(error instanceof Error&&error.message.startsWith('DurableClient error: Durable Functions extension replied with HTTP 404 response.'))return null;
        throw error;
      });
      if(!status)await client.startNew(name,{instanceId:id,input});
      else if(['Failed','Terminated','Canceled','Completed'].includes(status.runtimeStatus))await host.fail(input??task.id);
    }
  };
  const jobs=[dispatch(service,'agentMonitorV1',()=>null,t=>t.id)];
  if(maintenance)jobs.push(dispatch(maintenance,'proformaMaintenanceV1',t=>t,t=>`proforma-maintenance-${t.id}`));
  if(reports)jobs.push((async()=>{
    for(const key of await reports.pending()){
      const id=`executive-report-${key.runId}-${key.attempt}`;
      const status=await client.getStatus(id).catch(error=>{
        if(error instanceof Error&&error.message.startsWith('DurableClient error: Durable Functions extension replied with HTTP 404 response.'))return null;
        throw error;
      });
      if(!status)await client.startNew('executiveReportV1',{instanceId:id,input:key});
      else if(['Failed','Terminated','Canceled','Completed'].includes(status.runtimeStatus))await reports.pause(key);
    }
  })());
  const results=await Promise.allSettled(jobs);
  if(results.some(r=>r.status==='rejected'))throw new Error('One or more agent schedules could not be dispatched; retained runs will be checked again.');
}

// No public HTTP starter, source payload endpoint, or management key is exposed
// through the web app. The timer claims only server-authorized assignments.
/** @param {{service:any,maintenance?:any,reports?:any,schedule?:string,runtime?:any}} options */
export function registerEveryAgentFunctions({ service, maintenance=null, reports=null, schedule = "0 * * * * *", runtime={app,df} }) {
  const {app,df}=runtime;
  const enabled = () => process.env.EVERYAGENT_WORKER_ENABLED === "true" && process.env.EVERYAGENT_WORKER_MODE === "durable";
  df.app.orchestration("agentMonitorV1", everyAgentMonitorV1);
  df.app.activity("agentCollectV1", { handler: id => service.collect(id) });
  df.app.activity("agentValidateV1", { handler: ({ id, source }) => service.validate(id, source) });
  df.app.activity("agentPublishV1", { handler: ({ id, result }) => service.publish(id, result) });
  df.app.activity("agentFailV1", { handler: id => service.fail(id) });
  if(reports){
    df.app.orchestration('executiveReportV1',executiveReportV1);
    df.app.activity('executiveReportAdvanceV1',{handler:async key=>{
      // A timer switch cannot stop activities already queued by an orchestration.
      if (!enabled()) { await reports.pause(key); return { status: 'paused' }; }
      const started=Date.now();let result;
      // Each advance keeps its existing durable checkpoint/lease. Continue a
      // short interactive investigation here instead of redispatching each read
      // through the worker queue. Recovery resumes from the last checkpoint.
      for(let phase=0;phase<8;phase++) {
        if(!enabled()){await reports.pause(key);return {status:'paused'};}
        result=await reports.advance(key);
        if(!['queued','reading','analyzing'].includes(result.status) || result.claimed===false || !Number.isSafeInteger(result.revision) || Date.now()-started>=45_000) return result;
      }
      return result;
    }});
    df.app.activity('executiveReportPauseV1',{handler:key=>reports.pause(key)});
    app.timer('executiveReportScheduleV1', {
      schedule: '*/2 * * * * *', runOnStartup: false, useMonitor: false, extraInputs: [df.input.durableClient()],
      handler: async (_timer, context) => {
        if (!enabled()) return;
        await dispatchEveryAgentSchedules({service:{prepare:async()=>[]},reports,client:df.getClient(context)});
      }
    });
  }
  if(maintenance){
    df.app.orchestration('proformaMaintenanceV1',proformaMaintenanceV1);
    df.app.activity('proformaMaintenanceRunV1',{handler:key=>maintenance.execute(key)});
    df.app.activity('proformaMaintenanceFailV1',{handler:key=>maintenance.fail(key)});
  }
  app.timer("agentScheduleV1", {
    schedule, runOnStartup: false, useMonitor: true, extraInputs: [df.input.durableClient()],
    handler: async (_timer, context) => {
      if (!enabled()) return;
      const client = df.getClient(context);
      await dispatchEveryAgentSchedules({service,maintenance,client});
    }
  });
}
