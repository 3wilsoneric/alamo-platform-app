import { createHash, randomUUID } from "node:crypto";
import { everyAgentActor, freshAssignment, grantFor, scopeAllows } from "./everyagent-access.mjs";
import { createEveryAgentStore } from "./everyagent-store.mjs";
import { createConversationStore } from "./everyagent-conversation-store.mjs";
import { createConversationSources } from "./everyagent-conversation-sources.mjs";
import { createConversationModel, validateConversationAnswer } from "./everyagent-conversation-model.mjs";
import { validateConversationCommand } from "../shared/everyagent-conversations.mjs";
import { createHttpError } from "./http-error-contract.mjs";
import { proformaSourceFailure } from './proforma-source-transport.mjs';
import { createConversationGuidance, PROFORMA_CONVERSATION_SKILL } from './proforma-conversation-guidance.mjs';

const hidden = () => createHttpError(404, "not_found", "Not found.");
const changed = () => createHttpError(409, "conversation_changed", "This chat changed. Refresh before sending again.");
const digest = value => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const pending = turn => turn.status === "working";
const project = chat => ({ id: chat.id, version: chat.version, createdAt: chat.createdAt, scope: chat.scope,
  workId: chat.workId, turns: chat.turns.map(({ requestHash: _hash, deadline: _deadline, sourceReceipts: _receipts, guidanceReceipts: _guidance, modelAttempts: _attempts, failure: _failure, ...turn }) => turn) });

export function createConversationService({ store = createConversationStore(), workStore = createEveryAgentStore(), source,
  model = createConversationModel(), clientIds = /** @type {string[]} */ ([]), now = () => Date.now(), guidance = /** @type {any} */ (null),
  enabledSkillIds = ['licensing', 'admissions-watch', 'assessment-review', ...(guidance ? [PROFORMA_CONVERSATION_SKILL] : [])] }) {
  const sources = createConversationSources({ workStore, source });
  const guides = createConversationGuidance(guidance);
  if (!Array.isArray(enabledSkillIds) || !enabledSkillIds.length || enabledSkillIds.some(id => !['licensing','admissions-watch','assessment-review',PROFORMA_CONVERSATION_SKILL].includes(id)) || (enabledSkillIds.includes(PROFORMA_CONVERSATION_SKILL) && !guidance)) throw new Error('Configure valid conversation capabilities.');
  async function authorizeSources(auth, chat) { await sources.authorize(chat); await guides.authorize(auth, chat); }
  const allowedClients = new Set(clientIds.map(id => id.toLowerCase()));
  const actor = auth => {
    const userId = everyAgentActor(auth);
    // Transcript-bearing hosts are registered by authenticated client ID, not
    // by Origin, a claimed host name, URL context, or conversation possession.
    if (!allowedClients.has(String(auth.claims.azp ?? "").toLowerCase())) throw hidden();
    return userId;
  };
  const find = (state, userId, id) => {
    const chat = state.conversations.find(item => item.id === id && item.userId === userId);
    if (!chat) throw hidden(); return chat;
  };
  async function expire() {
    await store.update(state => {
      let touched = false;
      for (const chat of state.conversations) for (const turn of chat.turns) if (pending(turn) && turn.deadline <= now()) {
        turn.status = "interrupted"; chat.version++; touched = true;
      }
      return touched;
    });
  }
  async function read(auth, id = /** @type {string | null} */ (null)) {
    const userId = actor(auth);
    await expire();
    const { value } = await store.read();
    if (id) {
      const chat = find(value, userId, id);
      await authorizeSources(auth, chat);
      return project(chat);
    }
    const chats = value.conversations.filter(chat => chat.userId === userId).slice().reverse();
    const access = new Map();
    return { modelAvailable: model.available, availableSkillIds: enabledSkillIds.filter(id => id !== 'assessment-review'), conversations: await Promise.all(chats.map(async chat => {
      try {
        const scopeKey = JSON.stringify([chat.scope, chat.sourceReceipts, chat.turns.map(turn => [turn.status, turn.sourceReceipts, turn.guidanceReceipts])]);
        if (!access.has(scopeKey)) access.set(scopeKey, authorizeSources(auth, chat));
        await access.get(scopeKey);
        return { id: chat.id, title: chat.turns[0]?.text.slice(0, 80) ?? "New chat", createdAt: chat.createdAt, locked: false };
      } catch { return { id: chat.id, title: "Source access unavailable", createdAt: chat.createdAt, locked: true }; }
    })) };
  }
  async function create(auth, input) {
    const userId = actor(auth);
    const { value } = await workStore.read();
    const scope = input.skillIds.map(skillId => {
      if (!enabledSkillIds.includes(skillId)) throw hidden();
      if (skillId === PROFORMA_CONVERSATION_SKILL) return { skillId, communityIds: [] };
      const skill = grantFor(userId).find(item => item.id === skillId);
      if (!skill) throw hidden();
      const assignment = value.assignments.find(item => item.userId === userId && item.skillId === skillId) ?? freshAssignment(userId, skill);
      return { skillId, communityIds: [...assignment.communityIds] };
    });
    let resourceIds = [];
    const sourceReceipts = [];
    if (input.workId) {
      if (scope.some(item => item.skillId === PROFORMA_CONVERSATION_SKILL)) throw hidden();
      const work = value.work.find(item => item.id === input.workId && item.userId === userId);
      if (!work || scope.length !== 1 || scope[0].skillId !== work.skillId || !scopeAllows(work, scope[0])) throw hidden();
      scope[0].communityIds = [...work.communityIds];
      if (work.sourceGrant) sourceReceipts.push({ skillId: work.skillId, grant: work.sourceGrant });
      else if (work.skillId === "assessment-review") throw hidden();
      // The initial monitoring receipt cites an example source but represents
      // the whole assignment. Reviewed change items retain their record scope.
      if (!(work.status === "completed" && work.reviewedAt === null)) resourceIds = work.evidence.filter(item => ["report", "application", "referral"].includes(item.kind)).map(item => item.id);
    }
    const candidate = { id: randomUUID(), userId, requestId: input.requestId, requestHash: digest(input), version: 0,
      scope, sourceReceipts, resourceIds, workId: input.workId, createdAt: new Date(now()).toISOString(), turns: [] };
    const authorized = await sources.authorize(candidate);
    await guides.authorize(auth, candidate);
    // Bind even an empty chat before accepting its first question. Otherwise a
    // permission change between claim and collection could expose a saved title
    // without any receipt from the evidence that prompted the user's question.
    for (const assignment of authorized) candidate.sourceReceipts.push({ skillId: assignment.skillId, grant: await source.authorize(assignment) });
    await authorizeSources(auth, candidate);
    const state = await store.update(state => {
      const prior = state.conversations.find(chat => chat.userId === userId && chat.requestId === input.requestId);
      if (prior) { if (prior.requestHash !== candidate.requestHash) throw changed(); return false; }
      if (state.conversations.length >= 50) throw createHttpError(409, "conversation_capacity", "The pilot has reached its saved-chat limit.");
      state.conversations.push(candidate); return true;
    });
    const chat = state.conversations.find(chat => chat.userId === userId && chat.requestId === input.requestId);
    return read(auth, chat.id);
  }
  async function send(auth, input) {
    const userId = actor(auth);
    await expire();
    const chat = find((await store.read()).value, userId, input.conversationId);
    await authorizeSources(auth, chat);
    const requestHash = digest({ text: input.text, conversationId: input.conversationId });
    const prior = chat.turns.find(turn => turn.id === input.requestId);
    if (prior) { if (prior.requestHash !== requestHash) throw changed(); return read(auth, chat.id); }
    if (!model.available) throw createHttpError(503, "conversation_model_unavailable", "Chat answers are not configured yet. Your saved work remains available.");
    const turn = { id: input.requestId, requestHash, text: input.text, status: "working", createdAt: new Date(now()).toISOString(), deadline: now() + 120_000,
      model: model.model, promptVersion: model.promptVersion, modelStartedAt: null, usage: null };
    let claimed = false;
    await store.update(state => {
      claimed = false;
      const current = find(state, userId, chat.id);
      const existing = current.turns.find(item => item.id === turn.id);
      if (existing) { if (existing.requestHash !== requestHash) throw changed(); return false; }
      if (current.version !== input.expectedVersion || current.turns.some(pending)) throw changed();
      const recent = state.conversations.filter(item => item.userId === userId).flatMap(item => item.turns).filter(item => Date.parse(item.createdAt) > now() - 86_400_000);
      if (recent.filter(pending).length >= 2) throw createHttpError(429, "conversation_concurrency", "Two answers are already running. Wait or stop one before continuing.");
      if (recent.length >= 50) throw createHttpError(429, "conversation_budget", "The daily chat limit has been reached. Saved work is still available.");
      if (current.turns.length >= 40) throw createHttpError(409, "conversation_capacity", "Start a new chat to continue.");
      current.turns.push(turn); current.version++; claimed = true; return true;
    });
    if (!claimed) return read(auth, chat.id);
    let stage = 'collect';
    try {
      const { evidence, receipts } = await sources.collect(chat);
      const starting = await store.update(state => {
        const current = find(state, userId, chat.id);
        const saved = current.turns.find(item => item.id === turn.id);
        if (!saved || !pending(saved) || saved.deadline <= now()) return false;
        saved.sourceReceipts = receipts.map(({ assignment, grant }) => ({ skillId: assignment.skillId, grant }));
        saved.modelStartedAt = new Date(now()).toISOString(); current.version++; return true;
      });
      const currentTurn = find(starting, userId, chat.id).turns.find(item => item.id === turn.id);
      if (!currentTurn || !pending(currentTurn) || currentTurn.deadline <= now()) return read(auth, chat.id);
      const history = chat.turns.filter(item => item.status === "complete").slice(-3).map(item => ({ question: item.text,
        answer: item.answer.paragraphs.map(paragraph => paragraph.text).join("\n") })).filter(item => item.question.length + item.answer.length <= 6000);
      const guidanceSession = guides.session(auth, chat, evidence, async receipts => {
        let retained = false;
        await store.update(state => {
          retained = false;
          const current = find(state, userId, chat.id), saved = current.turns.find(item => item.id === turn.id);
          if (!saved || !pending(saved) || saved.deadline <= now()) return false;
          saved.guidanceReceipts = receipts; current.version++; retained = true; return true;
        });
        if (!retained) throw changed();
      });
      stage = 'model';
      const answer = await model.answer({ text: input.text, history, evidence, guidance: guidanceSession, onModelEvent: async event => {
        let retained = false;
        await store.update(state => {
          retained = false;
          const current = find(state, userId, chat.id), saved = current.turns.find(item => item.id === turn.id);
          if (!saved || (event.state === 'started' && (!pending(saved) || saved.deadline <= now()))) return false;
          saved.modelAttempts ??= [];
          const index = saved.modelAttempts.findIndex(item => item.call === event.call);
          if (index < 0) saved.modelAttempts.push(event); else saved.modelAttempts[index] = event;
          saved.usage = saved.modelAttempts.every(item => item.usage) ? saved.modelAttempts.reduce((total, item) => ({
            inputTokens: total.inputTokens + item.usage.inputTokens, outputTokens: total.outputTokens + item.usage.outputTokens,
          }), { inputTokens: 0, outputTokens: 0 }) : null;
          current.version++; retained = true; return true;
        });
        if (!retained) throw changed();
      } });
      stage = 'validate';
      const validated = validateConversationAnswer(answer, evidence);
      stage = 'reauthorize';
      await sources.recheck(chat, receipts);
      await guidanceSession?.recheck();
      stage = 'save';
      await store.update(state => {
        const current = find(state, userId, chat.id);
        const saved = current.turns.find(item => item.id === turn.id);
        if (!saved || !pending(saved) || saved.deadline <= now()) return false;
        const cited = new Set(validated.paragraphs.flatMap(item => item.sourceIds));
        Object.assign(saved, { status: "complete", answer: validated, evidence: evidence.filter(item => cited.has(item.id)),
          completedAt: new Date(now()).toISOString(), usage: answer.usage });
        current.version++; return true;
      });
    } catch (error) {
      await store.update(state => {
        const current = find(state, userId, chat.id);
        const saved = current.turns.find(item => item.id === turn.id);
        if (!saved || !pending(saved)) return false;
        const code = error && typeof error === 'object' && 'code' in error && ['conversation_request_budget','conversation_model_incomplete','conversation_answer_invalid','conversation_source_unavailable'].includes(String(error.code)) ? String(error.code) : 'conversation_failed';
        const source = proformaSourceFailure(error);
        saved.status = "failed"; saved.failure = { stage: source ? 'source' : stage, code: source ? 'conversation_source_unavailable' : code,
          ...(source ? { source } : {}), at: new Date(now()).toISOString() }; current.version++; return true;
      });
    }
    return read(auth, chat.id);
  }
  async function command(auth, raw) {
    actor(auth);
    let input;
    try { input = validateConversationCommand(raw); } catch { throw createHttpError(400, "conversation_command_invalid", "Choose a valid chat action."); }
    if (input.action === "create") return create(auth, input);
    if (input.action === "send") return send(auth, input);
    const canceledState = await store.update(state => {
      const chat = find(state, actor(auth), input.conversationId);
      const turn = chat.turns.find(item => item.id === input.turnId);
      if (!turn) throw hidden();
      if (!pending(turn)) return false;
      turn.status = "canceled"; chat.version++; return true;
    });
    // Cancellation is available after source revocation without returning any
    // transcript or suggesting that an already charged model call was undone.
    return { canceled: find(canceledState, actor(auth), input.conversationId).turns.find(item => item.id === input.turnId).status === "canceled" };
  }
  return { read, command };
}
