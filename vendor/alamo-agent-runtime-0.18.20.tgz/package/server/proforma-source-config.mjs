import path from 'node:path';
import {maintenanceObject as object,maintenanceId as id} from '../shared/proforma-maintenance-contracts.mjs';
import {validateAutomationBinding} from '../shared/proforma-automation-contracts.mjs';
import {EVERYAGENT_TENANT,EVERYAGENT_USERS} from '../shared/everyagent-identity.mjs';
/** @typedef {{schemaVersion:1,id:string,origin:string,scope:{tenantId:string,workspace:'workflow'},actorId:string,documentIds:string[],purpose:string,policyVersion:string}} SourceBinding */
/** @typedef {{schemaVersion:1,identity:{tenantId:string,clientId:string,credential:{kind:'certificate',path:string}|{kind:'managed-identity',clientId:string}},sourceScope:string,bindings:SourceBinding[]}} SourceConfig */
const invalid=()=>{throw new Error('Invalid ProForma source connection.');};
/** Validate deployment-owned source metadata. This grants no source access.
 * @returns {SourceConfig} */
export function validateProFormaSourceConfig(input,env){
  const v=object(input,['schemaVersion','identity','sourceScope','bindings']);
  if(v.schemaVersion!==1)return invalid();
    const identity=object(v.identity,['tenantId','clientId','credential']);id(identity.clientId);
    if(identity.tenantId!==EVERYAGENT_TENANT||env.ALAMOAGENT_ENTRA_TENANT_ID!==identity.tenantId||![identity.clientId,`api://${identity.clientId}`].includes(env.ALAMOAGENT_ENTRA_API_AUDIENCE))return invalid();
    if(identity.credential?.kind==='certificate'){
      const c=object(identity.credential,['kind','path']);if(typeof c.path!=='string'||!path.isAbsolute(c.path)||c.path.length>4096||c.path.includes('\0'))return invalid();
    }else if(identity.credential?.kind==='managed-identity'){
      const c=object(identity.credential,['kind','clientId']);id(c.clientId);
    }else return invalid();
    if(typeof v.sourceScope!=='string'||!/^api:\/\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/(?:access_as_user|\.default)$/.test(v.sourceScope)||v.sourceScope.startsWith(`api://${identity.clientId}/`))return invalid();
    if(!Array.isArray(v.bindings)||!v.bindings.length||v.bindings.length>50)return invalid();
    const bindings=/** @type {SourceBinding[]} */(v.bindings.map(validateAutomationBinding)),ids=new Set(),documents=new Set();
    for(const b of bindings){
      if(ids.has(b.id)||b.scope.tenantId!==identity.tenantId||!EVERYAGENT_USERS.some(user=>b.actorId===`entra:${identity.tenantId}:${user}`))return invalid();ids.add(b.id);
      for(const doc of b.documentIds){const key=`${b.actorId}:${doc}`;if(documents.has(key))return invalid();documents.add(key);}
    }
    return structuredClone(/** @type {SourceConfig} */({...v,bindings}));
}
