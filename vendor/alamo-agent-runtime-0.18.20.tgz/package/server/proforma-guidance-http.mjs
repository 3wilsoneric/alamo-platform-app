import { PROFORMA_GUIDANCE_PATH } from './proforma-guidance-service.mjs';
import { createHttpError } from './http-error-contract.mjs';
import { readJsonRequestBody } from './http-body.mjs';

export async function handleProFormaGuidanceHttp(req, res, auth, service) {
  const url = new URL(req.url, 'https://agent.invalid');
  if (url.pathname !== PROFORMA_GUIDANCE_PATH || !service) throw createHttpError(404, 'not_found', 'Not found.');
  if (url.search) throw createHttpError(400, 'guidance_input', 'Send guidance inputs in the request body.');
  if (req.method === 'GET') { res.status(200).json(await service.describe(auth)); return; }
  if (req.method === 'POST') { res.status(200).json(await service.command(auth, await readJsonRequestBody(req, 8192))); return; }
  res.setHeader('Allow', 'GET, POST'); throw createHttpError(405, 'method_not_allowed', 'Method not allowed.');
}
