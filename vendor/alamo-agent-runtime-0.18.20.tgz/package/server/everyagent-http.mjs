import { EVERYAGENT_API_PATH } from "../shared/everyagent-client.mjs";
import { readJsonRequestBody } from "./http-body.mjs";
import { applyProtectedApiHeaders } from "./http-response.mjs";
import { HttpError, createHttpError } from "./http-error-contract.mjs";
import { AGENT_CONVERSATIONS_PATH } from "../shared/everyagent-conversations.mjs";
import { handleConversationHttp } from "./everyagent-conversation-http.mjs";
import { ONBOARDING_API_PATH } from "../shared/onboarding-contracts.mjs";
import { handleOnboardingHttp } from "./onboarding-http.mjs";
import { AGENT_CATALOG_PATH } from "../shared/application-catalog.mjs";
import { handleApplicationCatalogHttp } from "./application-catalog-http.mjs";
import { ASSESSOR_SANDBOX_PATH } from "../shared/assessor-sandbox.mjs";
import { handleAssessorSandboxHttp } from "./assessor-sandbox-http.mjs";
import { EXECUTIVE_REPORT_PATH } from "../shared/executive-report-contracts.mjs";
import { handleExecutiveReportHttp } from "./executive-report-http.mjs";
import { PROFORMA_GUIDANCE_PATH } from './proforma-guidance-service.mjs';
import { handleProFormaGuidanceHttp } from './proforma-guidance-http.mjs';

// Shared by the Platform compatibility facade and the independent agent host.
// Both inject a verified identity provider; this layer has no auth bypass.
export function createEveryAgentRequestHandler({ authorize, service, conversations = /** @type {any} */ (null), onboarding = /** @type {any} */ (null), catalog = /** @type {any} */ (null), sandbox = /** @type {any} */ (null), reports = /** @type {any} */ (null), guidance = /** @type {any} */ (null), paths = [EVERYAGENT_API_PATH] }) {
  if (typeof authorize !== "function" || !service) throw new Error("Agent identity and service are required.");
  return async (req, res) => {
    applyProtectedApiHeaders(res);
    try {
      const auth = await authorize(req);
      const pathname = String(req.url ?? "").split("?", 1)[0] ?? "";
      if (pathname === PROFORMA_GUIDANCE_PATH) { await handleProFormaGuidanceHttp(req, res, auth, guidance); return; }
      if (pathname === EXECUTIVE_REPORT_PATH) { await handleExecutiveReportHttp(req, res, auth, reports); return; }
      if (pathname === ASSESSOR_SANDBOX_PATH) { await handleAssessorSandboxHttp(req, res, auth, sandbox); return; }
      if (pathname === AGENT_CATALOG_PATH) { await handleApplicationCatalogHttp(req, res, auth, catalog); return; }
      if (pathname === AGENT_CONVERSATIONS_PATH) { await handleConversationHttp(req, res, auth, conversations); return; }
      if (pathname === ONBOARDING_API_PATH) { await handleOnboardingHttp(req, res, auth, onboarding); return; }
      if (!paths.includes(pathname)) { res.status(404).json({ error: "Not found." }); return; }
      if (req.method === "GET") { res.status(200).json(await service.overview(auth)); return; }
      if (req.method === "POST") { res.status(200).json(await service.command(auth, await readJsonRequestBody(req, 4096))); return; }
      res.setHeader("Allow", "GET, POST");
      res.status(405).json({ error: "Method not allowed." });
    } catch (error) {
      const temporarySource = error instanceof HttpError && error.statusCode === 503 && error.code === 'conversation_source_temporarily_unavailable';
      const publicError = error instanceof HttpError && Number.isInteger(error.statusCode) && error.statusCode >= 400 && error.statusCode < 500 ? error
        : temporarySource ? createHttpError(503, 'conversation_source_temporarily_unavailable',
          'The source check is temporarily unavailable. Try opening this saved chat again.') : null;
      const status = publicError?.statusCode ?? 503;
      // Connector/provider errors may contain sensitive context. Never echo
      // them, even when this host runs locally.
      res.status(status).json({ error: publicError?.message ?? "AlamoAgent is temporarily unavailable. Try again later.",
        code: publicError?.code ?? null });
    }
  };
}
