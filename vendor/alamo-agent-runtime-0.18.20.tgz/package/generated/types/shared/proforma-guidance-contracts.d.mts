export function guidanceRequest(binding: any, query?: string, limit?: number): {
    schemaVersion: number;
    documentIds: any[];
    query: string;
    limit: number;
};
export function validateGuidanceDiscovery(input: any, binding: any, request: any): Record<string, any>;
export const PROFORMA_GUIDANCE_CAPABILITY: Readonly<{
    id: "proforma.guidance.discover";
    version: 1;
    operation: "read";
    scope: "source-user";
    protocol: {
        id: string;
        version: number;
    };
    resourceKinds: string[];
}>;
