export function executiveModelCost(input: any, output: any): number;
export const executiveModelPricing: Readonly<{
    model: "gpt-6.1-sol";
    currency: "USD";
    inputMicrodollars: 2;
    outputMicrodollars: 10;
    checkedAt: "2026-11-22";
}>;
export const EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS: 6000;
