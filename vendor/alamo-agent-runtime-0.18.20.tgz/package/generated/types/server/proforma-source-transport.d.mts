export function proformaSourceFailure(error: any): {
    status?: any;
    operation: any;
    reason: any;
    elapsedMs: number;
} | null;
export function createProFormaSourceTransport({ binding, getToken, fetchImpl, now, onFailure }: {
    binding: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
    onFailure?: ((diagnostic: any) => void) | undefined;
}): {
    request: (token: string, suffix: string, command?: Record<string, any> | null) => Promise<any>;
    authorized: (permission: any) => Promise<any>;
    validated: (operation: any, validate: any) => any;
};
