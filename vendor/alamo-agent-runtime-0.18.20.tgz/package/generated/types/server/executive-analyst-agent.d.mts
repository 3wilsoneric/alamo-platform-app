/** The SDK owns the tool loop; the host retains authority, evidence and money.
 * No hosted sessions or tracing: the existing report store owns conversation. */
export function investigateWithAgent({ model, request, schema, instructions, context, controls, promptVersion }: {
    model: any;
    request: any;
    schema: any;
    instructions: any;
    context: any;
    controls: any;
    promptVersion: any;
}): Promise<any>;
export function calculateSteps(steps: any): {
    error: string;
    step: number;
    calculations: {
        operation: any;
        left: any;
        right: any;
        result: number;
    }[];
} | {
    calculations: {
        operation: any;
        left: any;
        right: any;
        result: number;
    }[];
    error?: never;
    step?: never;
};
