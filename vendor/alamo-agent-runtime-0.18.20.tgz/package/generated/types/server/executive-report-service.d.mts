/** A checkpointed read-only investigation. Source owns authorization and facts;
 * model owns proposals. A worker advances one bounded phase per activity. */
export function createExecutiveReportService({ store, source, model, allowedSubjects, now, leaseMs, deadlineMs }: {
    store: any;
    source: any;
    model: any;
    allowedSubjects: any;
    now?: (() => number) | undefined;
    leaseMs?: number | undefined;
    deadlineMs?: number | undefined;
}): {
    create: (auth: any, input: any) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    }>;
    get: (auth: any, ownerId: any, id: any, version?: null) => Promise<{
        selectedVersion: any;
        canEdit: boolean;
        scope: any;
        objective: any;
        status: any;
        error: any;
        artifact: any;
        view: any;
        readers: any;
        sourceProgress: any;
        versions: any;
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        completedSources: any;
        totalSources: any;
    }>;
    list: (auth: any) => Promise<any[]>;
    command: (auth: any, input: any) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    }>;
    pending: () => Promise<any[]>;
    advance: ({ ownerId, id, runId, attempt }: {
        ownerId: any;
        id: any;
        runId?: null | undefined;
        attempt?: null | undefined;
    }) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    } | {
        status: any;
        claimed: boolean;
    }>;
    pause: ({ ownerId, id, runId, attempt }: {
        ownerId: any;
        id: any;
        runId: any;
        attempt: any;
    }) => Promise<void>;
};
