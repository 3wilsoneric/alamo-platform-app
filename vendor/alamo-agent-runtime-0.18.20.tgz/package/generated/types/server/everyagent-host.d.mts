export function createEveryAgentHttpServer({ authorize, service, conversations, onboarding, catalog, sandbox, reports, guidance, webRoot, origins }: {
    authorize: any;
    service: any;
    conversations?: any;
    onboarding?: any;
    catalog?: any;
    sandbox?: any;
    reports?: any;
    guidance?: any;
    webRoot?: string | undefined;
    origins?: string[] | undefined;
}): import("node:http").Server<typeof import("node:http").IncomingMessage, typeof import("node:http").ServerResponse>;
