export function savedReportEvidence(report: any, version: any): {
    sourceId: string;
    reference: {
        ownerId: any;
        reportId: any;
        version: any;
    };
    value: any;
};
export function validateSavedReportEvidence(item: any): void;
