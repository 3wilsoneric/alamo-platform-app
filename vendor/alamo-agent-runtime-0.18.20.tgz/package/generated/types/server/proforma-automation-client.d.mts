/** Read an exact reviewed definition for agent engineering. This client has no
 * execution, registration, publication or source-write operation. Re-read before
 * using a retained definition; its digest is not continuing source authority. */
export function createProFormaAutomationClient({ binding: input, getToken, fetchImpl, now }: {
    binding: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    discover({ query, limit }?: {
        query?: string | undefined;
        limit?: number | undefined;
    }): Promise<any>;
    read(input: any): Promise<any>;
};
