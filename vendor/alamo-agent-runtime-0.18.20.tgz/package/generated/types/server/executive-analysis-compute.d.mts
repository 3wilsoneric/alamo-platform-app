export function computeAnalysis({ code, title, sourceIds }: {
    code: any;
    title: any;
    sourceIds: any;
}, evidence: any, scope: any, observedAt: any): Promise<{
    sourceId: string;
    value: any;
    proof: {
        code: any;
        sources: {
            id: any;
            revision: any;
        }[];
    };
}>;
