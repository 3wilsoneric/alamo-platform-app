export function createExecutiveModelSpend({ store, limitMicrodollars, creditAllowance, now }: {
    store: any;
    limitMicrodollars?: number | undefined;
    creditAllowance?: {
        id: string;
        limitMicrodollars: number;
        validFrom: string;
        expiresAt: string;
    } | null | undefined;
    now?: (() => number) | undefined;
}): {
    reserve(inputTokens: any, maxOutputTokens: any): Promise<(usage: any) => Promise<void>>;
};
export function countExecutiveModelInput({ request, headers, fetchImpl }: {
    request: any;
    headers: any;
    fetchImpl: any;
}): Promise<any>;
