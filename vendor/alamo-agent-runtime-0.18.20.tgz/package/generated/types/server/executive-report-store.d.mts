export function createExecutiveReportStore({ azure, localRoot, persistenceFor }?: {
    azure?: boolean | undefined;
    localRoot?: string | undefined;
    persistenceFor?: typeof createEveryAgentPersistence | undefined;
}): {
    read: (ownerId: any, id: any) => Promise<{
        value: any;
        version: string | null;
    }>;
    update: (ownerId: any, id: any, mutate: any) => any;
    index: (subject: any, ownerId: any, id: any) => Promise<any>;
    reserveExecution: (subject: any, key: any, now: any) => Promise<void>;
    claimModel: (subject: any, token: any, now: any, leaseMs: any) => Promise<boolean>;
    releaseModel: (token: any) => Promise<void>;
    cachedSynthesis: (subject: any, key: any, now: any) => Promise<{
        proposal: any;
        reportId: any;
        runId: any;
    } | null>;
};
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
