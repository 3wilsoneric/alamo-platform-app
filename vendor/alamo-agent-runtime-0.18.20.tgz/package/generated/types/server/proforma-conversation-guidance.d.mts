export function createConversationGuidance(guidance: any): {
    authorize: (auth: any, chat: any) => Promise<void>;
    session: (auth: any, chat: any, evidence: any, saveReceipts: any) => {
        find(query: any): Promise<{
            results: any[];
            instruction: string;
        }>;
        read(guideIds: any): Promise<{
            evidence: any[];
        }>;
        recheck: () => Promise<void>;
    } | null;
};
export const PROFORMA_CONVERSATION_SKILL: "proforma-guidance";
