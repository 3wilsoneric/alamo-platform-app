export function handleProFormaGuidanceHttp(req: any, res: any, auth: any, service: any): Promise<void>;
