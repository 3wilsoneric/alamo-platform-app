/** @param {any} options */
export function createProFormaGuidanceRuntime({ env, authorize, credentialFor, managedIdentityFor, fetchImpl, now }: any): {
    authorize: any;
    guidance: null;
} | {
    guidance: {
        describe(auth: any): Promise<{
            schemaVersion: number;
            application: string;
            product: string;
            capabilities: (Readonly<{
                id: "proforma.guidance.discover";
                version: 1;
                operation: "read";
                scope: "source-user";
                protocol: {
                    id: string;
                    version: number;
                };
                resourceKinds: string[];
            }> | {
                id: string;
                version: number;
                operation: string;
                scope: string;
                protocol: {
                    id: string;
                    version: number;
                };
                resourceKinds: string[];
            })[];
            connections: {
                id: string;
                purpose: string;
                configured: boolean;
                access: string;
            }[];
            modules: {
                id: string;
                version: number;
                application: string;
                inputs: string[];
            }[];
            canExecute: boolean;
        }>;
        command(auth: any, raw: any): Promise<{
            schemaVersion: number;
            sourceBindingId: string;
            result: Record<string, any>;
        }>;
    };
    authorize: (req: any) => any;
};
