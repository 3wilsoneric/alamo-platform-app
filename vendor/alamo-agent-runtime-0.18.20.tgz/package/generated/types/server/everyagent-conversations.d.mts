export function createConversationService({ store, workStore, source, model, clientIds, now, guidance, enabledSkillIds }: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    workStore?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    source: any;
    model?: {
        available: boolean;
        model: string;
        promptVersion: string;
        answer({ text, history, evidence, guidance, onModelEvent }: {
            text: string;
            history: any[];
            evidence: any[];
            guidance?: {
                find: (query: unknown) => Promise<any>;
                read: (ids: unknown) => Promise<any>;
            } | null;
            onModelEvent?: (event: any) => Promise<void>;
        }): Promise<{
            model: string;
            promptVersion: string;
            usage: {
                inputTokens: number;
                outputTokens: number;
            } | null;
            paragraphs: any;
        }>;
    } | undefined;
    clientIds?: string[] | undefined;
    now?: (() => number) | undefined;
    guidance?: any;
    enabledSkillIds?: string[] | undefined;
}): {
    read: (auth: any, id?: string | null) => Promise<{
        id: any;
        version: any;
        createdAt: any;
        scope: any;
        workId: any;
        turns: any;
    } | {
        modelAvailable: boolean;
        availableSkillIds: string[];
        conversations: any[];
    }>;
    command: (auth: any, raw: any) => Promise<{
        id: any;
        version: any;
        createdAt: any;
        scope: any;
        workId: any;
        turns: any;
    } | {
        modelAvailable: boolean;
        availableSkillIds: string[];
        conversations: any[];
    } | {
        canceled: boolean;
    }>;
};
