export function createProFormaConfiguredExecution({ store, bindingsFor, sourceFor, getPolicy, now }: {
    store: any;
    bindingsFor: any;
    sourceFor: any;
    getPolicy: any;
    now?: (() => number) | undefined;
}): {
    configurationCommand: (auth: any, raw: any) => Promise<{
        sourceBindingId: any;
        source: any;
        macros: any;
        capability: Readonly<{
            id: "assessor-referral-handoff-draft-v1";
            revision: string;
            mode: "synthetic-only";
            authority: "read_investigate_draft";
            phases: string[];
            sourceWork: "unconfirmed";
            delivery: "not_performed";
            receivingAcceptance: "source-required";
        }>;
        configurations: {
            mode: string;
            proposalHash?: any;
            macroId?: any;
            id: any;
            revision: any;
            status: any;
            enabled: any;
            available: boolean;
        }[];
        mode: string;
    } | {
        sourceBindingId: any;
        guidance: Record<string, any>;
        configuration?: never;
    } | {
        configuration: {
            available: boolean;
            id: any;
            revision: any;
            proposalHash: any;
            status: any;
            enabled: any;
            mode: string;
            source: {
                documentId: any;
                publicationId: any;
                fingerprint: any;
            };
        } | {
            available: boolean;
            proposalHash: any;
            source: any;
            macro: any;
            stepBindings: any;
            capability: Readonly<{
                id: "assessor-referral-handoff-draft-v1";
                revision: string;
                mode: "synthetic-only";
                authority: "read_investigate_draft";
                phases: string[];
                sourceWork: "unconfirmed";
                delivery: "not_performed";
                receivingAcceptance: "source-required";
            }>;
            models: any;
            evaluationDigest: any;
            review: any;
            history: any;
            id: any;
            revision: any;
            status: any;
            enabled: any;
            mode: string;
        };
        sourceBindingId?: never;
        guidance?: never;
    }>;
    preview: (...args: any[]) => Promise<any>;
    bind: (...args: any[]) => Promise<any>;
    assertCurrent: (...args: any[]) => Promise<any>;
};
export const PROCESS_CONFIGURATION_ACTIONS: string[];
