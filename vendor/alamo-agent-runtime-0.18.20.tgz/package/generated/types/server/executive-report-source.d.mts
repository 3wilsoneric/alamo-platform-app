export function createExecutiveReportSource({ origin, getToken, fetchImpl, now }: {
    origin: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    authorize(subject: any, scope: any, step: any): Promise<any>;
    authorizeMany(subject: any, checks: any, scope?: any): Promise<any[]>;
    prepare(subject: any, scope: any): Promise<{
        catalog: any;
        prepared: any;
    }>;
    catalog(subject: any, scope: any): Promise<any>;
    read(subject: any, scope: any, step: any): Promise<any>;
};
