export function validateConversationAnswer(value: any, evidence: any): {
    paragraphs: any;
};
export function createConversationModel({ apiKey, model, fetchImpl, maxRequestBytes }?: {
    apiKey?: string | undefined;
    model?: string | undefined;
    fetchImpl?: typeof fetch | undefined;
    maxRequestBytes?: number | undefined;
}): {
    available: boolean;
    model: string;
    promptVersion: string;
    /** @param {{text:string, history:any[], evidence:any[], guidance?:{find:(query:unknown)=>Promise<any>,read:(ids:unknown)=>Promise<any>}|null,onModelEvent?:(event:any)=>Promise<void>}} input */
    answer({ text, history, evidence, guidance, onModelEvent }: {
        text: string;
        history: any[];
        evidence: any[];
        guidance?: {
            find: (query: unknown) => Promise<any>;
            read: (ids: unknown) => Promise<any>;
        } | null;
        onModelEvent?: (event: any) => Promise<void>;
    }): Promise<{
        model: string;
        promptVersion: string;
        usage: {
            inputTokens: number;
            outputTokens: number;
        } | null;
        paragraphs: any;
    }>;
};
