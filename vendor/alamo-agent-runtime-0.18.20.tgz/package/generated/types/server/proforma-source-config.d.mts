/** Validate deployment-owned source metadata. This grants no source access.
 * @returns {SourceConfig} */
export function validateProFormaSourceConfig(input: any, env: any): SourceConfig;
export type SourceBinding = {
    schemaVersion: 1;
    id: string;
    origin: string;
    scope: {
        tenantId: string;
        workspace: "workflow";
    };
    actorId: string;
    documentIds: string[];
    purpose: string;
    policyVersion: string;
};
export type SourceConfig = {
    schemaVersion: 1;
    identity: {
        tenantId: string;
        clientId: string;
        credential: {
            kind: "certificate";
            path: string;
        } | {
            kind: "managed-identity";
            clientId: string;
        };
    };
    sourceScope: string;
    bindings: SourceBinding[];
};
