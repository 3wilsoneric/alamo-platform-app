<a id="alamoagent-engine"></a>
# Ally engine

Edit the agent here. This is an independent source project for the API, skills,
application connectors, workflows and conversation policy. It builds without a
Platform, Carelog or Pipeline checkout or a browser UI. This directory is the canonical Ally source;
`/Users/eric/CareEngineMain/alamoagent` is a path compatibility link. The portable
task contract package lives at [packages/ally-core](packages/ally-core/README.md).
Start with the [product brief](docs/product-brief.md)
for the complete direction and the [living build spec](docs/build-spec.md) for
current engineering decisions. The [architecture map](docs/architecture-map.md)
shows the engine, applications and deployment boundaries. The
[executable build plan](docs/build-spec.md#executable-build-plan) gives the phased
delivery order and completion gates. The active work is the suite-wide foundation:
common identity, data and application contracts; agent execution; internal Alamo
setup; environments, releases and evaluations. Alamo is the only intended customer
for the foreseeable future. The selected proof covers assessment answer quality
and assessor handoffs, plus LIC 624 wording at commit and executive exceptions.
First-release authority is read, investigate and draft; confirm actions. Exact
wording-review interaction and alert rules remain open. External customer onboarding
is deferred; existing reusable contracts and isolation regressions are retained.

The suite architecture uses one shared data and knowledge foundation. Applications
both publish to it and read from it. Analytics is one capability alongside records,
documents, events, shared meaning and governance; this does not require one physical
database. Ally is an independent peer service, with a thin helper embedded
across the suite. It reads governed shared data, runs skills and publishes its
work/outcomes back into the layer. Actions use each owning app's API.
This is the agreed architecture; current connector and rollout status is below.

That shared foundation is a native product capability. We own the application
setup/catalog, ontology, governance and work lineage, execution contracts, skills
and evaluation lifecycle. Databricks and other backends support them through
explicit adapters; source/backend authority remains enforced. See the
[native product boundary](docs/build-spec.md#native-product-boundary) for ownership
and portability requirements. This engine remains a separate runtime within that product.

Engine **0.17.0** adds a [Workflow knowledge read capability](docs/connectors.md#workflow-knowledge-delegated-on-demand-read)
for source excerpts and versioned citations in Platform's existing helper. The
small dependency-free package preserves the host's older runtime pin. Independent
API conversation wiring and durable Workflow publication remain to build. See the
[build spec](docs/build-spec.md) and release receipt for verified deployment status.

API and worker **0.18.14** are deployed for Eric, Andrew and Betty in Platform.
The owner authorized the existing **$199.09 prepaid allowance**, expiring December
17, replacing the 50¢ daily pilot. Reserve before generation, settle verified
token usage and retain unknown exposure; the cumulative ledger does not reset
at midnight. Only the report scheduler is enabled. Source reads remain aggregate
only, and access is limited to those three subjects. Current live answer,
cost-ledger and browser acceptance are recorded in the [build spec](docs/build-spec.md)
and Platform operations log.
ProForma-specific acceptance remains deferred; Platform is the active priority.

Version **0.18.13** bounds read-only discovery concurrency and reduces the idle
worker polling ceiling while retaining fresh source authorization. A fresh live
answer took 14.309 seconds; this is not evidence of a consistent full-answer
speedup. See the [latency measurements](docs/build-spec.md#november-23-response-latency--01813-deployed).

All three identity/API/source boundaries and all 134 deployed worker files pass
verification. The 12 previous reports and spending ledgers are preserved. The
first new live question and follow-up settled four model calls at $0.020320.
No credit purchase or automatic top-up is enabled. Platform's scroll correction
is deployed and verified: 28 predeployment stages, four postdeployment stages,
15 live routes and 12 interactions pass. Real conversation, saved history, phone
layouts and native PDF export pass in Eric's signed-in session. Andrew and Betty
have verified directory/service access; neither was interactively impersonated.
Platform's subsequent readability release is also live: readable chart fields,
responsive record layouts and compact saved-report source links. The fresh full
28-stage gate and four-stage postdeployment gate pass. The [Platform operations record](/Users/eric/.codex/worktrees/platform-ally-conversation-20261123/docs/platform/deployment-operations.md#ally-readability-and-response-latency--november-23)
owns immutable deployment and rollback receipts.

The current source candidate adds a [ProForma maintenance consumer](docs/proforma-maintenance.md):
delegated change reads, quoted proposals and durable retries through the source's
review/publication lifecycle. Its API contract is verified with fictional data;
a model-backed assessor and fictional evaluation runner are implemented. Limited real-model development checks now pass; semantic usefulness and
independent staff review remain open. An optional scheduled host now has partitioned checkpoints,
evidence, retries and cancellation through the existing worker timer. Production
identity/configuration and sustained retention remain open. This is not deployed.

The [reviewed ProForma macro binding](docs/proforma-automation.md) also connects an
exact published guide and proposed macro to the existing signed assessor sandbox.
It retains source/plan/run/artifact references, preserves explicit draft review and
stops on source or configuration changes. The connected referral-draft check uses
fictional records and model responses. Saved configuration review/activation and ProForma conversation wiring are now
implemented in source. An optional [runtime connection](docs/proforma-runtime.md) now
constructs trusted bindings and request-bound delegated identity from deployment
configuration. Real identity/consent, source/quality readiness and deployment remain open.

Engine **0.16.0** adds a [durable synthetic publication proof](docs/workflow-publication.md)
and a [verified source/configuration inventory](docs/suite-integration-readiness.md).
Invented Pipeline history passes through separate foundation persistence into the
existing scoped views and skill runner. Source lag, duplicates, conflicts, lost
acknowledgments, process restart and fresh review authorization are tested. This
does not connect real records, deploy the engine or update Platform's 0.13.0 pin.

## Where to edit

| Change | Source |
|---|---|
| ProForma-owned role responsibilities and agent-owned skill cards | [Role reference](docs/roles/README.md), [skill library](docs/skills/README.md), [content ownership and exchange](docs/workflow-library-content.md), [staff review worksheet](docs/roles/review-workbook.md) |
| Verified suite integration boundaries and synthetic source publication | [Suite inventory](docs/suite-integration-readiness.md), [publication proof](docs/workflow-publication.md) |
| Native application/capability catalog and live access observations | [definitions](shared/application-catalog.mjs), [service](server/application-catalog-service.mjs), [API contract](docs/foundation-contracts.md#native-capability-catalog) |
| A skill's purpose, source application and scope | [skills/licensing/definition.mjs](skills/licensing/definition.mjs), [skills/admissions-watch/definition.mjs](skills/admissions-watch/definition.mjs), [skills/assessment-review/definition.mjs](skills/assessment-review/definition.mjs) |
| Register a reviewed skill | [shared/everyagent-catalog.mjs](shared/everyagent-catalog.mjs) |
| Route skills to source apps | [server/application-connectors.mjs](server/application-connectors.mjs) |
| Connector identity and deployment configuration | [server/everyagent-source-runtime.mjs](server/everyagent-source-runtime.mjs) |
| API request/response and grant protocol | [shared/everyagent-source-contracts.mjs](shared/everyagent-source-contracts.mjs), [server/everyagent-source-client.mjs](server/everyagent-source-client.mjs) |
| Durable execution, retries and cancellation | [server/everyagent-workflow-service.mjs](server/everyagent-workflow-service.mjs), [server/everyagent-orchestrator.mjs](server/everyagent-orchestrator.mjs) |
| Conversation behavior and budgets | [server/everyagent-conversations.mjs](server/everyagent-conversations.mjs) |
| Model instructions and structured answers | [server/everyagent-conversation-model.mjs](server/everyagent-conversation-model.mjs) |
| Scope-aware evidence retrieval | [server/everyagent-conversation-sources.mjs](server/everyagent-conversation-sources.mjs) |
| Company onboarding, source mappings and reviews | [server/onboarding-service.mjs](server/onboarding-service.mjs), [shared/onboarding-contracts.mjs](shared/onboarding-contracts.mjs), [API guide](docs/onboarding.md) |
| Assessment responsibility and completion proof | [policy](skills/assessment-review/responsibility.mjs), [binding](server/assessment-review-responsibility.mjs) |
| First workflow observation | [producer](server/assessment-review-observation.mjs), [contract](shared/assessment-review-observation.mjs); saved with the assessment review receipt |
| Synthetic helper connection, explicit draft review and scoped HTTP traces | [Assessor sandbox](docs/assessor-sandbox.md) |
| Executable skills, shared runner, traces and candidate comparisons | [Skill harness](docs/skill-harness.md) |
| Question-driven report skill, source coverage and independent-host acceptance | [Report skill](docs/report-skill.md) |
| Assessor grading, trace-linked corrections and fresh fictional case intake | [Human review process](docs/assessor-human-review.md), [case worksheet](docs/assessor-case-intake.md) |
| One event history serving assessor, supervisor and executive scopes | [Cross-role proof](docs/workflow-role-proof.md), [contracts](shared/workflow-history-contracts.mjs), [reference projection](server/workflow-evidence-projection.mjs) |
| Full Alamo/company/application context, component research questions and acceptance evidence | [Research map](docs/component-research-map.md) |
| Current decisions, learning/eval roadmap and limits | [docs/build-spec.md](docs/build-spec.md) |
| Assessor knowledge graph, workflows and candidate skills | [Assessor work model](docs/assessor-work-model.md) |
| Authored assessor procedures, clickpaths and agent workflow definitions | [Procedure library](../../alamo-workflow/docs/assessor-procedures.md), [clickpaths](../../alamo-workflow/docs/assessor-clickpaths.md), [agent workflows](docs/assessor-agent-workflows.md) |
| Suite-wide employee work dossiers and role blueprints | [Employee work-dossier design](docs/build-spec.md#employee-work-dossiers) |
| Target capabilities by app, skill library and evaluation contracts | [Application capabilities](docs/build-spec.md#capabilities-by-application), [library](docs/build-spec.md#library-organization-and-initial-catalog), [evaluations](docs/build-spec.md#evaluation-system-for-the-skill-library) |
| Common company/app/skill/responsibility and evidence contracts | [Foundation contract guide](docs/foundation-contracts.md), [validators](shared/foundation-contracts.mjs), [conformance](shared/foundation-conformance.mjs), [compatibility](shared/foundation-compatibility.mjs), [examples](examples/foundation/catalog.json) |
| Scoped work context and the fictional assessor draft/review loop | [Boundary and usage](docs/work-context.md), [example result](docs/assessor-synthetic-demo.md), [contract](shared/work-context-contracts.mjs), [activities](server/assessor-work-context.mjs) |
| Pipeline assessor clarification and handoff stages | [Flow and limits](docs/assessor-follow-through.md), [activities](server/assessor-follow-through.mjs), [fictional rehearsal](scripts/demo-assessor-follow-through.mjs) |
| Durable immutable drafts and version-bound review receipts | [Contract and limits](docs/draft-reviews.md), [store](server/draft-review-store.mjs), [service](server/draft-review-service.mjs) |
| Model-backed answer-quality proposals, source excerpts and evaluations | [Skill and limits](docs/assessment-quality.md), [prompt/contract](skills/assessment-review/quality.mjs), [provider](server/assessment-quality-model.mjs), [activities](server/assessment-quality-review.mjs) |

## Work locally

The current executive report release is **0.18.11**, with core **0.2.14**.
It includes source-date/percentage validation, report authorization recovery,
scoped answer reuse, conditional daily spending control, and source-validated
chart measures shared by screen and PDF. The API is keyless; the separate worker
owns model calls. Platform's source-runtime package pin is independent of this
backward-compatible report API. The historical $11 development campaign is closed;
the ongoing owner pilot uses its own 50-cent daily ledger. See the
[current spec](docs/build-spec.md#november-23-platform-first-execution-and-chart-correction)
for exact deployment, acceptance, recovery and rollout limits.

The preceding **0.18.3** candidate separated the keyless API from
provider-backed execution and retaining the live-evaluation corrections to
period labels, source caveats and scoped planning. A bounded five-question
fictional cloud/browser run passed, and its temporary configuration was removed.
A separate production API/worker is now installed with reports, sources, model
execution and executive access still disabled; existing apps are unchanged. The
preceding **0.18.1** permission correction blocks publication when a source
grant changes during synthesis and preserves source detail restrictions across
saved/shared reports. Its source contract requires `grant.detail` and evidence
`requiresDetail`; deploy it with the corresponding Platform source change.
That paired 0.18.1 correction is deployed to the disabled staging API, worker and
Platform source. Cloud sharing and detail-downgrade checks passed with fictional
records; revocation and cleanup also passed after honoring an Azure exec
retry interval. Active test reports, grants and the fixture snapshot are removed.
The final fictional live run passed all 30 development cases within the owner’s
$10 campaign limit. [Results and limits](docs/evaluations/executive-quality-2026-11-22.md)
include the failures found and corrected. See the [current spec](docs/build-spec.md)
for evidence, immutable-history recovery and the rollout boundary.

The role/skill authoring library is revisioned separately from the runtime. It
contains 16 draft role families, 32 workflow summaries and 40 skill cards: five
local synthetic implementations and 35 design-only candidates. Alamo Workflow
owns role definitions, human workflows, SOPs, docs and teaching; edit skills here
in `skills/library/skills.v1.json`. Import Workflow role revisions using
`npm run library:import-roles -- <explicit-path>`, run `npm run library:docs`, then
`npm run check:library`. The combined catalog and Markdown pages are generated
references, not role authoring sources. This does not
register skills, publish procedures in Alamo Workflow or create employee dossiers.

```sh
npm ci --ignore-scripts
npm test
npm run build:api
npm run build:worker
npm run check:package
```

Tests use synthetic identities, two local HTTP source applications and temporary
state. They make no live model calls and create no cloud resources. The package
check installs the API outside this checkout, boots its production entry point,
and checks health, authentication, configuration guards and clean shutdown.

The optional Functions integration check runs the packaged worker registration,
timer, orchestrator and activities in Microsoft's real Functions host with local
Azurite storage. Pull its images once, then run:

```sh
docker pull --platform linux/amd64 mcr.microsoft.com/azure-functions/node:4-node22
docker pull mcr.microsoft.com/azure-storage/azurite:3.35.0
npm run check:executive-functions-host
```

It uses fictional records, a canned model and the canonical file report adapter
on an isolated internal Docker network. No ports, real credentials or production
test endpoints are exposed. The fixture is excluded from deployment packages.
Logs and versioned evidence remain in `generated/executive-functions-*`; test
containers and their network are removed afterward. On Apple Silicon, only this
test container applies Microsoft's documented .NET emulation workaround. This
check does not establish cloud identity/source access, live model quality or
production latency. Those remain separate acceptance requirements.

`npm run eval:executive-reports` prepares the 30-case executive development
answer sheet and a blank human-review worksheet under
`generated/executive-evaluations/`, with **zero model calls**. The cases use fixed
fictional projections and canonical report execution; `npm run
check:executive-evaluation` checks the evaluator with canned proposals. These
authored cases are not held out and do not replace source/cloud/device checks.
The authorized `npm run eval:executive-reports -- --live` run uses the verified shared connection from `OPENAI_API_KEY`,
`OPENAI_PROJECT_ID`, `ALLY_MODEL` and `ALLY_CONNECTION_VERIFIED_UNTIL`. It does not
load an environment file or extend production verification. It also requires an
absolute `ALLY_EVAL_BUDGET_FILE` shared across this campaign’s runs. The locked
ledger reserves exact provider-counted input (plus a 256-token cushion) and the
maximum output at reviewed standard rates before each generation request, up to
$10 total. Failed/interrupted reservations are never reused. A process crash
leaves the lock for inspection; do not delete it or start a fresh ledger to reset
the allowance. Only `gpt-6.1-sol` with function proposals at standard tier is priced;
review pricing and the authorization before changing that scope. `--case executive-01` limits a
run to one known case. The full run permits at most 64 provider calls, no automatic
provider retries, and stops after a provider/model failure. Actual model metadata,
tokens, timings, source revisions, proposals, findings and views are retained;
semantic grades remain blank until reviewed. `--conversation` runs a fixed ten-turn
follow-up benchmark instead, retaining each question, answer, cost inputs and
previous report versions. It uses the same campaign ledger and permits at most
20 generation requests. No command activates a release.

`npm start` is the real API entry. It requires production storage, Entra and
connector configuration; see [.env.example](.env.example). The Functions worker
is a separate deployment. This repo does not turn on a local auth bypass.

## Connect an application

Read [docs/connectors.md](docs/connectors.md). Integration has three parts: exchange
data with the shared foundation through publishing and governed reads, embed the common agent client,
and expose permitted actions through the app's API. The app keeps its business
rules and transactional authority. The agent owns skills, task state and orchestration.
The current runtime uses bounded source read APIs. A shared analytical read
capability belongs in the suite-wide foundation design before integration work.

Platform exposes Licensing summaries and a protected Admissions aggregate.
The direct Pipeline assessment-review connector is implemented in 0.2.0 with a
source-owned v2 projection; the skill starts paused and has not been deployed.
Workflow, Workforce and AlamoHealth connectors are not
implemented here yet. Engine 0.5.0 binds reviewed Pipeline definitions to a bounded
assessment-review responsibility in the existing durable worker. It verifies
current grants, definitions, rules and complete page coverage, and saves evidence
and a completion receipt together. Discovery prepares proposals and preserves
reviews on unchanged evidence. General system discovery,
operational graph retrieval, reviewed learning and application write tools remain
planned; registering a manual reference does not connect that application.

Engine 0.5.1 adds one typed observation to each new verified assessment-review
receipt. It records the agent run, source and definition revisions, evidence
references and scan counts in the same write. It is not human activity capture,
a complete event journal or analytical publication. Existing receipts remain
readable; no history is backfilled. Delivery continues in small verified increments,
without a fixed 60-day release schedule.

Engine 0.6.0 implements the first foundation contract pack. It validates pinned
company/application/skill definitions, responsibilities and declared evidence/outcome
cases, with two synthetic companies and both Licensing and assessment-review examples.
Run `npm run check:foundation` for focused conformance checks. Existing wire formats
remain unchanged; compatibility reports explicitly require a company/source binding.
The pack does not enable companies, invoke sources or migrate persisted state.

Engine **0.7.0** adds the first native foundation API: `GET /api/agent/v1/catalog`.
It lists the four reviewed apps and three current read capabilities, distinguishes
implemented/configured/current-access states, and checks source grants for the
signed-in user's actual assignments. Workflow and Point of Care remain explicitly
unimplemented. The endpoint is read-only and Eric-only, with no business-record
collection, new company binding, workflow activation or deployed-host upgrade.
Run `npm run check:catalog`; see the [contract](docs/foundation-contracts.md#native-capability-catalog).

Engine **0.8.0** adds the bounded work-context contract and deterministic assessor
draft/review activities. The pure Pipeline projection and all demonstrations use
fictional records; no content source route, grant, model service or worker binding
is enabled. Run `npm run demo:assessor` or `npm run check:work-context`. The same
contract is checked against a second, synthetic Licensing work shape. See the
[implementation boundary](docs/work-context.md). Do not access real assessments
under the current user restriction.

Engine **0.9.0** adds a separate model-backed assessment-quality skill and a fixed
nine-case fictional evaluation runner. The prompt, cited output validation, model
adapter, source rechecks and draft-review activities are implemented locally.
`npm run check:assessment-quality` tests the controls with canned responses;
`npm run eval:assessment-quality -- --live` runs only the fictional suite with a
configured model key. Engine **0.9.1** records a **9/9 live synthetic regression pass**
after stricter prompt, validation and false-positive checks. The [evaluation record](docs/evaluations/assessment-quality-2026-10-17.md)
includes actual outputs and limits; independent episodes and assessor review remain.
No real assessment, HTTP/worker binding or source-content grant is
enabled. See the [evaluation guide](docs/assessment-quality.md).

Engine **0.10.0** connects assessment-quality activities to a shared durable
[draft/review repository](docs/draft-reviews.md). Fictional assessment and LIC 624
shapes prove immutable drafts, version-bound review receipts, restart, idempotency,
concurrent writes and source rechecks. Run `npm run check:draft-reviews`. This adds
no HTTP/worker binding, live content source, source commit or deployment. The 0.8
deterministic demo remains an earlier transient prototype.

Engine **0.11.0** connects the Pipeline assessor [review → clarification → handoff
flow](docs/assessor-follow-through.md) through the shared durable repository. The
fixed rehearsal uses three fictional source versions, canned model responses and
simulated human decisions. Stage acceptance is separate from source work and
sending. Run `npm run check:assessor-flow` or `npm run demo:assessor-flow`; no UI,
HTTP/worker registration, live assessment access or deployment is added.

Engine **0.12.0** adds the [assessor skill pack and shared execution harness](docs/skill-harness.md).
The model selects quality review, clarification or handoff; deterministic eligibility,
source/review rechecks and mandatory traces guard execution. Repeated fictional model
evaluations and version-bound feedback comparisons use that runner. Human grading and
release approval remain required; the embedded helper/worker are not wired to it yet.

Engine **0.13.0** connects the shared runner to the [existing helper through an
explicit synthetic sandbox](docs/assessor-sandbox.md). Signed HTTP, isolated durable
traces, idempotent requests and explicit draft acceptance/rejection are implemented.
The helper entry is restricted to loopback development. Two live fictional HTTP
journeys passed; no production rollout or real assessment access is enabled.

Engine **0.14.0** adds the [cross-role foundation proof](docs/workflow-role-proof.md):
one fictional source history drives assessor preparation, team exceptions and
defined executive cohort metrics. It exercises scope/reassignment, late corrections,
replayed events and stale/partial source rejection. The importable source service
is unbound; no live feed, model skill, new access or deployment is enabled.
Run `npm run demo:workflow-roles` for a readable rehearsal and
`npm run check:workflow-roles` for the controls. Platform stays pinned to 0.13.0.

Engine **0.15.0** adds [supervisor/executive brief skills](docs/workflow-briefs.md)
using the shared runner and draft service, plus a separate source-owned Pipeline
synthetic audit mapper. The mapper reports partial coverage; role skills continue
using complete fictional history. New-role model routing is unverified because
no process credential was available. Run `npm run check:workflow-briefs` and
`npm run demo:workflow-briefs`. No host binding or rollout changes.

## Update Platform's compatibility package

```sh
npm test
npm run pack:runtime
```

The resulting `generated/alamo-agent-runtime-0.15.0.tgz` is an internal distribution,
not a second source tree. Copy a reviewed, versioned archive into Platform's
`vendor/`, update its dependency and lock, and run its integration checks. Bump
the package version for subsequent releases; never silently replace a deployed
version. Production uses locked package bytes and does not need this sibling
directory to exist. Nothing is published to npm or GitHub by these commands.

Platform's old `everyagent-*` files are compatibility exports. Its source API,
source grants, UI and domain adapters remain Platform-owned. Common utility and
public resource-directory snapshots were extracted at `a1daade`; source apps are
still authoritative for current authorization and resource membership.

Eric-only rollout; no emails; Andrew's Wilson branding stays inactive. Local
verification is not production deployment. The build spec records remaining work.

## ProForma reviewed definitions

The source candidate adds a [read-only publication client](docs/proforma-automation.md).
It retrieves exact reviewed guides and proposed macros through current delegated
source access. Frozen content, revisions, dependency anchors and unresolved bindings
are validated; no execution host or deployment is enabled.

The current source lock pins patched MSAL Node 7.1.1 beneath Azure Identity.
Run `npm run check:identity-dependencies` for real-library checks with simulated
identity endpoints; the certificate fixture requires `openssl`. See the
[living build spec](docs/build-spec.md) for package and deployment limits.

The ProForma maintenance assessor now passes two automatic samples of 18 fictional
cases. Separate assistant review retains five responses with optional examples or
explanatory overreach. Model usefulness, staff review and production activation
remain open. See [maintenance evaluation](docs/proforma-maintenance.md#maintenance-evaluation--2026-10-24).

The **0.18.16 source candidate** adds the shared executive analyst skill,
iterative source investigation, recent conversation context, evidence-preserving
rewrites, longer reports and optional inline visuals. Consecutive checkpointed
phases avoid repeated Durable queue dispatches. The six-read/four-model limits,
source grants, cancellation and cumulative credit controls remain. Release and
real-model acceptance are pending; see the living build spec.
