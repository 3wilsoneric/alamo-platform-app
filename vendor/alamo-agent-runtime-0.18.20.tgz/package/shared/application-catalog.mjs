import { WORKFLOW_KNOWLEDGE_CAPABILITY, WORKFLOW_KNOWLEDGE_SKILL } from "./workflow-knowledge-contracts.mjs";
import { EVERYAGENT_SKILLS } from "./everyagent-catalog.mjs";
import { validateApplicationManifest } from "./foundation-contracts.mjs";

export const AGENT_CATALOG_PATH = "/api/agent/v1/catalog";

// Reviewed product definitions. Configuration can connect these capabilities;
// neither model output nor an HTTP caller can register a new executable tool.
const definitions = [
  { schemaVersion: 1, id: "platform", revision: 1, name: "Platform", capabilities: [
    { id: "licensing.published-reports.read", version: 1, operation: "read", scope: "community",
      protocol: { id: "agent-summary", version: 1 }, resourceKinds: ["licensing-library"] },
    { id: "pipeline.admissions-summary.read", version: 1, operation: "read", scope: "organization",
      protocol: { id: "agent-summary", version: 1 }, resourceKinds: ["admissions-summary"] }
  ] },
  { schemaVersion: 1, id: "pipeline", revision: 1, name: "Pipeline", capabilities: [
    { id: "pipeline.assessment-review.read", version: 1, operation: "read", scope: "source-user",
      protocol: { id: "assessment-review", version: 2 }, resourceKinds: ["assessment-scan"] }
  ] },
  { schemaVersion: 1, id: "workflow", revision: 2, name: "ProForma", capabilities: [WORKFLOW_KNOWLEDGE_CAPABILITY] },
  { schemaVersion: 1, id: "alamohealth", revision: 1, name: "Point of Care", capabilities: [] }
];

/** Return detached metadata and check that every definition has a runtime binding.
 * This describes implementation, never grants or deployment readiness. */
export function describeApplicationCatalog() {
  const applications = definitions.map(validateApplicationManifest);
  const registered = [...EVERYAGENT_SKILLS, WORKFLOW_KNOWLEDGE_SKILL];
  const skills = registered.map(skill => ({ id: skill.id, version: skill.version, name: skill.title,
    application: skill.sourceApplication, capability: skill.capability, scope: skill.scope }));
  for (const skill of registered) {
    const capability = applications.find(app => app.id === skill.sourceApplication)?.capabilities.find(item => item.id === skill.capability);
    if (!capability || capability.scope !== skill.scope || capability.protocol.version !== (skill.sourceProtocol ?? 1)) {
      throw new Error("Application catalog does not match the reviewed skill registry.");
    }
  }
  for (const app of applications) for (const capability of app.capabilities) {
    if (!skills.some(skill => skill.application === app.id && skill.capability === capability.id)) {
      throw new Error("Application capability has no reviewed runtime binding.");
    }
  }
  return { schemaVersion: 1, applications, skills };
}
