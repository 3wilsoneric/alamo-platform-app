import { maintenanceObject as object, maintenanceId as id, maintenanceDigest as digest, maintenanceHash as hash, maintenanceInteger as integer, maintenanceText as text } from './proforma-maintenance-contracts.mjs';

const invalid = () => { throw new Error('Invalid ProForma guidance discovery.'); };
export const PROFORMA_GUIDANCE_CAPABILITY = Object.freeze({ id: 'proforma.guidance.discover', version: 1,
  operation: 'read', scope: 'source-user', protocol: { id: 'proforma-guidance', version: 1 }, resourceKinds: ['published-guide'] });

export function guidanceRequest(binding, query = '', limit = 5) {
  if (typeof query !== 'string' || query.length > 500 || query.includes('\0') || !Number.isSafeInteger(limit) || limit < 1 || limit > 10) invalid();
  return { schemaVersion: 1, documentIds: [...binding.documentIds].sort(), query: query.trim(), limit };
}

// An agent may choose a view from a fixed module library, never arbitrary HTML,
// executable code or a source-supplied URL. The owning app checks access on open.
export function validateGuidanceDiscovery(input, binding, request) {
  const v = object(input, ['schemaVersion','kind','producer','scope','actorId','request','documents','matchedCount','limited','unavailableDocumentIds','canExecute','discoveryHash']);
  if (Buffer.byteLength(JSON.stringify(v)) > 524288 || v.schemaVersion !== 1 || v.kind !== 'proforma.guidance-discovery' || v.producer !== 'ProForma' ||
    v.actorId !== binding.actorId || hash(v.scope) !== hash(binding.scope) || hash(v.request) !== hash(request) || v.canExecute !== false) invalid();
  const { discoveryHash, ...payload } = v;
  if (digest(discoveryHash) !== hash(payload) || !Array.isArray(v.documents) || v.documents.length > request.limit ||
    !Number.isSafeInteger(v.matchedCount) || v.matchedCount < v.documents.length || v.matchedCount > request.documentIds.length || v.limited !== (v.matchedCount > v.documents.length) ||
    !Array.isArray(v.unavailableDocumentIds) || v.unavailableDocumentIds.length > request.documentIds.length) invalid();
  const seen = new Set();
  for (const document of v.documents) {
    object(document, ['source','title','kind','status','contentRevision','publicationRevision','publishedAt','view']);
    const s = object(document.source, ['documentId','publicationId','fingerprint']); id(s.documentId); id(s.publicationId); digest(s.fingerprint);
    if (!request.documentIds.includes(s.documentId) || seen.has(s.documentId)) invalid(); seen.add(s.documentId);
    text(document.title, 160); integer(document.contentRevision); integer(document.publicationRevision);
    if (!['procedure','policy','tutorial'].includes(document.kind) || document.status !== 'published' || document.contentRevision > document.publicationRevision ||
      typeof document.publishedAt !== 'string' || !Number.isFinite(Date.parse(document.publishedAt))) invalid();
    const view = object(document.view, ['module','version','href']);
    const href = `/workflow?${new URLSearchParams({ view: 'training', publication: s.publicationId, fingerprint: s.fingerprint })}`;
    if (view.module !== 'proforma.publication-reader' || view.version !== 1 || view.href !== href) invalid();
  }
  for (const value of v.unavailableDocumentIds) {
    id(value); if (!request.documentIds.includes(value) || seen.has(value)) invalid(); seen.add(value);
  }
  if (v.matchedCount + v.unavailableDocumentIds.length > request.documentIds.length) invalid();
  return structuredClone(v);
}
