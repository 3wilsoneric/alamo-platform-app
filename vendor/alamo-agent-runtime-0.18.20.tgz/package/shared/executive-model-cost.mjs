// Standard token rates verified November 22, 2026. Cached-input discounts are
// deliberately ignored, so this bound never assumes a cache discount.
export const executiveModelPricing = Object.freeze({model:'gpt-6.1-sol',currency:'USD',inputMicrodollars:2,outputMicrodollars:10,checkedAt:'2026-11-22'});
export const EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS = 6000;
export function executiveModelCost(input, output) {
  if (!Number.isSafeInteger(input) || input < 0 || input > 200256 || !Number.isSafeInteger(output) || output < 0 || output > EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS) throw Error('Invalid model usage.');
  return input * executiveModelPricing.inputMicrodollars + output * executiveModelPricing.outputMicrodollars;
}
