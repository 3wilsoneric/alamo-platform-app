import { createHash } from 'node:crypto';
import { foundationObject } from './foundation-contracts.mjs';

export const EXECUTIVE_REPORT_PATH = '/api/agent/v1/reports';
export const EXECUTIVE_REPORT_SOURCE_PATH = '/api/platform/ally-source/v1';
export const REPORT_TERMINAL = new Set(['ready', 'partial', 'failed', 'cancelled', 'paused']);
// Bump when validation or synthesis-context semantics change. Cached proposals
// are still revalidated; this revision prevents reuse across policy changes.
export const REPORT_CACHE_VERSION = 'executive-report-cache-v6';
export const reportHash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
/** @returns {never} */
const invalid = () => { throw new Error('Invalid executive report contract.'); };
/** @returns {Record<string, any>} */
export function reportObject(value, required, optional = []) {
  const present = optional.filter(key => value && Object.hasOwn(value, key));
  return foundationObject(value, [...required, ...present]);
}
const object = reportObject;
export function reportId(value) {
  if (typeof value !== 'string' || !/^[a-f0-9]{64}$/.test(value)) return invalid();
  return value;
}
export function reportSubject(value) {
  if (typeof value !== 'string' || !/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value)) return invalid();
  return value;
}
export function reportText(value, max = 2000) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)) return invalid();
  return value;
}
export function reportJson(value, max = 80_000) {
  const visit = (v, depth) => {
    if (depth > 12 || typeof v === 'number' && !Number.isFinite(v)) return invalid();
    if (v === null || ['string', 'boolean', 'number'].includes(typeof v)) return;
    if (!v || typeof v !== 'object' || Object.getPrototypeOf(v) !== (Array.isArray(v) ? Array.prototype : Object.prototype)) return invalid();
    for (const [key, item] of Object.entries(v)) {
      if (['__proto__', 'constructor', 'prototype'].includes(key)) return invalid();
      visit(item, depth + 1);
    }
  };
  visit(value, 0);
  if (Buffer.byteLength(JSON.stringify(value)) > max) return invalid();
  return structuredClone(value);
}
export function validateReportScope(input) {
  const v = object(input, ['communityIds', 'from', 'through']);
  if (!Array.isArray(v.communityIds) || v.communityIds.length > 25 || new Set(v.communityIds).size !== v.communityIds.length ||
      v.communityIds.some(id => typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(id))) return invalid();
  for (const key of ['from', 'through']) {
    if (typeof v[key] !== 'string' || !/^20\d{2}-\d{2}-\d{2}$/.test(v[key]) || new Date(`${v[key]}T00:00:00Z`).toISOString().slice(0, 10) !== v[key]) return invalid();
  }
  if (v.from > v.through) return invalid();
  return { communityIds: [...v.communityIds].sort(), from: v.from, through: v.through };
}
export function validateReportCreate(input) {
  const v = object(input, ['requestId', 'objective', 'scope']);
  return { requestId: reportSubject(v.requestId), objective: reportText(v.objective), scope: validateReportScope(v.scope) };
}
export function validateReportCommand(input) {
  const extra = input?.action === 'followup' ? ['requestId', 'objective', 'scope'] : input?.action === 'refresh' ? ['requestId'] :
    ['share', 'unshare'].includes(input?.action) ? ['readerId'] : [];
  const v = object(input, ['ownerId', 'id', 'revision', 'action', ...extra]);
  reportSubject(v.ownerId); reportId(v.id);
  if (!['refresh', 'followup', 'resume', 'cancel', 'share', 'unshare'].includes(v.action) || !Number.isSafeInteger(v.revision) || v.revision < 1) return invalid();
  if (v.requestId !== undefined) reportSubject(v.requestId);
  if (v.readerId !== undefined) reportSubject(v.readerId);
  if (v.objective !== undefined) reportText(v.objective);
  if (v.scope !== undefined) v.scope = validateReportScope(v.scope);
  return reportJson(v, 10_000);
}
export function validateReportPlan(input, catalog) {
  const v = object(input, ['steps', 'gaps']);
  // Pure user-supplied scenarios need no source read. Findings still require
  // cited evidence or exact quoted assumptions and verified arithmetic.
  if (!Array.isArray(v.steps) || v.steps.length > 6 || !Array.isArray(v.gaps) || v.gaps.length > 8) return invalid();
  const capabilities = new Set(catalog.map(c => c.id));
  const steps = v.steps.map((raw, i) => {
    const s = object(raw, ['capability', 'input'], ['scope']);
    if (!capabilities.has(s.capability)) return invalid();
    object(s.input, Object.keys(s.input));
    return { id: `source-${i + 1}`, capability: s.capability, input: reportJson(s.input, 8000),
      ...(s.scope !== undefined ? { scope: validateReportScope(s.scope) } : {}) };
  });
  if (new Set(steps.map(s => reportHash([s.capability, s.input, s.scope ?? null]))).size !== steps.length) return invalid();
  return { steps, gaps: v.gaps.map(gap => reportText(gap, 400)) };
}
export function validateReportEvidence(input, step, scope) {
  const v = object(input, ['capability', 'inputHash', 'scope', 'revision', 'grantRevision', 'requiresDetail', 'observedAt', 'period', 'grain', 'status', 'title', 'answer', 'note'], ['dataset', 'coverage']);
  if (v.capability !== step.capability || v.inputHash !== reportHash(step.input) || reportHash(validateReportScope(v.scope)) !== reportHash(step.scope ?? scope) ||
      typeof v.requiresDetail !== 'boolean' || !['verified', 'unavailable'].includes(v.status) || !Number.isFinite(Date.parse(v.observedAt))) return invalid();
  reportId(v.revision); reportId(v.grantRevision); reportText(v.period, 120); reportText(v.grain, 120);
  reportText(v.title, 240); reportText(v.note, 600);
  if (v.status === 'verified') reportText(v.answer, 16_000);
  else if (v.answer !== null || v.dataset !== undefined) return invalid();
  if (v.coverage !== undefined && !['complete', 'partial'].includes(v.coverage)) return invalid();
  if (v.dataset !== undefined) {
    const d = object(v.dataset, ['title', 'shape', 'columns', 'rows']);
    reportText(d.title, 240);
    if (!['records', 'categories', 'series'].includes(d.shape) || !Array.isArray(d.columns) || !d.columns.length || d.columns.length > 40 ||
        !Array.isArray(d.rows) || d.rows.length > 100 || new Set(d.columns.map(c => c.key)).size !== d.columns.length) return invalid();
    for (const c of d.columns) {
      object(c, ['key', 'label', 'type']); reportText(c.label, 120);
      if (!/^[A-Za-z_][A-Za-z0-9_]{0,79}$/.test(c.key) || !['string', 'number'].includes(c.type)) return invalid();
    }
    for (const row of d.rows) {
      object(row, d.columns.map(c => c.key));
      for (const c of d.columns) if (row[c.key] !== null && (c.type === 'number' ? typeof row[c.key] !== 'number' || !Number.isFinite(row[c.key]) : !['string', 'number', 'boolean'].includes(typeof row[c.key]))) return invalid();
    }
  }
  return reportJson(v, 70_000);
}
export function isReportBlobPath(value) {
  return /^everyagent\/reports-v1\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/(?:index|model|spend-20\d{2}-\d{2}-\d{2}|credits-20\d{6}|[a-f0-9]{64})\.json$/.test(value);
}
