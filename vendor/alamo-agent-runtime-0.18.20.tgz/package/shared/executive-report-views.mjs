export { applyViewCalculations } from '../packages/ally-core/dist/on-demand-view.js';
import { compileViewPlan, selectViewComponents } from '../packages/ally-core/dist/on-demand-view.js';

// Reviewed Platform renderers. No model HTML, CSS, routes, queries or values.
/** @type {import('../packages/ally-core/dist/on-demand-view.js').ViewComponentManifest[]} */
export const EXECUTIVE_REPORT_VIEWS = [
  { id: 'table', version: 'v1', purpose: 'Exact values and record detail', tags: ['table', 'detail', 'list'], shapes: ['records', 'categories', 'series'], maxRows: 100, hosts: ['platform'] },
  { id: 'comparison', version: 'v1', purpose: 'Compare labeled counts within the same source', tags: ['compare', 'community', 'stage'], shapes: ['categories'], maxRows: 20, hosts: ['platform'] },
  { id: 'trend', version: 'v1', purpose: 'Show one numeric measure over dated observations', tags: ['trend', 'time', 'change'], shapes: ['series'], maxRows: 100, hosts: ['platform'] }
];
export function reportViewContext(evidence, scopeKey, objective) {
  const datasets = evidence.filter(e => e.value.dataset).map(e => ({ id: e.sourceId, shape: e.value.dataset.shape,
    columnKeys: e.value.dataset.columns.map(column => column.key),
    numericKeys: e.value.dataset.columns.filter(column => column.type === 'number').map(column => column.key),
    rowCount: e.value.dataset.rows.length, scopeKey, sourceIds: [e.sourceId], observedAt: e.value.observedAt,
    coverage: e.value.coverage === 'partial' ? 'partial' : 'verified' }));
  return { host: 'platform', scopeKey, datasets, catalog: selectViewComponents(objective, 'platform', datasets, EXECUTIVE_REPORT_VIEWS) };
}
export function reportViewPlan(proposal, context) {
  if (!context.datasets.length) return null;
  // An explicit empty selection means prose only. The exact source datasets
  // remain in the saved report and reader; null still means legacy table fallback.
  if(proposal?.version==='1.0' && Object.keys(proposal).sort().join(',')==='blocks,version' && Array.isArray(proposal.blocks) && proposal.blocks.length===0) return {version:'1.0',blocks:[]};
  return compileViewPlan(proposal ?? { version: '1.0', blocks: context.datasets.map(d => ({ id: `view-${d.id}`, datasetId: d.id, componentId: 'table' })) }, context);
}
