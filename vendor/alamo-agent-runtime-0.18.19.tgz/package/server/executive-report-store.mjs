import path from 'node:path';
import {executiveModelPricing,executiveModelCost} from '../shared/executive-model-cost.mjs';
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
import { isProductionLikeRuntime } from './runtime-environment.mjs';
import { reportId, reportSubject, reportJson, reportHash, validateReportScope, reportText, reportObject } from '../shared/executive-report-contracts.mjs';
import { createHttpError } from './http-error-contract.mjs';
import { EVERYAGENT_TENANT } from '../shared/everyagent-identity.mjs';

function validate(state) {
  if (/^(?:spend-20\d{2}-\d{2}-\d{2}|credits-20\d{6})$/.test(state.id)) {
    const prepaid=state.id.startsWith('credits-');
    reportObject(state,['schemaVersion','revision','ownerId','id','pricing','requests'],prepaid?['creditAllowance']:[]);
    if(prepaid){
      const grant=reportObject(state.creditAllowance,['id','limitMicrodollars','validFrom','expiresAt']);
      if(grant.id!==state.id||!Number.isSafeInteger(grant.limitMicrodollars)||grant.limitMicrodollars<=0||!Number.isFinite(Date.parse(grant.validFrom))||!(Date.parse(grant.expiresAt)>Date.parse(grant.validFrom)))throw Error('Invalid prepaid report allowance.');
    }
    if(state.ownerId!==EVERYAGENT_TENANT||reportHash(state.pricing)!==reportHash(executiveModelPricing)||!Array.isArray(state.requests)||state.requests.length>(prepaid?20000:1000)||new Set(state.requests.map(r=>r.token)).size!==state.requests.length)throw Error('Report spend ledger is unavailable.');
    for(const r of state.requests){
      reportObject(r,['token','at','inputTokens','maxOutputTokens','reservedMicrodollars','actualMicrodollars']);reportSubject(r.token);
      if(!Number.isSafeInteger(r.inputTokens)||r.inputTokens<0||!Number.isFinite(Date.parse(r.at))||(!prepaid && 'spend-'+r.at.slice(0,10)!==state.id)||prepaid&&(Date.parse(r.at)<Date.parse(state.creditAllowance.validFrom)||Date.parse(r.at)>=Date.parse(state.creditAllowance.expiresAt))||r.maxOutputTokens<1||r.reservedMicrodollars!==executiveModelCost(r.inputTokens+256,r.maxOutputTokens)||r.actualMicrodollars!==null&&(!Number.isSafeInteger(r.actualMicrodollars)||r.actualMicrodollars<0||r.actualMicrodollars>r.reservedMicrodollars))throw Error('Invalid report spend receipt.');
    }
    return;
  }
  if (state.id === 'model') {
    reportObject(state, ['schemaVersion', 'revision', 'ownerId', 'id', 'leases']);
    if (state.ownerId !== EVERYAGENT_TENANT || !Array.isArray(state.leases) || state.leases.length > 2 ||
        new Set(state.leases.map(l => l.subject)).size !== state.leases.length) throw new Error('Report model queue is unavailable.');
    for (const lease of state.leases) {
      reportObject(lease, ['subject', 'token', 'until']); reportSubject(lease.subject); reportSubject(lease.token);
      if (!Number.isFinite(lease.until)) throw new Error('Report model queue is unavailable.');
    }
    return;
  }
  if (state.id === 'index') {
    reportObject(state, ['schemaVersion', 'revision', 'ownerId', 'id', 'entries'], ['budget']);
    if (!Array.isArray(state.entries) || state.entries.length > 100 || new Set(state.entries.map(e => `${e.ownerId}:${e.id}`)).size !== state.entries.length) throw new Error('Report index is unavailable.');
    for (const e of state.entries) { reportObject(e, ['ownerId', 'id']); reportSubject(e.ownerId); reportId(e.id); }
    if (state.budget) {
      reportObject(state.budget, ['day', 'requests']);
      if (!/^20\d{2}-\d{2}-\d{2}$/.test(state.budget.day) || !Array.isArray(state.budget.requests) || state.budget.requests.length > 100 || new Set(state.budget.requests).size !== state.budget.requests.length) throw Error('Report budget is unavailable.');
      state.budget.requests.forEach(reportId);
    }
    return;
  }
  reportObject(state, ['schemaVersion', 'revision', 'id', 'ownerId', 'tenantId', 'createdAt', 'readers', 'runs']);
  reportSubject(state.tenantId);
  if (!Array.isArray(state.readers) || state.readers.length > 10 || new Set(state.readers).size !== state.readers.length ||
      !Array.isArray(state.runs) || !state.runs.length || state.runs.length > 12) throw new Error('Report state is unavailable.');
  state.readers.forEach(reportSubject);
  for (const run of state.runs) {
    reportSubject(run.id); reportSubject(run.requestId); reportId(run.requestHash); reportText(run.objective); validateReportScope(run.scope);
    if (!['queued', 'reading', 'analyzing', 'ready', 'partial', 'paused', 'failed', 'cancelled'].includes(run.status) ||
        !Number.isSafeInteger(run.attempt) || run.attempt < 0 || !Array.isArray(run.evidence) || run.evidence.length > 6 ||
        !Number.isFinite(run.deadline) || !Number.isFinite(Date.parse(run.createdAt)) || !Number.isFinite(Date.parse(run.updatedAt)) ||
        ['ready', 'partial'].includes(run.status) && !run.artifact) throw new Error('Report run is unavailable.');
    if (run.synthesisCache) {
      reportObject(run.synthesisCache, ['key', 'proposal', 'createdAt']); reportId(run.synthesisCache.key);
      reportJson(run.synthesisCache.proposal, 80_000);
      if (run.status !== 'ready' || !Number.isFinite(run.synthesisCache.createdAt)) throw new Error('Report answer cache is unavailable.');
    }
  }
}

// Reuse conditional Blob writes/file locks. Each report is isolated; no source
// credential is persisted. The index is only a discovery/queue hint, never ACL.
export function createExecutiveReportStore({ azure = isProductionLikeRuntime(), localRoot = path.resolve('generated'), persistenceFor = createEveryAgentPersistence } = {}) {
  const pendingUpdates = new Map();
  function target(ownerId, id) {
    reportSubject(ownerId); if (!['index', 'model'].includes(id) && !/^(?:spend-20\d{2}-\d{2}-\d{2}|credits-20\d{6})$/.test(id)) reportId(id);
    const blobPath = `everyagent/reports-v1/${ownerId}/${id}.json`;
    return persistenceFor({ azure, blobPath, localPath: path.join(localRoot, blobPath) });
  }
  async function read(ownerId, id) {
    const snapshot = await target(ownerId, id).read();
    if (snapshot.value && (snapshot.value.schemaVersion !== 1 || !Number.isSafeInteger(snapshot.value.revision) || snapshot.value.revision < 1 ||
        snapshot.value.ownerId !== ownerId || snapshot.value.id !== id)) throw new Error('Report state is unavailable.');
    if (snapshot.value) { reportJson(snapshot.value, snapshot.value.id.startsWith('credits-')?8_000_000:4_000_000); validate(snapshot.value); }
    return snapshot;
  }
  function update(ownerId, id, mutate) {
    const key = `${ownerId}/${id}`;
    // Serialize this host's writers before taking a snapshot. Conditional writes
    // still arbitrate other processes; local bursts must not exhaust their retries.
    const pending = (pendingUpdates.get(key) ?? Promise.resolve()).then(() => updateConditional(ownerId, id, mutate));
    const settled = pending.then(() => {}, () => {}).finally(() => {
      if (pendingUpdates.get(key) === settled) pendingUpdates.delete(key);
    });
    pendingUpdates.set(key, settled);
    return pending;
  }
  async function updateConditional(ownerId, id, mutate) {
    for (let attempt = 0; attempt < 8; attempt++) {
      const { value, version } = await read(ownerId, id), next = structuredClone(value);
      const updated = await mutate(next);
      if (updated === null) return value;
      if (updated.ownerId !== ownerId || updated.id !== id || updated.revision !== (value?.revision ?? 0)) throw new Error('Invalid report state transition.');
      updated.schemaVersion = 1; updated.revision++;
      reportJson(updated, updated.id.startsWith('credits-')?8_000_000:4_000_000); validate(updated);
      if (value && (value.id.startsWith('spend-') || value.id.startsWith('credits-'))) {
        if(reportHash(updated.creditAllowance??null)!==reportHash(value.creditAllowance??null))throw Error('Prepaid allowance is immutable.');
        if(updated.requests.length<value.requests.length||reportHash(updated.pricing)!==reportHash(value.pricing))throw Error('Spend history cannot be removed.');
        for(const [i,before] of value.requests.entries()){
          const {actualMicrodollars,...immutable}=before,{actualMicrodollars:nextActual,...nextImmutable}=updated.requests[i];
          if(reportHash(immutable)!==reportHash(nextImmutable)||actualMicrodollars!==null&&nextActual!==actualMicrodollars)throw Error('Spend history is immutable.');
        }
      }
      if (value?.runs) {
        if (updated.runs.length < value.runs.length) throw new Error('Report history cannot be removed.');
        for (const [i, before] of value.runs.entries()) {
          const after = updated.runs[i];
          for (const key of ['id', 'requestId', 'requestHash', 'objective', 'scope', 'createdAt', 'previousVersion']) {
            if (reportHash(before[key]) !== reportHash(after[key])) throw new Error('Report history is immutable.');
          }
          if (before.artifact && reportHash(before.artifact) !== reportHash(after.artifact)) throw new Error('Saved report versions are immutable.');
          if (before.view && reportHash(before.view) !== reportHash(after.view)) throw new Error('Saved report views are immutable.');
          if (before.synthesisCache && reportHash(before.synthesisCache) !== reportHash(after.synthesisCache)) throw new Error('Saved answer proposals are immutable.');
          if (before.evidence.some((e, j) => reportHash(e) !== reportHash(after.evidence[j] ?? null))) throw new Error('Saved report evidence is immutable.');
        }
      }
      try { await target(ownerId, id).write(updated, version); return updated; }
      catch (error) {
        if (!(error && typeof error === 'object' && 'code' in error && error.code === 'EVERYAGENT_CONFLICT') || attempt === 7) throw error;
        await new Promise(resolve => setTimeout(resolve, 10 * (attempt + 1)));
      }
    }
    throw new Error('Report could not be saved.');
  }
  async function index(subject, ownerId, id) {
    reportSubject(ownerId); reportId(id);
    return update(subject, 'index', state => {
      state ??= { schemaVersion: 1, revision: 0, ownerId: subject, id: 'index', entries: [] };
      if (state.entries.some(e => e.ownerId === ownerId && e.id === id)) return null;
      if (state.entries.length >= 100) throw new Error('Saved report capacity reached.');
      state.entries.push({ ownerId, id }); return state;
    });
  }
  async function reserveExecution(subject, key, now) {
    reportId(key);
    const day = new Date(now).toISOString().slice(0, 10);
    await update(subject, 'index', state => {
      state ??= {schemaVersion:1,revision:0,ownerId:subject,id:'index',entries:[]};
      if (state.budget?.day !== day) state.budget = {day,requests:[]};
      if (state.budget.requests.includes(key)) return null;
      if (state.budget.requests.length >= 100) throw createHttpError(429,'report_budget','The daily investigation limit has been reached. Saved reports remain available.');
      state.budget.requests.push(key); return state;
    });
  }
  // One shared conditional write covers all report workers and owners. Keep this
  // outside the report index so older runtimes can still reopen saved reports.
  async function claimModel(subject, token, now, leaseMs) {
    reportSubject(subject); reportSubject(token);
    if (!Number.isFinite(now) || !Number.isFinite(leaseMs) || leaseMs <= 0 || leaseMs > 90_000) throw new Error('Invalid report model lease.');
    const state = await update(EVERYAGENT_TENANT, 'model', current => {
      current ??= { schemaVersion: 1, revision: 0, ownerId: EVERYAGENT_TENANT, id: 'model', leases: [] };
      current.leases = current.leases.filter(l => l.until > now);
      if (current.leases.length >= 2 || current.leases.some(l => l.subject === subject)) return null;
      current.leases.push({ subject, token, until: now + leaseMs }); return current;
    });
    return state?.leases.some(l => l.token === token) === true;
  }
  async function releaseModel(token) {
    reportSubject(token);
    await update(EVERYAGENT_TENANT, 'model', state => {
      if (!state?.leases.some(l => l.token === token)) return null;
      state.leases = state.leases.filter(l => l.token !== token); return state;
    });
  }
  async function cachedSynthesis(subject, key, now) {
    reportId(key);
    const entries = (await read(subject, 'index')).value?.entries ?? [];
    // Deliberately bounded to the last twenty owned reports and fifteen minutes.
    // No copied answer store, cross-user lookup, or sliding expiration.
    for (const entry of entries.filter(e => e.ownerId === subject).slice(-20).reverse()) {
      const state = (await read(subject, entry.id)).value;
      if (!state || state.tenantId !== EVERYAGENT_TENANT) continue;
      for (const run of [...state.runs].reverse()) {
        const cache = run.synthesisCache;
        if (run.status === 'ready' && cache?.key === key && now >= cache.createdAt && now - cache.createdAt < 15 * 60_000) {
          return { proposal: cache.proposal, reportId: state.id, runId: run.id };
        }
      }
    }
    return null;
  }
  return { read, update, index, reserveExecution, claimModel, releaseModel, cachedSynthesis };
}
