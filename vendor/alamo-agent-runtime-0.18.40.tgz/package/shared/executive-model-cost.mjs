// Standard token rates verified November 22, 2026. Cached-input discounts are
// deliberately ignored, so this bound never assumes a cache discount.
export const executiveModelPricing = Object.freeze({model:'gpt-6.1-sol',currency:'USD',inputMicrodollars:2,outputMicrodollars:10,checkedAt:'2026-11-22'});
export const EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS = 6000;
// Native Codex uses the provider's model limits, not the legacy short-report
// output ceiling. Keep the old ledger's validator/rates unchanged for live readers.
export const CODEX_MODEL_CONTEXT_TOKENS = 1050000;
export const CODEX_MODEL_OUTPUT_TOKENS = 128000;
export function codexModelReceiptCost(usage) {
  const input=usage?.input_tokens,output=usage?.output_tokens;
  if(!Number.isSafeInteger(input)||input<0||input>CODEX_MODEL_CONTEXT_TOKENS||
    !Number.isSafeInteger(output)||output<0||output>CODEX_MODEL_OUTPUT_TOKENS)throw Error('Invalid native model usage.');
  const long=input>272000,details=usage.input_tokens_details;
  let inputCost=input*2.5;
  if(details?.cache_write_tokens!==undefined && details?.cached_tokens!==undefined){
    const writes=details.cache_write_tokens,cached=details.cached_tokens;
    if(!Number.isSafeInteger(writes)||writes<0||!Number.isSafeInteger(cached)||cached<0||writes+cached>input)
      throw Error('Invalid model cache usage.');
    inputCost=(input-writes-cached)*2+writes*2.5+cached*0.1;
  }
  return Math.ceil(inputCost*(long?2:1)+output*10*(long?1.5:1));
}
// One recoverable task window. A model exchange is cancelled by the host's
// deadline/lease checks, not by an unrelated one-minute transport timeout.
export const EXECUTIVE_REPORT_EXECUTION_MS = 20 * 60_000;
export function executiveModelCost(input, output) {
  if (!Number.isSafeInteger(input) || input < 0 || input > 200256 || !Number.isSafeInteger(output) || output < 0 || output > EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS) throw Error('Invalid model usage.');
  return input * executiveModelPricing.inputMicrodollars + output * executiveModelPricing.outputMicrodollars;
}

// Current Standard pricing includes cache writes at 1.25× input and reads at
// 0.05×. A receipt without cache details gets the maximum input rate, never an
// assumed discount. Keep historical ledger pricing/receipts unchanged.
export function executiveModelReceiptCost(usage) {
  executiveModelCost(usage.input_tokens,usage.output_tokens);
  const details=usage.input_tokens_details;
  if (!details || details.cache_write_tokens===undefined || details.cached_tokens===undefined)
    return Math.ceil(usage.input_tokens*2.5+usage.output_tokens*10);
  const writes=details.cache_write_tokens,cached=details.cached_tokens;
  if (!Number.isSafeInteger(writes)||writes<0||!Number.isSafeInteger(cached)||cached<0||writes+cached>usage.input_tokens)
    throw Error('Invalid model cache usage.');
  return Math.ceil((usage.input_tokens-writes-cached)*2+writes*2.5+cached*0.1+usage.output_tokens*10);
}
