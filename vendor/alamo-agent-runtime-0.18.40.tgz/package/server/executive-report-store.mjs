import path from 'node:path';
import {executiveModelPricing,executiveModelCost} from '../shared/executive-model-cost.mjs';
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
import { isProductionLikeRuntime } from './runtime-environment.mjs';
import { reportId, reportSubject, reportJson, reportHash, validateReportScope, reportText, reportObject, validateReportEvidence, validateInvestigationBrief } from '../shared/executive-report-contracts.mjs';
import {validateInvestigationSession} from './executive-investigation-session.mjs';
import { EVERYAGENT_TENANT } from '../shared/everyagent-identity.mjs';
import { validateSavedReportEvidence } from './executive-saved-report.mjs';

function validate(state) {
  if (/^(?:spend-20\d{2}-\d{2}-\d{2}|credits-20\d{6})$/.test(state.id)) {
    const prepaid=state.id.startsWith('credits-');
    reportObject(state,['schemaVersion','revision','ownerId','id','pricing','requests'],prepaid?['creditAllowance']:[]);
    if(prepaid){
      const grant=reportObject(state.creditAllowance,['id','limitMicrodollars','validFrom','expiresAt']);
      if(grant.id!==state.id||!Number.isSafeInteger(grant.limitMicrodollars)||grant.limitMicrodollars<=0||!Number.isFinite(Date.parse(grant.validFrom))||!(Date.parse(grant.expiresAt)>Date.parse(grant.validFrom)))throw Error('Invalid prepaid report allowance.');
    }
    if(state.ownerId!==EVERYAGENT_TENANT||reportHash(state.pricing)!==reportHash(executiveModelPricing)||!Array.isArray(state.requests)||state.requests.length>(prepaid?20000:1000)||new Set(state.requests.map(r=>r.token)).size!==state.requests.length)throw Error('Report spend ledger is unavailable.');
    for(const r of state.requests){
      reportObject(r,['token','at','inputTokens','maxOutputTokens','reservedMicrodollars','actualMicrodollars']);reportSubject(r.token);
      if(!Number.isSafeInteger(r.inputTokens)||r.inputTokens<0||!Number.isFinite(Date.parse(r.at))||(!prepaid && 'spend-'+r.at.slice(0,10)!==state.id)||prepaid&&(Date.parse(r.at)<Date.parse(state.creditAllowance.validFrom)||Date.parse(r.at)>=Date.parse(state.creditAllowance.expiresAt))||r.maxOutputTokens<1||r.reservedMicrodollars!==executiveModelCost(r.inputTokens+256,r.maxOutputTokens)||r.actualMicrodollars!==null&&(!Number.isSafeInteger(r.actualMicrodollars)||r.actualMicrodollars<0||r.actualMicrodollars>r.reservedMicrodollars))throw Error('Invalid report spend receipt.');
    }
    return;
  }
  if (state.id === 'model') {
    reportObject(state, ['schemaVersion', 'revision', 'ownerId', 'id', 'leases']);
    if (state.ownerId !== EVERYAGENT_TENANT || !Array.isArray(state.leases) || state.leases.length > 2 ||
        new Set(state.leases.map(l => l.subject)).size !== state.leases.length) throw new Error('Report model queue is unavailable.');
    for (const lease of state.leases) {
      reportObject(lease, ['subject', 'token', 'until']); reportSubject(lease.subject); reportSubject(lease.token);
      if (!Number.isFinite(lease.until)) throw new Error('Report model queue is unavailable.');
    }
    return;
  }
  if (state.id === 'index') {
    reportObject(state, ['schemaVersion', 'revision', 'ownerId', 'id', 'entries'], ['budget']);
    if (!Array.isArray(state.entries) || new Set(state.entries.map(e => `${e.ownerId}:${e.id}`)).size !== state.entries.length) throw new Error('Report index is unavailable.');
    for (const e of state.entries) { reportObject(e, ['ownerId', 'id']); reportSubject(e.ownerId); reportId(e.id); }
    if (state.budget) {
      reportObject(state.budget, ['day', 'requests']);
      if (!/^20\d{2}-\d{2}-\d{2}$/.test(state.budget.day) || !Array.isArray(state.budget.requests) || new Set(state.budget.requests).size !== state.budget.requests.length) throw Error('Report budget is unavailable.');
      state.budget.requests.forEach(reportId);
    }
    return;
  }
  reportObject(state, ['schemaVersion', 'revision', 'id', 'ownerId', 'tenantId', 'createdAt', 'readers', 'runs']);
  reportSubject(state.tenantId);
  if (!Array.isArray(state.readers) || state.readers.length > 10 || new Set(state.readers).size !== state.readers.length ||
      !Array.isArray(state.runs) || !state.runs.length) throw new Error('Report state is unavailable.');
  state.readers.forEach(reportSubject);
  for (const run of state.runs) {
    reportSubject(run.id); reportSubject(run.requestId); reportId(run.requestHash); reportText(run.objective); validateReportScope(run.scope);
    if (run.investigation !== undefined) validateInvestigationBrief(run.investigation);
    if (run.agentSession !== undefined) validateInvestigationSession(run.agentSession);
    if (!['queued', 'reading', 'analyzing', 'ready', 'partial', 'paused', 'failed', 'cancelled'].includes(run.status) ||
        !Number.isSafeInteger(run.attempt) || run.attempt < 0 || !Array.isArray(run.evidence) ||
        !Number.isFinite(run.deadline) || !Number.isFinite(Date.parse(run.createdAt)) || !Number.isFinite(Date.parse(run.updatedAt)) ||
        ['ready', 'partial'].includes(run.status) && !run.artifact) throw new Error('Report run is unavailable.');
    if(run.savedReports!==undefined) {
      if(!Array.isArray(run.savedReports)||new Set(run.savedReports.map(r=>r.sourceId)).size!==run.savedReports.length)throw Error('Invalid saved report references.');
      run.savedReports.forEach(validateSavedReportEvidence);
    }
    if (run.computations !== undefined) {
      if (!Array.isArray(run.computations)) throw Error('Invalid stored computations.');
      const prior=[...run.evidence,...(run.savedReports ?? [])];
      for (const item of run.computations) {
        reportObject(item,['sourceId','value','proof']);reportObject(item.proof,['code','sources']);reportText(item.proof.code,12000);
        if (!Array.isArray(item.proof.sources) || !item.proof.sources.length) throw Error('Invalid computation inputs.');
        for(const ref of item.proof.sources) {
          reportObject(ref,['id','revision']);
          if(!prior.some(input=>input.sourceId===ref.id && input.value.revision===ref.revision))throw Error('Computation evidence changed.');
        }
        const output=JSON.parse(item.value.answer);
        const hash=reportHash({proof:item.proof,output:{result:output.result,...(item.value.dataset?{dataset:item.value.dataset}:{})}});
        if(item.value.revision!==hash || item.sourceId!==`analysis-${hash.slice(0,12)}` || prior.some(input=>input.sourceId===item.sourceId))throw Error('Invalid computation receipt.');
        // A follow-up may retain a computation from an earlier scope. Its
        // original scope stays unchanged; source grants and immutable input
        // revisions establish access, never the new page's selection.
        validateReportEvidence(item.value,{capability:'computed-analysis',input:item.proof,scope:item.value.scope},run.scope);
        prior.push(item);
      }
    }
    if (run.synthesisCache) {
      reportObject(run.synthesisCache, ['key', 'proposal', 'createdAt']); reportId(run.synthesisCache.key);
      reportJson(run.synthesisCache.proposal, 80_000);
      if (run.status !== 'ready' || !Number.isFinite(run.synthesisCache.createdAt)) throw new Error('Report answer cache is unavailable.');
    }
  }
}

// Reuse conditional Blob writes/file locks. Each report is isolated; no source
// credential is persisted. The index is only a discovery/queue hint, never ACL.
export function createExecutiveReportStore({ azure = isProductionLikeRuntime(), localRoot = path.resolve('generated'), persistenceFor = createEveryAgentPersistence,
  partitionReports = !azure || process.env.ALLY_REPORT_PARTITIONED_STORAGE === 'true' } = {}) {
  const pendingUpdates = new Map();
  const arrayFields=['evidence','computations','savedReports'];
  const objectFields=['agentSession','artifact','view','findingProofs','synthesisCache'];
  // Content-addressed objects are immutable. This bounded cache avoids fetching
  // the same original evidence at every heartbeat; it never caches source grants.
  /** @type {Map<string,{value:any,bytes:number}>} */
  const objects=new Map();let cachedBytes=0;
  function remember(key,value){
    const bytes=Buffer.byteLength(JSON.stringify(value));
    const previous=objects.get(key);if(previous){cachedBytes-=previous.bytes;objects.delete(key);}
    while(objects.size && cachedBytes+bytes>8_000_000){const oldest=objects.entries().next().value;if(!oldest)break;cachedBytes-=oldest[1].bytes;objects.delete(oldest[0]);}
    if(bytes<=8_000_000){objects.set(key,{value:structuredClone(value),bytes});cachedBytes+=bytes;}
  }
  function objectTarget(ownerId,id,hash){
    reportSubject(ownerId);reportId(id);reportId(hash);
    const blobPath=`everyagent/reports-v1/${ownerId}/${id}/objects/${hash}.json`;
    return persistenceFor({azure,blobPath,localPath:path.join(localRoot,blobPath)});
  }
  async function objectValue(ownerId,id,ref){
    reportObject(ref,['objectHash']);reportId(ref.objectHash);
    const key=`${ownerId}/${id}/${ref.objectHash}`,cached=objects.get(key);
    if(cached)return structuredClone(cached.value);
    const {value}=await objectTarget(ownerId,id,ref.objectHash).read();
    if(!value)throw Error('Saved report content is unavailable.');
    reportObject(value,['schemaVersion','revision','ownerId','reportId','hash'],['value','chunks','decodedBytes']);
    reportJson(value,4_000_000);
    if(![1,2].includes(value.schemaVersion) || value.revision!==1 || value.ownerId!==ownerId || value.reportId!==id || value.hash!==ref.objectHash)throw Error('Saved report content changed.');
    let decoded=value.value;
    if(value.schemaVersion===2){
      if(value.value!==undefined || !Array.isArray(value.chunks) || !value.chunks.length || !Number.isSafeInteger(value.decodedBytes) || value.decodedBytes<1 || value.decodedBytes>512*1024*1024)throw Error('Invalid saved content chunks.');
      if(value.chunks.length!==Math.ceil(value.decodedBytes/2_000_000))throw Error('Invalid saved content chunks.');
      const parts=[];let total=0;
      for(const chunk of value.chunks){
        reportObject(chunk,['objectHash']);reportId(chunk.objectHash);
        // Chunk objects are leaves. Read and verify them directly so a corrupt
        // manifest cannot create recursion or cross-report references.
        const leaf=(await objectTarget(ownerId,id,chunk.objectHash).read()).value;
        if(!leaf)throw Error('Saved report content is unavailable.');
        reportObject(leaf,['schemaVersion','revision','ownerId','reportId','hash','value']);reportJson(leaf,4_000_000);
        if(leaf.schemaVersion!==1 || leaf.revision!==1 || leaf.ownerId!==ownerId || leaf.reportId!==id || leaf.hash!==chunk.objectHash || typeof leaf.value!=='string' || reportHash(leaf.value)!==chunk.objectHash)throw Error('Saved report content changed.');
        const bytes=Buffer.from(leaf.value,'base64');if(bytes.toString('base64')!==leaf.value)throw Error('Invalid saved content encoding.');
        if(bytes.length!==Math.min(2_000_000,value.decodedBytes-total))throw Error('Invalid saved content chunk length.');
        total+=bytes.length;if(total>value.decodedBytes)throw Error('Invalid saved content length.');parts.push(bytes);
      }
      if(total!==value.decodedBytes)throw Error('Invalid saved content length.');decoded=Buffer.concat(parts,total).toString('utf8');
    }else if(value.chunks!==undefined || value.decodedBytes!==undefined)throw Error('Invalid saved content shape.');
    if(reportHash(decoded)!==ref.objectHash)throw Error('Saved report content changed.');
    remember(key,decoded);return structuredClone(decoded);
  }
  async function saveObject(ownerId,id,value){
    const hash=reportHash(value),key=`${ownerId}/${id}/${hash}`,ref={objectHash:hash};
    if(objects.has(key))return ref;
    /** @type {{schemaVersion:number,revision:number,ownerId:string,reportId:string,hash:string,value?:any,chunks?:{objectHash:string}[],decodedBytes?:number}} */
    let record={schemaVersion:1,revision:1,ownerId,reportId:id,hash,value};
    if(typeof value==='string' && Buffer.byteLength(JSON.stringify(record))>4_000_000){
      const bytes=Buffer.from(value);if(bytes.length>512*1024*1024)throw Error('Saved content exceeds checkpoint capacity.');
      const chunks=[];for(let offset=0;offset<bytes.length;offset+=2_000_000)chunks.push(await saveObject(ownerId,id,bytes.subarray(offset,offset+2_000_000).toString('base64')));
      record={schemaVersion:2,revision:1,ownerId,reportId:id,hash,chunks,decodedBytes:bytes.length};
    }
    reportJson(record,4_000_000);
    const persistence=objectTarget(ownerId,id,hash);
    for(let attempt=0;attempt<8;attempt++){
      const current=await persistence.read();
      if(current.value){await objectValue(ownerId,id,ref);return ref;}
      try{await persistence.write(record,null);remember(key,value);return ref;}
      catch(error){
        if(!(error && typeof error==='object' && 'code' in error && error.code==='EVERYAGENT_CONFLICT') || attempt===7)throw error;
        await new Promise(resolve=>setTimeout(resolve,10*(attempt+1)));
      }
    }
    throw Error('Saved report content could not be retained.');
  }
  async function mapContent(state,convert){
    const value=structuredClone(state);
    // Keep I/O bounded without turning a large investigation into a read quota.
    for(const run of value.runs){
      for(const field of arrayFields)if(run[field]!==undefined){
        if(!Array.isArray(run[field]))throw Error('Saved report content is invalid.');
        for(let i=0;i<run[field].length;i+=6)
          run[field].splice(i,Math.min(6,run[field].length-i),...await Promise.all(run[field].slice(i,i+6).map(item=>convert(state.ownerId,state.id,item))));
      }
      for(const field of objectFields)if(run[field]!==undefined && run[field]!==null)run[field]=await convert(state.ownerId,state.id,run[field]);
    }
    return value;
  }
  function target(ownerId, id) {
    reportSubject(ownerId); if (!['index', 'model'].includes(id) && !/^(?:spend-20\d{2}-\d{2}-\d{2}|credits-20\d{6})$/.test(id)) reportId(id);
    const blobPath = `everyagent/reports-v1/${ownerId}/${id}.json`;
    return persistenceFor({ azure, blobPath, localPath: path.join(localRoot, blobPath) });
  }
  async function readSnapshot(ownerId, id) {
    const snapshot = await target(ownerId, id).read();
    if (snapshot.value && (![1,2].includes(snapshot.value.schemaVersion) || !Number.isSafeInteger(snapshot.value.revision) || snapshot.value.revision < 1 ||
        snapshot.value.ownerId !== ownerId || snapshot.value.id !== id)) throw new Error('Report state is unavailable.');
    if(snapshot.value)reportJson(snapshot.value,snapshot.value.id.startsWith('credits-')?8_000_000:4_000_000);
    return snapshot;
  }
  // Cancellation needs only task ownership, never the potentially large saved
  // evidence/workspace. This read cannot authorize or publish report content.
  async function readExecution(ownerId,id){
    reportId(id);const {value}=await readSnapshot(ownerId,id);if(!value)return null;
    if(!Array.isArray(value.runs)||!value.runs.length)throw Error('Report execution is unavailable.');
    const run=value.runs.at(-1);reportSubject(run.id);
    if(!['queued','reading','analyzing','ready','partial','paused','failed','cancelled'].includes(run.status)||!Number.isFinite(run.deadline))throw Error('Report execution is unavailable.');
    if(run.lease!==null){reportObject(run.lease,['id','until']);reportSubject(run.lease.id);if(!Number.isFinite(run.lease.until))throw Error('Report lease is unavailable.');}
    return {id:run.id,status:run.status,deadline:run.deadline,lease:run.lease};
  }
  async function read(ownerId,id){
    const snapshot=await readSnapshot(ownerId,id),partitioned=snapshot.value?.schemaVersion===2;
    if (snapshot.value) {
      if(snapshot.value.schemaVersion===2){
        if(!/^[a-f0-9]{64}$/.test(id) || !Array.isArray(snapshot.value.runs))throw Error('Report manifest is invalid.');
        snapshot.value=await mapContent(snapshot.value,objectValue);snapshot.value.schemaVersion=1;
      }
      validate(snapshot.value);
    }
    return {...snapshot,partitioned};
  }
  function update(ownerId, id, mutate) {
    const key = `${ownerId}/${id}`;
    // Serialize this host's writers before taking a snapshot. Conditional writes
    // still arbitrate other processes; local bursts must not exhaust their retries.
    const pending = (pendingUpdates.get(key) ?? Promise.resolve()).then(() => updateConditional(ownerId, id, mutate));
    const settled = pending.then(() => {}, () => {}).finally(() => {
      if (pendingUpdates.get(key) === settled) pendingUpdates.delete(key);
    });
    pendingUpdates.set(key, settled);
    return pending;
  }
  async function updateConditional(ownerId, id, mutate) {
    for (let attempt = 0; attempt < 8; attempt++) {
      const { value, version, partitioned } = await read(ownerId, id), next = structuredClone(value);
      const updated = await mutate(next);
      if (updated === null) return value;
      if (updated.ownerId !== ownerId || updated.id !== id || updated.revision !== (value?.revision ?? 0)) throw new Error('Invalid report state transition.');
      updated.schemaVersion = 1; updated.revision++;
      validate(updated);
      if (value && (value.id.startsWith('spend-') || value.id.startsWith('credits-'))) {
        if(reportHash(updated.creditAllowance??null)!==reportHash(value.creditAllowance??null))throw Error('Prepaid allowance is immutable.');
        if(updated.requests.length<value.requests.length||reportHash(updated.pricing)!==reportHash(value.pricing))throw Error('Spend history cannot be removed.');
        for(const [i,before] of value.requests.entries()){
          const {actualMicrodollars,...immutable}=before,{actualMicrodollars:nextActual,...nextImmutable}=updated.requests[i];
          if(reportHash(immutable)!==reportHash(nextImmutable)||actualMicrodollars!==null&&nextActual!==actualMicrodollars)throw Error('Spend history is immutable.');
        }
      }
      if (value?.runs) {
        if (updated.runs.length < value.runs.length) throw new Error('Report history cannot be removed.');
        for (const [i, before] of value.runs.entries()) {
          const after = updated.runs[i];
          for (const key of ['id', 'requestId', 'requestHash', 'objective', 'scope', 'createdAt', 'previousVersion']) {
            if (reportHash(before[key]) !== reportHash(after[key])) throw new Error('Report history is immutable.');
          }
          if (before.artifact && reportHash(before.artifact) !== reportHash(after.artifact)) throw new Error('Saved report versions are immutable.');
          if (before.artifact && reportHash(before.investigation ?? null) !== reportHash(after.investigation ?? null)) throw Error('Saved investigation context is immutable.');
          if (before.artifact && before.agentSession !== after.agentSession) throw Error('Saved investigation history is immutable.');
          if (before.view && reportHash(before.view) !== reportHash(after.view)) throw new Error('Saved report views are immutable.');
          if (before.synthesisCache && reportHash(before.synthesisCache) !== reportHash(after.synthesisCache)) throw new Error('Saved answer proposals are immutable.');
          if (before.evidence.some((e, j) => reportHash(e) !== reportHash(after.evidence[j] ?? null))) throw new Error('Saved report evidence is immutable.');
          if ((before.savedReports ?? []).some((e,j)=>reportHash(e)!==reportHash(after.savedReports?.[j] ?? null)))throw Error('Saved report references are immutable.');
        }
      }
      // Persist objects before publishing the manifest. A crash or losing CAS
      // may leave unreferenced objects, but can never expose a partial version.
      // Ledgers/indexes retain their original format for existing live readers.
      // Reader-first rollout: Azure writers stay in v1 until both API and worker
      // understand v2. Once a manifest is v2, never silently downgrade it.
      const stored=updated.runs && (partitionReports || partitioned) ? {...await mapContent(updated,saveObject),schemaVersion:2} : updated;
      reportJson(stored,stored.id.startsWith('credits-')?8_000_000:4_000_000);
      try { await target(ownerId, id).write(stored, version); return updated; }
      catch (error) {
        if (!(error && typeof error === 'object' && 'code' in error && error.code === 'EVERYAGENT_CONFLICT') || attempt === 7) throw error;
        await new Promise(resolve => setTimeout(resolve, 10 * (attempt + 1)));
      }
    }
    throw new Error('Report could not be saved.');
  }
  async function index(subject, ownerId, id) {
    reportSubject(ownerId); reportId(id);
    return update(subject, 'index', state => {
      state ??= { schemaVersion: 1, revision: 0, ownerId: subject, id: 'index', entries: [] };
      if (state.entries.some(e => e.ownerId === ownerId && e.id === id)) return null;
      state.entries.push({ ownerId, id }); return state;
    });
  }
  async function reserveExecution(subject, key, now) {
    reportId(key);
    const day = new Date(now).toISOString().slice(0, 10);
    await update(subject, 'index', state => {
      state ??= {schemaVersion:1,revision:0,ownerId:subject,id:'index',entries:[]};
      if (state.budget?.day !== day) state.budget = {day,requests:[]};
      if (state.budget.requests.includes(key)) return null;
      state.budget.requests.push(key); return state;
    });
  }
  // One shared conditional write covers all report workers and owners. Keep this
  // outside the report index so older runtimes can still reopen saved reports.
  async function claimModel(subject, token, now, leaseMs) {
    reportSubject(subject); reportSubject(token);
    if (!Number.isFinite(now) || !Number.isFinite(leaseMs) || leaseMs <= 0 || leaseMs > 90_000) throw new Error('Invalid report model lease.');
    const state = await update(EVERYAGENT_TENANT, 'model', current => {
      current ??= { schemaVersion: 1, revision: 0, ownerId: EVERYAGENT_TENANT, id: 'model', leases: [] };
      current.leases = current.leases.filter(l => l.until > now);
      if (current.leases.length >= 2 || current.leases.some(l => l.subject === subject)) return null;
      current.leases.push({ subject, token, until: now + leaseMs }); return current;
    });
    return state?.leases.some(l => l.token === token) === true;
  }
  async function releaseModel(token) {
    reportSubject(token);
    await update(EVERYAGENT_TENANT, 'model', state => {
      if (!state?.leases.some(l => l.token === token)) return null;
      state.leases = state.leases.filter(l => l.token !== token); return state;
    });
  }
  async function renewModel(subject,token,now,leaseMs) {
    reportSubject(subject);reportSubject(token);
    if(!Number.isFinite(now)||!Number.isFinite(leaseMs)||leaseMs<=0||leaseMs>90_000)throw Error('Invalid report model lease.');
    let renewed=false;
    await update(EVERYAGENT_TENANT,'model',state=>{
      renewed=false;
      const lease=state?.leases.find(l=>l.token===token&&l.subject===subject&&l.until>now);
      if(!lease)return null;
      lease.until=now+leaseMs;renewed=true;return state;
    });
    return renewed;
  }
  async function cachedSynthesis(subject, key, now) {
    reportId(key);
    const entries = (await read(subject, 'index')).value?.entries ?? [];
    // Deliberately bounded to the last twenty owned reports and fifteen minutes.
    // No copied answer store, cross-user lookup, or sliding expiration.
    for (const entry of entries.filter(e => e.ownerId === subject).slice(-20).reverse()) {
      const state = (await read(subject, entry.id)).value;
      if (!state || state.tenantId !== EVERYAGENT_TENANT) continue;
      for (const run of [...state.runs].reverse()) {
        const cache = run.synthesisCache;
        if (run.status === 'ready' && cache?.key === key && now >= cache.createdAt && now - cache.createdAt < 15 * 60_000) {
          return { proposal: cache.proposal, investigation:run.investigation ?? null, reportId: state.id, runId: run.id };
        }
      }
    }
    return null;
  }
  return { read, readExecution, update, index, reserveExecution, claimModel, renewModel, releaseModel, cachedSynthesis };
}
