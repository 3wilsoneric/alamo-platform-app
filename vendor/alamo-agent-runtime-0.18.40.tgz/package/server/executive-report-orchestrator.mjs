// Durable orchestration contains identifiers only. All source/model I/O and
// checkpoints happen in the activity; replay does not repeat those operations.
export function* executiveReportV1(context) {
  const key = context.df.getInput();
  try {
    for (let phase = 0; phase < 24; phase++) {
      const result = yield context.df.callActivity('executiveReportAdvanceV1', key);
      if (['ready', 'partial', 'paused', 'failed', 'cancelled'].includes(result.status)) return result.status;
      if (result.claimed === false) yield context.df.createTimer(new Date(context.df.currentUtcDateTime.getTime() + 10_000));
    }
  } catch {
    yield context.df.callActivity('executiveReportPauseV1', key);
    return 'paused';
  }
  // Bound orchestration history, not investigation length. The activity owns
  // the deadline, cancellation, authority and prepaid allowance. Continuing
  // the durable instance keeps the same task and its saved investigation.
  context.df.continueAsNew(key);
  return 'continuing';
}
