import {createExecutiveAnalystWorkspace,ANALYST_RUNTIME_INSTRUCTIONS} from './executive-analyst-workspace.mjs';
export {calculateSteps, collectRecords} from './executive-analyst-workspace.mjs';
import OpenAI from 'openai';
import { Agent, Runner, RunResult, MaxTurnsExceededError } from '@openai/agents-core';
import { OpenAIResponsesModel } from '@openai/agents-openai';
import { EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS,EXECUTIVE_REPORT_EXECUTION_MS } from '../shared/executive-model-cost.mjs';
import { evidenceForModel } from './executive-model-evidence.mjs';

/** The SDK owns the tool loop; the host retains authority, evidence and money.
 * No hosted sessions or tracing: the existing report store owns conversation. */
export async function investigateWithAgent({ model, request, schema, instructions, context, controls, promptVersion }) {
  const receipts = [];
  let providerError=null;
  const workspace = createExecutiveAnalystWorkspace({schema,context,controls});
  const tools=workspace.tools;
  const client = new OpenAI({ apiKey: 'host-managed', maxRetries: 0, timeout: EXECUTIVE_REPORT_EXECUTION_MS,
    fetch: async (_url, init) => {
      try {
        const { payload, metadata } = await request(JSON.parse(String(init?.body)),init?.signal);
        receipts.push(metadata);
        return Response.json(payload);
      } catch(error) { providerError=error;throw error; }
    } });
  const provider = new OpenAIResponsesModel(client, model);
  const metered = {
    getResponse: input => {
      // Completion is the model's decision, checked by the host. A scheduler
      // slice must never turn an unfinished investigation into a final answer.
      const requiredTool = !workspace.investigation ? 'set_investigation' : null;
      return controls.modelCall(signal => provider.getResponse({...input,signal,
        ...(requiredTool?{modelSettings:{...input.modelSettings,toolChoice:requiredTool}}:{})}));
    },
    // This host publishes verified artifacts. Token streaming is not enabled
    // until the host can quarantine unverified drafts and settle SSE receipts.
    async *getStreamedResponse() { throw Error('Use the verified report response.'); }
  };
  const agent = new Agent({ name: 'Ally analyst', model: metered,
    instructions: `${instructions}\n${ANALYST_RUNTIME_INSTRUCTIONS}`,
    tools, resetToolChoice: false, toolUseBehavior: { stopAtToolNames: ['publish_analysis'] },
    modelSettings: { toolChoice: 'required', parallelToolCalls: false, maxTokens: EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS,
      // Compact within the host's transport/context envelope, not below the
      // measured size of an ordinary retained investigation. A 32k threshold
      // recompacted every exchange of the real admissions follow-up.
      contextManagement: [{type:'compaction',compactThreshold:96_000}],
      reasoning: { effort: 'high', context: 'all_turns' }, retry: { maxRetries: 0 }, providerData: { store: false, service_tier: 'default' } } });
  const runner = new Runner({ tracingDisabled: true, traceIncludeSensitiveData: false });
  let result;
  // Keep the stable catalog before the changing question, matching the existing
  // provider path so prompt caching survives across ordinary follow-ups.
  const { catalog, ...turn } = context;
  const current = JSON.stringify({ catalog, ...turn, evidence: evidenceForModel(turn.evidence ?? []),
    ...(controls.session ? {continuation:'Continue from the saved tool history. This is the current authorized workspace, not a request to restart completed work.'} : {}) });
  /** @type {import('@openai/agents-core').AgentInputItem[]} */
  let input = [...(controls.session ? JSON.parse(controls.session) : []),{role:'user',content:current}];
  // One SDK exchange per checkpoint, not one exchange per investigation. The
  // SDK persists complete tool-call/result pairs and handles native compaction.
  // A crash can replay read-only work since the last checkpoint; source reads
  // and computations are independently retained and deduplicated by the host.
  for (;;) {
    let exchange;
    try { result = await runner.run(agent, input, {maxTurns:1}); exchange=result; }
    catch (error) {
      if (!(error instanceof MaxTurnsExceededError) || !error.state) throw providerError ?? workspace.error ?? error;
      exchange = new RunResult(error.state);
    }
    input=exchange.history;
    await controls.checkpointSession?.(JSON.stringify(input));
    if (result) break;
  }
  if (typeof result.finalOutput !== 'string') throw Error('The analyst did not publish a report.');
  const proposal = JSON.parse(result.finalOutput);
  if (proposal.additionalReads?.length) throw Error('The analyst returned unexecuted reads.');
  return { ...proposal, metadata: { requestedModel: model, promptVersion,
    inputTokens: receipts.reduce((sum, item) => sum + item.inputTokens, 0),
    outputTokens: receipts.reduce((sum, item) => sum + item.outputTokens, 0),
    compactionItems: receipts.reduce((sum, item) => sum + item.compactionItems, 0),
    latencyMs: receipts.reduce((sum, item) => sum + item.latencyMs, 0), calls: receipts.length } };
}
