// Credential-free Docker or Azure session transport. No host mounts, source credentials, container
// socket or network. Native shell tools operate only in this disposable sandbox.
import assert from 'node:assert/strict';
import {spawn,execFile} from 'node:child_process';
import {createInterface} from 'node:readline';
import {PassThrough,Writable} from 'node:stream';
import {EventEmitter} from 'node:events';
import {randomUUID} from 'node:crypto';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';

/** @param {{image:string,gateway:string,token:string,sessionEndpoint?:string|null,sessionClientId?:string|null,signal?:AbortSignal}} options */
export async function spawnIsolatedCodex({image,gateway,token,sessionEndpoint=null,sessionClientId=null,signal}){
  signal?.throwIfAborted();
  assert(/^sha256:[a-f0-9]{64}$/.test(image),'Pin the tested development image ID.');
  const name=`ally-codex-${randomUUID()}`;
  const args=['run','--rm','-i','--name',name,'--network','none','--read-only','--cap-drop=ALL','--security-opt','no-new-privileges','--user','1000:1000','--pids-limit','128','--cpus','1','--memory','1g','--tmpfs','/tmp:rw,exec,nosuid,size=268435456,uid=1000,gid=1000','--tmpfs','/workspace:rw,exec,nosuid,size=268435456,uid=1000,gid=1000','--tmpfs','/home/node:rw,exec,nosuid,size=134217728,uid=1000,gid=1000','--entrypoint','node',image,'/opt/ally/codex-isolated-bridge.mjs'];
  const docker=sessionEndpoint?spawn(process.execPath,[fileURLToPath(new URL('./codex-session-client.mjs',import.meta.url)),sessionEndpoint,...(sessionClientId?[sessionClientId]:[])],{stdio:['pipe','pipe','pipe']}):spawn('docker',args,{stdio:['pipe','pipe','pipe']});
  const requests=new Map();let closing=false;
  /** @type {Promise<void>|undefined} */ let stopping;
  const emit=value=>{if(!closing)docker.stdin.write(JSON.stringify(value)+'\n');};
  const runtime=Object.assign(new EventEmitter(),{stdout:new PassThrough(),stderr:new PassThrough(),stdin:new Writable({write(chunk,_encoding,done){try{for(const line of chunk.toString().trim().split('\n'))emit({channel:'codex',message:JSON.parse(line)});done();}catch(error){done(error instanceof Error?error:Error(String(error)));}}}),
  kill:()=>stopping??=(async()=>{closing=true;for(const controller of requests.values())controller.abort();docker.stdin.end();
    if(sessionEndpoint){if(docker.exitCode!==null)return;await new Promise(resolve=>{const timer=setTimeout(()=>{docker.kill('SIGKILL');resolve(undefined);},12000);docker.once('exit',()=>{clearTimeout(timer);resolve(undefined);});docker.kill('SIGTERM');});}
    else await promisify(execFile)('docker',['rm','-f',name]).catch(error=>{if(!/No such container/.test(String(error.stderr??'')))throw error;});})()});
  const ready=new Promise((resolve,reject)=>{
    docker.on('error',reject);docker.on('exit',code=>{reject(Error(`Isolated Codex exited ${code}`));runtime.emit('exit',code);runtime.stdout.end();});
    createInterface({input:docker.stdout}).on('line',async line=>{
      try{
        const message=JSON.parse(line);
        if(message.channel==='fatal')throw Error(/^session_(?:http_\d{3}|transport_failed)$/.test(message.code)?message.code:'Isolated session transport failed');
        if(message.channel==='ready'){assert.equal(message.version,'0.157.0');resolve(undefined);}
        else if(message.channel==='codex')runtime.stdout.write(JSON.stringify(message.message)+'\n');
        else if(message.channel==='provider-close'){requests.get(message.id)?.abort();requests.delete(message.id);}
        else if(message.channel==='provider'){
          assert.equal(message.path,'/v1/responses');
          const body=Buffer.from(message.body,'base64');assert(body.length<=15*1024*1024);
          const controller=new AbortController();requests.set(message.id,controller);
          try{
            const result=await fetch(gateway+message.path,{method:'POST',redirect:'error',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body,signal:controller.signal});
            emit({channel:'provider',id:message.id,status:result.status,contentType:result.headers.get('content-type')??'application/json'});
            assert(result.body,'Provider response has no body');
            for await(const bytes of result.body)emit({channel:'provider',id:message.id,body:Buffer.from(bytes).toString('base64')});
            emit({channel:'provider',id:message.id,end:true});
          }catch(error){if(!controller.signal.aborted)emit({channel:'provider',id:message.id,status:502,end:true});}
          finally{requests.delete(message.id);}
        }else throw Error('Invalid isolated transport message');
      }catch(error){reject(error);if(runtime.listenerCount('error'))runtime.emit('error',error);}
    });
  });
  docker.stderr.pipe(runtime.stderr);
  let startupTimer;let abort=()=>{};
  const cancelled=new Promise((_,reject)=>{
    abort=()=>reject(signal?.reason??Error('Workspace cancelled'));signal?.addEventListener('abort',abort,{once:true});
    if(signal?.aborted)abort();
  });
  try{await Promise.race([ready,cancelled,new Promise((_,reject)=>{startupTimer=setTimeout(()=>reject(Error('Isolated workspace did not become ready within three minutes')),180000);})]);return runtime;}
  catch(error){await runtime.kill();throw error;}
  finally{clearTimeout(startupTimer);signal?.removeEventListener('abort',abort);}
}
