import { reportHash } from '../shared/executive-report-contracts.mjs';

// Coverage belongs to a collection of exact source pages, not a model claim or
// the last page. Keep original evidence immutable and recompute this proof for
// the actual inputs to a calculation or publication.
export function completeEvidencePages(evidence, readSteps = [], { selectCompleteChain = false } = {}) {
  const groups = new Map(), nativeGroups = new Map(), proofs = new Map();
  for (const {sourceId, value} of evidence) {
    if(value.status !== 'verified') continue;
    let data; try { data = JSON.parse(value.answer); } catch { continue; }
    if (!data || !/^[a-f0-9]{64}$/.test(data.revision ?? '')) continue;
    let rows, total, selection, kind, native;
    if(value.capability === 'platform-data') {
      if(data.version !== 'ally-platform-data-v1' || data.populationCoverage !== 'complete' ||
        data.query?.operation !== 'rows' || !Array.isArray(data.rows) || data.returnedRows !== data.rows.length ||
        data.textExcerpts?.some(excerpt => !excerpt.complete)) continue;
      rows=data.rows;total=data.totalRows;kind='population';
      const {offset:_offset,revision:_revision,limit:_limit,...query}=data.query;
      selection=query;
      if(data.hasMore !== (data.offset+rows.length<total))continue;
    } else if(value.capability === 'pipeline-records') {
      const step=readSteps.find(step=>step.id===sourceId && step.capability===value.capability);
      if(!step || value.inputHash!==reportHash(step.input))continue;
      const {offset=0,revision,pointer,paths,search,columns,...parameters}=step.input;
      if(typeof data.sourceComplete!=='boolean' || data.contentComplete!==true ||
        search!==undefined || data.operation!==(parameters.view??'catalog') ||
        !data.parameters || reportHash(data.parameters)!==reportHash(parameters) || data.offset!==offset ||
        offset>0 && revision!==data.revision || revision!==undefined && revision!==data.revision) continue;
      if(paths!==undefined) {
        if(!data.sourceComplete || parameters.cursor)continue;
        rows=data.selections;total=data.totalSelections;
        if(!Array.isArray(paths) || total!==paths.length || !Array.isArray(rows) ||
          rows.some((item,index)=>item.pointer!==paths[offset+index]))continue;
      } else {
        rows=data.items;total=data.totalResponseRows;
        // Native list metadata is retained for the canonical list pointer.
        // Other pointers do not prove source pagination was exhausted.
        if(data.pointer!=='/data/records' || pointer!==undefined && pointer!=='/data/records' || !data.page)continue;
      }
      if(data.operation==='workspace-review' && (!Array.isArray(data.page?.requestedReferralIds) ||
        !Array.isArray(parameters.referralIds) || reportHash(data.page.requestedReferralIds)!==reportHash(parameters.referralIds)))continue;
      selection={parameters,pointer:data.pointer,paths:paths??null,columns:columns??null};kind='selected-response';
      if(paths===undefined && Object.hasOwn(data.page,'next_cursor')) {
        const cursor=parameters.cursor??null,next=data.page.next_cursor;
        if(cursor!==null && (typeof cursor!=='string' || !cursor) ||
          next!==null && (typeof next!=='string' || !next) || data.sourceComplete!==(next===null))continue;
        const {cursor:_cursor,sourceRevision,referralRevision,...query}=parameters;
        const version={source:data.page.sourceRevision??null,referral:data.page.referralRevision??null};
        // Multiple native pages require the source's stable revision contract.
        if((cursor!==null || next!==null) && (!Number.isSafeInteger(version.source) || version.source<0 ||
          data.operation==='assessment-review' && (!Number.isSafeInteger(version.referral) || version.referral<0)))continue;
        if(cursor!==null && sourceRevision!==version.source || sourceRevision!==undefined && sourceRevision!==version.source ||
          data.operation==='assessment-review' && cursor!==null && referralRevision!==version.referral ||
          referralRevision!==undefined && referralRevision!==version.referral)continue;
        native={cursor,next,key:reportHash({capability:value.capability,scope:value.scope,grant:value.grantRevision,
          version,query,pointer:data.pointer,columns:columns??null}),version};
      } else if(!data.sourceComplete || parameters.cursor)continue;
    } else continue;
    if(!Array.isArray(rows) || !Number.isSafeInteger(total) || total<0 ||
      !Number.isSafeInteger(data.offset) || data.offset<0)continue;
    const end=data.offset+rows.length;
    if(end>total || data.nextOffset!==(end<total?end:null) || end<total&&!rows.length)continue;
    const key=reportHash({capability:value.capability,scope:value.scope,grant:value.grantRevision,revision:data.revision,selection});
    const group=groups.get(key)??[];
    group.push({id:sourceId,start:data.offset,end,total,kind,native,revision:data.revision});groups.set(key,group);
  }
  for(let pages of groups.values()) {
    pages.sort((a,b)=>a.start-b.start);
    let end=0;const total=pages[0].total;
    if(selectCompleteChain){
      // Publication searches the retained workspace, which may also contain an
      // earlier exploratory page. Choose an exact non-overlapping chain; never
      // let an unused sample invalidate the subsequently complete collection.
      // Calculations keep the strict default: every supplied input must belong
      // to the chain, so overlapping rows cannot acquire a population proof.
      if(total===0)pages=pages.slice(0,1);
      else {
        /** @type {Map<number, typeof pages>} */
        const paths=new Map([[total,[]]]);
        for(const page of [...pages].sort((a,b)=>b.start-a.start || b.end-a.end)){
          const tail=paths.get(page.end);
          if(page.total===total && page.end>page.start && tail && !paths.has(page.start))paths.set(page.start,[page,...tail]);
        }
        const chain=paths.get(0);if(!chain?.length)continue;pages=chain;
      }
    }
    if(total===0 && pages.length!==1)continue;
    if(!pages.every(page=>{if(page.total!==total || page.start!==end)return false;end=page.end;return true;}) || end!==total)continue;
    const proof={kind:pages[0].kind,revision:pages[0].revision,total,sourceIds:pages.map(page=>page.id)};
    if(pages[0].native) {
      const node=pages[0].native,group=nativeGroups.get(node.key)??[];
      // A response's transport pages must agree about its native continuation.
      if(pages.some(page=>reportHash(page.native)!==reportHash(node)))continue;
      group.push({...node,proof});nativeGroups.set(node.key,group);
    } else for(const page of pages)proofs.set(page.id,proof);
  }
  for(const nodes of nativeGroups.values()) {
    const visited=new Set(),ordered=[];let cursor=null,complete=false;
    while(visited.size<nodes.length) {
      const matching=nodes.filter(node=>node.cursor===cursor);
      if(matching.length!==1 || visited.has(matching[0]))break;
      const node=matching[0];visited.add(node);ordered.push(node.proof);cursor=node.next;
      if(cursor===null){complete=visited.size===nodes.length;break;}
    }
    if(!complete)continue;
    const proof={kind:'native-query',revision:reportHash(ordered.map(p=>p.revision)),
      sourceVersion:nodes[0].version,total:ordered.reduce((n,p)=>n+p.total,0),sourceIds:ordered.flatMap(p=>p.sourceIds)};
    for(const id of proof.sourceIds)proofs.set(id,proof);
  }
  return proofs;
}
