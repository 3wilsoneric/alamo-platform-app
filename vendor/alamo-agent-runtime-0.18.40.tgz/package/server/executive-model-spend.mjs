import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {EVERYAGENT_TENANT} from '../shared/everyagent-identity.mjs';
import {executiveModelCost,executiveModelPricing,executiveModelReceiptCost,codexModelReceiptCost,CODEX_MODEL_CONTEXT_TOKENS,CODEX_MODEL_OUTPUT_TOKENS} from '../shared/executive-model-cost.mjs';
import {reportObject} from '../shared/executive-report-contracts.mjs';
import {createHttpError} from './http-error-contract.mjs';

// One shared, durable allowance. Existing UTC-day ledgers stay readable; a
// prepaid allowance never resets at midnight. No prompts are stored.
export function createExecutiveModelSpend({store,limitMicrodollars=/** @type {number | undefined} */ (undefined),creditAllowance=/** @type {{id:string;limitMicrodollars:number;validFrom:string;expiresAt:string} | null} */ (null),now=Date.now}) {
  if (creditAllowance) {
    reportObject(creditAllowance,['id','limitMicrodollars','validFrom','expiresAt']);
    assert(limitMicrodollars===undefined && /^credits-20\d{6}$/.test(creditAllowance.id),'Choose one authorized report allowance.');
    assert(Number.isSafeInteger(creditAllowance.limitMicrodollars) && creditAllowance.limitMicrodollars>0);
    assert(Number.isFinite(Date.parse(creditAllowance.validFrom)) && Date.parse(creditAllowance.expiresAt)>Date.parse(creditAllowance.validFrom));
    creditAllowance=Object.freeze({...creditAllowance});
  } else assert(typeof limitMicrodollars==='number' && Number.isSafeInteger(limitMicrodollars) && limitMicrodollars > 0 && limitMicrodollars <= 500000,'Configure the authorized daily report budget.');
  const ceiling=creditAllowance?.limitMicrodollars??limitMicrodollars;
  assert(typeof ceiling==='number');
  async function reserve(inputTokens,maxOutputTokens,{compaction=false,cacheAware=false,native=false}={}) {
      assert(typeof ceiling==='number');
      assert(typeof compaction==='boolean'&&typeof cacheAware==='boolean');
      if(native)codexModelReceiptCost({input_tokens:inputTokens,output_tokens:maxOutputTokens});
      else executiveModelCost(inputTokens,maxOutputTokens);
      // Inline compaction can feed generated tokens back into the same request.
      // With no hosted tools, the response's output bound covers this additional
      // input. Budget all input at the maximum cache-write rate until a receipt
      // establishes the actual mix. The persisted v1 inputTokens field is the
      // reservation basis at its historical $2/M rate, not a usage measurement.
      // This preserves readability by the live v1 engine and existing receipts.
      const inputCeiling=native?Math.min(CODEX_MODEL_CONTEXT_TOKENS,inputTokens+256+(compaction?maxOutputTokens:0)):inputTokens+256+(compaction?maxOutputTokens:0);
      const reservationInput=cacheAware?Math.ceil(inputCeiling*1.25)-256:inputCeiling-256;
      const time=now(),at=new Date(time).toISOString(),id=creditAllowance?.id??'spend-'+at.slice(0,10);
      const denied=()=>createHttpError(429,creditAllowance?'report_credit_limit':'report_spend_limit',creditAllowance?'The prepaid Ally allowance is exhausted or expired. Saved reports remain available.':'The daily Ally model budget is reached. Saved reports remain available.');
      if(creditAllowance && (time<Date.parse(creditAllowance.validFrom)||time>=Date.parse(creditAllowance.expiresAt)))throw denied();
      // One atomic reservation, represented as v1-compatible capacity entries.
      // These are accounting units, not extra provider calls. This is necessary
      // until all live readers can migrate together; do not change v1 semantics.
      const entries=[];
      if(native){
        let capacity=codexModelReceiptCost({input_tokens:inputCeiling,output_tokens:maxOutputTokens});
        do{
          const output=Math.max(1,Math.min(6000,Math.floor((capacity-512)/10)));
          const input=Math.max(0,Math.min(200000,Math.ceil((capacity-512-output*10)/2)));
          entries.push({token:randomUUID(),at,inputTokens:input,maxOutputTokens:output,reservedMicrodollars:executiveModelCost(input+256,output),actualMicrodollars:null});
          capacity-=executiveModelCost(input+256,output);
        }while(capacity>0);
      }else entries.push({token:randomUUID(),at,inputTokens:reservationInput,maxOutputTokens,reservedMicrodollars:executiveModelCost(reservationInput+256,maxOutputTokens),actualMicrodollars:null});
      const reserved=entries.reduce((n,e)=>n+e.reservedMicrodollars,0);
      await store.update(EVERYAGENT_TENANT,id,state=>{
        state??={schemaVersion:1,revision:0,ownerId:EVERYAGENT_TENANT,id,pricing:executiveModelPricing,...(creditAllowance?{creditAllowance}:{}),requests:[]};
        assert.deepEqual(state.pricing,executiveModelPricing);
        if(creditAllowance)assert.deepEqual(state.creditAllowance,creditAllowance);
        const used=state.requests.reduce((sum,r)=>sum+(r.actualMicrodollars??r.reservedMicrodollars),0);
        if(used+reserved>ceiling || state.requests.length+entries.length>(creditAllowance?20000:1000))throw denied();
        state.requests.push(...entries);return state;
      });
      // Only a verified usage receipt releases the unused reservation. Network,
      // storage and ambiguous provider failures retain the full reservation.
      return async usage=>{
        assert(Number.isSafeInteger(usage?.input_tokens)&&usage.input_tokens>=0&&usage.input_tokens<=inputCeiling);
        assert(Number.isSafeInteger(usage?.output_tokens)&&usage.output_tokens>=0&&usage.output_tokens<=maxOutputTokens);
        const actual=native?codexModelReceiptCost(usage):cacheAware?executiveModelReceiptCost(usage):executiveModelCost(usage.input_tokens,usage.output_tokens);
        assert(actual<=reserved);
        await store.update(EVERYAGENT_TENANT,id,state=>{
          assert(state);let remaining=actual,changed=false;
          for(const reservedEntry of entries){
            const entry=state.requests.find(r=>r.token===reservedEntry.token);assert(entry);
            const share=Math.min(remaining,entry.reservedMicrodollars);remaining-=share;
            if(entry.actualMicrodollars!==null)assert.equal(entry.actualMicrodollars,share);
            else{entry.actualMicrodollars=share;changed=true;}
          }
          assert.equal(remaining,0);return changed?state:null;
        });
      };
  }
  return {reserve,
    reserveNative:(inputTokens,maxOutputTokens=CODEX_MODEL_OUTPUT_TOKENS,{compaction=false}={})=>reserve(inputTokens,maxOutputTokens,{native:true,cacheAware:true,compaction})};
}

// Counting includes instructions and the function schema. It generates no text.
export async function countExecutiveModelInput({request,headers,fetchImpl,maxInputTokens=200000}) {
  assert.equal(request.model,executiveModelPricing.model);
  assert(Number.isSafeInteger(maxInputTokens)&&maxInputTokens>0&&maxInputTokens<=CODEX_MODEL_CONTEXT_TOKENS);
  const response=await fetchImpl('https://api.openai.com/v1/responses/input_tokens',{
    method:'POST',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(10000),headers,
    body:JSON.stringify({model:request.model,instructions:request.instructions,input:request.input,tools:request.tools,tool_choice:request.tool_choice,parallel_tool_calls:request.parallel_tool_calls??false,
      ...(request.reasoning ? {reasoning:request.reasoning} : {})})
  });
  const chunks=[];let size=0;
  try {
    if(!response.ok)throw Error('Model token count unavailable.');
    for await(const chunk of response.body??[]){size+=chunk.length;assert(size<=4096);chunks.push(Buffer.from(chunk));}
    const result=JSON.parse(Buffer.concat(chunks).toString('utf8'));
    assert.equal(result.object,'response.input_tokens');
    assert(Number.isSafeInteger(result.input_tokens)&&result.input_tokens>=0&&result.input_tokens<=maxInputTokens);
    return result.input_tokens;
  } finally {await response.body?.cancel().catch(()=>{});}
}
