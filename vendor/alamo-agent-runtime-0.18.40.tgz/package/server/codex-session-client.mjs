// Trusted host transport. Session tokens remain here, outside the model sandbox.
import assert from 'node:assert/strict';
import {createInterface} from 'node:readline';
import {randomUUID} from 'node:crypto';
import {ManagedIdentityCredential} from '@azure/identity';
assert(process.argv[2],'Session endpoint is required');
const endpoint=new URL(process.argv[2]);
assert(endpoint.protocol==='https:'&&endpoint.hostname.endsWith('.azurecontainerapps.io')&&!endpoint.username&&!endpoint.password&&!endpoint.search&&!endpoint.hash);
const clientId=process.argv[3]??process.env.AZURE_CLIENT_ID;
const credential=clientId?new ManagedIdentityCredential(clientId):new ManagedIdentityCredential(),identifier=randomUUID();
const url=path=>{const value=new URL(endpoint.href.replace(/\/$/,'')+path);value.searchParams.set('identifier',identifier);value.searchParams.set('api-version','2025-02-02-preview');return value;};
const headers=async()=>({'content-type':'application/json',authorization:`Bearer ${(await credential.getToken('https://dynamicsessions.io/.default')).token}`});
let queue=[],batch=0,after=0,stopped=false,failureCode='session_transport_failed';
const input=createInterface({input:process.stdin}).on('line',line=>{queue.push(JSON.parse(line));}).on('close',()=>{stopped=true;});
process.on('SIGTERM',()=>{stopped=true;});
try{
 while(!stopped){
  const messages=queue;queue=[];
  const body=JSON.stringify({batch:++batch,after,messages});let result;
  for(let attempt=0;;attempt++){
   try{const response=await fetch(url('/exchange'),{method:'POST',redirect:'error',headers:await headers(),body,signal:AbortSignal.timeout(45000)});
    if(!response.ok){failureCode=`session_http_${response.status}`;throw Error(failureCode);}let size=0;const chunks=[];assert(response.body,'Session response has no body');for await(const chunk of response.body){size+=chunk.length;assert(size<=40*1024*1024);chunks.push(chunk);}
    result=JSON.parse(Buffer.concat(chunks).toString());break;
   }catch(error){if(stopped||attempt===2)throw error;await new Promise(r=>setTimeout(r,250));}
  }
  assert.equal(result.batch,batch);assert(!result.exited,'Native session exited');
  for(const item of result.messages){if(item.sequence<=after)continue;assert.equal(item.sequence,after+1);process.stdout.write(JSON.stringify(item.message)+'\n');after=item.sequence;}
 }
}catch{process.exitCode=1;process.stdout.write(JSON.stringify({channel:'fatal',code:failureCode})+'\n');}
finally{input.close();process.stdin.destroy();try{await fetch(url('/.management/stopSession'),{method:'POST',redirect:'error',headers:await headers(),signal:AbortSignal.timeout(10000)});}catch{}}
