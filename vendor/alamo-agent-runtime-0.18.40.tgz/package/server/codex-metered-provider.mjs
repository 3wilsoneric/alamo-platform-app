// Development integration boundary. Use the installed official SDK's SSE parser;
// retain original native events and compacted items, never synthesize a stream.
import assert from 'node:assert/strict';
import OpenAI from 'openai';
import {once} from 'node:events';
import {countExecutiveModelInput} from './executive-model-spend.mjs';
import {CODEX_MODEL_CONTEXT_TOKENS,CODEX_MODEL_OUTPUT_TOKENS,EXECUTIVE_REPORT_EXECUTION_MS} from '../shared/executive-model-cost.mjs';
// Pinned Codex's own Responses message bound (codex-api/common.rs).
export const CODEX_PROTOCOL_BYTES=15*1024*1024;

/** @param {{apiKey:string,projectId:string,spend:any,fetchImpl?:typeof fetch,onReceipt?:(receipt:any)=>any,onProgress?:(text:string)=>any}} options */
export function createCodexMeteredProvider({apiKey,projectId,spend,fetchImpl=fetch,onReceipt=()=>{},onProgress=()=>{}}){
  const client=new OpenAI({apiKey,project:projectId,maxRetries:0,timeout:EXECUTIVE_REPORT_EXECUTION_MS,fetch:(url,options)=>fetchImpl(url,{...options,redirect:'error',cache:'no-store'})});
  return async function respond({input,controls,res}){
    const request={...input,service_tier:'default',stream:true,store:false,max_output_tokens:CODEX_MODEL_OUTPUT_TOKENS};
    delete request.client_metadata;
    const started=Date.now();
    return controls.modelCall(async signal=>{
      const headers={'Content-Type':'application/json',Authorization:`Bearer ${apiKey}`,'OpenAI-Project':projectId};
      const count=await countExecutiveModelInput({request,headers,fetchImpl,maxInputTokens:CODEX_MODEL_CONTEXT_TOKENS});
      const inlineCompaction=Array.isArray(request.input)&&request.input.some(item=>item.type==='compaction_trigger');
      const settle=await spend.reserveNative(count,CODEX_MODEL_OUTPUT_TOKENS,{compaction:inlineCompaction});
      const record=async body=>{
        assert(body?.usage,'Provider ended without a usage receipt.');
        await settle(body.usage);
        const receipt={inputTokens:body.usage.input_tokens,outputTokens:body.usage.output_tokens,latencyMs:Date.now()-started,compaction:inlineCompaction};
        await onReceipt(receipt);
      };
      const stream=await client.responses.create(/** @type {import('openai/resources/responses/responses').ResponseCreateParamsStreaming} */({...request,stream:true}),{signal});
      res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache'});
      let terminal=false;
      for await(const event of stream){
        assert(!terminal,'Unexpected event after terminal response.');
        const serialized=JSON.stringify(event);assert(Buffer.byteLength(serialized)<=CODEX_PROTOCOL_BYTES);
        if(event.type==='response.completed'||event.type==='response.incomplete'||event.type==='response.failed'){
          terminal=true;
          await record(event.response);
          assert.equal(event.type,'response.completed',`Codex provider incomplete: ${event.response?.incomplete_details?.reason??event.response?.error?.code??'unknown'}`);
        }
        if(!res.write(`event: ${event.type}\ndata: ${serialized}\n\n`))await once(res,'drain',{signal});
        if(event.type==='response.output_text.delta')await onProgress(event.delta);
      }
      assert(terminal,'Provider stream ended without completion.');
      res.end();
    });
  };
}
