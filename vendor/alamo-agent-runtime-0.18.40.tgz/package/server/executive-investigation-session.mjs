import {protocol} from '@openai/agents-core';
import {gzipSync,gunzipSync} from 'node:zlib';
import {reportHash,reportObject,reportSubject,REPORT_MODEL_PROTOCOL_BYTES} from '../shared/executive-report-contracts.mjs';

export const CODEX_WORKSPACE_BYTES=256*1024*1024;
const NATIVE_CHECKPOINT_BYTES=512*1024*1024;

// The report store owns checkpoints, not one framework's in-memory history.
// Native rollouts are version-pinned data, never host file paths or credentials.
export function validateInvestigationSession(history) {
  if(typeof history!=='string'||Buffer.byteLength(history)>NATIVE_CHECKPOINT_BYTES)throw Error('Invalid investigation session.');
  const value=JSON.parse(history);
  if(Array.isArray(value)) {if(Buffer.byteLength(history)>REPORT_MODEL_PROTOCOL_BYTES)throw Error('Invalid investigation session.');for(const item of value)protocol.ModelItem.parse(item);return value;}
  reportObject(value,['runtime','threadId','rollout','digest'],['workspace','workspaceDigest','encoding','workspaceEncoding']);
  if(value.encoding!==undefined){
    if(value.encoding!=='gzip-base64'||typeof value.rollout!=='string'||Buffer.from(value.rollout,'base64').toString('base64')!==value.rollout)throw Error('Invalid compressed native checkpoint.');
    value.rollout=gunzipSync(Buffer.from(value.rollout,'base64'),{maxOutputLength:32*1024*1024}).toString('utf8');
    delete value.encoding;
  }
  if(value.runtime!=='codex-app-server-0.157.0'||typeof value.rollout!=='string'||value.digest!==reportHash(value.rollout))throw Error('Invalid Codex investigation checkpoint.');
  reportSubject(value.threadId);
  const records=value.rollout.trimEnd().split('\n').map(line=>JSON.parse(line));
  const meta=records[0];
  if(meta?.type!=='session_meta'||meta.payload?.id!==value.threadId||meta.payload?.cli_version!=='0.157.0')throw Error('Codex checkpoint identity/version mismatch.');
  if(records.some(r=>!r||typeof r.type!=='string'||!r.payload||typeof r.payload!=='object'||!Number.isFinite(Date.parse(r.timestamp))))throw Error('Invalid Codex rollout record.');
  if(value.workspaceEncoding!==undefined){
    if(value.workspaceEncoding!=='gzip-base64'||typeof value.workspace!=='string'||Buffer.from(value.workspace,'base64').toString('base64')!==value.workspace)throw Error('Invalid compressed workspace checkpoint.');
    value.workspace=JSON.parse(gunzipSync(Buffer.from(value.workspace,'base64'),{maxOutputLength:384*1024*1024}).toString('utf8'));
    delete value.workspaceEncoding;
  }
  if(value.workspace!==undefined||value.workspaceDigest!==undefined){
    if(!Array.isArray(value.workspace)||value.workspaceDigest!==reportHash(value.workspace))throw Error('Invalid Codex workspace checkpoint.');
    const paths=new Set();let workspaceBytes=0;
    for(const file of value.workspace){
      reportObject(file,['path','data']);
      if(typeof file.path!=='string'||file.path.includes('\\')||file.path.includes('\0')||file.path.split('/').some(part=>!part||part==='.'||part==='..')||
        file.path.split('/')[0]==='evidence'||paths.has(file.path)||typeof file.data!=='string'||Buffer.from(file.data,'base64').toString('base64')!==file.data)
        throw Error('Invalid Codex workspace file.');
      workspaceBytes+=Buffer.from(file.data,'base64').length;if(workspaceBytes>CODEX_WORKSPACE_BYTES)throw Error('Workspace exceeds its checkpoint capacity.');
      paths.add(file.path);
    }
  }
  return value;
}

export function codexInvestigationCheckpoint(threadId,rollout,workspace=undefined) {
  if(typeof rollout!=='string'||Buffer.byteLength(rollout)>32*1024*1024)throw Error('Native history exceeds checkpoint capacity.');
  const result=JSON.stringify({runtime:'codex-app-server-0.157.0',threadId,rollout:gzipSync(rollout).toString('base64'),encoding:'gzip-base64',digest:reportHash(rollout),...(workspace?{workspace:gzipSync(JSON.stringify(workspace)).toString('base64'),workspaceEncoding:'gzip-base64',workspaceDigest:reportHash(workspace)}:{})});
  validateInvestigationSession(result);
  return result;
}
