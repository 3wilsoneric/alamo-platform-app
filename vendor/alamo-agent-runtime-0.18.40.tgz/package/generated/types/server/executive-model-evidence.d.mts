export function evidenceForModel(items: any): any;
export function inspectEvidence(items: any, requests: any): {
    inspections: {
        sourceId: any;
        revision: any;
        offset: any;
        end: number;
        totalCharacters: number;
        nextOffset: number | null;
        text: string;
    }[];
    notice: string;
};
