/** @param {{apiKey:string,projectId:string,spend:any,fetchImpl?:typeof fetch,onReceipt?:(receipt:any)=>any,onProgress?:(text:string)=>any}} options */
export function createCodexMeteredProvider({ apiKey, projectId, spend, fetchImpl, onReceipt, onProgress }: {
    apiKey: string;
    projectId: string;
    spend: any;
    fetchImpl?: typeof fetch;
    onReceipt?: (receipt: any) => any;
    onProgress?: (text: string) => any;
}): ({ input, controls, res }: {
    input: any;
    controls: any;
    res: any;
}) => Promise<any>;
export const CODEX_PROTOCOL_BYTES: number;
