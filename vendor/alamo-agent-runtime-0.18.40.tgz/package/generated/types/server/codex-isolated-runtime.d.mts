/** @param {{image:string,gateway:string,token:string,sessionEndpoint?:string|null,sessionClientId?:string|null,signal?:AbortSignal}} options */
export function spawnIsolatedCodex({ image, gateway, token, sessionEndpoint, sessionClientId, signal }: {
    image: string;
    gateway: string;
    token: string;
    sessionEndpoint?: string | null;
    sessionClientId?: string | null;
    signal?: AbortSignal;
}): Promise<EventEmitter<any> & {
    stdout: PassThrough;
    stderr: PassThrough;
    stdin: Writable;
    kill: () => Promise<void>;
}>;
import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import { Writable } from 'node:stream';
