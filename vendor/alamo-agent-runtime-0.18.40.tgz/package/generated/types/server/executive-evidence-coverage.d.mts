export function completeEvidencePages(evidence: any, readSteps?: any[], { selectCompleteChain }?: {
    selectCompleteChain?: boolean | undefined;
}): Map<any, any>;
