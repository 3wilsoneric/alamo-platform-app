export function createExecutiveModelSpend({ store, limitMicrodollars, creditAllowance, now }: {
    store: any;
    limitMicrodollars?: number | undefined;
    creditAllowance?: {
        id: string;
        limitMicrodollars: number;
        validFrom: string;
        expiresAt: string;
    } | null | undefined;
    now?: (() => number) | undefined;
}): {
    reserve: (inputTokens: any, maxOutputTokens: any, { compaction, cacheAware, native }?: {
        compaction?: boolean | undefined;
        cacheAware?: boolean | undefined;
        native?: boolean | undefined;
    }) => Promise<(usage: any) => Promise<void>>;
    reserveNative: (inputTokens: any, maxOutputTokens?: number, { compaction }?: {
        compaction?: boolean | undefined;
    }) => Promise<(usage: any) => Promise<void>>;
};
export function countExecutiveModelInput({ request, headers, fetchImpl, maxInputTokens }: {
    request: any;
    headers: any;
    fetchImpl: any;
    maxInputTokens?: number | undefined;
}): Promise<any>;
