export function createExecutiveReportModel({ apiKey, projectId, model, verifiedUntil: _legacyVerification, fetchImpl, now, investigator, investigatorId, spend }: {
    apiKey: any;
    projectId: any;
    model: any;
    verifiedUntil?: undefined;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
    investigator?: typeof investigateWithAgent | undefined;
    investigatorId?: string | undefined;
    spend?: {
        reserve: (inputTokens: any, maxOutputTokens: any, { compaction, cacheAware, native }?: {
            compaction?: boolean | undefined;
            cacheAware?: boolean | undefined;
            native?: boolean | undefined;
        }) => Promise<(usage: any) => Promise<void>>;
        reserveNative: (inputTokens: any, maxOutputTokens?: number, { compaction }?: {
            compaction?: boolean | undefined;
        }) => Promise<(usage: any) => Promise<void>>;
    } | null | undefined;
}): {
    investigate(context: any, controls: any): Promise<any>;
    cacheIdentity: string;
    plan(context: any): Promise<{
        plan: {
            steps: any;
            gaps: any;
        };
        reusePreviousEvidence: boolean;
        metadata: {
            requestedModel: any;
            responseModel: any;
            promptVersion: string;
            inputTokens: any;
            outputTokens: any;
            compactionItems: any;
            latencyMs: number;
        };
    }>;
    synthesize(context: any): Promise<any>;
};
export const EXECUTIVE_REPORT_PROMPT: "executive-agent-workspace-v17";
import { investigateWithAgent } from './executive-analyst-agent.mjs';
