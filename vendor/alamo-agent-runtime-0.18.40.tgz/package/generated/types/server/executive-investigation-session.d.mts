export function validateInvestigationSession(history: any): any;
export function codexInvestigationCheckpoint(threadId: any, rollout: any, workspace?: undefined): string;
export const CODEX_WORKSPACE_BYTES: number;
