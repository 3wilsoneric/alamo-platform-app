export function createExecutiveReportStore({ azure, localRoot, persistenceFor, partitionReports }?: {
    azure?: boolean | undefined;
    localRoot?: string | undefined;
    persistenceFor?: typeof createEveryAgentPersistence | undefined;
    partitionReports?: boolean | undefined;
}): {
    read: (ownerId: any, id: any) => Promise<{
        partitioned: boolean;
        value: any;
        version: string | null;
    }>;
    readExecution: (ownerId: any, id: any) => Promise<{
        id: any;
        status: any;
        deadline: any;
        lease: any;
    } | null>;
    update: (ownerId: any, id: any, mutate: any) => any;
    index: (subject: any, ownerId: any, id: any) => Promise<any>;
    reserveExecution: (subject: any, key: any, now: any) => Promise<void>;
    claimModel: (subject: any, token: any, now: any, leaseMs: any) => Promise<boolean>;
    renewModel: (subject: any, token: any, now: any, leaseMs: any) => Promise<boolean>;
    releaseModel: (token: any) => Promise<void>;
    cachedSynthesis: (subject: any, key: any, now: any) => Promise<{
        proposal: any;
        investigation: any;
        reportId: any;
        runId: any;
    } | null>;
};
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
