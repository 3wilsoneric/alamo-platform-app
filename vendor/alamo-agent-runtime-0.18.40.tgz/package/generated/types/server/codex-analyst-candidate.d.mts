/** @param {{apiKey:string,projectId:string,spend:any,root?:string,isolatedImage?:string|null,sessionEndpoint?:string|null,sessionClientId?:string|null,onEvent?:(event:any)=>any,onProgress?:(text:string)=>any,fetchImpl?:typeof fetch}} options */
export function createCodexInvestigator({ apiKey, projectId, spend, root, isolatedImage, sessionEndpoint, sessionClientId, onEvent, onProgress, fetchImpl }: {
    apiKey: string;
    projectId: string;
    spend: any;
    root?: string;
    isolatedImage?: string | null;
    sessionEndpoint?: string | null;
    sessionClientId?: string | null;
    onEvent?: (event: any) => any;
    onProgress?: (text: string) => any;
    fetchImpl?: typeof fetch;
}): ({ model, schema, instructions, context, controls, promptVersion }: {
    model: any;
    schema: any;
    instructions: any;
    context: any;
    controls: any;
    promptVersion: any;
}) => Promise<any>;
