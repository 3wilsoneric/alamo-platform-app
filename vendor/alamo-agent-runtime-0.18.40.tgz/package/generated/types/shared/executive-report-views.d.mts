export function reportViewContext(evidence: any, scopeKey: any, objective: any): {
    host: string;
    scopeKey: any;
    datasets: any;
    catalog: {
        tags: string[];
        shapes: import("../packages/ally-core/dist/on-demand-view.js").ViewDataShape[];
        hosts: string[];
        id: string;
        version: string;
        purpose: string;
        maxRows: number;
    }[];
};
export function reportViewPlan(proposal: any, context: any): {
    version: "1.0";
    blocks: {
        id: any;
        componentId: any;
        componentVersion: any;
        datasetId: any;
        shape: any;
        sourceIds: any[];
        observedAt: any;
        coverage: any;
        measureKey?: any;
        sort?: {
            key: string;
            direction: "asc" | "desc";
        } | undefined;
        computedColumns?: import("../packages/ally-core/dist/on-demand-view.js").ViewComputedColumn[] | undefined;
        labelKey?: any;
        dateKey?: any;
    }[];
} | {
    version: string;
    blocks: never[];
} | null;
export { applyViewCalculations } from "../packages/ally-core/dist/on-demand-view.js";
/** @type {import('../packages/ally-core/dist/on-demand-view.js').ViewComponentManifest[]} */
export const EXECUTIVE_REPORT_VIEWS: import("../packages/ally-core/dist/on-demand-view.js").ViewComponentManifest[];
