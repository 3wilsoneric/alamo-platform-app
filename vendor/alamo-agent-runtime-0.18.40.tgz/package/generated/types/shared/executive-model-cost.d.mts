export function codexModelReceiptCost(usage: any): number;
export function executiveModelCost(input: any, output: any): number;
export function executiveModelReceiptCost(usage: any): number;
export const executiveModelPricing: Readonly<{
    model: "gpt-6.1-sol";
    currency: "USD";
    inputMicrodollars: 2;
    outputMicrodollars: 10;
    checkedAt: "2026-11-22";
}>;
export const EXECUTIVE_REPORT_MAX_OUTPUT_TOKENS: 6000;
export const CODEX_MODEL_CONTEXT_TOKENS: 1050000;
export const CODEX_MODEL_OUTPUT_TOKENS: 128000;
export const EXECUTIVE_REPORT_EXECUTION_MS: number;
