export function workflowBriefPackDefinition(operation: any): {
    id: string;
    version: number;
    mode: string;
    authority: string;
    limits: {
        selections: number;
        activities: number;
        modelCalls: number;
        sourceReads: number;
        deadlineMs: number;
    };
    skills: any[];
};
export function prepareWorkflowBriefPayload(packet: any): {
    kind: any;
    evidence: any;
    followUp: any;
    humanReview: string;
    sourceMutation: boolean;
    publication: string;
};
export const workflowBriefSkills: Readonly<{
    team_exceptions: {
        id: string;
        version: number;
        title: string;
        when: string;
        prerequisites: string;
        tools: string[];
        output: string;
        completion: string;
    };
    workflow_trend: {
        id: string;
        version: number;
        title: string;
        when: string;
        prerequisites: string;
        tools: string[];
        output: string;
        completion: string;
    };
}>;
export const WORKFLOW_BRIEF_POLICY: string;
