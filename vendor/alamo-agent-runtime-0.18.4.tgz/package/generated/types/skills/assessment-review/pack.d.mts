export namespace assessorSkillPack {
    let id: string;
    let version: number;
    let mode: string;
    let authority: string;
    let requiredCapability: string;
    let sourceApplication: string;
    let inputs: string[];
    namespace limits {
        let selections: number;
        let activities: number;
        let modelCalls: number;
        let sourceReads: number;
        let deadlineMs: number;
    }
    let stop: string[];
    let recovery: string;
    let humanReview: string;
    namespace evaluations {
        let suite: string;
        let rubric: string;
        let humanReviewRequired: boolean;
    }
    let skills: {
        id: string;
        version: number;
        title: string;
        when: string;
        prerequisites: string;
        tools: string[];
        output: string;
        completion: string;
    }[];
}
export const ASSESSOR_PACK_REVISION: string;
