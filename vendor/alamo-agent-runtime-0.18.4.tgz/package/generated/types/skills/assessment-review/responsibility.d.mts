export function validateAssessmentCoverage(value: any, entries: any, sourceCheckedAt: any): {
    version: number;
    recordsExpected: any;
    recordsReviewed: any;
    pageCount: any;
    startedAt: any;
    finishedAt: any;
    rulesVersions: any[];
};
export const ASSESSMENT_REVIEW_RESPONSIBILITY: Readonly<{
    id: "pipeline-assessment-review";
    version: 1;
    skillVersion: 1;
    outcome: "Review every referral returned by the authorized Pipeline scan and save source-linked review evidence.";
    permittedActions: string[];
    requiredLocators: string[];
    completionChecks: string[];
    deadlineMinutes: 20;
    maximumRecords: 500;
    limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
}>;
