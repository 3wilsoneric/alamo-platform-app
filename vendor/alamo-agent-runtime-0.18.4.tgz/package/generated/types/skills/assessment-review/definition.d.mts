declare const _default: Readonly<{
    id: "assessment-review";
    version: 1;
    sourceApplication: "pipeline";
    sourceProtocol: 2;
    title: "Assessment review";
    application: "pipeline";
    applicationName: "Pipeline";
    capability: "pipeline.assessment-review.read";
    responsibility: "Review assessment workflow exceptions";
    description: "Check assigned assessments for missing work, documented decisions and evidence that needs review. Open Pipeline for details.";
    cadence: "Manual activation; checks every 15 minutes when enabled";
    scope: "source-user";
    initiallyPaused: true;
    communities: never[];
    href: "https://alamo-pipeline.com/";
    actions: string[];
}>;
export default _default;
