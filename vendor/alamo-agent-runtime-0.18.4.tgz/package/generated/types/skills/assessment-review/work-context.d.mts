export function draftAssessorSupport(context: any): {
    policyVersion: number;
    teachingSource: Readonly<{
        application: "workflow";
        packId: "alamo-assessor-procedures";
        version: 1;
        sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a";
    }>;
    authority: string;
    status: string;
    sourceWork: string;
    scope: any;
    source: any;
    assignment: any;
    preparation: {
        questions: any;
    };
    review: {
        findings: any;
        clinicalQuality: string;
        wordingSuggestions: never[];
        limitation: string;
    };
    handoff: {
        recordedInformation: any;
        pending: any;
        missingContext: any;
        readiness: string;
        delivery: string;
        procedure: {
            id: string;
            version: number;
            step: string;
        } | undefined;
    };
    evidence: any;
    nextActions: any;
};
export const ASSESSOR_CONTEXT_POLICY_VERSION: 1;
export const ASSESSOR_CONTEXT_TEACHING: Readonly<{
    application: "workflow";
    packId: "alamo-assessor-procedures";
    version: 1;
    sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a";
}>;
export const ASSESSOR_CONTEXT_PROCEDURES: readonly {
    id: string;
    version: number;
    step: string;
}[];
