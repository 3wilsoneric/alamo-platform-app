export function readWorkflowKnowledge({ request, source }: {
    request: any;
    source: any;
}): Promise<import("../../shared/workflow-knowledge-contracts.mjs").KnowledgeResponse>;
export { WORKFLOW_KNOWLEDGE_SKILL };
import { WORKFLOW_KNOWLEDGE_SKILL } from "../../shared/workflow-knowledge-contracts.mjs";
