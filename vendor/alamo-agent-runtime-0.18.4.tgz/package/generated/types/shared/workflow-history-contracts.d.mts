export function workflowStamp(value: any): string;
export function validateWorkflowEvent(value: any): {
    schemaVersion: number;
    id: string;
    caseId: string;
    sourceRevision: any;
    occurredAt: string;
    ingestedAt: string;
    producer: string;
    origin: any;
    kind: any;
    supersedes: string | null;
    data: {
        ownerId: string;
        teamId: string;
        communityId: string;
        summary: string;
        blockerId?: never;
        category?: never;
        question?: never;
        attemptId?: never;
        result?: never;
    } | {
        ownerId: string;
        teamId?: never;
        communityId?: never;
        summary?: never;
        blockerId?: never;
        category?: never;
        question?: never;
        attemptId?: never;
        result?: never;
    } | {
        blockerId: string;
        category: any;
        question: string;
        ownerId?: never;
        teamId?: never;
        communityId?: never;
        summary?: never;
        attemptId?: never;
        result?: never;
    } | {
        blockerId: string;
        ownerId?: never;
        teamId?: never;
        communityId?: never;
        summary?: never;
        category?: never;
        question?: never;
        attemptId?: never;
        result?: never;
    } | {
        attemptId: string;
        result: any;
        ownerId?: never;
        teamId?: never;
        communityId?: never;
        summary?: never;
        blockerId?: never;
        category?: never;
        question?: never;
    } | {
        attemptId: string;
        ownerId?: never;
        teamId?: never;
        communityId?: never;
        summary?: never;
        blockerId?: never;
        category?: never;
        question?: never;
        result?: never;
    };
};
export function workflowFeedRevision(value: any): string;
export function validateWorkflowFeed(value: any, now: any): {
    schemaVersion: number;
    mode: string;
    companyId: string;
    tenantId: string;
    observedAt: string;
    completeThrough: string;
    coverage: any;
    events: {
        schemaVersion: number;
        id: string;
        caseId: string;
        sourceRevision: any;
        occurredAt: string;
        ingestedAt: string;
        producer: string;
        origin: any;
        kind: any;
        supersedes: string | null;
        data: {
            ownerId: string;
            teamId: string;
            communityId: string;
            summary: string;
            blockerId?: never;
            category?: never;
            question?: never;
            attemptId?: never;
            result?: never;
        } | {
            ownerId: string;
            teamId?: never;
            communityId?: never;
            summary?: never;
            blockerId?: never;
            category?: never;
            question?: never;
            attemptId?: never;
            result?: never;
        } | {
            blockerId: string;
            category: any;
            question: string;
            ownerId?: never;
            teamId?: never;
            communityId?: never;
            summary?: never;
            attemptId?: never;
            result?: never;
        } | {
            blockerId: string;
            ownerId?: never;
            teamId?: never;
            communityId?: never;
            summary?: never;
            category?: never;
            question?: never;
            attemptId?: never;
            result?: never;
        } | {
            attemptId: string;
            result: any;
            ownerId?: never;
            teamId?: never;
            communityId?: never;
            summary?: never;
            blockerId?: never;
            category?: never;
            question?: never;
        } | {
            attemptId: string;
            ownerId?: never;
            teamId?: never;
            communityId?: never;
            summary?: never;
            blockerId?: never;
            category?: never;
            question?: never;
            result?: never;
        };
    }[];
    revision: string;
};
export function validateWorkflowActor(value: any): {
    companyId: string;
    tenantId: string;
    subjectId: string;
};
export function validateWorkflowGrant(value: any, actor: any, operation: any, now: any): any;
export function validateWorkflowRead(value: any): {
    operation: any;
};
export const WORKFLOW_OPERATIONS: readonly string[];
export const WORKFLOW_HISTORY_LIMITS: Readonly<{
    events: 500;
    bytes: 1048576;
    freshnessMs: 900000;
}>;
export function workflowUnavailable(): never;
