/** @returns {never} */
export function draftReviewUnavailable(): never;
export function draftReviewId(value: any): string;
export function draftReviewDigest(value: any): string;
export function draftReviewJson(value: any): any;
export function validateDraftReviewCommand(value: any): {
    requestId: string;
    expectedArtifactRevision: string;
    decision: string;
};
export function validateDraftReviewRecord(value: any): {
    artifactRevision: string;
    review: {
        requestId: string;
        artifactRevision: string;
        decision: string;
        subjectId: string;
        reviewedAt: string;
    } | null;
    schemaVersion: number;
    id: string;
    createdAt: string;
    request: {
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
    };
    skillId: string;
    policyRevision: string;
    contextRevision: string;
    payload: any;
};
export function validateDraftReviewState(value: any): {
    version: number;
    revision: number;
    records: {
        artifactRevision: string;
        review: {
            requestId: string;
            artifactRevision: string;
            decision: string;
            subjectId: string;
            reviewedAt: string;
        } | null;
        schemaVersion: number;
        id: string;
        createdAt: string;
        request: {
            scope: {
                companyId: string;
                tenantId: string;
                subjectId: string;
            };
            resourceScope: {
                kind: "community" | "organization" | "source-user";
                ids: string[];
            };
            source: {
                application: string;
                kind: string;
                id: string;
                revision: string | null;
            };
        };
        skillId: string;
        policyRevision: string;
        contextRevision: string;
        payload: any;
    }[];
};
export const DRAFT_REVIEW_LIMITS: Readonly<{
    records: 100;
    payloadBytes: 131072;
    stateBytes: 4194304;
}>;
export function draftReviewConflict(): Error & {
    code: string;
};
export function draftReviewHash(value: any): string;
