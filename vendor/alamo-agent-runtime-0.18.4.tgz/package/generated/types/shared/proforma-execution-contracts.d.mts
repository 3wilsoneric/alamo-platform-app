export function validateExecutionDefinition(input: any): Record<string, any>;
export function validateExecutionCandidate(input: any): Record<string, any>;
export function validateExecutionReference(input: any): Record<string, any>;
export const PROFORMA_REFERRAL_CAPABILITY: "assessor-referral-handoff-draft-v1";
export const EXECUTION_STAGES: string[];
export function executionDefinitionHash(v: any): string;
