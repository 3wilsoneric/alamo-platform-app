export function validateWorkflowBriefView(value: any): {
    kind: string;
    cases: {
        caseId: string;
        ownerId: string;
        teamId: string;
        communityId: string;
        sourceRevision: string;
        elapsedMinutes: number;
        issues: {
            code: any;
            since: string;
            evidenceIds: string[];
        }[];
        latestHandoff: {
            result: any;
            acknowledgment: any;
        };
        sourceEvidenceIds: string[];
    }[];
    coverage: {
        authorizedCases: number;
        source: string;
    };
    asOf: string;
    authority: string;
    sourceMutation: boolean;
    metric?: never;
    periods?: never;
    lineage?: never;
    recordDrilldown?: never;
    causalConclusion?: never;
} | {
    kind: string;
    metric: Readonly<{
        id: "pipeline-first-handoff";
        version: 1;
        minimumCohort: 3;
        periods: {
            id: string;
            from: string;
            through: string;
        }[];
        cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.";
        duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.";
        blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.";
        limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status.";
    }>;
    periods: ({
        measures: null;
        period: string;
        from: string;
        through: string;
        periodStatus: unknown;
        status: unknown;
    } | {
        measures: Record<string, any>;
        period: string;
        from: string;
        through: string;
        periodStatus: unknown;
        status: unknown;
    })[];
    lineage: {
        application: string;
        asOf: string;
        coverage: string;
        queryRevision: string;
    };
    recordDrilldown: string;
    causalConclusion: string;
    sourceMutation: boolean;
    cases?: never;
    coverage?: never;
    asOf?: never;
    authority?: never;
};
export function validateWorkflowBriefPacket(value: any, now: any): {
    schemaVersion: number;
    mode: string;
    snapshot: {
        schemaVersion: number;
        id: string;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        observedAt: string;
        asOf: string | null;
        completeness: "complete" | "partial" | "unknown";
        grant: {
            application: string;
            id: string;
            revision: string;
            expiresAt: string;
        };
    };
    view: {
        kind: string;
        cases: {
            caseId: string;
            ownerId: string;
            teamId: string;
            communityId: string;
            sourceRevision: string;
            elapsedMinutes: number;
            issues: {
                code: any;
                since: string;
                evidenceIds: string[];
            }[];
            latestHandoff: {
                result: any;
                acknowledgment: any;
            };
            sourceEvidenceIds: string[];
        }[];
        coverage: {
            authorizedCases: number;
            source: string;
        };
        asOf: string;
        authority: string;
        sourceMutation: boolean;
        metric?: never;
        periods?: never;
        lineage?: never;
        recordDrilldown?: never;
        causalConclusion?: never;
    } | {
        kind: string;
        metric: Readonly<{
            id: "pipeline-first-handoff";
            version: 1;
            minimumCohort: 3;
            periods: {
                id: string;
                from: string;
                through: string;
            }[];
            cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.";
            duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.";
            blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.";
            limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status.";
        }>;
        periods: ({
            measures: null;
            period: string;
            from: string;
            through: string;
            periodStatus: unknown;
            status: unknown;
        } | {
            measures: Record<string, any>;
            period: string;
            from: string;
            through: string;
            periodStatus: unknown;
            status: unknown;
        })[];
        lineage: {
            application: string;
            asOf: string;
            coverage: string;
            queryRevision: string;
        };
        recordDrilldown: string;
        causalConclusion: string;
        sourceMutation: boolean;
        cases?: never;
        coverage?: never;
        asOf?: never;
        authority?: never;
    };
};
export function verifyWorkflowBriefPacket(value: any, input: any, operation: any, now: any): {
    schemaVersion: number;
    mode: string;
    snapshot: {
        schemaVersion: number;
        id: string;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        observedAt: string;
        asOf: string | null;
        completeness: "complete" | "partial" | "unknown";
        grant: {
            application: string;
            id: string;
            revision: string;
            expiresAt: string;
        };
    };
    view: {
        kind: string;
        cases: {
            caseId: string;
            ownerId: string;
            teamId: string;
            communityId: string;
            sourceRevision: string;
            elapsedMinutes: number;
            issues: {
                code: any;
                since: string;
                evidenceIds: string[];
            }[];
            latestHandoff: {
                result: any;
                acknowledgment: any;
            };
            sourceEvidenceIds: string[];
        }[];
        coverage: {
            authorizedCases: number;
            source: string;
        };
        asOf: string;
        authority: string;
        sourceMutation: boolean;
        metric?: never;
        periods?: never;
        lineage?: never;
        recordDrilldown?: never;
        causalConclusion?: never;
    } | {
        kind: string;
        metric: Readonly<{
            id: "pipeline-first-handoff";
            version: 1;
            minimumCohort: 3;
            periods: {
                id: string;
                from: string;
                through: string;
            }[];
            cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.";
            duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.";
            blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.";
            limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status.";
        }>;
        periods: ({
            measures: null;
            period: string;
            from: string;
            through: string;
            periodStatus: unknown;
            status: unknown;
        } | {
            measures: Record<string, any>;
            period: string;
            from: string;
            through: string;
            periodStatus: unknown;
            status: unknown;
        })[];
        lineage: {
            application: string;
            asOf: string;
            coverage: string;
            queryRevision: string;
        };
        recordDrilldown: string;
        causalConclusion: string;
        sourceMutation: boolean;
        cases?: never;
        coverage?: never;
        asOf?: never;
        authority?: never;
    };
};
export const WORKFLOW_TREND_POLICY: Readonly<{
    id: "pipeline-first-handoff";
    version: 1;
    minimumCohort: 3;
    periods: {
        id: string;
        from: string;
        through: string;
    }[];
    cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.";
    duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.";
    blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.";
    limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status.";
}>;
export const WORKFLOW_BRIEF_OPERATIONS: readonly string[];
