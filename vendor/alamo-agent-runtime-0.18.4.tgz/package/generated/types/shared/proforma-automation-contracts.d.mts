export function validateAutomationBinding(input: any): {
    documentIds: any;
};
export function validateAutomationDefinition(input: any, binding: any, expected: any): Record<string, any>;
export namespace AUTOMATION_BINDINGS {
    let status: string;
    let execution: null;
    let permissions: null;
    let staffAssignments: null;
    let humanDecisions: string;
    let receivingAcceptance: string;
}
