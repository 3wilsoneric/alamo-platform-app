/** @returns {never} */
export function workContextInvalid(): never;
export function validateWorkContextRequest(value: any): {
    scope: {
        companyId: string;
        tenantId: string;
        subjectId: string;
    };
    resourceScope: {
        kind: "community" | "organization" | "source-user";
        ids: string[];
    };
    source: {
        application: string;
        kind: string;
        id: string;
        revision: string | null;
    };
};
/** Parse a bounded source-owned snapshot. Never fetches, grants access or writes. */
export function validateWorkContext(value: any): {
    schemaVersion: number;
    snapshot: {
        schemaVersion: number;
        id: string;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        observedAt: string;
        asOf: string | null;
        completeness: "complete" | "partial" | "unknown";
        grant: {
            application: string;
            id: string;
            revision: string;
            expiresAt: string;
        };
    };
    assignment: {
        ownerId: string;
        revision: string;
    };
    relatedSources: {
        application: string;
        kind: string;
        id: string;
        revision: string | null;
    }[];
    missing: string[];
    content: {
        id: string;
        label: string;
        text: string | null;
        status: any;
        evidenceIds: string[];
    }[];
    evidence: {
        id: string;
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        locator: string;
    }[];
    requirements: {
        id: string;
        label: string;
        status: any;
        ownerId: string | null;
        evidenceIds: string[];
    }[];
    nextActions: {
        id: string;
        label: string;
        mode: string;
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
    }[];
};
export function verifyWorkContext(value: any, request: any, now: any): {
    schemaVersion: number;
    snapshot: {
        schemaVersion: number;
        id: string;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        observedAt: string;
        asOf: string | null;
        completeness: "complete" | "partial" | "unknown";
        grant: {
            application: string;
            id: string;
            revision: string;
            expiresAt: string;
        };
    };
    assignment: {
        ownerId: string;
        revision: string;
    };
    relatedSources: {
        application: string;
        kind: string;
        id: string;
        revision: string | null;
    }[];
    missing: string[];
    content: {
        id: string;
        label: string;
        text: string | null;
        status: any;
        evidenceIds: string[];
    }[];
    evidence: {
        id: string;
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        locator: string;
    }[];
    requirements: {
        id: string;
        label: string;
        status: any;
        ownerId: string | null;
        evidenceIds: string[];
    }[];
    nextActions: {
        id: string;
        label: string;
        mode: string;
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
    }[];
};
export const WORK_CONTEXT_VERSION: 1;
