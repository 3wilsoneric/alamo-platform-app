/** Validates only reviewed capability metadata; no record values or arbitrary tools. */
export function validatePipelineManifest(value: any): {
    version: number;
    application: string;
    capability: string;
    title: any;
    steward: any;
    questionnaireRulesVersion: any;
    concepts: any;
    revision: any;
};
export const PIPELINE_METADATA_MAX_BYTES: 16384;
export const PIPELINE_ONBOARDING_SOURCE: "pipeline-assessment-contract";
export function metadataFields(value: any, keys: any): boolean;
