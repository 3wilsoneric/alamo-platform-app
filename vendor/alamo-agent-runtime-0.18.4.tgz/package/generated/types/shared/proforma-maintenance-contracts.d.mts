/** @returns {never} */
export function invalidMaintenance(message?: string): never;
/** @returns {Record<string, any>} */
export function maintenanceObject(value: any, required: any, optional?: any[]): Record<string, any>;
export function maintenanceText(value: any, max?: number, empty?: boolean): string;
export function maintenanceInteger(value: any, max?: number): number;
export function maintenanceDigest(value: any): string;
export function maintenanceId(value: any): string;
export function validateMaintenanceBinding(input: any): Record<string, any>;
export function validateMaintenanceSession(input: any, binding: any, permission: any): undefined;
export function validateMaintenanceSource(input: any): Record<string, any>;
export function maintenanceApplicationChanges(event: any): {
    signalId: any;
    nodeId: any;
    beforeFingerprint: any;
    afterFingerprint: any;
    before: any;
    after: any;
}[];
export function validateMaintenanceFeed(input: any, binding: any, after: any, streamId: any): Record<string, any>;
export function validateMaintenanceContext(input: any, binding: any, processId: any): {
    source: any;
    streamId: any;
    process: {
        steps: any;
        flow: {
            schemaVersion: number;
            entryStepId: any;
            transitions: any[];
        };
        flowOrigin: any;
        gaps: string[];
        connections: any[];
        id: any;
        title: any;
    };
    work: any;
    assessments: any;
};
export function maintenanceAssessment(context: any, event: any, decision: any): {
    schemaVersion: number;
    streamId: any;
    signalIds: any[];
    processId: any;
    sourceVersion: any;
    outcome: any;
    reason: string;
};
export function validateMaintenanceCommand(input: any): Record<string, any>;
export function validateMaintenanceReceipt(input: any, binding: any, command: any): Record<string, any>;
export const PROFORMA_MAINTENANCE_PATH: "/api/platform/workflow/v1";
export function maintenanceHash(value: any): string;
