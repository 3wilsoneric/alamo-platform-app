/** @returns {OnboardingCommand} */
export function validateOnboardingCommand(value: any): OnboardingCommand;
export function createOnboardingClient(requestJson: any): {
    list: () => any;
    read: (id: any) => any;
    export: (id: any) => any;
    command: (value: any) => any;
};
export const ONBOARDING_API_PATH: "/api/agent/v1/onboarding";
export const ONBOARDING_LIMITS: Readonly<{
    workspaces: 20;
    events: 120;
    sources: 20;
    concepts: 40;
    mappings: 10;
    commandBytes: 8192;
    stateBytes: number;
}>;
export function onboardingId(value: any): boolean;
export type SourceMapping = {
    sourceId: string;
    sourceRevision: number;
    locator: string;
};
export type CreateWorkspace = {
    action: "create";
    requestId: string;
    companyName: string;
    outcome: string;
    successCriterion: string;
};
export type RevisionCommand = {
    requestId: string;
    workspaceId: string;
    expectedRevision: number;
};
export type RegisterSource = RevisionCommand & {
    action: "register_source";
    sourceId: string;
    title: string;
    application: string;
    reference: string;
    sourceVersion: string;
    steward: string;
};
export type ProposeConcept = RevisionCommand & {
    action: "propose_concept";
    conceptId: string;
    label: string;
    definition: string;
    mappings: SourceMapping[];
};
export type ReviewConcept = RevisionCommand & {
    action: "review_concept";
    conceptId: string;
    decision: "confirmed" | "rejected";
    note: string;
};
export type DiscoverPipeline = RevisionCommand & {
    action: "discover_pipeline";
};
export type OnboardingCommand = CreateWorkspace | RegisterSource | ProposeConcept | ReviewConcept | DiscoverPipeline;
