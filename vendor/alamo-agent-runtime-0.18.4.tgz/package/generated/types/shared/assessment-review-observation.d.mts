/** @returns {AssessmentReviewObservation} */
export function validateAssessmentReviewObservation(value: any): AssessmentReviewObservation;
/**
 * A receipt for the agent's review scan, never a claim that Pipeline work was
 * resolved. It contains references and counts only. Validation checks structure;
 * the authenticated producer and existing source checks establish authority.
 */
export type AssessmentReviewObservation = {
    version: 1;
    id: string;
    type: "assessment_review.completed";
    producer: "alamoagent";
    tenantId: string;
    actor: {
        kind: "agent";
        onBehalfOf: string;
    };
    runId: string;
    skill: {
        id: "assessment-review";
        version: number;
        workflowVersion: number;
        assignmentVersion: number;
    };
    occurredAt: string;
    source: {
        application: "pipeline";
        grantId: string;
        grantRevision: string;
        observedFrom: string;
        observedThrough: string;
    };
    definitions: {
        workspaceId: string;
        bindingRevision: string;
        rulesRevision: string;
    };
    outcome: {
        code: "review_completed";
        recordsReviewed: number;
        pageCount: number;
        sourceMutation: false;
    };
    evidence: {
        resultDigest: string;
        workCount: number;
        workIdsDigest: string;
    };
};
