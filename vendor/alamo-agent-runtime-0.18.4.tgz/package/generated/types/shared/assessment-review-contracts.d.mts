export function assessmentReviewRequest(assignment: any, operation: any, cursor?: null): {
    version: number;
    operation: any;
    subjectId: any;
    skillId: any;
    communityIds: never[];
    cursor: null;
};
export function validateAssessmentReviewPage(page: any): any;
export const ASSESSMENT_REVIEW_PATH: "/api/integrations/agent/assessment-review/v2";
