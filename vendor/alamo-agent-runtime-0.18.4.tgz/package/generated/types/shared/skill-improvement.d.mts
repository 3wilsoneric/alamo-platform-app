export function prepareSkillCandidateReview({ baseline, candidate, feedback }: {
    baseline: any;
    candidate: any;
    feedback: any;
}): {
    schemaVersion: number;
    baseline: {
        runId: any;
        harnessRevision: any;
    };
    candidate: {
        runId: any;
        harnessRevision: any;
        parentRevision: any;
    };
    suiteRevision: any;
    rubricVersion: any;
    feedback: {
        id: string;
        evalRunId: any;
        caseId: any;
        trial: any;
        traceRunId: string;
        reviewerId: string;
        category: string;
        observation: string;
        proposedChange: string;
    }[];
    feedbackRevision: string;
    comparisons: {
        id: any;
        baselinePassed: any;
        candidatePassed: any;
        trials: any;
        regression: boolean;
    }[];
    recommendation: string;
    humanApproval: string;
    activation: string;
    releaseReady: boolean;
    limits: string;
};
