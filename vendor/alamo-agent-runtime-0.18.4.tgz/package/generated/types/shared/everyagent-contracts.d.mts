import type { EveryAgentSkill } from "./everyagent-catalog.mjs";
export const EVERYAGENT_VERSION: number;
export interface BindAssessmentReview {
  action: "bind_assessment_review"; workspaceId: string; expectedWorkspaceRevision: number; expectedVersion: number; paused: boolean;
}
export type EveryAgentCommand = { action: "review"; workId: string } | { action: "cancel_run"; runId: string } | { action: "retry_run"; runId: string } | {
  action: "configure"; skillId: string; paused: boolean; communityIds: string[]; expectedVersion: number;
} | BindAssessmentReview;
export function validateEveryAgentCommand(value: unknown): Exclude<EveryAgentCommand, BindAssessmentReview> |
  (BindAssessmentReview & { skillId: "assessment-review"; communityIds: [] });
type ResponsibilityService = ReturnType<typeof import("../server/assessment-review-responsibility.mjs").createAssessmentReviewResponsibility>;
export type AssessmentReviewBinding = Awaited<ReturnType<ResponsibilityService["bind"]>>;
export type AssessmentReviewCompletion = NonNullable<ReturnType<ResponsibilityService["complete"]>> & {
  evidenceWorkIds: string[]; resultDigest: string;
  observation?: import("./assessment-review-observation.mjs").AssessmentReviewObservation;
};
export interface EveryAgentEvidence {
  id: string; kind: string; label: string; href: string; observedAt: string | null;
  resource?: { application: string; kind: string; id: string; revision: string | null };
}
export interface EveryAgentWork {
  runId?: string;
  responsibilityFingerprint?: string;
  sourceFingerprint?: string; sourceCheckedAt?: string | null;
  id: string; skillId: string; title: string; summary: string; status: "needs_review" | "completed";
  createdAt: string; reviewedAt: string | null; communityIds: string[];
  evidence: EveryAgentEvidence[]; relationships: { from: string; relation: string; to: string }[];
}
export interface EveryAgentResponsibility {
  responsibility?: AssessmentReviewBinding;
  outcomeContract?: ResponsibilityService["contract"];
  readiness?: "ready" | "blocked";
  skillId: string; version: number; paused: boolean; communityIds: string[];
  lastChecked: string | null; sourceCheckedAt: string | null; nextCheck: string | null;
  connection: "connected" | "unavailable" | "not_connected" | "not_checked";
  issue: string | null;
}
export interface EveryAgentOverview {
  tasks?: EveryAgentTask[];
  version: number; emailEnabled: false; workerEnabled: boolean;
  skills: EveryAgentSkill[]; responsibilities: EveryAgentResponsibility[]; work: EveryAgentWork[];
  runs: { id: string; skillId: string; startedAt: string; finishedAt: string; status: string; completion?: AssessmentReviewCompletion }[];
  working: boolean;
}
export interface EveryAgentTask {
  completion?: AssessmentReviewCompletion;
  id: string; skillId: string; assignmentVersion: number; skillVersion: number; workflowVersion: number;
  status: "queued" | "running" | "completed" | "failed" | "canceled" | "blocked";
  phase: "queued" | "collect" | "validate" | "publish" | "completed" | "failed" | "canceled" | "blocked";
  attempts: number; createdAt: string; updatedAt: string; finishedAt: string | null;
  issue: string | null; previousRunId: string | null;
}
