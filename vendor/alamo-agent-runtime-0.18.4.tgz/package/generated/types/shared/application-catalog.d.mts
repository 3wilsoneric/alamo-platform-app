/** Return detached metadata and check that every definition has a runtime binding.
 * This describes implementation, never grants or deployment readiness. */
export function describeApplicationCatalog(): {
    schemaVersion: number;
    applications: {
        schemaVersion: number;
        id: string;
        revision: number;
        name: string;
        capabilities: {
            id: string;
            version: number;
            operation: "read";
            scope: "community" | "organization" | "source-user";
            protocol: {
                id: "agent-summary" | "assessment-review" | "workflow-knowledge";
                version: number;
            };
            resourceKinds: string[];
        }[];
    }[];
    skills: {
        id: string;
        version: number;
        name: string;
        application: string;
        capability: string;
        scope: string;
    }[];
};
export const AGENT_CATALOG_PATH: "/api/agent/v1/catalog";
