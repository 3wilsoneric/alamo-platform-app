export function validateMaintenanceDefinition(input: any): Record<string, any>;
export function maintenanceRunKey(binding: any, definitionHash: any, runId: any): Record<string, any>;
export function validateMaintenanceRunKey(input: any): Record<string, any>;
export function maintenancePartition(input: any): string;
export function isMaintenanceBlobPath(value: any): boolean;
export function validateMaintenanceTrace(input: any): Record<string, any>;
export function maintenanceDefinitionHash(value: any): string;
