import type { AgentConversation, ConversationClient } from "./everyagent-conversations.mjs";
export const ASSESSOR_SANDBOX_PATH: string;
export const ASSESSOR_SANDBOX_CASES: { id: string; label: string }[];
export interface SandboxReviewCommand { conversationId: string; turnId: string; requestId: string; expectedArtifactRevision: string; decision: "accept" | "reject" }
export interface AssessorSandboxClient extends ConversationClient { reviewDraft(input: SandboxReviewCommand): Promise<AgentConversation> }
export function createAssessorSandboxClient(requestJson: <T>(path: string, init: RequestInit) => Promise<T>): AssessorSandboxClient;
