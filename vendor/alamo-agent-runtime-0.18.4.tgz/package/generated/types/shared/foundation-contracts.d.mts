/** @returns {never} */
export function foundationInvalid(): never;
/** @param {unknown} value @param {string[]} names @returns {Record<string, unknown>} */
export function foundationObject(value: unknown, names: string[]): Record<string, unknown>;
/** @param {unknown} value */
export function foundationKey(value: unknown): string;
/** @template T @param {unknown} value @param {(item: unknown) => T} validate @param {number} maximum @param {number} [minimum] @returns {T[]} */
export function foundationList<T>(value: unknown, validate: (item: unknown) => T, maximum: number, minimum?: number): T[];
/** @template T @param {T[]} values @param {(item: T) => string} key @returns {T[]} */
export function foundationUnique<T>(values: T[], key: (item: T) => string): T[];
/** @param {unknown} value */
export function validateFoundationScope(value: unknown): {
    companyId: string;
    tenantId: string;
    subjectId: string;
};
/** @param {unknown} value */
export function validateFoundationResourceScope(value: unknown): {
    kind: "community" | "organization" | "source-user";
    ids: string[];
};
/** @param {unknown} value */
export function validateCompanyDefinition(value: unknown): {
    schemaVersion: number;
    companyId: string;
    tenantId: string;
    revision: number;
    name: string;
    subjects: string[];
    applications: {
        id: string;
        revision: number;
    }[];
    skills: {
        id: string;
        version: number;
    }[];
};
/** @param {unknown} value */
export function validateApplicationManifest(value: unknown): {
    schemaVersion: number;
    id: string;
    revision: number;
    name: string;
    capabilities: {
        id: string;
        version: number;
        operation: "read";
        scope: "community" | "organization" | "source-user";
        protocol: {
            id: "agent-summary" | "assessment-review" | "workflow-knowledge";
            version: number;
        };
        resourceKinds: string[];
    }[];
};
/** @param {unknown} value */
export function validateFoundationSkill(value: unknown): {
    schemaVersion: number;
    id: string;
    version: number;
    application: string;
    capability: string;
    capabilityVersion: number;
    scope: "community" | "organization" | "source-user";
    completion: {
        kind: "evidence-collection" | "review-scan";
        checkIds: string[];
    };
    limits: {
        maxRecords: number;
        deadlineSeconds: number;
        maxEvidenceAgeSeconds: number;
    };
    evaluation: {
        id: string;
        version: number;
    };
};
/** @param {unknown} value */
export function validateFoundationResponsibility(value: unknown): {
    schemaVersion: number;
    id: string;
    revision: number;
    scope: {
        companyId: string;
        tenantId: string;
        subjectId: string;
    };
    skill: {
        id: string;
        version: number;
    };
    resourceScope: {
        kind: "community" | "organization" | "source-user";
        ids: string[];
    };
    trigger: {
        kind: "manual";
    };
    state: "draft" | "paused";
};
/** @param {unknown} value */
export function validateFoundationSourceReference(value: unknown): {
    application: string;
    kind: string;
    id: string;
    revision: string | null;
};
/** @param {unknown} value */
export function validateFoundationEvidence(value: unknown): {
    schemaVersion: number;
    id: string;
    scope: {
        companyId: string;
        tenantId: string;
        subjectId: string;
    };
    resourceScope: {
        kind: "community" | "organization" | "source-user";
        ids: string[];
    };
    source: {
        application: string;
        kind: string;
        id: string;
        revision: string | null;
    };
    observedAt: string;
    asOf: string | null;
    completeness: "complete" | "partial" | "unknown";
    grant: {
        application: string;
        id: string;
        revision: string;
        expiresAt: string;
    };
};
/** @param {unknown} value */
export function validateFoundationOutcome(value: unknown): {
    schemaVersion: number;
    id: string;
    runId: string;
    correlationId: string;
    causationId: string | null;
    responsibility: {
        id: string;
        revision: number;
    };
    scope: {
        companyId: string;
        tenantId: string;
        subjectId: string;
    };
    skill: {
        id: string;
        version: number;
    };
    producer: "alamoagent";
    occurredAt: string;
    status: "completed" | "blocked" | "failed" | "canceled";
    reasonCode: string | null;
    kind: "evidence-collection" | "review-scan";
    checks: {
        id: string;
        status: "unknown" | "failed" | "passed";
    }[];
    evidenceIds: string[];
    coverage: {
        expected: number;
        reviewed: number;
    } | null;
    sourceMutation: false;
    publication: "not-published";
};
/**
 * Foundation definition contracts, schema v1. Pure validation: these documents
 * are not deployment configuration, authenticated claims or completion proof.
 * No validator fetches a source, registers a tool or changes production access.
 */
export const FOUNDATION_SCHEMA_VERSION: 1;
