/** Cross-reference validation only; a consistent definition is not an access grant. @param {unknown} value */
export function validateFoundationCatalog(value: unknown): {
    schemaVersion: number;
    applications: {
        schemaVersion: number;
        id: string;
        revision: number;
        name: string;
        capabilities: {
            id: string;
            version: number;
            operation: "read";
            scope: "community" | "organization" | "source-user";
            protocol: {
                id: "agent-summary" | "assessment-review" | "workflow-knowledge";
                version: number;
            };
            resourceKinds: string[];
        }[];
    }[];
    skills: {
        schemaVersion: number;
        id: string;
        version: number;
        application: string;
        capability: string;
        capabilityVersion: number;
        scope: "community" | "organization" | "source-user";
        completion: {
            kind: "evidence-collection" | "review-scan";
            checkIds: string[];
        };
        limits: {
            maxRecords: number;
            deadlineSeconds: number;
            maxEvidenceAgeSeconds: number;
        };
        evaluation: {
            id: string;
            version: number;
        };
    }[];
};
/** @param {unknown} value */
export function validateFoundationBundle(value: unknown): {
    schemaVersion: number;
    catalog: {
        schemaVersion: number;
        applications: {
            schemaVersion: number;
            id: string;
            revision: number;
            name: string;
            capabilities: {
                id: string;
                version: number;
                operation: "read";
                scope: "community" | "organization" | "source-user";
                protocol: {
                    id: "agent-summary" | "assessment-review" | "workflow-knowledge";
                    version: number;
                };
                resourceKinds: string[];
            }[];
        }[];
        skills: {
            schemaVersion: number;
            id: string;
            version: number;
            application: string;
            capability: string;
            capabilityVersion: number;
            scope: "community" | "organization" | "source-user";
            completion: {
                kind: "evidence-collection" | "review-scan";
                checkIds: string[];
            };
            limits: {
                maxRecords: number;
                deadlineSeconds: number;
                maxEvidenceAgeSeconds: number;
            };
            evaluation: {
                id: string;
                version: number;
            };
        }[];
    };
    company: {
        schemaVersion: number;
        companyId: string;
        tenantId: string;
        revision: number;
        name: string;
        subjects: string[];
        applications: {
            id: string;
            revision: number;
        }[];
        skills: {
            id: string;
            version: number;
        }[];
    };
    responsibilities: {
        schemaVersion: number;
        id: string;
        revision: number;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        skill: {
            id: string;
            version: number;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        trigger: {
            kind: "manual";
        };
        state: "draft" | "paused";
    }[];
};
/**
 * Validate a declared outcome against its pinned definition and evidence metadata.
 * Passing this function does NOT authenticate the producer, recheck source access,
 * establish source truth, activate paused work, or publish a completion receipt.
 * @param {unknown} value
 */
export function validateFoundationOutcomeCase(value: unknown): {
    schemaVersion: number;
    bundle: {
        schemaVersion: number;
        catalog: {
            schemaVersion: number;
            applications: {
                schemaVersion: number;
                id: string;
                revision: number;
                name: string;
                capabilities: {
                    id: string;
                    version: number;
                    operation: "read";
                    scope: "community" | "organization" | "source-user";
                    protocol: {
                        id: "agent-summary" | "assessment-review" | "workflow-knowledge";
                        version: number;
                    };
                    resourceKinds: string[];
                }[];
            }[];
            skills: {
                schemaVersion: number;
                id: string;
                version: number;
                application: string;
                capability: string;
                capabilityVersion: number;
                scope: "community" | "organization" | "source-user";
                completion: {
                    kind: "evidence-collection" | "review-scan";
                    checkIds: string[];
                };
                limits: {
                    maxRecords: number;
                    deadlineSeconds: number;
                    maxEvidenceAgeSeconds: number;
                };
                evaluation: {
                    id: string;
                    version: number;
                };
            }[];
        };
        company: {
            schemaVersion: number;
            companyId: string;
            tenantId: string;
            revision: number;
            name: string;
            subjects: string[];
            applications: {
                id: string;
                revision: number;
            }[];
            skills: {
                id: string;
                version: number;
            }[];
        };
        responsibilities: {
            schemaVersion: number;
            id: string;
            revision: number;
            scope: {
                companyId: string;
                tenantId: string;
                subjectId: string;
            };
            skill: {
                id: string;
                version: number;
            };
            resourceScope: {
                kind: "community" | "organization" | "source-user";
                ids: string[];
            };
            trigger: {
                kind: "manual";
            };
            state: "draft" | "paused";
        }[];
    };
    outcome: {
        schemaVersion: number;
        id: string;
        runId: string;
        correlationId: string;
        causationId: string | null;
        responsibility: {
            id: string;
            revision: number;
        };
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        skill: {
            id: string;
            version: number;
        };
        producer: "alamoagent";
        occurredAt: string;
        status: "completed" | "blocked" | "failed" | "canceled";
        reasonCode: string | null;
        kind: "evidence-collection" | "review-scan";
        checks: {
            id: string;
            status: "unknown" | "failed" | "passed";
        }[];
        evidenceIds: string[];
        coverage: {
            expected: number;
            reviewed: number;
        } | null;
        sourceMutation: false;
        publication: "not-published";
    };
    evidence: {
        schemaVersion: number;
        id: string;
        scope: {
            companyId: string;
            tenantId: string;
            subjectId: string;
        };
        resourceScope: {
            kind: "community" | "organization" | "source-user";
            ids: string[];
        };
        source: {
            application: string;
            kind: string;
            id: string;
            revision: string | null;
        };
        observedAt: string;
        asOf: string | null;
        completeness: "complete" | "partial" | "unknown";
        grant: {
            application: string;
            id: string;
            revision: string;
            expiresAt: string;
        };
    }[];
};
