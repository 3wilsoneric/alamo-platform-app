export function validateWorkflowPublisher(value: any): {
    application: string;
    datasetId: string;
    companyId: string;
    tenantId: string;
};
export function workflowPublicationRevision(value: any): string;
export function validateWorkflowPublication(value: any, now: any): {
    schemaVersion: number;
    publisher: {
        application: string;
        datasetId: string;
        companyId: string;
        tenantId: string;
    };
    sequence: number;
    previousRevision: string | null;
    feed: {
        schemaVersion: number;
        mode: string;
        companyId: string;
        tenantId: string;
        observedAt: string;
        completeThrough: string;
        coverage: any;
        events: {
            schemaVersion: number;
            id: string;
            caseId: string;
            sourceRevision: any;
            occurredAt: string;
            ingestedAt: string;
            producer: string;
            origin: any;
            kind: any;
            supersedes: string | null;
            data: {
                ownerId: string;
                teamId: string;
                communityId: string;
                summary: string;
                blockerId?: never;
                category?: never;
                question?: never;
                attemptId?: never;
                result?: never;
            } | {
                ownerId: string;
                teamId?: never;
                communityId?: never;
                summary?: never;
                blockerId?: never;
                category?: never;
                question?: never;
                attemptId?: never;
                result?: never;
            } | {
                blockerId: string;
                category: any;
                question: string;
                ownerId?: never;
                teamId?: never;
                communityId?: never;
                summary?: never;
                attemptId?: never;
                result?: never;
            } | {
                blockerId: string;
                ownerId?: never;
                teamId?: never;
                communityId?: never;
                summary?: never;
                category?: never;
                question?: never;
                attemptId?: never;
                result?: never;
            } | {
                attemptId: string;
                result: any;
                ownerId?: never;
                teamId?: never;
                communityId?: never;
                summary?: never;
                blockerId?: never;
                category?: never;
                question?: never;
            } | {
                attemptId: string;
                ownerId?: never;
                teamId?: never;
                communityId?: never;
                summary?: never;
                blockerId?: never;
                category?: never;
                question?: never;
                result?: never;
            };
        }[];
        revision: string;
    };
    revision: string;
};
