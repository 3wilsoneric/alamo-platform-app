/**
 * Compare declarations with the checked-in registry. No migration, connection,
 * authentication, grant creation or claim of source readiness occurs here.
 * @param {unknown} value
 */
export function describeFoundationCompatibility(value: unknown): {
    skillId: string;
    application: string;
    protocolVersion: number;
    status: "declaration-compatible";
    completionMapping: string;
    requiresCompanySourceBinding: boolean;
    productionActivation: boolean;
}[];
/**
 * Produce an offline wire-format EXAMPLE for the existing request validators.
 * Legacy wire protocols do not carry companyId. A future runtime adapter must
 * separately verify the company/tenant/source binding and current source grant.
 * This function is never used by the API, worker or transport to authorize work.
 * @param {unknown} value @param {string} responsibilityId
 */
export function buildLegacyReadExample(value: unknown, responsibilityId: string): {
    companyId: string;
    tenantId: string;
    application: string;
    request: {
        version: number;
        operation: any;
        subjectId: any;
        skillId: any;
        communityIds: any[];
    };
    authorization: "not-established";
};
