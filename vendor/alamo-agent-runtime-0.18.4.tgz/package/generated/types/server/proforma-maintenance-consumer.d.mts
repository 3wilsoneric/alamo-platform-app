export function createProFormaMaintenanceConsumer({ binding: input, source, persistence, assess, now }: {
    binding: any;
    source: any;
    persistence: any;
    assess: any;
    now?: (() => string) | undefined;
}): {
    runOnce: ({ maxOperations }?: {
        maxOperations?: number | undefined;
    }) => Promise<{
        status: string;
        cursor: any;
        streamId: any;
        assessed: number;
        skipped: number;
        canExecute: boolean;
    }>;
    status(): Promise<{
        revision: any;
        cursor: any;
        streamId: any;
        pending: boolean;
        receipts: any;
        canExecute: boolean;
    }>;
};
