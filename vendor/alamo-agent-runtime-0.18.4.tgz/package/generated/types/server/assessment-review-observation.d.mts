export function createAssessmentReviewObservation(task: any, completion: any): import("../shared/assessment-review-observation.mjs").AssessmentReviewObservation;
