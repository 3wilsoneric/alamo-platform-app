export function createExecutiveReportSource({ origin, getToken, fetchImpl, now }: {
    origin: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    authorize(subject: any, scope: any, step: any): Promise<any>;
    catalog(subject: any, scope: any): Promise<any>;
    read(subject: any, scope: any, step: any): Promise<any>;
};
