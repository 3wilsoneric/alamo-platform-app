export function createAssessmentReviewResponsibility({ onboarding, now }?: {
    onboarding?: {
        read: (auth: any, id?: string | null, format?: string) => Promise<{
            workspaces: {
                id: string;
                companyName: string;
                outcome: string;
                revision: number;
                readiness: {
                    definitions: string;
                    gaps: ({
                        code: string;
                        subjectId: string;
                    } | {
                        code: string;
                        subjectId: null;
                    })[];
                    activation: string;
                    remainingGates: string[];
                };
            }[];
            schema?: never;
            exportedAt?: never;
            tenantId?: never;
            ownerId?: never;
            workspace?: never;
            history?: never;
        } | {
            schema: string;
            exportedAt: string;
            tenantId: string;
            ownerId: string;
            workspace: {
                concepts: {
                    status: string;
                    id: string;
                    label: string;
                    definition: string;
                    revision: number;
                    mappings: import("./onboarding-workspace.mjs").Mapping[];
                    review: import("./onboarding-workspace.mjs").Review | null;
                    originSourceId?: string;
                    retired?: boolean;
                }[];
                readiness: {
                    definitions: string;
                    gaps: ({
                        code: string;
                        subjectId: string;
                    } | {
                        code: string;
                        subjectId: null;
                    })[];
                    activation: string;
                    remainingGates: string[];
                };
                id: string;
                companyName: string;
                outcome: string;
                successCriterion: string;
                revision: number;
                sources: import("./onboarding-workspace.mjs").Source[];
            };
            history: import("./onboarding-workspace.mjs").OnboardingEvent[];
            workspaces?: never;
        } | {
            workspace: {
                concepts: {
                    status: string;
                    id: string;
                    label: string;
                    definition: string;
                    revision: number;
                    mappings: import("./onboarding-workspace.mjs").Mapping[];
                    review: import("./onboarding-workspace.mjs").Review | null;
                    originSourceId?: string;
                    retired?: boolean;
                }[];
                readiness: {
                    definitions: string;
                    gaps: ({
                        code: string;
                        subjectId: string;
                    } | {
                        code: string;
                        subjectId: null;
                    })[];
                    activation: string;
                    remainingGates: string[];
                };
                id: string;
                companyName: string;
                outcome: string;
                successCriterion: string;
                revision: number;
                sources: import("./onboarding-workspace.mjs").Source[];
            };
            workspaces?: never;
            schema?: never;
            exportedAt?: never;
            tenantId?: never;
            ownerId?: never;
            history?: never;
        }>;
        command: (auth: any, input: any) => Promise<{
            workspace: {
                concepts: {
                    status: string;
                    id: string;
                    label: string;
                    definition: string;
                    revision: number;
                    mappings: import("./onboarding-workspace.mjs").Mapping[];
                    review: import("./onboarding-workspace.mjs").Review | null;
                    originSourceId?: string;
                    retired?: boolean;
                }[];
                readiness: {
                    definitions: string;
                    gaps: ({
                        code: string;
                        subjectId: string;
                    } | {
                        code: string;
                        subjectId: null;
                    })[];
                    activation: string;
                    remainingGates: string[];
                };
                id: string;
                companyName: string;
                outcome: string;
                successCriterion: string;
                revision: number;
                sources: import("./onboarding-workspace.mjs").Source[];
            };
            receipt: {
                requestId: string;
                appliedRevision: number;
                replayed: boolean;
            };
        }>;
    } | undefined;
    now?: (() => number) | undefined;
}): {
    bind: (userId: any, workspaceId: any, expectedRevision: any) => Promise<{
        fingerprint: string;
        workspaceRevision: number;
        contractId: "pipeline-assessment-review";
        contractVersion: 1;
        skillVersion: 1;
        workspaceId: any;
        sourceId: string;
        manifestRevision: string;
        questionnaireRulesVersion: any;
        sourceAccess: {
            application: any;
            id: any;
            revision: any;
        };
        definitionsDigest: string;
    }>;
    authorize: (assignment: any) => Promise<void>;
    complete: (assignment: any, result: any, startedAt: any) => {
        contractId: "pipeline-assessment-review";
        contractVersion: 1;
        outcome: string;
        binding: any;
        sourceGrant: any;
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
        checks: {
            id: string;
            status: string;
        }[];
        completedAt: string;
        limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
    } | null;
    contract: Readonly<{
        id: "pipeline-assessment-review";
        version: 1;
        skillVersion: 1;
        outcome: "Review every referral returned by the authorized Pipeline scan and save source-linked review evidence.";
        permittedActions: string[];
        requiredLocators: string[];
        completionChecks: string[];
        deadlineMinutes: 20;
        maximumRecords: 500;
        limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
    }>;
};
