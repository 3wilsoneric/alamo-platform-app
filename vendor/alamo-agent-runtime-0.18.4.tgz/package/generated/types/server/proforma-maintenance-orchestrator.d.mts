/** @type {import('durable-functions').OrchestrationHandler} */
export const proformaMaintenanceV1: import("durable-functions").OrchestrationHandler;
