export function createEveryAgentSourceRuntime({ env, credentialFor }?: {
    env?: NodeJS.ProcessEnv | undefined;
    credentialFor?: ((clientId: any) => ManagedIdentityCredential) | undefined;
}): {
    authorize: (assignment: any, receipt?: undefined) => any;
    adapters: {
        [k: string]: (assignment: any) => any;
    };
    describe: (assignment: any) => any;
    configuredApplications: () => any[];
};
import { ManagedIdentityCredential } from "@azure/identity";
