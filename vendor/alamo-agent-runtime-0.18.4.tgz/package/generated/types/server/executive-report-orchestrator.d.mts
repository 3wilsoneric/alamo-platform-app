export function executiveReportV1(context: any): Generator<any, any, unknown>;
