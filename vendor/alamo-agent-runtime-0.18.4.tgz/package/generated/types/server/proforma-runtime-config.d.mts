/** @returns {RuntimeConfig|null} */
export function readProFormaRuntimeConfig(env?: NodeJS.ProcessEnv): RuntimeConfig | null;
export type SourceBinding = {
    schemaVersion: 1;
    id: string;
    origin: string;
    scope: {
        tenantId: string;
        workspace: "workflow";
    };
    actorId: string;
    documentIds: string[];
    purpose: string;
    policyVersion: string;
};
export type RuntimeConfig = {
    schemaVersion: 1;
    identity: {
        tenantId: string;
        clientId: string;
        credential: {
            kind: "certificate";
            path: string;
        } | {
            kind: "managed-identity";
            clientId: string;
        };
    };
    sourceScope: string;
    bindings: SourceBinding[];
    models: {
        quality: string;
        selection: string;
    };
    evaluationDigest: string;
};
