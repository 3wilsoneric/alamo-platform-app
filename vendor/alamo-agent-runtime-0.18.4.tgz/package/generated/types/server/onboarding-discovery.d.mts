export function validateDiscoveryEvidence(value: any): {
    reference: string;
    observedAt: any;
    manifest: {
        version: number;
        application: string;
        capability: string;
        title: any;
        steward: any;
        questionnaireRulesVersion: any;
        concepts: any;
        revision: any;
    };
    grant: {
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    };
};
export function sameDiscoveryAccess(a: any, b: any): boolean;
