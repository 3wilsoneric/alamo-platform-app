export function workContextRevision(context: any): string;
export function prepareAssessorWork(value: any, deps: any): Promise<{
    schemaVersion: number;
    contextRevision: string;
    draft: {
        policyVersion: number;
        teachingSource: Readonly<{
            application: "workflow";
            packId: "alamo-assessor-procedures";
            version: 1;
            sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a";
        }>;
        authority: string;
        status: string;
        sourceWork: string;
        scope: any;
        source: any;
        assignment: any;
        preparation: {
            questions: any;
        };
        review: {
            findings: any;
            clinicalQuality: string;
            wordingSuggestions: never[];
            limitation: string;
        };
        handoff: {
            recordedInformation: any;
            pending: any;
            missingContext: any;
            readiness: string;
            delivery: string;
            procedure: {
                id: string;
                version: number;
                step: string;
            } | undefined;
        };
        evidence: any;
        nextActions: any;
    };
}>;
export function readAssessorDraft(candidate: any, value: any, deps: any): Promise<{
    schemaVersion: number;
    contextRevision: string;
    draft: {
        policyVersion: number;
        teachingSource: Readonly<{
            application: "workflow";
            packId: "alamo-assessor-procedures";
            version: 1;
            sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a";
        }>;
        authority: string;
        status: string;
        sourceWork: string;
        scope: any;
        source: any;
        assignment: any;
        preparation: {
            questions: any;
        };
        review: {
            findings: any;
            clinicalQuality: string;
            wordingSuggestions: never[];
            limitation: string;
        };
        handoff: {
            recordedInformation: any;
            pending: any;
            missingContext: any;
            readiness: string;
            delivery: string;
            procedure: {
                id: string;
                version: number;
                step: string;
            } | undefined;
        };
        evidence: any;
        nextActions: any;
    };
}>;
export function reviewAssessorDraft(candidate: any, decision: any, value: any, deps: any): Promise<{
    humanReview: {
        decision: any;
        subjectId: any;
        reviewedAt: string;
    };
    status: string;
    sourceWork: string;
    schemaVersion: number;
    contextRevision: string;
    draft: {
        policyVersion: number;
        teachingSource: Readonly<{
            application: "workflow";
            packId: "alamo-assessor-procedures";
            version: 1;
            sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a";
        }>;
        authority: string;
        status: string;
        sourceWork: string;
        scope: any;
        source: any;
        assignment: any;
        preparation: {
            questions: any;
        };
        review: {
            findings: any;
            clinicalQuality: string;
            wordingSuggestions: never[];
            limitation: string;
        };
        handoff: {
            recordedInformation: any;
            pending: any;
            missingContext: any;
            readiness: string;
            delivery: string;
            procedure: {
                id: string;
                version: number;
                step: string;
            } | undefined;
        };
        evidence: any;
        nextActions: any;
    };
}>;
