export function createSkillRunner({ pack, selector, traceSink, clock }: {
    pack: any;
    selector: any;
    traceSink: any;
    clock?: (() => number) | undefined;
}): {
    run(value: any): Promise<{
        runId: `${string}-${string}-${string}-${string}-${string}`;
        status: string;
        reason: string | null;
        choice: string | null;
        artifact: any;
        sourceWork: string;
        delivery: string;
    }>;
};
export const SKILL_RUNNER_VERSION: "bounded-skill-runner-v1";
