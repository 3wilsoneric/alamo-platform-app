export function createSourceTransport({ origin, getToken, fetchImpl, now, application, endpoint, maximumBytes, timeoutMs }: {
    origin: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
    application?: string | undefined;
    endpoint?: string | undefined;
    maximumBytes?: number | undefined;
    timeoutMs?: number | undefined;
}): (input: any) => Promise<any>;
export function createEveryAgentSourceClient(config: any): {
    authorize: (assignment: any, expected?: ReturnType<typeof validateAgentSourceGrant> | null) => Promise<{
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    }>;
    read: (assignment: any) => Promise<{
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
    }>;
    adapters: {
        licensing: (assignment: any) => Promise<{
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage?: never;
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage?: never;
        }>;
        "admissions-watch": (assignment: any) => Promise<{
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage?: never;
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
            coverage?: never;
        }>;
    };
};
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
