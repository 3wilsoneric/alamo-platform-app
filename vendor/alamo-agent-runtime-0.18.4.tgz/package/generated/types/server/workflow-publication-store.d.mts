export function createWorkflowPublicationStore({ publisher, persistence, authorizePublisher, now }: {
    publisher: any;
    persistence: any;
    authorizePublisher: any;
    now?: (() => number) | undefined;
}): {
    publish: (input: any) => Promise<{
        status: any;
        sequence: any;
        publicationRevision: any;
        feedRevision: any;
        completeThrough: any;
    }>;
    readFeed(): Promise<any>;
};
