export function handleAssessorSandboxHttp(req: any, res: any, auth: any, sandbox: any): Promise<void>;
