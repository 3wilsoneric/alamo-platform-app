export function createAssessorSkillPack(deps: any): {
    definition: {
        id: string;
        version: number;
        mode: string;
        authority: string;
        requiredCapability: string;
        sourceApplication: string;
        inputs: string[];
        limits: {
            selections: number;
            activities: number;
            modelCalls: number;
            sourceReads: number;
            deadlineMs: number;
        };
        stop: string[];
        recovery: string;
        humanReview: string;
        evaluations: {
            suite: string;
            rubric: string;
            humanReviewRequired: boolean;
        };
        skills: {
            id: string;
            version: number;
            title: string;
            when: string;
            prerequisites: string;
            tools: string[];
            output: string;
            completion: string;
        }[];
    };
    revision: string;
    observe(request: any, parentId: any, readPacket: any): Promise<{
        state: {
            quality: string;
            openQuestions: any;
            sourceWork: string;
            delivery: string;
            receivingOwner: string;
        };
        eligible: string[];
        packetRevision: string;
        revision: string;
    }>;
    readPacket: any;
    execute(choice: any, request: any, parentId: any, readPacket: any, callModel: any): Promise<any>;
};
