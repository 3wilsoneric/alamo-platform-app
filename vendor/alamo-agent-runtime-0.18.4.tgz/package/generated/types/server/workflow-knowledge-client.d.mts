export function createWorkflowKnowledgeClient({ origin, getToken, fetchImpl, now }: {
    origin: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    read(request: any): Promise<import("../shared/workflow-knowledge-contracts.mjs").KnowledgeResponse>;
};
export { hasEveryAgentAccess } from "../shared/everyagent-identity.mjs";
export { readWorkflowKnowledge, WORKFLOW_KNOWLEDGE_SKILL } from "../skills/workflow-knowledge/read.mjs";
