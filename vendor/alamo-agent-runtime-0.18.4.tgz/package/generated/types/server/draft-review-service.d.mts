export function createDraftReviewService({ store, skillId, policyRevision, readContext, contextRevision, validatePayload, now }: {
    store: any;
    skillId: any;
    policyRevision: any;
    readContext: any;
    contextRevision: any;
    validatePayload: any;
    now: any;
}): {
    save: (...args: any[]) => Promise<any>;
    read: (...args: any[]) => Promise<any>;
    review: (...args: any[]) => Promise<any>;
};
