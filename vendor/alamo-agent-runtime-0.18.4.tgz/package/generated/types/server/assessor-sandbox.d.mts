/** @param {{store:any,drafts:any,model:any,selector:any,clientIds:string[],now?:()=>number,processExecution?:any}} options */
export function createAssessorSandboxService({ store, drafts, model, selector, clientIds, now, processExecution }: {
    store: any;
    drafts: any;
    model: any;
    selector: any;
    clientIds: string[];
    now?: () => number;
    processExecution?: any;
}): {
    read: (auth: any, id?: string | null) => Promise<{
        modelAvailable: boolean;
        conversations: {
            id: any;
            title: string;
            createdAt: any;
            locked: boolean;
        }[];
    } | {
        processBinding?: any;
        processOutcome?: {
            sourceWork: string;
            delivery: string;
            humanSteps: any;
        };
        id: string;
        version: any;
        createdAt: any;
        scope: {
            skillId: string;
            communityIds: never[];
        }[];
        workId: any;
        turns: {
            trace?: {
                runId: any;
                events: any;
            };
            draftReview?: {
                artifactId: any;
                artifactRevision: any;
                decision: any;
            };
            answer?: {
                paragraphs: {
                    kind: string;
                    text: any;
                    sourceIds: never[];
                }[];
            };
            id: any;
            text: any;
            status: any;
            createdAt: any;
        }[];
        modelAvailable?: never;
        conversations?: never;
    }>;
    command(auth: any, raw: any): Promise<any>;
};
