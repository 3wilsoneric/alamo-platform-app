/** Server-owned definitions must come from authenticated review/activation state.
 * No model response, source prose, browser field or timer can approve a binding. */
export function createProFormaMaintenanceHost({ definitions, sourceFor, modelFor, authorizeControl, storageFor, now }: {
    definitions: any;
    sourceFor: any;
    modelFor: any;
    authorizeControl: any;
    storageFor?: typeof createProFormaMaintenanceStorage | undefined;
    now?: (() => number) | undefined;
}): {
    prepare: () => Promise<any[]>;
    execute: (input: any) => Promise<{
        key: any;
        status: any;
        attempts: any;
        createdAt: any;
        updatedAt: any;
        result: any;
        evidenceIds: any;
        issue: any;
        canExecute: boolean;
    }>;
    fail(input: any): Promise<{
        key: any;
        status: any;
        attempts: any;
        createdAt: any;
        updatedAt: any;
        result: any;
        evidenceIds: any;
        issue: any;
        canExecute: boolean;
    }>;
    cancel(input: any, caller: any): Promise<{
        key: any;
        status: any;
        attempts: any;
        createdAt: any;
        updatedAt: any;
        result: any;
        evidenceIds: any;
        issue: any;
        canExecute: boolean;
    }>;
    status(input: any, caller: any): Promise<{
        key: any;
        status: any;
        attempts: any;
        createdAt: any;
        updatedAt: any;
        result: any;
        evidenceIds: any;
        issue: any;
        canExecute: boolean;
    }>;
    evidence(input: any, id: any, caller: any): Promise<Record<string, any>>;
};
import { createProFormaMaintenanceStorage } from './proforma-maintenance-storage.mjs';
