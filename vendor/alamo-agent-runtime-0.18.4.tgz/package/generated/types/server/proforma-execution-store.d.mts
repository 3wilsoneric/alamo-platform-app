export function createProFormaExecutionStore(persistence: any): {
    read: () => Promise<any>;
    update: (mutate: any) => Promise<any>;
};
