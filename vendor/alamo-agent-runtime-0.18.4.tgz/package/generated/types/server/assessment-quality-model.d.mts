/** @returns {never} */
export function qualityUnavailable(): never;
export function validateAssessmentQualityResult(value: any, packet: any): {
    review: {
        reviews: {
            contentId: string;
            assessment: any;
            support: {
                evidenceId: string;
                quote: string;
            }[];
            findings: {
                kind: any;
                explanation: string;
                citations: {
                    evidenceId: string;
                    quote: string;
                }[];
            }[];
            wording: {
                text: string;
                citations: {
                    evidenceId: string;
                    quote: string;
                }[];
            } | null;
            question: string | null;
        }[];
        handoff: {
            text: string;
            citations: {
                evidenceId: string;
                quote: string;
            }[];
        }[];
    };
    requestedModel: string;
    responseModel: string;
    promptVersion: string;
    usage: {
        inputTokens: number;
        outputTokens: number;
    } | null;
};
export function createAssessmentQualityModel({ apiKey, model, fetchImpl }?: {
    apiKey?: string | undefined;
    model?: string | undefined;
    fetchImpl?: typeof fetch | undefined;
}): {
    available: boolean;
    model: string;
    promptVersion: string;
    review(packet: any): Promise<{
        review: {
            reviews: {
                contentId: string;
                assessment: any;
                support: {
                    evidenceId: string;
                    quote: string;
                }[];
                findings: {
                    kind: any;
                    explanation: string;
                    citations: {
                        evidenceId: string;
                        quote: string;
                    }[];
                }[];
                wording: {
                    text: string;
                    citations: {
                        evidenceId: string;
                        quote: string;
                    }[];
                } | null;
                question: string | null;
            }[];
            handoff: {
                text: string;
                citations: {
                    evidenceId: string;
                    quote: string;
                }[];
            }[];
        };
        requestedModel: string;
        responseModel: string;
        promptVersion: string;
        usage: {
            inputTokens: number;
            outputTokens: number;
        } | null;
    }>;
};
