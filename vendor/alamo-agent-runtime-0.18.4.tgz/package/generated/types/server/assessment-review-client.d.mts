export function assessmentReviewEntry(row: any, observedAt: any): {
    key: string;
    fingerprint: string;
    communityIds: never[];
    title: string;
    summary: string;
    evidence: {
        id: string;
        kind: string;
        label: string;
        href: string;
        observedAt: any;
    }[];
    relationships: never[];
};
export function createAssessmentReviewClient(config: any): {
    authorize: (assignment: any, expected?: ReturnType<typeof validateAgentSourceGrant> | null) => Promise<{
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    }>;
    read: (assignment: any) => Promise<{
        connection: string;
        issue: null;
        sourceCheckedAt: any;
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        entries: {
            key: string;
            fingerprint: string;
            communityIds: never[];
            title: string;
            summary: string;
            evidence: {
                id: string;
                kind: string;
                label: string;
                href: string;
                observedAt: any;
            }[];
            relationships: never[];
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: number;
            pageCount: number;
            startedAt: any;
            finishedAt: string;
            rulesVersions: any[];
        };
    }>;
    describe: (assignment: any) => Promise<{
        reference: string;
        observedAt: string;
        manifest: {
            version: number;
            application: string;
            capability: string;
            title: any;
            steward: any;
            questionnaireRulesVersion: any;
            concepts: any;
            revision: any;
        };
        grant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    }>;
};
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
