export function prepareAssessmentQualityDraft(value: any, deps: any): Promise<{
    id: any;
    contextRevision: any;
    artifactRevision: any;
    modelRun: any;
    draft: any;
    humanReview: any;
    status: any;
    sourceWork: any;
}>;
export function readAssessmentQualityDraft(id: any, value: any, deps: any): Promise<{
    id: any;
    contextRevision: any;
    artifactRevision: any;
    modelRun: any;
    draft: any;
    humanReview: any;
    status: any;
    sourceWork: any;
}>;
export function reviewAssessmentQualityDraft(id: any, command: any, value: any, deps: any): Promise<{
    id: any;
    contextRevision: any;
    artifactRevision: any;
    modelRun: any;
    draft: any;
    humanReview: any;
    status: any;
    sourceWork: any;
}>;
export function assessmentQualityPacketRevision(packet: any): string;
