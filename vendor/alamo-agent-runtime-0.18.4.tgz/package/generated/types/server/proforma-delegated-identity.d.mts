export function createProFormaDelegatedIdentity({ config, authorize, now, credentialFor, managedIdentityFor }: {
    config: any;
    authorize: any;
    now?: (() => number) | undefined;
    credentialFor?: ((options: any) => OnBehalfOfCredential) | undefined;
    managedIdentityFor?: ((clientId: any) => ManagedIdentityCredential) | undefined;
}): {
    authorize: (req: any) => Promise<any>;
    getToken: (auth: any) => Promise<{
        token: any;
        expiresOnTimestamp: number;
    }>;
};
import { OnBehalfOfCredential } from '@azure/identity';
import { ManagedIdentityCredential } from '@azure/identity';
