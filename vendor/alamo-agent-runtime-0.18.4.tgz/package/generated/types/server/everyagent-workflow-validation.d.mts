export function validateEveryAgentWorkflowResult(value: any, assignment: any): {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    coverage: {
        version: number;
        recordsExpected: any;
        recordsReviewed: any;
        pageCount: any;
        startedAt: any;
        finishedAt: any;
        rulesVersions: any[];
    };
    sourceGrant?: never;
} | {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    coverage?: never;
    sourceGrant?: never;
} | {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    coverage: {
        version: number;
        recordsExpected: any;
        recordsReviewed: any;
        pageCount: any;
        startedAt: any;
        finishedAt: any;
        rulesVersions: any[];
    };
    sourceGrant: {
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    };
} | {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    coverage?: never;
    sourceGrant: {
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    };
};
