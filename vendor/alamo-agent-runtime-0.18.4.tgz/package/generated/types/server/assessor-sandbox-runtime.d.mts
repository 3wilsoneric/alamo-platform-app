/** @param {{enabled?:string|undefined,deploymentKind?:string|undefined,clientIds:string[],processExecution?:any,model?:any,selector?:any}} options */
export function createAssessorSandboxRuntime({ enabled, deploymentKind, clientIds, processExecution, model, selector }: {
    enabled?: string | undefined;
    deploymentKind?: string | undefined;
    clientIds: string[];
    processExecution?: any;
    model?: any;
    selector?: any;
}): {
    read: (auth: any, id?: string | null) => Promise<{
        modelAvailable: boolean;
        conversations: {
            id: any;
            title: string;
            createdAt: any;
            locked: boolean;
        }[];
    } | {
        processBinding?: any;
        processOutcome?: {
            sourceWork: string;
            delivery: string;
            humanSteps: any;
        };
        id: string;
        version: any;
        createdAt: any;
        scope: {
            skillId: string;
            communityIds: never[];
        }[];
        workId: any;
        turns: {
            trace?: {
                runId: any;
                events: any;
            };
            draftReview?: {
                artifactId: any;
                artifactRevision: any;
                decision: any;
            };
            answer?: {
                paragraphs: {
                    kind: string;
                    text: any;
                    sourceIds: never[];
                }[];
            };
            id: any;
            text: any;
            status: any;
            createdAt: any;
        }[];
        modelAvailable?: never;
        conversations?: never;
    }>;
    command(auth: any, raw: any): Promise<any>;
} | null;
