export function createExecutiveReportStore({ azure, localRoot, persistenceFor }?: {
    azure?: boolean | undefined;
    localRoot?: string | undefined;
    persistenceFor?: typeof createEveryAgentPersistence | undefined;
}): {
    read: (ownerId: any, id: any) => Promise<{
        value: any;
        version: string | null;
    }>;
    update: (ownerId: any, id: any, mutate: any) => Promise<any>;
    index: (subject: any, ownerId: any, id: any) => Promise<any>;
    reserveExecution: (subject: any, key: any, now: any) => Promise<void>;
};
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
