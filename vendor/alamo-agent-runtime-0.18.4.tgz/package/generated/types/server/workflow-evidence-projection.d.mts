export function projectWorkflowHistory(feed: any): any[];
export function projectRoleView(records: any, grant: any, operation: any, feed: any): {
    kind: string;
    metric: Readonly<{
        id: "pipeline-first-handoff";
        version: 1;
        minimumCohort: 3;
        periods: {
            id: string;
            from: string;
            through: string;
        }[];
        cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.";
        duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.";
        blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.";
        limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status.";
    }>;
    periods: ({
        period: string;
        from: string;
        through: string;
        periodStatus: string;
        status: string;
        measures: null;
    } | {
        period: string;
        from: string;
        through: string;
        periodStatus: string;
        status: string;
        measures: {
            cases: any;
            casesWithRecordedSend: any;
            pendingRecordedSend: number;
            casesWithBlocker: any;
            blockerDenominator: any;
            casesWithUnresolvedBlockers: any;
            casesWithUnknownAcknowledgment: any;
            medianMinutesToFirstRecordedSend: number | null;
            durationStatus: string;
            sentCaseDenominator: any;
        };
    })[];
    lineage: {
        application: string;
        asOf: any;
        coverage: string;
        queryRevision: string;
    };
    recordDrilldown: string;
    causalConclusion: string;
    sourceMutation: boolean;
} | {
    kind: any;
    cases: any;
    coverage: {
        authorizedCases: any;
        source: string;
    };
    asOf: any;
    authority: string;
    sourceMutation: boolean;
};
export { WORKFLOW_TREND_POLICY };
import { WORKFLOW_TREND_POLICY } from "../shared/workflow-brief-contracts.mjs";
