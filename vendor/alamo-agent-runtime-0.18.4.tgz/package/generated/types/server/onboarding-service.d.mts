export function createOnboardingService({ store, now, source }?: {
    store?: {
        read: () => Promise<{
            value: import("./onboarding-store.mjs").OnboardingState;
            version: string | null;
        }>;
        update: (mutate: (state: OnboardingState) => boolean | Promise<boolean>) => Promise<import("./onboarding-store.mjs").OnboardingState>;
    } | undefined;
    now?: (() => number) | undefined;
    source?: {
        describe: (assignment: any) => Promise<ReturnType<typeof validateDiscoveryEvidence>>;
    } | null | undefined;
}): {
    read: (auth: any, id?: string | null, format?: string) => Promise<{
        workspaces: {
            id: string;
            companyName: string;
            outcome: string;
            revision: number;
            readiness: {
                definitions: string;
                gaps: ({
                    code: string;
                    subjectId: string;
                } | {
                    code: string;
                    subjectId: null;
                })[];
                activation: string;
                remainingGates: string[];
            };
        }[];
        schema?: never;
        exportedAt?: never;
        tenantId?: never;
        ownerId?: never;
        workspace?: never;
        history?: never;
    } | {
        schema: string;
        exportedAt: string;
        tenantId: string;
        ownerId: string;
        workspace: {
            concepts: {
                status: string;
                id: string;
                label: string;
                definition: string;
                revision: number;
                mappings: import("./onboarding-workspace.mjs").Mapping[];
                review: import("./onboarding-workspace.mjs").Review | null;
                originSourceId?: string;
                retired?: boolean;
            }[];
            readiness: {
                definitions: string;
                gaps: ({
                    code: string;
                    subjectId: string;
                } | {
                    code: string;
                    subjectId: null;
                })[];
                activation: string;
                remainingGates: string[];
            };
            id: string;
            companyName: string;
            outcome: string;
            successCriterion: string;
            revision: number;
            sources: import("./onboarding-workspace.mjs").Source[];
        };
        history: import("./onboarding-workspace.mjs").OnboardingEvent[];
        workspaces?: never;
    } | {
        workspace: {
            concepts: {
                status: string;
                id: string;
                label: string;
                definition: string;
                revision: number;
                mappings: import("./onboarding-workspace.mjs").Mapping[];
                review: import("./onboarding-workspace.mjs").Review | null;
                originSourceId?: string;
                retired?: boolean;
            }[];
            readiness: {
                definitions: string;
                gaps: ({
                    code: string;
                    subjectId: string;
                } | {
                    code: string;
                    subjectId: null;
                })[];
                activation: string;
                remainingGates: string[];
            };
            id: string;
            companyName: string;
            outcome: string;
            successCriterion: string;
            revision: number;
            sources: import("./onboarding-workspace.mjs").Source[];
        };
        workspaces?: never;
        schema?: never;
        exportedAt?: never;
        tenantId?: never;
        ownerId?: never;
        history?: never;
    }>;
    command: (auth: any, input: any) => Promise<{
        workspace: {
            concepts: {
                status: string;
                id: string;
                label: string;
                definition: string;
                revision: number;
                mappings: import("./onboarding-workspace.mjs").Mapping[];
                review: import("./onboarding-workspace.mjs").Review | null;
                originSourceId?: string;
                retired?: boolean;
            }[];
            readiness: {
                definitions: string;
                gaps: ({
                    code: string;
                    subjectId: string;
                } | {
                    code: string;
                    subjectId: null;
                })[];
                activation: string;
                remainingGates: string[];
            };
            id: string;
            companyName: string;
            outcome: string;
            successCriterion: string;
            revision: number;
            sources: import("./onboarding-workspace.mjs").Source[];
        };
        receipt: {
            requestId: string;
            appliedRevision: number;
            replayed: boolean;
        };
    }>;
};
import { validateDiscoveryEvidence } from "./onboarding-discovery.mjs";
