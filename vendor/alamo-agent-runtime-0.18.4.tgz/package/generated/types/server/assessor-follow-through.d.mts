export function createAssessorFollowThrough({ qualityDraftId, ...deps }: {
    [x: string]: any;
    qualityDraftId: any;
}): {
    prepare: (...args: any[]) => Promise<any>;
    read: (...args: any[]) => Promise<any>;
    review: (...args: any[]) => Promise<any>;
};
export const ASSESSOR_FOLLOW_THROUGH_POLICY: Readonly<{
    version: 1;
    stages: string[];
    parentReview: "accepted_current_quality_draft";
    clarification: "source_update_and_new_quality_review_required";
    handoff: "all_projected_answers_supported_no_open_quality_questions";
    sourceWork: "unconfirmed";
    delivery: "not_performed";
    receivingOwner: "unknown";
}>;
