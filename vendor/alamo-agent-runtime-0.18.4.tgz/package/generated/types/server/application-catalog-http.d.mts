export function handleApplicationCatalogHttp(req: any, res: any, auth: any, service: any): Promise<void>;
