/** @param {{service:any,maintenance?:any,client:any,reports?:any}} options */
export function dispatchEveryAgentSchedules({ service, maintenance, client, reports }: {
    service: any;
    maintenance?: any;
    client: any;
    reports?: any;
}): Promise<void>;
/** @param {{service:any,maintenance?:any,reports?:any,schedule?:string,runtime?:any}} options */
export function registerEveryAgentFunctions({ service, maintenance, reports, schedule, runtime }: {
    service: any;
    maintenance?: any;
    reports?: any;
    schedule?: string;
    runtime?: any;
}): void;
