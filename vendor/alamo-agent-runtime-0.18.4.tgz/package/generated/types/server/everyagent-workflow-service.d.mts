export function createEveryAgentWorkflowService({ store, adapters, sourceAccess, responsibility, now }?: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    adapters?: {} | undefined;
    sourceAccess?: ((assignment: any, receipt?: any) => Promise<any>) | null | undefined;
    responsibility?: {
        bind: (userId: any, workspaceId: any, expectedRevision: any) => Promise<{
            fingerprint: string;
            workspaceRevision: number;
            contractId: "pipeline-assessment-review";
            contractVersion: 1;
            skillVersion: 1;
            workspaceId: any;
            sourceId: string;
            manifestRevision: string;
            questionnaireRulesVersion: any;
            sourceAccess: {
                application: any;
                id: any;
                revision: any;
            };
            definitionsDigest: string;
        }>;
        authorize: (assignment: any) => Promise<void>;
        complete: (assignment: any, result: any, startedAt: any) => {
            contractId: "pipeline-assessment-review";
            contractVersion: 1;
            outcome: string;
            binding: any;
            sourceGrant: any;
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
            checks: {
                id: string;
                status: string;
            }[];
            completedAt: string;
            limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
        } | null;
        contract: Readonly<{
            id: "pipeline-assessment-review";
            version: 1;
            skillVersion: 1;
            outcome: "Review every referral returned by the authorized Pipeline scan and save source-linked review evidence.";
            permittedActions: string[];
            requiredLocators: string[];
            completionChecks: string[];
            deadlineMinutes: 20;
            maximumRecords: 500;
            limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
        }>;
    } | null | undefined;
    now?: (() => number) | undefined;
}): {
    prepare: () => Promise<any>;
    collect: (id: any) => Promise<{
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | null>;
    validate: (id: any, result: any) => Promise<{
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage: {
            version: number;
            recordsExpected: any;
            recordsReviewed: any;
            pageCount: any;
            startedAt: any;
            finishedAt: any;
            rulesVersions: any[];
        };
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        coverage?: never;
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | null>;
    publish: (id: any, result: any) => Promise<{
        id: any;
        status: any;
    }>;
    fail: (id: any) => Promise<{
        id: any;
        status: any;
    }>;
    visible: (state: any, userId: any, assignments: any) => any;
    command: (userId: any, input: any) => Promise<void>;
};
