/** @param {any} options */
export function createProFormaExecutionRuntime({ env, authorize, persistence, model, selector, credentialFor, managedIdentityFor, fetchImpl, now }: any): {
    authorize: any;
    processExecution: null;
    model: null;
    selector: null;
} | {
    authorize: (req: any) => Promise<any>;
    processExecution: {
        configurationCommand: (auth: any, raw: any) => Promise<{
            sourceBindingId: any;
            source: any;
            macros: any;
            capability: Readonly<{
                id: "assessor-referral-handoff-draft-v1";
                revision: string;
                mode: "synthetic-only";
                authority: "read_investigate_draft";
                phases: string[];
                sourceWork: "unconfirmed";
                delivery: "not_performed";
                receivingAcceptance: "source-required";
            }>;
            configurations: {
                mode: string;
                proposalHash?: any;
                macroId?: any;
                id: any;
                revision: any;
                status: any;
                enabled: any;
                available: boolean;
            }[];
            mode: string;
        } | {
            configuration: {
                available: boolean;
                id: any;
                revision: any;
                proposalHash: any;
                status: any;
                enabled: any;
                mode: string;
                source: {
                    documentId: any;
                    publicationId: any;
                    fingerprint: any;
                };
            } | {
                available: boolean;
                proposalHash: any;
                source: any;
                macro: any;
                stepBindings: any;
                capability: Readonly<{
                    id: "assessor-referral-handoff-draft-v1";
                    revision: string;
                    mode: "synthetic-only";
                    authority: "read_investigate_draft";
                    phases: string[];
                    sourceWork: "unconfirmed";
                    delivery: "not_performed";
                    receivingAcceptance: "source-required";
                }>;
                models: any;
                evaluationDigest: any;
                review: any;
                history: any;
                id: any;
                revision: any;
                status: any;
                enabled: any;
                mode: string;
            };
        }>;
        preview: (...args: any[]) => Promise<any>;
        bind: (...args: any[]) => Promise<any>;
        assertCurrent: (...args: any[]) => Promise<any>;
    };
    model: any;
    selector: any;
};
