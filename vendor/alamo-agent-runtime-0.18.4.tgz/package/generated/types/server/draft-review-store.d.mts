export function createDraftReviewStore(persistence?: {
    read(): Promise<{
        value: any;
        version: string | null;
    }>;
    write(value: any, version: any): Promise<void>;
}): {
    read: () => Promise<{
        value: {
            version: number;
            revision: number;
            records: {
                artifactRevision: string;
                review: {
                    requestId: string;
                    artifactRevision: string;
                    decision: string;
                    subjectId: string;
                    reviewedAt: string;
                } | null;
                schemaVersion: number;
                id: string;
                createdAt: string;
                request: {
                    scope: {
                        companyId: string;
                        tenantId: string;
                        subjectId: string;
                    };
                    resourceScope: {
                        kind: "community" | "organization" | "source-user";
                        ids: string[];
                    };
                    source: {
                        application: string;
                        kind: string;
                        id: string;
                        revision: string | null;
                    };
                };
                skillId: string;
                policyRevision: string;
                contextRevision: string;
                payload: any;
            }[];
        };
        version: string | null;
    }>;
    update: (mutate: (state: ReturnType<typeof validateDraftReviewState>) => Promise<boolean>) => Promise<{
        version: number;
        revision: number;
        records: {
            artifactRevision: string;
            review: {
                requestId: string;
                artifactRevision: string;
                decision: string;
                subjectId: string;
                reviewedAt: string;
            } | null;
            schemaVersion: number;
            id: string;
            createdAt: string;
            request: {
                scope: {
                    companyId: string;
                    tenantId: string;
                    subjectId: string;
                };
                resourceScope: {
                    kind: "community" | "organization" | "source-user";
                    ids: string[];
                };
                source: {
                    application: string;
                    kind: string;
                    id: string;
                    revision: string | null;
                };
            };
            skillId: string;
            policyRevision: string;
            contextRevision: string;
            payload: any;
        }[];
    }>;
};
import { validateDraftReviewState } from "../shared/draft-review-contracts.mjs";
