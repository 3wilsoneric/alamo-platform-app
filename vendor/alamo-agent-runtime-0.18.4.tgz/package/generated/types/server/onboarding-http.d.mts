export function handleOnboardingHttp(req: any, res: any, auth: any, service: any): Promise<void>;
