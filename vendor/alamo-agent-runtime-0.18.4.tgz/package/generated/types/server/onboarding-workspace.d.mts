/** Apply one validated command to the projection; journal history remains immutable.
 * @param {Workspace} workspace @param {OnboardingEvent} event */
export function applyOnboardingEvent(workspace: Workspace, event: OnboardingEvent): void;
/** @param {WorkspaceRecord} record @returns {Workspace} */
export function projectOnboardingWorkspace(record: WorkspaceRecord): Workspace;
/** Review state is derived from current evidence, never trusted from a client.
 * @param {Workspace} workspace @param {string[]} [staleSourceIds] */
export function onboardingView(workspace: Workspace, staleSourceIds?: string[]): {
    concepts: {
        status: string;
        id: string;
        label: string;
        definition: string;
        revision: number;
        mappings: Mapping[];
        review: Review | null;
        originSourceId?: string;
        retired?: boolean;
    }[];
    readiness: {
        definitions: string;
        gaps: ({
            code: string;
            subjectId: string;
        } | {
            code: string;
            subjectId: null;
        })[];
        activation: string;
        remainingGates: string[];
    };
    id: string;
    companyName: string;
    outcome: string;
    successCriterion: string;
    revision: number;
    sources: Source[];
};
export function onboardingCapacity(): import("./http-error-contract.mjs").HttpError;
export type Command = import("../shared/onboarding-contracts.mjs").OnboardingCommand;
export type Mapping = import("../shared/onboarding-contracts.mjs").SourceMapping;
export type Discovery = ReturnType<typeof validateDiscoveryEvidence>;
export type OnboardingEvent = {
    requestId: string;
    revision: number;
    actorId: string;
    at: string;
    command: Command;
    discovery?: Discovery;
};
export type WorkspaceRecord = {
    id: string;
    tenantId: string;
    ownerId: string;
    events: OnboardingEvent[];
};
export type Source = {
    id: string;
    title: string;
    application: string;
    reference: string;
    sourceVersion: string;
    steward: string;
    revision: number;
    provenance: "declared" | "observed_contract";
    discovery?: Discovery;
};
export type Review = {
    decision: "confirmed" | "rejected";
    actorId: string;
    at: string;
    note: string;
    workspaceRevision: number;
};
export type Concept = {
    id: string;
    label: string;
    definition: string;
    revision: number;
    mappings: Mapping[];
    review: Review | null;
    originSourceId?: string;
    retired?: boolean;
};
export type Workspace = {
    id: string;
    companyName: string;
    outcome: string;
    successCriterion: string;
    revision: number;
    sources: Source[];
    concepts: Concept[];
};
import { validateDiscoveryEvidence } from "./onboarding-discovery.mjs";
