export function createOnboardingStore(persistence?: {
    read(): Promise<{
        value: any;
        version: string | null;
    }>;
    write(value: any, version: any): Promise<void>;
}): {
    read: () => Promise<{
        value: OnboardingState;
        version: string | null;
    }>;
    update: (mutate: (state: OnboardingState) => boolean | Promise<boolean>) => Promise<OnboardingState>;
};
export type OnboardingState = {
    version: 1;
    revision: number;
    workspaces: import("./onboarding-workspace.mjs").WorkspaceRecord[];
};
