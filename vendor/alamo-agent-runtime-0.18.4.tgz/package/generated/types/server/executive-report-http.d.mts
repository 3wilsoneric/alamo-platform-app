export function handleExecutiveReportHttp(req: any, res: any, auth: any, service: any): Promise<void>;
