/** @param {{apiKey?: string, model?: string, fetchImpl?: typeof fetch, selectComponents?: Function, compilePlan?: Function}} options */
export function createOnDemandViewModel({ apiKey, model, fetchImpl, selectComponents, compilePlan }?: {
    apiKey?: string;
    model?: string;
    fetchImpl?: typeof fetch;
    selectComponents?: Function;
    compilePlan?: Function;
}): {
    available: boolean;
    model: string;
    promptVersion: string;
    plan({ question, host, scopeKey, datasets, catalog }: {
        question: any;
        host: any;
        scopeKey: any;
        datasets: any;
        catalog: any;
    }): Promise<{
        plan: any;
        requestedModel: string;
        responseModel: any;
        promptVersion: string;
        usage: {
            inputTokens: any;
            outputTokens: any;
        } | null;
    }>;
};
export const VIEW_PLANNER_PROMPT_VERSION: "on-demand-view-plan-v1";
