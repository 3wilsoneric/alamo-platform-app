export function createEveryAgentService({ store, adapters, now, portableLinks, sourceAccess, responsibility }?: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    adapters?: {} | undefined;
    now?: (() => number) | undefined;
    portableLinks?: boolean | undefined;
    sourceAccess?: ((assignment: any, receipt?: any) => Promise<any>) | null | undefined;
    responsibility?: {
        bind: (userId: any, workspaceId: any, expectedRevision: any) => Promise<{
            fingerprint: string;
            workspaceRevision: number;
            contractId: "pipeline-assessment-review";
            contractVersion: 1;
            skillVersion: 1;
            workspaceId: any;
            sourceId: string;
            manifestRevision: string;
            questionnaireRulesVersion: any;
            sourceAccess: {
                application: any;
                id: any;
                revision: any;
            };
            definitionsDigest: string;
        }>;
        authorize: (assignment: any) => Promise<void>;
        complete: (assignment: any, result: any, startedAt: any) => {
            contractId: "pipeline-assessment-review";
            contractVersion: 1;
            outcome: string;
            binding: any;
            sourceGrant: any;
            coverage: {
                version: number;
                recordsExpected: any;
                recordsReviewed: any;
                pageCount: any;
                startedAt: any;
                finishedAt: any;
                rulesVersions: any[];
            };
            checks: {
                id: string;
                status: string;
            }[];
            completedAt: string;
            limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
        } | null;
        contract: Readonly<{
            id: "pipeline-assessment-review";
            version: 1;
            skillVersion: 1;
            outcome: "Review every referral returned by the authorized Pipeline scan and save source-linked review evidence.";
            permittedActions: string[];
            requiredLocators: string[];
            completionChecks: string[];
            deadlineMinutes: 20;
            maximumRecords: 500;
            limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality.";
        }>;
    } | null | undefined;
}): {
    overview: (auth: any, attempt?: number) => Promise<{
        version: number;
        emailEnabled: boolean;
        workerEnabled: boolean;
        skills: import("../shared/everyagent-catalog.mjs").EveryAgentSkill[];
        responsibilities: any[];
        work: any;
        runs: any;
        tasks: any;
        working: any;
    }>;
    command: (auth: any, raw: any) => Promise<{
        version: number;
        emailEnabled: boolean;
        workerEnabled: boolean;
        skills: import("../shared/everyagent-catalog.mjs").EveryAgentSkill[];
        responsibilities: any[];
        work: any;
        runs: any;
        tasks: any;
        working: any;
    }>;
    tick: () => Promise<void>;
};
