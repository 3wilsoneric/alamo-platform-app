export function createAssessorSandboxStore(persistence: any): {
    read: () => Promise<{
        value: {
            version: number;
            revision: number;
            sessions: any[];
        };
        version: any;
    }>;
    update: (mutate: any) => Promise<{
        version: number;
        revision: number;
        sessions: any[];
    }>;
};
