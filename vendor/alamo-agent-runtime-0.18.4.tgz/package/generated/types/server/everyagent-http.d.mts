export function createEveryAgentRequestHandler({ authorize, service, conversations, onboarding, catalog, sandbox, reports, paths }: {
    authorize: any;
    service: any;
    conversations?: any;
    onboarding?: any;
    catalog?: any;
    sandbox?: any;
    reports?: any;
    paths?: string[] | undefined;
}): (req: any, res: any) => Promise<void>;
