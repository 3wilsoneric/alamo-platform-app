export function createProFormaExecution({ definitions, sourceFor }: {
    definitions: any;
    sourceFor: any;
}): {
    preview: (...args: any[]) => Promise<any>;
    bind: (...args: any[]) => Promise<any>;
    assertCurrent: (...args: any[]) => Promise<any>;
};
export const proformaReferralCapability: Readonly<{
    id: "assessor-referral-handoff-draft-v1";
    revision: string;
    mode: "synthetic-only";
    authority: "read_investigate_draft";
    phases: string[];
    sourceWork: "unconfirmed";
    delivery: "not_performed";
    receivingAcceptance: "source-required";
}>;
