/** One bounded formatting call. The named tool returns data only; it cannot run actions. */
export function createProFormaMaintenanceModel({ apiKey, model, fetchImpl }?: {
    apiKey?: string | undefined;
    model?: string | undefined;
    fetchImpl?: typeof fetch | undefined;
}): {
    available: boolean;
    model: string;
    policyVersion: string;
    /** @param {any} input @param {{signal?: AbortSignal}} options */
    assess(input: any, { signal }?: {
        signal?: AbortSignal;
    }): Promise<{
        decision: {
            outcome: string;
            reason: any;
            proposal: {
                title: any;
                changes: {
                    sourceEvidence?: {
                        signalId: any;
                        nodeId: any;
                        beforeFingerprint: any;
                        afterFingerprint: any;
                    }[];
                    instruction: any;
                    evidence: any;
                }[];
            };
        } | {
            outcome: string;
            reason: any;
        };
        requestedModel: string;
        responseModel: string;
        policyVersion: string;
        inputHash: string;
        promptVersion: string;
        usage: any;
    }>;
};
/** An assessor callback for the existing durable consumer. Evidence/provenance must
 * be recorded before the consumer can persist a proposal. Recording is host-owned. */
export function createProFormaMaintenanceAssessor({ binding: input, model, record }: {
    binding: any;
    model?: {
        available: boolean;
        model: string;
        policyVersion: string;
        /** @param {any} input @param {{signal?: AbortSignal}} options */
        assess(input: any, { signal }?: {
            signal?: AbortSignal;
        }): Promise<{
            decision: {
                outcome: string;
                reason: any;
                proposal: {
                    title: any;
                    changes: {
                        sourceEvidence?: {
                            signalId: any;
                            nodeId: any;
                            beforeFingerprint: any;
                            afterFingerprint: any;
                        }[];
                        instruction: any;
                        evidence: any;
                    }[];
                };
            } | {
                outcome: string;
                reason: any;
            };
            requestedModel: string;
            responseModel: string;
            policyVersion: string;
            inputHash: string;
            promptVersion: string;
            usage: any;
        }>;
    } | undefined;
    record: any;
}): (assessmentInput: any) => Promise<{
    outcome: string;
    reason: any;
    proposal: {
        title: any;
        changes: {
            sourceEvidence?: {
                signalId: any;
                nodeId: any;
                beforeFingerprint: any;
                afterFingerprint: any;
            }[];
            instruction: any;
            evidence: any;
        }[];
    };
} | {
    outcome: string;
    reason: any;
}>;
