export function createProFormaSourceTransport({ binding, getToken, fetchImpl, now }: {
    binding: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    request: (token: string, suffix: string, command?: Record<string, any> | null) => Promise<any>;
    authorized: (permission: any) => Promise<any>;
};
