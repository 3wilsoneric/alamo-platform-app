/** Native capability discovery over the same registry, assignments and source
 * grants as execution. It never reads business records, writes state or enables work.
 * @param {{source: {configuredApplications: () => string[], authorize: (assignment: any) => Promise<unknown>},
 * store?: ReturnType<typeof createEveryAgentStore>, now?: () => number}} options */
export function createApplicationCatalogService({ source, store, now }: {
    source: {
        configuredApplications: () => string[];
        authorize: (assignment: any) => Promise<unknown>;
    };
    store?: ReturnType<typeof createEveryAgentStore>;
    now?: () => number;
}): {
    read: (auth: any, attempt?: number) => Promise<{
        schemaVersion: number;
        revision: string;
        observedAt: string;
        scope: {
            tenantId: string;
            subjectId: string;
        };
        companyBinding: string;
        authorization: string;
        applications: {
            capabilities: {
                id: string;
                version: number;
                operation: "read";
                scope: "community" | "organization" | "source-user";
                protocol: {
                    id: "agent-summary" | "assessment-review" | "workflow-knowledge";
                    version: number;
                };
                resourceKinds: string[];
            }[];
            connection: string;
            schemaVersion: number;
            id: string;
            revision: number;
            name: string;
        }[];
        onDemand: {
            skillId: string;
            execution: string;
            access: string;
            activation: string;
        }[];
        skills: {
            id: string;
            version: number;
            name: string;
            application: string;
            capability: string;
            scope: string;
        }[];
        access: ({
            state: string;
            checkedAt: null;
            grant: null;
            skillId: string;
            application: string;
            capability: string;
            assignmentVersion: any;
            paused: any;
            resourceScope: {
                kind: string;
                ids: any[];
            };
        } | {
            state: string;
            checkedAt: string;
            grant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            skillId: string;
            application: string;
            capability: string;
            assignmentVersion: any;
            paused: any;
            resourceScope: {
                kind: string;
                ids: any[];
            };
        } | {
            state: string;
            checkedAt: string;
            grant: null;
            skillId: string;
            application: string;
            capability: string;
            assignmentVersion: any;
            paused: any;
            resourceScope: {
                kind: string;
                ids: any[];
            };
        })[];
    }>;
};
import { createEveryAgentStore } from "./everyagent-store.mjs";
