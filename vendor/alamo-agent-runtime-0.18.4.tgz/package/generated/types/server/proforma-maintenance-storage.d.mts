/** Per-binding partitions. Old runs and evidence remain in their own records;
 * nothing is deleted or migrated from the legacy single-responsibility store. */
export function createProFormaMaintenanceStorage(input: any, { azure, localRoot, persistenceFor }?: {
    azure?: boolean | undefined;
    localRoot?: string | undefined;
    persistenceFor?: typeof createEveryAgentPersistence | undefined;
}): {
    checkpoint: {
        read(): Promise<{
            value: any;
            version: string | null;
        }>;
        write(value: any, version: any): Promise<void>;
    };
    schedule: {
        read(): Promise<{
            value: any;
            version: string | null;
        }>;
        write(value: any, version: any): Promise<void>;
    };
    run: {
        read(): Promise<{
            value: any;
            version: string | null;
        }>;
        write(value: any, version: any): Promise<void>;
    };
    record(trace: any, at?: string): Promise<string>;
    evidence(id: any): Promise<Record<string, any>>;
};
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
