export function createProFormaMaintenanceClient({ binding: input, getToken, fetchImpl, now }: {
    binding: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    authorize(): Promise<void>;
    feed(after?: number, streamId?: null): Promise<Record<string, any>>;
    context(processId: any): Promise<{
        source: any;
        streamId: any;
        process: {
            steps: any;
            flow: {
                schemaVersion: number;
                entryStepId: any;
                transitions: any[];
            };
            flowOrigin: any;
            gaps: string[];
            connections: any[];
            id: any;
            title: any;
        };
        work: any;
        assessments: any;
    }>;
    command(value: any): Promise<Record<string, any>>;
};
