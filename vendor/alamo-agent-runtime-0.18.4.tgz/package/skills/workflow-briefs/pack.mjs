import { draftReviewHash } from "../../shared/draft-review-contracts.mjs";
import { WORKFLOW_TREND_POLICY } from "../../shared/workflow-brief-contracts.mjs";

export const workflowBriefSkills = Object.freeze({
  team_exceptions: { id: "supervisor-exception-brief", version: 1, title: "Prepare team exception brief",
    when: "Prepare a supervisor's team exception summary or choose the next team-review step.",
    prerequisites: "Current source-authorized team exceptions with complete evidence.",
    tools: ["read_governed_team_view", "save_immutable_draft"],
    output: "Source-cited exception queue and suggested human verification steps; no reassignment or messages.",
    completion: "Unaccepted brief saved for review. No source action or notification." },
  workflow_trend: { id: "executive-workflow-brief", version: 1, title: "Prepare workflow trend brief",
    when: "Summarize the supplied aggregate workflow trends or choose the next aggregate-review step.",
    prerequisites: "Current source-authorized aggregates with defined cohorts, coverage and disclosure limits.",
    tools: ["read_governed_aggregate_view", "save_immutable_draft"],
    output: "Fixed cohort measures, denominators, suppression and limitations; no individual records or causal claims.",
    completion: "Unaccepted aggregate brief saved for review. No publication or individual drill-down." },
});
export function workflowBriefPackDefinition(operation) {
  const skill = workflowBriefSkills[operation];
  if (!skill) throw new Error("Unknown workflow brief.");
  return { id: `pipeline-${operation.replaceAll("_", "-")}`, version: 1, mode: "synthetic-only", authority: "read_investigate_draft",
    limits: { selections: 1, activities: 1, modelCalls: 1, sourceReads: 16, deadlineMs: 120000 }, skills: [structuredClone(skill)] };
}
const nextSteps = Object.freeze({
  receiving_contact: "Verify the receiving contact in Pipeline before continuing the handoff.",
  answer_evidence: "Ask the assigned assessor to verify the answer against its source evidence.",
  placement_question: "Review the open placement question with the assigned assessor.",
  handoff_failed: "Inspect the recorded failure in Pipeline before explicitly retrying through the owning application.",
  acknowledgment_unknown: "Verify receiving acknowledgment; a recorded send does not establish receipt.",
});
const aggregateGuidance = "Compare only available measures with their denominators. Suppressed values remain unknown. Pending sends and provisional periods limit comparison; these measures do not establish causes or staff performance.";
export const WORKFLOW_BRIEF_POLICY = draftReviewHash({ version: 1, skills: workflowBriefSkills, metric: WORKFLOW_TREND_POLICY, nextSteps, aggregateGuidance,
  preparation: "deterministic-scoped-view-and-fixed-guidance-v1", humanReview: "explicit-version-bound-no-source-action" });
export function prepareWorkflowBriefPayload(packet) {
  const view = structuredClone(packet.view);
  return { kind: view.kind, evidence: view,
    followUp: view.kind === "team_exceptions" ? view.cases.map(c => ({ caseId: c.caseId,
      steps: c.issues.map(i => ({ code: i.code, instruction: nextSteps[i.code], evidenceIds: i.evidenceIds })) })) :
      [{ instruction: aggregateGuidance }],
    humanReview: "required", sourceMutation: false, publication: "not-published" };
}
