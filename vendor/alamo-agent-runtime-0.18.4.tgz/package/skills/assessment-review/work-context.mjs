// Bounded deterministic assistance. Exact source quotations are not independently
// verified facts; this module makes no model call or clinical-quality judgment.
export const ASSESSOR_CONTEXT_POLICY_VERSION = 1;
export const ASSESSOR_CONTEXT_TEACHING = Object.freeze({ application: "workflow", packId: "alamo-assessor-procedures", version: 1,
  sha256: "0dcf8757795e52c13259894c42b16c49274944c6a8ce305df8ec89e214d2d67a" });
export const ASSESSOR_CONTEXT_PROCEDURES = Object.freeze([
  { id: "ASM-002", version: 1, step: "W2.5" },
  { id: "ASM-005", version: 1, step: "W5.2" },
  { id: "ASM-007", version: 1, step: "W7.3" },
]);

export function draftAssessorSupport(context) {
  if (context.snapshot.source.application !== "pipeline" || context.snapshot.source.kind !== "assessment") {
    throw new Error("Assessment context is required.");
  }
  const findings = context.content.filter(item => item.status !== "recorded").map(item => ({
    contentId: item.id, label: item.label, kind: item.status, evidenceIds: item.evidenceIds,
    message: item.status === "unknown" ? "No answer was supplied in this projection. Verify in Pipeline; do not infer a negative answer."
      : item.status === "unreviewed" ? "The source marks this information as awaiting review. Confirm it against the original."
        : "The source reports a conflict. Preserve both accounts and ask the responsible person to resolve it.",
    procedure: ASSESSOR_CONTEXT_PROCEDURES[1],
  }));
  return {
    policyVersion: ASSESSOR_CONTEXT_POLICY_VERSION,
    teachingSource: ASSESSOR_CONTEXT_TEACHING,
    authority: "read_investigate_draft", status: "awaiting_human_review", sourceWork: "unconfirmed",
    scope: context.snapshot.scope, source: context.snapshot.source, assignment: context.assignment,
    preparation: { questions: findings.map(item => ({ contentId: item.contentId,
      question: `What evidence resolves the ${item.kind} information in ${item.label}?`, evidenceIds: item.evidenceIds,
      procedure: ASSESSOR_CONTEXT_PROCEDURES[0] })) },
    review: { findings, clinicalQuality: "not_evaluated", wordingSuggestions: [],
      limitation: "Checks source-declared gaps and review states only; no independent factual or clinical-quality judgment." },
    handoff: {
      recordedInformation: context.content.filter(item => item.text !== null).map(item => ({
        contentId: item.id, label: item.label, quote: item.text, status: item.status, evidenceIds: item.evidenceIds,
      })),
      pending: context.requirements.filter(item => item.status !== "met"), missingContext: context.missing,
      readiness: "human_verification_required", delivery: "not_performed", procedure: ASSESSOR_CONTEXT_PROCEDURES[2],
    },
    evidence: context.evidence, nextActions: context.nextActions,
  };
}
