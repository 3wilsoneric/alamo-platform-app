import { draftReviewHash } from "../../shared/draft-review-contracts.mjs";
import { ASSESSMENT_QUALITY_PROMPT_VERSION, ASSESSMENT_QUALITY_SYSTEM, ASSESSMENT_QUALITY_OUTPUT_SCHEMA } from "./quality.mjs";
import { ASSESSOR_CONTEXT_TEACHING, ASSESSOR_CONTEXT_PROCEDURES } from "./work-context.mjs";

// Executable activity bindings live in server/assessor-skill-pack.mjs. This pack
// does not activate the metadata watcher or the 17 authored workflow definitions.
export const assessorSkillPack = {
  id: "pipeline-assessor", version: 1, mode: "synthetic-only", authority: "read_investigate_draft",
  requiredCapability: "pipeline.assessment-context.read", sourceApplication: "pipeline",
  inputs: ["source-authorized current content packet", "user request", "optional current quality artifact ID"],
  limits: { selections: 1, activities: 1, modelCalls: 2, sourceReads: 48, deadlineMs: 120000 },
  stop: ["source access denied", "source or review changed", "invalid model output", "budget exceeded", "trace unavailable"],
  recovery: "Refresh authorized context; review any saved artifact before explicitly retrying. A retry may create a new draft.",
  humanReview: "Separate version-bound command; selection and draft preparation cannot accept a review.",
  evaluations: { suite: "assessor-harness-v1", rubric: "assessor-harness-rubric-v1", humanReviewRequired: true },
  skills: [
    { id: "assessment-answer-quality", version: 1, title: "Review answer quality",
      when: "Review or refresh supplied answers against independent source excerpts. Start here if no current quality draft exists.",
      prerequisites: "Current authorized content and independent evidence. A rejected review requires a fresh quality proposal.",
      tools: ["read_current_packet", "model_quality_proposal", "save_immutable_draft"],
      output: "Cited findings, optional wording, questions and handoff summary in an unaccepted quality artifact.",
      completion: "Current-source-bound draft saved; human review still required." },
    { id: "assessor-clarification", version: 1, title: "Prepare clarification checklist",
      when: "Prepare questions for the assessor, including when a requested handoff is blocked by answer questions.",
      prerequisites: "Accepted current quality draft with one or more open answer questions.",
      tools: ["read_current_packet", "read_reviewed_quality", "save_immutable_draft"],
      output: "Source-bound questions and proposed reviewers; source changes and verification remain human work.",
      completion: "Clarification draft saved; questions remain unresolved in the source." },
    { id: "assessor-handoff", version: 1, title: "Prepare handoff draft",
      when: "Prepare a handoff after the supplied answers have been reviewed and supported.",
      prerequisites: "Accepted current quality draft, every projected answer supported, no open answer questions.",
      tools: ["read_current_packet", "read_reviewed_quality", "save_immutable_draft"],
      output: "Reviewed answer summary, pending requirements and unknown receiving ownership; no delivery.",
      completion: "Handoff draft saved; human source verification and sending remain outstanding." },
  ],
};
export const ASSESSOR_PACK_REVISION = draftReviewHash({ pack: assessorSkillPack,
  quality: { version: ASSESSMENT_QUALITY_PROMPT_VERSION, system: ASSESSMENT_QUALITY_SYSTEM, schema: ASSESSMENT_QUALITY_OUTPUT_SCHEMA },
  teaching: ASSESSOR_CONTEXT_TEACHING, procedures: ASSESSOR_CONTEXT_PROCEDURES });
