// Reviewed executable policy, not customer-supplied instructions. Changing its
// meaning requires a new version and fresh binding before execution.
export const ASSESSMENT_REVIEW_RESPONSIBILITY = Object.freeze({
  id: "pipeline-assessment-review", version: 1, skillVersion: 1,
  outcome: "Review every referral returned by the authorized Pipeline scan and save source-linked review evidence.",
  permittedActions: ["describe", "authorize", "read", "publish_agent_review"],
  requiredLocators: ["decision", "assessmentState", "assessment.signedAt", "assessment.authorship", "assessment.completion", "assessment.sendStatus"],
  completionChecks: ["reviewed_definitions_current", "source_grant_current", "all_authorized_records_reviewed", "evidence_saved"],
  deadlineMinutes: 20, maximumRecords: 500,
  limitation: "Pages are live observations, not an atomic snapshot. Review completion does not resolve source workflow issues or confirm clinical quality."
});

export function validateAssessmentCoverage(value, entries, sourceCheckedAt) {
  if (!value || Object.keys(value).sort().join() !== "finishedAt,pageCount,recordsExpected,recordsReviewed,rulesVersions,startedAt,version" ||
      value.version !== 1 || !Number.isSafeInteger(value.recordsExpected) || value.recordsExpected < 0 || value.recordsExpected > 500 ||
      value.recordsReviewed !== value.recordsExpected || value.recordsReviewed !== entries.length ||
      !Number.isSafeInteger(value.pageCount) || value.pageCount < 1 || value.pageCount > 20 ||
      !Array.isArray(value.rulesVersions) || value.rulesVersions.length > value.recordsReviewed ||
      value.rulesVersions.some(item => typeof item !== "string" || !/^[a-f0-9]{64}$/.test(item)) ||
      new Set(value.rulesVersions).size !== value.rulesVersions.length ||
      value.startedAt !== sourceCheckedAt || typeof value.finishedAt !== "string" ||
      !Number.isFinite(Date.parse(value.startedAt)) || !Number.isFinite(Date.parse(value.finishedAt)) ||
      Date.parse(value.finishedAt) < Date.parse(value.startedAt)) throw new Error("Assessment scan coverage could not be verified.");
  return { version: 1, recordsExpected: value.recordsExpected, recordsReviewed: value.recordsReviewed,
    pageCount: value.pageCount, startedAt: value.startedAt, finishedAt: value.finishedAt, rulesVersions: [...value.rulesVersions].sort() };
}
