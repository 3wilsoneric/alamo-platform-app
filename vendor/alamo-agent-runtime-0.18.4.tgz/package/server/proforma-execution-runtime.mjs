import path from 'node:path';
import {readProFormaRuntimeConfig} from './proforma-runtime-config.mjs';
import {createProFormaDelegatedIdentity} from './proforma-delegated-identity.mjs';
import {createEveryAgentPersistence} from './everyagent-persistence.mjs';
import {createProFormaExecutionStore} from './proforma-execution-store.mjs';
import {createProFormaConfiguredExecution} from './proforma-execution-configuration.mjs';
import {createProFormaAutomationClient} from './proforma-automation-client.mjs';
import {createAssessmentQualityModel} from './assessment-quality-model.mjs';
import {createSkillSelectionModel} from './skill-selection-model.mjs';

/** @param {any} options */
export function createProFormaExecutionRuntime({env=process.env,authorize,persistence,model,selector,credentialFor,managedIdentityFor,fetchImpl=fetch,now=Date.now}){
  const config=readProFormaRuntimeConfig(env);
  if(!config)return {authorize,processExecution:null,model:null,selector:null};
  const runningModel=model??createAssessmentQualityModel({apiKey:env.ANTHROPIC_API_KEY??'',model:env.ALAMOAGENT_ASSESSMENT_MODEL||env.ANTHROPIC_MODEL||'claude-sonnet-4-6'});
  const runningSelector=selector??createSkillSelectionModel({apiKey:env.ANTHROPIC_API_KEY??'',model:env.ALAMOAGENT_ASSESSMENT_MODEL||env.ANTHROPIC_MODEL||'claude-sonnet-4-6'});
  if(!runningModel.available||!runningSelector.available||runningModel.model!==config.models.quality||runningSelector.model!==config.models.selection)throw new Error('ProForma execution requires the configured, evaluated model pair.');
  const identity=createProFormaDelegatedIdentity({config,authorize,now,...(credentialFor?{credentialFor}:{}),...(managedIdentityFor?{managedIdentityFor}:{})});
  const store=createProFormaExecutionStore(persistence??createEveryAgentPersistence({localPath:path.resolve('generated/everyagent/proforma-executions-v1.json'),blobPath:'everyagent/proforma-executions-v1.json'}));
  const processExecution=createProFormaConfiguredExecution({store,now,bindingsFor:async()=>config.bindings,getPolicy:async()=>({models:config.models,evaluationDigest:config.evaluationDigest}),
    sourceFor:(binding,auth)=>createProFormaAutomationClient({binding,getToken:()=>identity.getToken(auth),fetchImpl,now})});
  return {authorize:identity.authorize,processExecution,model:runningModel,selector:runningSelector};
}
