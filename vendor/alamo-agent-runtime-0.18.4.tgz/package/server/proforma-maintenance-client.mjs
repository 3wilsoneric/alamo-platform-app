import { createProFormaSourceTransport } from './proforma-source-transport.mjs';
import { validateMaintenanceBinding, validateMaintenanceFeed, validateMaintenanceContext, validateMaintenanceCommand, validateMaintenanceReceipt } from '../shared/proforma-maintenance-contracts.mjs';

// Explicit host-delegated transport. A binding is a responsibility scope, not an
// access grant. Every operation rechecks the source with the same delegated token.
export function createProFormaMaintenanceClient({ binding: input, getToken, fetchImpl = fetch, now = Date.now }) {
  const binding = validateMaintenanceBinding(input);
  const { request, authorized } = createProFormaSourceTransport({ binding, getToken, fetchImpl, now });
  return {
    async authorize() { await authorized('contribute'); },
    async feed(after = 0, streamId = null) {
      if (!Number.isSafeInteger(after) || after < 0 || after > 1000 || after && !streamId) throw new Error('Invalid maintenance cursor.');
      const query = new URLSearchParams({ after: String(after), limit: '100', ...(streamId ? { streamId } : {}) });
      return validateMaintenanceFeed(await request(await authorized('read'), `/processes/maintenance/events?${query}`), binding, after, streamId);
    },
    async context(processId) {
      if (!binding.processIds.includes(processId)) throw new Error('Process is outside this responsibility.');
      return validateMaintenanceContext(await request(await authorized('read'), `/processes/maintenance/context?${new URLSearchParams({ id: processId })}`), binding, processId);
    },
    async command(value) {
      const command = validateMaintenanceCommand(value);
      if (command.action === 'assess_changes' && !binding.processIds.includes(command.assessment.processId)) throw new Error('Process is outside this responsibility.');
      return validateMaintenanceReceipt(await request(await authorized('contribute'), '/processes/maintenance/commands', command), binding, command);
    },
  };
}
