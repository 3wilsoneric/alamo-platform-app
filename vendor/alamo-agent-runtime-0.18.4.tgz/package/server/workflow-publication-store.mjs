import { foundationObject } from "../shared/foundation-contracts.mjs";
import { draftReviewHash } from "../shared/draft-review-contracts.mjs";
import { validateWorkflowPublisher, validateWorkflowPublication } from "../shared/workflow-publication-contracts.mjs";
import { WORKFLOW_HISTORY_LIMITS, workflowUnavailable } from "../shared/workflow-history-contracts.mjs";
import { projectWorkflowHistory } from "./workflow-evidence-projection.mjs";

// Internal governed-foundation reference repository. No default storage, HTTP
// route, background job or cloud collection. A trusted host must bind producer
// authorization; consumers must use the reauthorizing workflow role service.
export function createWorkflowPublicationStore({ publisher, persistence, authorizePublisher, now = Date.now }) {
  const binding = validateWorkflowPublisher(publisher);
  if (!persistence || typeof persistence.read !== "function" || typeof persistence.write !== "function" ||
      typeof authorizePublisher !== "function") throw new Error("Explicit workflow publication adapters are required.");
  const checkBinding = publication => {
    if (draftReviewHash(publication.publisher) !== draftReviewHash(binding)) return workflowUnavailable();
    projectWorkflowHistory(publication.feed);
    return publication;
  };
  async function read() {
    const snapshot = await persistence.read();
    if (snapshot.value === null) {
      if (snapshot.version !== null) return workflowUnavailable();
      return { value: null, version: null };
    }
    const state = foundationObject(snapshot.value, ["schemaVersion", "revision", "publication"]);
    const publication = checkBinding(validateWorkflowPublication(state.publication, now()));
    if (state.schemaVersion !== 1 || state.revision !== publication.sequence || snapshot.version === null) return workflowUnavailable();
    return { value: publication, version: snapshot.version };
  }
  async function authorize() {
    if (await authorizePublisher(structuredClone(binding)) !== true) return workflowUnavailable();
  }
  const receipt = (publication, status) => ({ status, sequence: publication.sequence,
    publicationRevision: publication.revision, feedRevision: publication.feed.revision, completeThrough: publication.feed.completeThrough });
  async function publish(input) {
    try {
      await authorize();
      const incoming = checkBinding(validateWorkflowPublication(input, now()));
      for (let attempt = 0; attempt < 6; attempt++) {
        const { value: previous, version } = await read();
        if (previous?.revision === incoming.revision) { await authorize(); return receipt(previous, "already_published"); }
        if (incoming.sequence !== (previous?.sequence ?? 0) + 1 || incoming.previousRevision !== (previous?.revision ?? null) ||
            now() - Date.parse(incoming.feed.completeThrough) > WORKFLOW_HISTORY_LIMITS.freshnessMs) return workflowUnavailable();
        if (previous) {
          if (incoming.feed.observedAt <= previous.feed.observedAt || incoming.feed.completeThrough < previous.feed.completeThrough) return workflowUnavailable();
          const oldEvents = new Map(previous.feed.events.map(e => [e.id, draftReviewHash(e)]));
          const nextEvents = new Map(incoming.feed.events.map(e => [e.id, draftReviewHash(e)]));
          // Preserve all accepted evidence. Corrections append a new event with
          // an explicit supersedes link; replacement/deletion is not supported.
          for (const [id, hash] of oldEvents) if (nextEvents.get(id) !== hash) return workflowUnavailable();
          for (const event of incoming.feed.events) {
            if (!oldEvents.has(event.id) && event.ingestedAt <= previous.feed.observedAt) return workflowUnavailable();
          }
        }
        await authorize();
        if (now() - Date.parse(incoming.feed.completeThrough) > WORKFLOW_HISTORY_LIMITS.freshnessMs) return workflowUnavailable();
        try {
          // Evidence and checkpoint share one conditional atomic write. A lost
          // acknowledgment is reconciled by replaying the identical publication.
          await persistence.write({ schemaVersion: 1, revision: incoming.sequence, publication: incoming }, version);
          return receipt(incoming, "published");
        } catch (error) {
          if (!error || typeof error !== "object" || !("code" in error) || error.code !== "EVERYAGENT_CONFLICT" || attempt === 5) throw error;
          await new Promise(resolve => setTimeout(resolve, 20 * (attempt + 1)));
        }
      }
      return workflowUnavailable();
    } catch { return workflowUnavailable(); }
  }
  return {
    publish,
    // Internal adapter only; never expose the full feed to the helper/model.
    async readFeed() {
      try { const { value } = await read(); if (!value) return workflowUnavailable(); return value.feed; }
      catch { return workflowUnavailable(); }
    },
  };
}
