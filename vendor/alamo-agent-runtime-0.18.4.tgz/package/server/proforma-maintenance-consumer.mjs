import { randomUUID } from 'node:crypto';
import { invalidMaintenance, maintenanceHash, maintenanceObject, maintenanceInteger, validateMaintenanceBinding, validateMaintenanceCommand, maintenanceAssessment } from '../shared/proforma-maintenance-contracts.mjs';

// A run-once responsibility activity, independent of scheduling and model choice.
// The host supplies delegated transport, conditional durable storage and an
// evaluated assessor. Nothing here registers or activates a background routine.
export function createProFormaMaintenanceConsumer({ binding: input, source, persistence, assess, now = () => new Date().toISOString() }) {
  const binding = validateMaintenanceBinding(input), bindingHash = maintenanceHash(binding);
  if (typeof assess !== 'function' || !['authorize','feed','context','command'].every(name => typeof source?.[name] === 'function') || typeof persistence?.read !== 'function' || typeof persistence?.write !== 'function') throw new Error('Explicit maintenance adapters are required.');
  const seal = value => ({ ...value, integrity: maintenanceHash(value) });
  const initial = () => seal({ schemaVersion: 1, bindingHash, revision: 0, streamId: null, cursor: 0, pending: null, receipts: [] });
  async function read() {
    const snapshot = await persistence.read();
    const value = snapshot.value ?? initial();
    maintenanceObject(value,['schemaVersion','bindingHash','revision','streamId','cursor','pending','receipts','integrity']);
    const { integrity, ...content } = value;
    if (value.schemaVersion !== 1 || value.bindingHash !== bindingHash || integrity !== maintenanceHash(content) || !Array.isArray(value.receipts) || value.receipts.length > 2000 || value.cursor > 0 && !value.streamId) return invalidMaintenance('Maintenance checkpoint does not match this responsibility.');
    maintenanceInteger(value.revision); maintenanceInteger(value.cursor,1000);
    if (value.pending) {
      maintenanceObject(value.pending,['command','advanceTo','streamId','processId','sourceVersion']);
      validateMaintenanceCommand(value.pending.command); maintenanceInteger(value.pending.advanceTo,1000);
      if (value.pending.advanceTo < value.cursor || value.pending.advanceTo > value.cursor + 1) return invalidMaintenance();
    }
    return { value, version:snapshot.version };
  }
  async function save(snapshot, changes) {
    const { integrity: _integrity, ...current } = snapshot.value;
    const next = { ...current, ...changes, revision: current.revision + 1 };
    if (next.receipts.length > 2000) throw new Error('Retain maintenance history before extending the checkpoint capacity.');
    await persistence.write(seal(next),snapshot.version);
  }
  async function advance(snapshot, event, outcome) {
    await save(snapshot,{ cursor:event.sequence, streamId:event.streamId, receipts:[...snapshot.value.receipts,{ eventId:event.id, sequence:event.sequence, processId:event.processId, outcome, at:now() }] });
  }
  async function runOnce({ maxOperations = 250 } = {}) {
    if (!Number.isSafeInteger(maxOperations) || maxOperations < 1 || maxOperations > 1000) throw new Error('Use a maintenance budget between 1 and 1,000 operations.');
    await source.authorize();
    let assessed = 0, skipped = 0;
    for (let operation = 0; operation < maxOperations; operation++) {
      const snapshot = await read(), state = snapshot.value;
      if (state.pending) {
        const pending = state.pending;
        let result;
        try { result = await source.command(pending.command); }
        catch (error) {
          // These responses explicitly establish that the pending command was
          // not accepted. Ambiguous transport/auth failures retain the exact ID.
          if (error && typeof error === 'object' && 'status' in error && error.status === 409 && 'code' in error && ['revision_conflict','maintenance_stale','maintenance_signals'].includes(String(error.code))) {
            await save(snapshot,{pending:null}); continue;
          }
          throw error;
        }
        await save(snapshot,{ pending:null, cursor:pending.advanceTo, streamId:pending.streamId,
          receipts:[...state.receipts,{ commandId:pending.command.id, processId:pending.processId, sourceVersion:pending.sourceVersion,
            outcome:pending.command.assessment?.outcome ?? 'observed', receipt:result.receipt, at:now() }] });
        if (pending.command.action === 'assess_changes') assessed++;
        continue;
      }
      const feed = await source.feed(state.cursor,state.streamId);
      if (feed.pendingChanges) {
        await save(snapshot,{pending:{ command:{id:randomUUID(),expectedRevision:feed.revision,action:'reconcile'}, advanceTo:state.cursor, streamId:state.streamId, processId:null, sourceVersion:null }});
        continue;
      }
      const event = feed.events[0];
      if (!event) { await source.authorize(); return { status:'caught_up',cursor:state.cursor,streamId:feed.streamId,assessed,skipped,canExecute:false }; }
      if (!binding.processIds.includes(event.processId) || !event.after) {
        const nextSelected = feed.events.findIndex(e => e.after && binding.processIds.includes(e.processId));
        const skippedEvents = nextSelected < 0 ? feed.events : feed.events.slice(0,nextSelected);
        await save(snapshot,{ cursor:skippedEvents.at(-1).sequence,streamId:event.streamId,
          receipts:[...state.receipts,...skippedEvents.map(e => ({eventId:e.id,sequence:e.sequence,processId:e.processId,outcome:e.after?'outside_scope':'source_unavailable',at:now()}))] });
        skipped += skippedEvents.length; continue;
      }
      let context;
      try { context = await source.context(event.processId); }
      catch (error) {
        if (!error || typeof error !== 'object' || !('status' in error) || error.status !== 404 || !('code' in error) || error.code !== 'process_missing') throw error;
        await advance(snapshot,event,'source_unavailable'); skipped++; continue;
      }
      if (context.source.version !== event.after.version) { await advance(snapshot,event,'superseded'); skipped++; continue; }
      if (state.receipts.some(r => r.processId === event.processId && r.sourceVersion === context.source.version)) {
        await advance(snapshot,event,'already_assessed'); skipped++; continue;
      }
      const decision = await assess({ purpose:binding.purpose, policyVersion:binding.policyVersion, context:structuredClone(context), change:structuredClone(event) });
      const assessment = maintenanceAssessment(context,event,decision);
      // Persist before POST. Competing workers cannot send different proposals
      // for this checkpoint; a lost response replays the exact command.
      await source.authorize();
      await save(snapshot,{pending:{ command:{id:randomUUID(),expectedRevision:feed.revision,action:'assess_changes',assessment},
        advanceTo:event.sequence,streamId:event.streamId,processId:event.processId,sourceVersion:context.source.version }});
    }
    await source.authorize();
    const {value} = await read();
    return {status:'more_work',cursor:value.cursor,streamId:value.streamId,assessed,skipped,canExecute:false};
  }
  return { runOnce, async status() {
    await source.authorize(); const {value} = await read();
    return {revision:value.revision,cursor:value.cursor,streamId:value.streamId,pending:!!value.pending,receipts:value.receipts.length,canExecute:false};
  } };
}
