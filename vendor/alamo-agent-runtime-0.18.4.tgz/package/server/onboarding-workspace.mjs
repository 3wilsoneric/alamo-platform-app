import { ONBOARDING_LIMITS, onboardingId, validateOnboardingCommand } from "../shared/onboarding-contracts.mjs";
import { createHttpError } from "./http-error-contract.mjs";
import { PIPELINE_ONBOARDING_SOURCE } from "../shared/pipeline-metadata-contracts.mjs";
import { validateDiscoveryEvidence } from "./onboarding-discovery.mjs";

/** @typedef {import('../shared/onboarding-contracts.mjs').OnboardingCommand} Command */
/** @typedef {import('../shared/onboarding-contracts.mjs').SourceMapping} Mapping */
/** @typedef {ReturnType<typeof validateDiscoveryEvidence>} Discovery */
/** @typedef {{requestId: string, revision: number, actorId: string, at: string, command: Command, discovery?: Discovery}} OnboardingEvent */
/** @typedef {{id: string, tenantId: string, ownerId: string, events: OnboardingEvent[]}} WorkspaceRecord */
/** @typedef {{id: string, title: string, application: string, reference: string, sourceVersion: string, steward: string, revision: number, provenance: 'declared' | 'observed_contract', discovery?: Discovery}} Source */
/** @typedef {{decision: 'confirmed' | 'rejected', actorId: string, at: string, note: string, workspaceRevision: number}} Review */
/** @typedef {{id: string, label: string, definition: string, revision: number, mappings: Mapping[], review: Review | null, originSourceId?: string, retired?: boolean}} Concept */
/** @typedef {{id: string, companyName: string, outcome: string, successCriterion: string, revision: number, sources: Source[], concepts: Concept[]}} Workspace */

const conflict = () => createHttpError(409, "onboarding_revision_conflict", "This workspace changed. Refresh before editing or reviewing.");
export const onboardingCapacity = () => createHttpError(409, "onboarding_capacity", "The pilot onboarding storage limit was reached. Export the workspace and arrange a storage migration.");
const evidenceError = () => createHttpError(409, "onboarding_evidence_required", "Use current registered source references before confirming this definition.");
const managed = () => createHttpError(409, "onboarding_managed_definition", "Discovered source definitions are maintained by discovery. Use a separate concept for a local interpretation.");
const fresh = (workspace, mappings) => mappings.length > 0 && mappings.every(mapping =>
  workspace.sources.some(source => source.id === mapping.sourceId && source.revision === mapping.sourceRevision &&
    (!source.discovery || source.discovery.manifest.concepts.some(concept => concept.locator === mapping.locator))));

/** Apply one validated command to the projection; journal history remains immutable.
 * @param {Workspace} workspace @param {OnboardingEvent} event */
export function applyOnboardingEvent(workspace, event) {
  const command = event.command;
  if (command.action === "create") {
    if (workspace.revision !== 0 || command.requestId !== workspace.id) throw conflict();
    workspace.companyName = command.companyName; workspace.outcome = command.outcome; workspace.successCriterion = command.successCriterion;
  } else {
    if (command.workspaceId !== workspace.id || command.expectedRevision !== workspace.revision) throw conflict();
    if (command.action === "register_source") {
      const previous = workspace.sources.find(source => source.id === command.sourceId);
      if (previous?.discovery) throw managed();
      if (!previous && workspace.sources.length >= ONBOARDING_LIMITS.sources) throw onboardingCapacity();
      const source = { id: command.sourceId, title: command.title, application: command.application, reference: command.reference,
        sourceVersion: command.sourceVersion, steward: command.steward, revision: (previous?.revision ?? 0) + 1, provenance: /** @type {const} */ ("declared") };
      workspace.sources = [...workspace.sources.filter(item => item.id !== source.id), source];
    } else if (command.action === "propose_concept") {
      if (command.mappings.length && !fresh(workspace, command.mappings)) throw evidenceError();
      const previous = workspace.concepts.find(concept => concept.id === command.conceptId);
      if (previous?.originSourceId) throw managed();
      if (!previous && workspace.concepts.length >= ONBOARDING_LIMITS.concepts) throw onboardingCapacity();
      const concept = { id: command.conceptId, label: command.label, definition: command.definition,
        revision: (previous?.revision ?? 0) + 1, mappings: command.mappings, review: null };
      workspace.concepts = [...workspace.concepts.filter(item => item.id !== concept.id), concept];
    } else if (command.action === "discover_pipeline") {
      if (!event.discovery) throw evidenceError();
      applyDiscovery(workspace, event.discovery);
    } else {
      const concept = workspace.concepts.find(item => item.id === command.conceptId);
      if (!concept) throw createHttpError(404, "not_found", "Not found.");
      if (concept.retired) throw managed();
      if (command.decision === "confirmed" && !fresh(workspace, concept.mappings)) throw evidenceError();
      concept.review = { decision: command.decision, actorId: event.actorId, at: event.at, note: command.note, workspaceRevision: event.revision };
    }
  }
  workspace.revision = event.revision;
}

/** @param {Workspace} workspace @param {Discovery} discovery */
function applyDiscovery(workspace, discovery) {
  const sourceId = PIPELINE_ONBOARDING_SOURCE, manifest = discovery.manifest;
  const previous = workspace.sources.find(source => source.id === sourceId);
  if (previous && !previous.discovery) throw managed();
  if (!previous && workspace.sources.length >= ONBOARDING_LIMITS.sources) throw onboardingCapacity();
  const changed = previous?.sourceVersion !== manifest.revision;
  const revision = previous ? previous.revision + (changed ? 1 : 0) : 1;
  const source = { id: sourceId, title: manifest.title, application: "pipeline", reference: discovery.reference,
    sourceVersion: manifest.revision, steward: manifest.steward, revision, provenance: /** @type {const} */ ("observed_contract"), discovery };
  workspace.sources = [...workspace.sources.filter(item => item.id !== sourceId), source];
  if (!changed) return; // A repeated observation never erases human review.
  const ids = new Set(manifest.concepts.map(concept => `pipeline-${concept.id}`));
  for (const concept of workspace.concepts) {
    if (concept.originSourceId === sourceId && !ids.has(concept.id)) concept.retired = true;
  }
  for (const item of manifest.concepts) {
    const id = `pipeline-${item.id}`, prior = workspace.concepts.find(concept => concept.id === id);
    if (prior && prior.originSourceId !== sourceId) throw managed();
    if (!prior && workspace.concepts.length >= ONBOARDING_LIMITS.concepts) throw onboardingCapacity();
    const concept = { id, label: item.label, definition: item.definition, revision: (prior?.revision ?? 0) + 1,
      mappings: [{ sourceId, sourceRevision: revision, locator: item.locator }], review: null, originSourceId: sourceId, retired: false };
    workspace.concepts = [...workspace.concepts.filter(existing => existing.id !== id), concept];
  }
}

function exact(value, keys) {
  return value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
}

/** @param {WorkspaceRecord} record @returns {Workspace} */
export function projectOnboardingWorkspace(record) {
  const bad = () => { throw new Error("Onboarding state is unavailable."); };
  if (!exact(record, ["id", "tenantId", "ownerId", "events"]) || !onboardingId(record.id) || !onboardingId(record.tenantId) ||
      !onboardingId(record.ownerId) || !Array.isArray(record.events) || !record.events.length || record.events.length > ONBOARDING_LIMITS.events) bad();
  /** @type {Workspace} */
  const workspace = { id: record.id, companyName: "", outcome: "", successCriterion: "", revision: 0, sources: [], concepts: [] };
  const requests = new Set();
  for (const [index, event] of record.events.entries()) {
    if (!exact(event, ["requestId", "revision", "actorId", "at", "command", ...(event.command?.action === "discover_pipeline" ? ["discovery"] : [])]) || event.revision !== index + 1 ||
        event.actorId !== record.ownerId || !onboardingId(event.requestId) || requests.has(event.requestId) ||
        typeof event.at !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(event.at) || !Number.isFinite(Date.parse(event.at))) bad();
    const command = validateOnboardingCommand(event.command);
    if (command.action === "discover_pipeline" && JSON.stringify(validateDiscoveryEvidence(event.discovery)) !== JSON.stringify(event.discovery)) bad();
    if (command.requestId !== event.requestId || (index === 0) !== (command.action === "create") ||
        JSON.stringify(command) !== JSON.stringify(event.command) || Buffer.byteLength(JSON.stringify(command)) > ONBOARDING_LIMITS.commandBytes) bad();
    requests.add(event.requestId);
    try { applyOnboardingEvent(workspace, event); } catch { bad(); }
  }
  return workspace;
}

/** Review state is derived from current evidence, never trusted from a client.
 * @param {Workspace} workspace @param {string[]} [staleSourceIds] */
export function onboardingView(workspace, staleSourceIds = []) {
  const concepts = workspace.concepts.map(concept => ({ ...concept,
    status: concept.retired ? "retired" : concept.review?.decision === "rejected" ? "rejected" : !concept.review ? "proposed" :
      fresh(workspace, concept.mappings) && !concept.mappings.some(mapping => staleSourceIds.includes(mapping.sourceId)) ? "confirmed" : "needs_review" }));
  const gaps = [
    ...(!workspace.sources.length ? [{ code: "source_required", subjectId: null }] : []),
    ...(!concepts.some(concept => !concept.retired) ? [{ code: "concept_required", subjectId: null }] : []),
    ...staleSourceIds.map(id => ({ code: "source_refresh_required", subjectId: id })),
    ...concepts.filter(concept => !["confirmed", "retired"].includes(concept.status)).map(concept => ({ code: "concept_review_required", subjectId: concept.id }))
  ];
  return { ...workspace, concepts, readiness: { definitions: gaps.length ? "needs_review" : "reviewed", gaps,
    activation: "blocked", remainingGates: ["verified_source_access", "lineage_verification", "governance_policy", "skill_configuration", "outcome_evaluations", "activation_review"] } };
}
