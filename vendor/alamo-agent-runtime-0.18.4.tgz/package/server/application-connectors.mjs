import { EVERYAGENT_SKILLS } from "../shared/everyagent-catalog.mjs";
import { createEveryAgentSourceClient } from "./everyagent-source-client.mjs";
import { createAssessmentReviewClient } from "./assessment-review-client.mjs";

// Both API and worker use this router. A request cannot choose a URL, token
// audience, alternate source or a broader skill. Missing apps fail closed.
export function createApplicationConnectors({ connectors, skills = EVERYAGENT_SKILLS }) {
  if (!Array.isArray(connectors) || connectors.length > 32) throw new Error("Configure application connectors.");
  const clients = new Map();
  const bindings = new Map();
  for (const skill of skills) {
    if (bindings.has(skill.id) || !/^[a-z][a-z0-9-]{0,63}$/.test(skill.sourceApplication)) throw new Error("Invalid skill source binding.");
    bindings.set(skill.id, skill.sourceApplication);
  }
  for (const config of connectors) {
    if (!config || clients.has(config.application) || ![...bindings.values()].includes(config.application)) throw new Error("Unknown or duplicate application connector.");
    const protocol = skills.filter(skill => skill.sourceApplication === config.application).map(skill => skill.sourceProtocol ?? 1);
    if (new Set(protocol).size !== 1 || ![1, 2].includes(protocol[0] ?? 0)) throw new Error("An application must use one reviewed source protocol.");
    clients.set(config.application, protocol[0] === 2 ? createAssessmentReviewClient(config) : createEveryAgentSourceClient(config));
  }
  function clientFor(assignment) {
    const client = clients.get(bindings.get(assignment.skillId));
    if (!client) throw new Error("This skill's application is not connected.");
    return client;
  }
  const authorize = (assignment, receipt = undefined) => clientFor(assignment).authorize(assignment, receipt);
  const adapters = Object.fromEntries(skills.map(skill => [skill.id, assignment => {
    if (assignment.skillId !== skill.id) throw new Error("The assignment does not match this skill.");
    return clientFor(assignment).read(assignment);
  }]));
  const describe = assignment => {
    const client = clientFor(assignment);
    if (assignment.skillId !== "assessment-review" || typeof client.describe !== "function") throw new Error("Capability discovery is not connected.");
    return client.describe(assignment);
  };
  // Public metadata contains only reviewed application IDs, never endpoints or
  // credentials. Configuration is not a source-health or permission claim.
  const configuredApplications = () => [...clients.keys()].sort();
  return { authorize, adapters, describe, configuredApplications };
}
