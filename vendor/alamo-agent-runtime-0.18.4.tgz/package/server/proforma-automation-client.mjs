import { validateAutomationBinding, validateAutomationDefinition } from '../shared/proforma-automation-contracts.mjs';
import { maintenanceObject, maintenanceId, maintenanceDigest } from '../shared/proforma-maintenance-contracts.mjs';
import { createProFormaSourceTransport } from './proforma-source-transport.mjs';

/** Read an exact reviewed definition for agent engineering. This client has no
 * execution, registration, publication or source-write operation. Re-read before
 * using a retained definition; its digest is not continuing source authority. */
export function createProFormaAutomationClient({ binding: input, getToken, fetchImpl = fetch, now = Date.now }) {
  const binding=validateAutomationBinding(input), transport=createProFormaSourceTransport({binding,getToken,fetchImpl,now});
  return {
    async read(input) {
      const expected=maintenanceObject(input,['documentId','publicationId','fingerprint']);
      maintenanceId(expected.documentId);maintenanceId(expected.publicationId);maintenanceDigest(expected.fingerprint);
      if(!binding.documentIds.includes(expected.documentId))throw new Error('Guide is outside this source binding.');
      const token=await transport.authorized('read');
      const result=await transport.request(token,`/processes/handoff?${new URLSearchParams({publicationId:expected.publicationId,fingerprint:expected.fingerprint})}`);
      return validateAutomationDefinition(result,binding,expected);
    },
  };
}
