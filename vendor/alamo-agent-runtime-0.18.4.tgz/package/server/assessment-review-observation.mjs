import { createHash } from "node:crypto";
import { EVERYAGENT_TENANT } from "../shared/everyagent-identity.mjs";
import { validateAssessmentReviewObservation } from "../shared/assessment-review-observation.mjs";
import { ASSESSMENT_REVIEW_RESPONSIBILITY } from "../skills/assessment-review/responsibility.mjs";

// Called only inside the existing completion transaction, after source and
// responsibility checks. No ingestion endpoint accepts client-authored events.
export function createAssessmentReviewObservation(task, completion) {
  const checks = ASSESSMENT_REVIEW_RESPONSIBILITY.completionChecks;
  if (task.skillId !== "assessment-review" || completion.contractId !== ASSESSMENT_REVIEW_RESPONSIBILITY.id ||
      completion.contractVersion !== ASSESSMENT_REVIEW_RESPONSIBILITY.version || completion.outcome !== "review_completed" ||
      completion.binding.skillVersion !== task.skillVersion || completion.resultDigest !== task.resultDigest ||
      completion.coverage.recordsExpected !== completion.coverage.recordsReviewed ||
      !Array.isArray(completion.evidenceWorkIds) || completion.evidenceWorkIds.length !== completion.coverage.recordsReviewed ||
      completion.evidenceWorkIds.some(id => typeof id !== "string" || !/^[a-f0-9]{32}$/.test(id)) ||
      new Set(completion.evidenceWorkIds).size !== completion.evidenceWorkIds.length ||
      completion.sourceGrant.application !== "pipeline" ||
      ["application", "id", "revision"].some(key => completion.sourceGrant[key] !== completion.binding.sourceAccess[key]) ||
      completion.checks.length !== checks.length || checks.some(id => !completion.checks.some(check => check.id === id && check.status === "passed"))) {
    throw new Error("A verified assessment completion is required.");
  }
  return validateAssessmentReviewObservation({
    version: 1,
    id: createHash("sha256").update(JSON.stringify([1, EVERYAGENT_TENANT, task.userId, task.id, "assessment_review.completed"])).digest("hex"),
    type: "assessment_review.completed", producer: "alamoagent", tenantId: EVERYAGENT_TENANT,
    actor: { kind: "agent", onBehalfOf: task.userId }, runId: task.id,
    skill: { id: "assessment-review", version: task.skillVersion, workflowVersion: task.workflowVersion, assignmentVersion: task.assignmentVersion },
    occurredAt: new Date(completion.completedAt).toISOString(),
    source: { application: "pipeline", grantId: completion.sourceGrant.id, grantRevision: completion.sourceGrant.revision,
      observedFrom: new Date(completion.coverage.startedAt).toISOString(), observedThrough: new Date(completion.coverage.finishedAt).toISOString() },
    definitions: { workspaceId: completion.binding.workspaceId, bindingRevision: completion.binding.fingerprint,
      rulesRevision: completion.binding.questionnaireRulesVersion },
    outcome: { code: "review_completed", recordsReviewed: completion.coverage.recordsReviewed,
      pageCount: completion.coverage.pageCount, sourceMutation: false },
    // The run receipt owns the evidence IDs. Bind to them without duplicating
    // up to 500 references in every retained task/run observation.
    evidence: { resultDigest: completion.resultDigest, workCount: completion.evidenceWorkIds.length,
      workIdsDigest: createHash("sha256").update(JSON.stringify([...completion.evidenceWorkIds].sort())).digest("hex") }
  });
}
