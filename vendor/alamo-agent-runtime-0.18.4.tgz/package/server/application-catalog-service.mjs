import { WORKFLOW_KNOWLEDGE_SKILL } from "../shared/workflow-knowledge-contracts.mjs";
import { createHash } from "node:crypto";
import { describeApplicationCatalog } from "../shared/application-catalog.mjs";
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
import { everyAgentActor, grantFor, freshAssignment, allowedAssignment } from "./everyagent-access.mjs";
import { createEveryAgentStore } from "./everyagent-store.mjs";
import { createHttpError } from "./http-error-contract.mjs";

/** Native capability discovery over the same registry, assignments and source
 * grants as execution. It never reads business records, writes state or enables work.
 * @param {{source: {configuredApplications: () => string[], authorize: (assignment: any) => Promise<unknown>},
 * store?: ReturnType<typeof createEveryAgentStore>, now?: () => number}} options */
export function createApplicationCatalogService({ source, store = createEveryAgentStore(), now = () => Date.now() }) {
  const catalog = describeApplicationCatalog();
  const revision = createHash("sha256").update(JSON.stringify(catalog)).digest("hex");
  const configured = new Set(source.configuredApplications());
  if ([...configured].some(id => !catalog.applications.some(app => app.id === id && app.capabilities.length))) {
    throw new Error("Application configuration does not match the reviewed catalog.");
  }

  async function read(auth, attempt = 0) {
    const subjectId = everyAgentActor(auth);
    const skills = grantFor(subjectId);
    const snapshot = (await store.read()).value;
    const checks = await Promise.all(skills.map(async skill => {
      const assignment = snapshot.assignments.find(item => item.userId === subjectId && item.skillId === skill.id) ?? freshAssignment(subjectId, skill);
      // A paused responsibility may still have source access. Access observation
      // must not be mistaken for authorization to activate or complete that work.
      const base = { skillId: skill.id, application: skill.sourceApplication, capability: skill.capability,
        assignmentVersion: assignment.version, paused: assignment.paused,
        resourceScope: { kind: skill.scope, ids: [...assignment.communityIds].sort() } };
      if (!configured.has(skill.sourceApplication)) return { ...base, state: "not_configured", checkedAt: null, grant: null };
      if (!allowedAssignment(assignment)) return { ...base, state: "unavailable", checkedAt: null, grant: null };
      try {
        const grant = validateAgentSourceGrant(await source.authorize(assignment));
        if (grant.application !== skill.sourceApplication || Date.parse(grant.expiresAt) <= now()) throw new Error("Unavailable grant.");
        return { ...base, state: "verified", checkedAt: new Date(now()).toISOString(), grant };
      } catch {
        // Denials, missing membership, transport failures and invalid responses
        // share a safe state. Do not expose connector URLs, errors or stale grants.
        return { ...base, state: "unavailable", checkedAt: new Date(now()).toISOString(), grant: null };
      }
    }));
    // A concurrent scope change invalidates this observation, even if the old
    // source grant remains valid. Never publish a catalog for a stale assignment.
    if ((await store.read()).value.revision !== snapshot.revision) {
      if (attempt >= 2) throw createHttpError(409, "agent_state_changed", "Agent work changed. Refresh and try again.");
      return read(auth, attempt + 1);
    }
    const observedAt = new Date(now()).toISOString();
    const access = checks.map(check => check.grant && Date.parse(check.grant.expiresAt) <= now()
      ? { ...check, state: "unavailable", grant: null } : check);
    const visibleSkills = [...skills, WORKFLOW_KNOWLEDGE_SKILL];
    const visibleIds = new Set(visibleSkills.map(skill => skill.id));
    return { schemaVersion: catalog.schemaVersion, revision, observedAt,
      scope: { tenantId: String(auth.claims.tid).toLowerCase(), subjectId },
      companyBinding: "not_established", authorization: "observation_only",
      applications: catalog.applications.map(app => ({ ...structuredClone(app),
        capabilities: app.capabilities.filter(capability => visibleSkills.some(skill => skill.sourceApplication === app.id && skill.capability === capability.id))
          .map(capability => structuredClone(capability)),
        connection: configured.has(app.id) ? "configured" : app.capabilities.length ? "not_configured" : "not_implemented" })),
      onDemand: [{ skillId: WORKFLOW_KNOWLEDGE_SKILL.id, execution: "host-delegated-read", access: "not_observed", activation: "not_scheduled" }],
      skills: catalog.skills.filter(skill => visibleIds.has(skill.id)).map(skill => ({ ...skill })), access };
  }
  return { read };
}
