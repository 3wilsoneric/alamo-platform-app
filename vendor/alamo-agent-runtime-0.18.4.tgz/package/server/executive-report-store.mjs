import path from 'node:path';
import { createEveryAgentPersistence } from './everyagent-persistence.mjs';
import { isProductionLikeRuntime } from './runtime-environment.mjs';
import { reportId, reportSubject, reportJson, reportHash, validateReportScope, reportText, reportObject } from '../shared/executive-report-contracts.mjs';
import { createHttpError } from './http-error-contract.mjs';

function validate(state) {
  if (state.id === 'index') {
    reportObject(state, ['schemaVersion', 'revision', 'ownerId', 'id', 'entries'], ['budget']);
    if (!Array.isArray(state.entries) || state.entries.length > 100 || new Set(state.entries.map(e => `${e.ownerId}:${e.id}`)).size !== state.entries.length) throw new Error('Report index is unavailable.');
    for (const e of state.entries) { reportObject(e, ['ownerId', 'id']); reportSubject(e.ownerId); reportId(e.id); }
    if (state.budget) {
      reportObject(state.budget, ['day', 'requests']);
      if (!/^20\d{2}-\d{2}-\d{2}$/.test(state.budget.day) || !Array.isArray(state.budget.requests) || state.budget.requests.length > 20 || new Set(state.budget.requests).size !== state.budget.requests.length) throw Error('Report budget is unavailable.');
      state.budget.requests.forEach(reportId);
    }
    return;
  }
  reportObject(state, ['schemaVersion', 'revision', 'id', 'ownerId', 'tenantId', 'createdAt', 'readers', 'runs']);
  reportSubject(state.tenantId);
  if (!Array.isArray(state.readers) || state.readers.length > 10 || new Set(state.readers).size !== state.readers.length ||
      !Array.isArray(state.runs) || !state.runs.length || state.runs.length > 12) throw new Error('Report state is unavailable.');
  state.readers.forEach(reportSubject);
  for (const run of state.runs) {
    reportSubject(run.id); reportSubject(run.requestId); reportId(run.requestHash); reportText(run.objective); validateReportScope(run.scope);
    if (!['queued', 'reading', 'analyzing', 'ready', 'partial', 'paused', 'failed', 'cancelled'].includes(run.status) ||
        !Number.isSafeInteger(run.attempt) || run.attempt < 0 || !Array.isArray(run.evidence) || run.evidence.length > 6 ||
        !Number.isFinite(run.deadline) || !Number.isFinite(Date.parse(run.createdAt)) || !Number.isFinite(Date.parse(run.updatedAt)) ||
        ['ready', 'partial'].includes(run.status) && !run.artifact) throw new Error('Report run is unavailable.');
  }
}

// Reuse conditional Blob writes/file locks. Each report is isolated; no source
// credential is persisted. The index is only a discovery/queue hint, never ACL.
export function createExecutiveReportStore({ azure = isProductionLikeRuntime(), localRoot = path.resolve('generated'), persistenceFor = createEveryAgentPersistence } = {}) {
  function target(ownerId, id) {
    reportSubject(ownerId); if (id !== 'index') reportId(id);
    const blobPath = `everyagent/reports-v1/${ownerId}/${id}.json`;
    return persistenceFor({ azure, blobPath, localPath: path.join(localRoot, blobPath) });
  }
  async function read(ownerId, id) {
    const snapshot = await target(ownerId, id).read();
    if (snapshot.value && (snapshot.value.schemaVersion !== 1 || !Number.isSafeInteger(snapshot.value.revision) || snapshot.value.revision < 1 ||
        snapshot.value.ownerId !== ownerId || snapshot.value.id !== id)) throw new Error('Report state is unavailable.');
    if (snapshot.value) { reportJson(snapshot.value, 4_000_000); validate(snapshot.value); }
    return snapshot;
  }
  async function update(ownerId, id, mutate) {
    for (let attempt = 0; attempt < 8; attempt++) {
      const { value, version } = await read(ownerId, id), next = structuredClone(value);
      const updated = await mutate(next);
      if (updated === null) return value;
      if (updated.ownerId !== ownerId || updated.id !== id || updated.revision !== (value?.revision ?? 0)) throw new Error('Invalid report state transition.');
      updated.schemaVersion = 1; updated.revision++;
      reportJson(updated, 4_000_000); validate(updated);
      if (value?.runs) {
        if (updated.runs.length < value.runs.length) throw new Error('Report history cannot be removed.');
        for (const [i, before] of value.runs.entries()) {
          const after = updated.runs[i];
          for (const key of ['id', 'requestId', 'requestHash', 'objective', 'scope', 'createdAt', 'previousVersion']) {
            if (reportHash(before[key]) !== reportHash(after[key])) throw new Error('Report history is immutable.');
          }
          if (before.artifact && reportHash(before.artifact) !== reportHash(after.artifact)) throw new Error('Saved report versions are immutable.');
          if (before.view && reportHash(before.view) !== reportHash(after.view)) throw new Error('Saved report views are immutable.');
          if (before.evidence.some((e, j) => reportHash(e) !== reportHash(after.evidence[j] ?? null))) throw new Error('Saved report evidence is immutable.');
        }
      }
      try { await target(ownerId, id).write(updated, version); return updated; }
      catch (error) {
        if (!(error && typeof error === 'object' && 'code' in error && error.code === 'EVERYAGENT_CONFLICT') || attempt === 7) throw error;
        await new Promise(resolve => setTimeout(resolve, 10 * (attempt + 1)));
      }
    }
    throw new Error('Report could not be saved.');
  }
  async function index(subject, ownerId, id) {
    reportSubject(ownerId); reportId(id);
    return update(subject, 'index', state => {
      state ??= { schemaVersion: 1, revision: 0, ownerId: subject, id: 'index', entries: [] };
      if (state.entries.some(e => e.ownerId === ownerId && e.id === id)) return null;
      if (state.entries.length >= 100) throw new Error('Saved report capacity reached.');
      state.entries.push({ ownerId, id }); return state;
    });
  }
  async function reserveExecution(subject, key, now) {
    reportId(key);
    const day = new Date(now).toISOString().slice(0, 10);
    await update(subject, 'index', state => {
      state ??= {schemaVersion:1,revision:0,ownerId:subject,id:'index',entries:[]};
      if (state.budget?.day !== day) state.budget = {day,requests:[]};
      if (state.budget.requests.includes(key)) return null;
      if (state.budget.requests.length >= 20) throw createHttpError(429,'report_budget','The daily investigation limit has been reached. Saved reports remain available.');
      state.budget.requests.push(key); return state;
    });
  }
  return { read, update, index, reserveExecution };
}
