import { randomUUID } from "node:crypto";
import { everyAgentFingerprint } from "./everyagent-adapters.mjs";
import { grantFor, scopeAllows } from "./everyagent-access.mjs";

const INTERVAL = 15 * 60_000;

export function publishEveryAgentResult(state, assignment, result, started, finished, runId = randomUUID()) {
  const at = new Date(finished).toISOString();
  assignment.lastChecked = at;
  assignment.sourceCheckedAt = result.sourceCheckedAt;
  assignment.connection = result.connection;
  assignment.issue = result.issue;
  assignment.nextCheck = new Date(finished + INTERVAL).toISOString();
  state.runs.push({ id: runId, userId: assignment.userId, skillId: assignment.skillId, communityIds: assignment.communityIds,
    startedAt: new Date(started).toISOString(), finishedAt: at, status: result.connection === "connected" ? "completed" : result.connection });
  if (result.connection !== "connected") return;
  const entries = result.entries.filter(entry => scopeAllows(entry, assignment));
  // Referral projections are useful on their first read and must retain their
  // own links. A changed scope receipt republishes currently authorized records.
  const wasInitialized = assignment.cursor !== null || assignment.skillId === "assessment-review";
  const previous = assignment.cursor ?? {};
  const evidenceFor = entry => state.work.findLast(item => item.userId === assignment.userId && item.skillId === assignment.skillId &&
    (item.status !== "completed" || Date.parse(item.createdAt) > Date.now() - 90 * 86_400_000) &&
    item.sourceFingerprint === entry.fingerprint && item.responsibilityFingerprint === assignment.responsibility?.fingerprint &&
    ["application", "id", "revision"].every(key => item.sourceGrant?.[key] === result.sourceGrant?.[key]));
  const changed = entries.filter(entry => previous[entry.key] !== entry.fingerprint ||
    (assignment.skillId === "assessment-review" && (assignment.sourceRevision !== result.sourceGrant?.revision ||
      assignment.publishedResponsibility !== assignment.responsibility?.fingerprint || (assignment.responsibility && !evidenceFor(entry)))));
  const skill = grantFor(assignment.userId).find(s => s.id === assignment.skillId);
  if (!skill) throw new Error("The skill is no longer available.");
  const work = wasInitialized ? changed : [{
    key: "baseline", fingerprint: everyAgentFingerprint(entries.map(entry => [entry.key, entry.fingerprint])),
    communityIds: assignment.communityIds, title: `${skill.title} monitoring ready`,
    summary: assignment.skillId === "licensing" ? `${entries.length} archived reports available. Future new or changed reports will appear here for review.` : entries[0]?.summary ?? "Published summary checked.",
    evidence: entries[0]?.evidence ?? [{ id: skill.capability, kind: "module", label: `Open ${skill.title}`, href: skill.href, observedAt: result.sourceCheckedAt }],
    relationships: entries[0]?.relationships ?? []
  }];
  for (const item of work) {
    const id = everyAgentFingerprint([assignment.userId, assignment.skillId, item.key, item.fingerprint, wasInitialized ? result.sourceCheckedAt : "baseline",
      ...(assignment.responsibility ? [assignment.responsibility.fingerprint] : [])]);
    if (state.work.some(existing => existing.id === id)) continue;
    state.work.push({ ...(result.sourceGrant ? { sourceGrant: result.sourceGrant } : {}),
      ...(assignment.responsibility ? { responsibilityFingerprint: assignment.responsibility.fingerprint } : {}),
      id, runId, userId: assignment.userId, skillId: assignment.skillId, title: item.title, summary: item.summary,
      communityIds: item.communityIds, status: wasInitialized ? "needs_review" : "completed", createdAt: at, reviewedAt: null,
      sourceFingerprint: item.fingerprint, sourceCheckedAt: result.sourceCheckedAt,
      evidence: item.evidence, relationships: item.relationships });
  }
  assignment.cursor = Object.fromEntries(entries.map(entry => [entry.key, entry.fingerprint]));
  if (result.sourceGrant) assignment.sourceRevision = result.sourceGrant.revision;
  if (assignment.responsibility) assignment.publishedResponsibility = assignment.responsibility.fingerprint;
  if (assignment.responsibility) return entries.map(entry => {
    const evidence = evidenceFor(entry);
    if (!evidence) throw new Error("Review evidence could not be saved.");
    return evidence.id;
  });
  return undefined;
}
