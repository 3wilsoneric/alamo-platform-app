import { ONBOARDING_API_PATH, ONBOARDING_LIMITS, onboardingId } from "../shared/onboarding-contracts.mjs";
import { readJsonRequestBody } from "./http-body.mjs";
import { createHttpError } from "./http-error-contract.mjs";

export async function handleOnboardingHttp(req, res, auth, service) {
  const url = new URL(req.url, "https://agent.invalid");
  if (url.pathname !== ONBOARDING_API_PATH || !service) throw createHttpError(404, "not_found", "Not found.");
  if (req.method === "GET") {
    const id = url.searchParams.get("id");
    const format = url.searchParams.get("format") ?? "view";
    if ([...url.searchParams.keys()].some(key => !["id", "format"].includes(key)) || url.searchParams.getAll("id").length > 1 ||
        url.searchParams.getAll("format").length > 1 || (id !== null && !onboardingId(id)) ||
        !["view", "export"].includes(format) || (format === "export" && !id)) {
      throw createHttpError(400, "onboarding_query_invalid", "Choose a valid onboarding workspace.");
    }
    res.status(200).json(await service.read(auth, id, format)); return;
  }
  if (req.method === "POST") {
    if (url.search) throw createHttpError(400, "onboarding_query_invalid", "Onboarding commands do not accept query parameters.");
    res.status(200).json(await service.command(auth, await readJsonRequestBody(req, ONBOARDING_LIMITS.commandBytes))); return;
  }
  res.setHeader("Allow", "GET, POST");
  throw createHttpError(405, "method_not_allowed", "Method not allowed.");
}
