import { randomUUID } from 'node:crypto';
import { buildReportDocument, validateCitedReportFindings } from '../packages/ally-core/dist/index.js';
import { EVERYAGENT_TENANT } from '../shared/everyagent-identity.mjs';
import { REPORT_TERMINAL, reportHash, reportId, reportSubject, reportText, validateReportCreate, validateReportCommand, validateReportScope, validateReportPlan, validateReportEvidence } from '../shared/executive-report-contracts.mjs';
import { createHttpError } from './http-error-contract.mjs';
import { reportViewContext, reportViewPlan } from '../shared/executive-report-views.mjs';

const hidden = () => createHttpError(404, 'report_not_found', 'Report not found.');
const conflict = () => createHttpError(409, 'report_changed', 'The report changed. Refresh and try again.');
const last = report => report.runs.at(-1);
const summary = report => ({ id: report.id, ownerId: report.ownerId, title: last(report).objective,
  createdAt: report.createdAt, updatedAt: last(report).updatedAt, version: report.runs.length, revision: report.revision,
  status: last(report).status, completedSources: last(report).evidence.length, totalSources: last(report).plan?.steps.length ?? 0 });

/** A checkpointed read-only investigation. Source owns authorization and facts;
 * model owns proposals. A worker advances one bounded phase per activity. */
export function createExecutiveReportService({ store, source, model, allowedSubjects, now = Date.now, leaseMs = 90_000, deadlineMs = 20 * 60_000 }) {
  if (!Array.isArray(allowedSubjects) || !allowedSubjects.length || new Set(allowedSubjects).size !== allowedSubjects.length) throw new Error('Configure explicit report participants.');
  allowedSubjects.forEach(reportSubject);
  function actor(auth) {
    if (auth?.authenticated !== true || auth.mode !== 'entra-delegated' || auth.claims?.tid !== EVERYAGENT_TENANT ||
        !allowedSubjects.includes(auth.claims?.oid)) throw hidden();
    return reportSubject(auth.claims.oid);
  }
  async function allowed(subject, run, verifyCollectedGrant = false) {
    // Even a queued report rechecks the scope: knowing its identifier is no grant.
    try {
      if (!await source.authorize(subject, run.scope, null)) throw hidden();
      for (const step of run.plan?.steps ?? []) {
        const grant = await source.authorize(subject, run.scope, step);
        const evidence = run.evidence?.find(entry => entry.sourceId === step.id)?.value;
        if (!grant || evidence && (typeof evidence.requiresDetail !== 'boolean' ||
            evidence.requiresDetail && grant.detail !== true ||
            verifyCollectedGrant && grant.revision !== evidence.grantRevision)) throw hidden();
      }
    } catch (error) {
      if (error && typeof error === 'object' && 'statusCode' in error && [401,403,404].includes(Number(error.statusCode))) throw hidden();
      throw error;
    }
  }
  async function locate(subject, ownerId, id) {
    reportSubject(ownerId); reportId(id);
    const report = (await store.read(ownerId, id)).value;
    if (!report || report.tenantId !== EVERYAGENT_TENANT || !allowedSubjects.includes(ownerId) ||
        subject !== ownerId && !report.readers.includes(subject)) throw hidden();
    await allowed(subject, last(report)); return report;
  }
  function newRun(requestId, objective, scope, previous) {
    const at = new Date(now()).toISOString();
    return { id: randomUUID(), requestId, requestHash: reportHash({ objective, scope }), objective, scope,
      createdAt: at, updatedAt: at, deadline: now() + deadlineMs, status: 'queued', plan: null,
      evidence: [], artifact: null, lease: null, error: null, model: null, modelCalls: 0, attempt: 0,
      // Follow-up context is saved evidence, not client-provided assistant text.
      previousVersion: previous ?? null };
  }
  async function create(auth, input) {
    const subject = actor(auth), v = validateReportCreate(input);
    reportSubject(v.requestId); reportText(v.objective);
    const scope = validateReportScope(v.scope), id = reportHash([subject, v.requestId]);
    await allowed(subject, { scope, plan: null });
    // Reserve discovery before saving work: an interrupted or full index must
    // never leave paid work running without an accessible report entry.
    if (!(await store.read(subject,id)).value) await store.reserveExecution(subject, reportHash(['create',id]), now());
    await store.index(subject, subject, id);
    const initial = newRun(v.requestId, v.objective, scope, null);
    const report = await store.update(subject, id, state => {
      if (state) {
        if (state.runs[0].requestHash !== initial.requestHash) throw conflict();
        return null;
      }
      return { schemaVersion: 1, revision: 0, id, ownerId: subject, tenantId: EVERYAGENT_TENANT,
        createdAt: initial.createdAt, readers: [], runs: [initial] };
    });
    // Retrying the same create repairs an interrupted index write.
    await store.index(subject, subject, id);
    await allowed(subject, last(report)); return summary(report);
  }
  async function get(auth, ownerId, id, version = null) {
    const subject = actor(auth), report = await locate(subject, ownerId, id);
    const n = version ?? report.runs.length;
    if (!Number.isSafeInteger(n) || n < 1 || n > report.runs.length) throw hidden();
    const run = report.runs[n - 1]; await allowed(subject, run);
    // Never expose leases, private traces, or earlier unselected versions.
    return { ...summary(report), selectedVersion: n, canEdit: subject === ownerId,
      scope: run.scope, objective: run.objective, status: run.status, error: run.error,
      artifact: run.artifact, view: run.view ?? null, readers: subject === ownerId ? report.readers : [], sourceProgress: run.evidence.map(e => ({ id: e.sourceId, title: e.value.title, status: e.value.status })),
      versions: report.runs.map((r, i) => ({ version: i + 1, createdAt: r.createdAt, status: r.status })) };
  }
  async function list(auth) {
    const subject = actor(auth), entries = (await store.read(subject, 'index')).value?.entries ?? [];
    const reports = [];
    for (const entry of entries) {
      try { reports.push(summary(await locate(subject, entry.ownerId, entry.id))); }
      catch (error) { if (!(error && typeof error === 'object' && 'statusCode' in error && error.statusCode === 404)) throw error; }
    }
    return reports.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  async function command(auth, input) {
    const subject = actor(auth), v = validateReportCommand(input);
    const report = await locate(subject, v.ownerId, v.id);
    if (subject !== report.ownerId) throw hidden();
    if (!['refresh', 'followup', 'resume', 'cancel', 'share', 'unshare'].includes(v.action)) throw createHttpError(400, 'report_action_invalid', 'Choose a report action.');
    let next = null;
    if (['refresh', 'followup'].includes(v.action)) {
      reportSubject(v.requestId);
      const current = last(report), objective = v.action === 'refresh' ? current.objective : reportText(v.objective),
        scope = v.action === 'refresh' ? current.scope : validateReportScope(v.scope);
      await allowed(subject, { scope, plan: null });
      next = newRun(v.requestId, objective, scope, report.runs.length);
      if (!report.runs.some(r => r.requestId === next.requestId)) await store.reserveExecution(subject, reportHash([v.id, next.requestId]), now());
    }
    if (['share', 'unshare'].includes(v.action)) {
      reportSubject(v.readerId);
      if (v.readerId === subject || !allowedSubjects.includes(v.readerId)) throw hidden();
      if (v.action === 'share') {
        for (const run of report.runs) await allowed(v.readerId, run);
      }
    }
    const updated = await store.update(subject, v.id, state => {
      if (!state) throw hidden();
      if (next) {
        const prior = state.runs.find(r => r.requestId === next.requestId);
        if (prior) { if (prior.requestHash !== next.requestHash) throw conflict(); return null; }
      }
      // An acknowledged share can be retried to repair an interrupted index
      // write. The authoritative ACL and recipient's grants were checked above.
      if (v.action === 'share' && state.readers.includes(v.readerId)) return null;
      if (v.action === 'unshare' && !state.readers.includes(v.readerId)) return null;
      if (state.revision !== v.revision) throw conflict();
      const run = last(state);
      if (next) {
        if (!REPORT_TERMINAL.has(run.status) || state.runs.length >= 12) throw conflict();
        state.runs.push(next);
      } else if (v.action === 'cancel') {
        if (REPORT_TERMINAL.has(run.status)) return null;
        run.status = 'cancelled'; run.lease = null;
      } else if (v.action === 'resume') {
        if (!['paused', 'failed'].includes(run.status) || run.attempt >= 3) throw conflict();
        run.status = run.plan ? 'reading' : 'queued'; run.error = null; run.lease = null; run.deadline = now() + deadlineMs; run.attempt++;
      } else if (v.action === 'share') {
        if (!state.readers.includes(v.readerId)) state.readers.push(v.readerId);
      } else if (v.action === 'unshare') state.readers = state.readers.filter(id => id !== v.readerId);
      last(state).updatedAt = new Date(now()).toISOString(); return state;
    });
    if (v.action === 'share') await store.index(v.readerId, subject, v.id);
    return summary(updated);
  }
  async function pending() {
    const keys = [];
    for (const ownerId of allowedSubjects) {
      for (const entry of (await store.read(ownerId, 'index')).value?.entries ?? []) {
        if (entry.ownerId !== ownerId) continue;
        const report = (await store.read(ownerId, entry.id)).value;
        if (report && !REPORT_TERMINAL.has(last(report).status)) keys.push({ ownerId, id: entry.id, runId: last(report).id, attempt: last(report).attempt });
      }
    }
    return keys;
  }
  async function advance({ ownerId, id, runId = null, attempt = null }) {
    if (!allowedSubjects.includes(ownerId)) throw hidden();
    const leaseId = randomUUID();
    const claimed = await store.update(ownerId, id, state => {
      if (!state) throw hidden();
      const run = last(state);
      if (runId !== null && (run.id !== runId || run.attempt !== attempt)) return null;
      if (REPORT_TERMINAL.has(run.status) || run.lease?.until > now()) return null;
      if (run.deadline <= now()) { run.status = 'paused'; run.error = 'This investigation timed out. Resume to continue.'; run.lease = null; return state; }
      if (!run.plan || run.evidence.length === run.plan.steps.length) {
        if ((run.modelCalls ?? 0) >= 4) { run.status = 'paused'; run.error = 'This version reached its model limit. Start a narrower investigation.'; run.lease = null; return state; }
        run.modelCalls = (run.modelCalls ?? 0) + 1;
      }
      run.lease = { id: leaseId, until: now() + leaseMs }; return state;
    });
    const run = last(claimed);
    if (run.lease?.id !== leaseId) return { status: run.status, claimed: false };
    async function checkpoint(apply) {
      return store.update(ownerId, id, state => {
        const current = last(state);
        if (current.id !== run.id || current.lease?.id !== leaseId || REPORT_TERMINAL.has(current.status)) return null;
        if (current.lease.until <= now()) return null;
        apply(current); current.lease = null; current.updatedAt = new Date(now()).toISOString(); return state;
      });
    }
    try {
      // Advancing cached evidence requires the original, still-current grant.
      await allowed(ownerId, run, true);
      if (!run.plan) {
        const catalog = await source.catalog(ownerId, run.scope);
        const previous = run.previousVersion ? claimed.runs[run.previousVersion - 1] : null;
        if (previous) await allowed(ownerId, previous);
        const proposed = await model.plan({ objective: run.objective, scope: run.scope, catalog,
          previous: previous ? { objective: previous.objective, scope: previous.scope, findings: previous.artifact?.findings ?? [] } : null });
        const plan = validateReportPlan(proposed.plan, catalog);
        await allowed(ownerId, { ...run, plan });
        return summary(await checkpoint(current => { current.plan = plan; current.model = proposed.metadata ?? null; current.status = 'reading'; }));
      }
      const step = run.plan.steps[run.evidence.length];
      if (step) {
        const value = validateReportEvidence(await source.read(ownerId, run.scope, step), step, run.scope);
        const grant = await source.authorize(ownerId, run.scope, step);
        if (!grant || grant.revision !== value.grantRevision || value.requiresDetail && grant.detail !== true) throw hidden();
        return summary(await checkpoint(current => {
          current.evidence.push({ sourceId: step.id, value });
          current.status = current.evidence.length === current.plan.steps.length ? 'analyzing' : 'reading';
        }));
      }
      const viewContext = reportViewContext(run.evidence, reportHash(run.scope), run.objective);
      const synthesis = await model.synthesize({ objective: run.objective, scope: run.scope, evidence: run.evidence, views: viewContext });
      const verified = validateCitedReportFindings(synthesis, run.evidence);
      const gaps = [...run.plan.gaps, ...run.evidence.filter(e => e.value.coverage === 'partial').map(e => `${e.value.title}: ${e.value.note}`), ...(verified?.rejectedCount ? [`${verified.rejectedCount} unsupported findings withheld.`] : []),
        ...(!verified ? ['No analytical finding passed evidence checks. The source results remain available.'] : [])];
      let view;
      try { view = reportViewPlan(synthesis.views, viewContext); }
      catch { view = reportViewPlan(null, viewContext); gaps.push('The requested visualization could not be verified. Exact source tables are shown.'); }
      const artifact = buildReportDocument({ id: `${id}-${claimed.runs.length}`, title: run.objective,
        generatedAt: new Date(now()).toISOString(), filename: 'Ally report.html',
        sections: run.evidence.map(e => ({ id: e.sourceId, ...e.value })), gaps, findings: verified?.findings ?? [] });
      // The model call can outlive a grant revision. A still-authorized query
      // does not prove that evidence collected under the old grant is current.
      await allowed(ownerId, run, true);
      return summary(await checkpoint(current => {
        current.artifact = artifact; current.view = view; current.synthesisModel = synthesis.metadata ?? null; current.status = artifact.coverage === 'partial' ? 'partial' : 'ready';
      }));
    } catch (error) {
      const access = error && typeof error === 'object' && 'statusCode' in error && [401, 403, 404].includes(Number(error.statusCode));
      return summary(await checkpoint(current => {
        current.status = 'paused'; current.error = access ? 'Source access changed. Refresh the report after access is restored.' : 'A source or model is unavailable. Resume to retry.';
      }));
    }
  }
  async function pause({ ownerId, id, runId, attempt }) {
    if (!allowedSubjects.includes(ownerId)) throw hidden();
    await store.update(ownerId, id, state => {
      if (!state) return null;
      const run = last(state);
      if (run.id !== runId || run.attempt !== attempt || REPORT_TERMINAL.has(run.status)) return null;
      run.status = 'paused'; run.error = 'The report worker was interrupted. Resume to continue.'; run.lease = null; return state;
    });
  }
  return { create, get, list, command, pending, advance, pause };
}
