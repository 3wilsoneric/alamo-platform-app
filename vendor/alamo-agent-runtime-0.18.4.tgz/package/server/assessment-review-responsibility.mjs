import { createHash } from "node:crypto";
import { EVERYAGENT_TENANT } from "../shared/everyagent-catalog.mjs";
import { PIPELINE_ONBOARDING_SOURCE } from "../shared/pipeline-metadata-contracts.mjs";
import { ASSESSMENT_REVIEW_RESPONSIBILITY as contract, validateAssessmentCoverage } from "../skills/assessment-review/responsibility.mjs";
import { createOnboardingService } from "./onboarding-service.mjs";
import { createHttpError } from "./http-error-contract.mjs";

const blocked = () => createHttpError(409, "assessment_responsibility_blocked",
  "Assessment review is blocked. Refresh and confirm all six Pipeline definitions, then bind the responsibility again.");
const hash = value => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const authFor = userId => ({ authenticated: true, mode: "entra-delegated", claims: { tid: EVERYAGENT_TENANT, oid: userId } });

export function createAssessmentReviewResponsibility({ onboarding = createOnboardingService(), now = () => Date.now() } = {}) {
  async function current(userId, workspaceId) {
    const response = await onboarding.read(authFor(userId), workspaceId);
    const workspace = response.workspace;
    if (!workspace || workspace.readiness.definitions !== "reviewed") throw blocked();
    const source = workspace.sources.find(item => item.id === PIPELINE_ONBOARDING_SOURCE && item.provenance === "observed_contract");
    if (!source?.discovery) throw blocked();
    const concepts = workspace.concepts.filter(item => item.originSourceId === source.id && !item.retired);
    if (concepts.length !== contract.requiredLocators.length || contract.requiredLocators.some(locator =>
      !concepts.some(item => item.status === "confirmed" && item.mappings.length === 1 && item.mappings[0]?.locator === locator))) throw blocked();
    const grant = source.discovery.grant;
    const basis = { contractId: contract.id, contractVersion: contract.version, skillVersion: contract.skillVersion,
      workspaceId, sourceId: source.id, manifestRevision: source.sourceVersion,
      questionnaireRulesVersion: source.discovery.manifest.questionnaireRulesVersion,
      sourceAccess: { application: grant.application, id: grant.id, revision: grant.revision },
      definitionsDigest: hash(concepts.map(item => ({ id: item.id, revision: item.revision, mappings: item.mappings, review: item.review })).sort((a, b) => a.id.localeCompare(b.id))) };
    return { ...basis, fingerprint: hash(basis), workspaceRevision: workspace.revision };
  }
  async function bind(userId, workspaceId, expectedRevision) {
    const binding = await current(userId, workspaceId);
    if (binding.workspaceRevision !== expectedRevision) throw blocked();
    return binding;
  }
  async function authorize(assignment) {
    if (assignment.skillId !== "assessment-review") return;
    const binding = assignment.responsibility;
    if (!binding || typeof binding.workspaceId !== "string") throw blocked();
    try {
      const latest = await current(assignment.userId, binding.workspaceId);
      // A metadata refresh with unchanged meanings preserves the binding.
      const { workspaceRevision: _old, ...saved } = binding;
      const { workspaceRevision: _new, ...expected } = latest;
      if (JSON.stringify(saved) !== JSON.stringify(expected)) throw blocked();
    } catch { throw blocked(); }
  }
  function complete(assignment, result, startedAt) {
    if (assignment.skillId !== "assessment-review") return null;
    if (result.connection !== "connected" || result.issue !== null || !assignment.responsibility || !result.sourceGrant ||
        Date.parse(result.sourceGrant.expiresAt) <= now() || ["application", "id", "revision"].some(key =>
          assignment.responsibility.sourceAccess[key] !== result.sourceGrant[key])) throw blocked();
    const coverage = validateAssessmentCoverage(result.coverage, result.entries, result.sourceCheckedAt);
    if (Date.parse(coverage.finishedAt) > now() + 5000 || Date.parse(coverage.startedAt) < Date.parse(startedAt) - 5000 ||
        coverage.rulesVersions.some(version => version !== assignment.responsibility.questionnaireRulesVersion)) throw blocked();
    return { contractId: contract.id, contractVersion: contract.version, outcome: "review_completed",
      binding: assignment.responsibility, sourceGrant: result.sourceGrant, coverage,
      checks: contract.completionChecks.map(id => ({ id, status: "passed" })), completedAt: new Date(now()).toISOString(),
      limitation: contract.limitation };
  }
  return { bind, authorize, complete, contract };
}
