import { PROFORMA_MAINTENANCE_PATH, validateMaintenanceSession } from '../shared/proforma-maintenance-contracts.mjs';

// Shared delegated transport for ProForma source contracts; bindings never grant access.
export function createProFormaSourceTransport({ binding, getToken, fetchImpl = fetch, now = Date.now }) {
  const origin = new URL(binding.origin);
  if (typeof getToken !== 'function') throw new Error('A delegated ProForma token provider is required.');
  /** @param {string} token @param {string} suffix @param {Record<string, any> | null} [command] */
  async function request(token, suffix, command = null) {
    const response = await fetchImpl(new URL(PROFORMA_MAINTENANCE_PATH + suffix, origin), {
      method: command ? 'POST' : 'GET', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(12000),
      headers: { Authorization: `Bearer ${token}`, ...(command ? { 'Content-Type': 'application/json' } : {}) }, ...(command ? { body: JSON.stringify(command) } : {}),
    });
    try {
      const limit = suffix.includes('/commands') || suffix === '/session' ? 16000 : 524288;
      if (!/^application\/json\b/i.test(response.headers.get('content-type') ?? '') || Number(response.headers.get('content-length')) > limit) throw new Error('Invalid ProForma response.');
      const chunks = []; let size = 0;
      for await (const bytes of response.body ?? []) { size += bytes.length; if (size > limit) throw new Error('ProForma response exceeded its limit.'); chunks.push(Buffer.from(bytes)); }
      const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (!response.ok) throw Object.assign(new Error('ProForma request was not accepted.'), { status: response.status, code: typeof data.error?.code === 'string' ? data.error.code : 'source_unavailable' });
      return data;
    } finally { await response.body?.cancel().catch(() => {}); }
  }
  async function authorized(permission) {
    const value = await getToken();
    if (!value || typeof value.token !== 'string' || !value.token || value.token.length > 16000 || !Number.isFinite(value.expiresOnTimestamp) || value.expiresOnTimestamp <= now()) throw new Error('ProForma sign-in is unavailable.');
    validateMaintenanceSession(await request(value.token, '/session'), binding, permission);
    if (value.expiresOnTimestamp <= now()) throw new Error('ProForma sign-in expired.');
    return value.token;
  }
  return { request, authorized };
}
