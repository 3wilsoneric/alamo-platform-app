import { maintenanceObject as object, maintenanceText as text, maintenanceHash as hash, validateMaintenanceBinding, maintenanceAssessment } from '../shared/proforma-maintenance-contracts.mjs';
import { MAINTENANCE_SYSTEM, maintenanceOutputSchema, MAINTENANCE_PROMPT_VERSION, maintenancePolicyVersion, prepareMaintenanceInput, resolveMaintenanceDecision } from '../skills/proforma-maintenance/assess.mjs';

const modelName=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value))throw new Error('Choose a configured maintenance model.');return value;};
const unavailable=()=>new Error('Maintenance assessment is unavailable; no decision was accepted.');
function usage(input){
  if(input===null)return null;
  object(input,['inputTokens','outputTokens']);
  if(![input.inputTokens,input.outputTokens].every(n=>Number.isSafeInteger(n)&&n>=0&&n<=1000000))throw unavailable();
  return {...input};
}
/** One bounded formatting call. The named tool returns data only; it cannot run actions. */
export function createProFormaMaintenanceModel({apiKey=process.env.ANTHROPIC_API_KEY,model=process.env.ALAMOAGENT_PROFORMA_MAINTENANCE_MODEL||process.env.ANTHROPIC_MODEL||'claude-sonnet-4-6',fetchImpl=fetch}={}){
  const requestedModel=modelName(model),policyVersion=maintenancePolicyVersion(requestedModel);
  return {available:Boolean(apiKey),model:requestedModel,policyVersion,
    /** @param {any} input @param {{signal?: AbortSignal}} options */
    async assess(input,{signal}={}){
      if(!apiKey)throw new Error('Maintenance model is not configured.');
      if(input.policyVersion!==policyVersion)throw new Error('Maintenance model policy changed; review its binding.');
      const prepared=prepareMaintenanceInput(input);let response;
      try{
        response=await fetchImpl('https://api.anthropic.com/v1/messages',{method:'POST',redirect:'error',signal:signal?AbortSignal.any([signal,AbortSignal.timeout(30000)]):AbortSignal.timeout(30000),
          headers:{'Content-Type':'application/json','x-api-key':apiKey,'anthropic-version':'2023-06-01'},
          body:JSON.stringify({model:requestedModel,max_tokens:3000,system:MAINTENANCE_SYSTEM,messages:[{role:'user',content:JSON.stringify(prepared)}],
            tools:[{name:'assess_maintenance',description:'Return a cited revision proposal or no-change decision for human process guidance. Does not execute work.',strict:true,input_schema:maintenanceOutputSchema(prepared)}],tool_choice:{type:'tool',name:'assess_maintenance',disable_parallel_tool_use:true}})});
        if(!response.ok||!response.headers.get('content-type')?.includes('application/json')||Number(response.headers.get('content-length'))>64000)throw unavailable();
        const reader=response.body?.getReader();if(!reader)throw unavailable();let size=0;const chunks=[];
        try{for(;;){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>64000){await reader.cancel();throw unavailable();}chunks.push(Buffer.from(part.value));}}finally{reader.releaseLock();}
        const payload=JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if(payload.stop_reason!=='tool_use'||payload.content?.length!==1||payload.content[0]?.type!=='tool_use'||payload.content[0]?.name!=='assess_maintenance')throw unavailable();
        const counts=[payload.usage?.input_tokens,payload.usage?.output_tokens];
        return {decision:resolveMaintenanceDecision(payload.content[0].input,input,prepared),requestedModel,responseModel:modelName(payload.model),policyVersion,inputHash:hash(prepared),promptVersion:MAINTENANCE_PROMPT_VERSION,
          usage:counts.every(n=>Number.isSafeInteger(n)&&n>=0&&n<=1000000)?usage({inputTokens:counts[0],outputTokens:counts[1]}):null};
      }catch{throw unavailable();}finally{await response?.body?.cancel().catch(()=>{});}
    },
  };
}
/** An assessor callback for the existing durable consumer. Evidence/provenance must
 * be recorded before the consumer can persist a proposal. Recording is host-owned. */
export function createProFormaMaintenanceAssessor({binding:input,model=createProFormaMaintenanceModel(),record}){
  const binding=validateMaintenanceBinding(input),requestedModel=modelName(model.model),policyVersion=maintenancePolicyVersion(requestedModel);
  if(typeof record!=='function'||typeof model.assess!=='function')throw new Error('Maintenance requires a model and durable assessment evidence sink.');
  if(binding.policyVersion!==policyVersion||model.policyVersion!==policyVersion)throw new Error('Maintenance model policy changed; review its binding.');
  return async assessmentInput=>{
    if(assessmentInput.purpose!==binding.purpose||assessmentInput.policyVersion!==policyVersion||!binding.processIds.includes(assessmentInput.context?.source?.processId))throw new Error('Assessment is outside this responsibility.');
    const prepared=prepareMaintenanceInput(assessmentInput),inputHash=hash(prepared);
    const trace={schemaVersion:1,kind:'proforma.maintenance-assessment',responsibilityId:binding.id,bindingHash:hash(binding),processId:prepared.source.processId,sourceVersion:prepared.source.version,signalId:prepared.observation.id,inputHash,policyVersion,promptVersion:MAINTENANCE_PROMPT_VERSION,requestedModel};
    let result;
    try{
      result=await model.assess(assessmentInput);object(result,['decision','requestedModel','responseModel','policyVersion','inputHash','promptVersion','usage']);
      if(result.requestedModel!==requestedModel||result.policyVersion!==policyVersion||result.inputHash!==inputHash||result.promptVersion!==MAINTENANCE_PROMPT_VERSION)throw unavailable();
      modelName(result.responseModel);usage(result.usage);text(result.decision?.reason);
      maintenanceAssessment(assessmentInput.context,assessmentInput.change,result.decision);
    }catch{
      await record({...trace,status:'failed',decisionHash:null,responseModel:null,usage:null});throw unavailable();
    }
    await record({...trace,status:'validated',decisionHash:hash(result.decision),responseModel:result.responseModel,usage:result.usage});
    return structuredClone(result.decision);
  };
}
