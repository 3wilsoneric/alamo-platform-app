import path from "node:path";
import { createEveryAgentPersistence } from "./everyagent-persistence.mjs";
import { validateDraftReviewState, draftReviewUnavailable, draftReviewHash } from "../shared/draft-review-contracts.mjs";

// Internal repository, not a user-facing read API. Services must reauthorize
// every operation. A separate collection leaves existing execution state intact.
export function createDraftReviewStore(persistence = createEveryAgentPersistence({
  localPath: path.resolve("generated/everyagent/draft-reviews-v1.json"), blobPath: "everyagent/draft-reviews-v1.json"
})) {
  async function read() {
    const snapshot = await persistence.read();
    return { value: validateDraftReviewState(snapshot.value ?? { version: 1, revision: 0, records: [] }), version: snapshot.version };
  }
  /** @param {(state: ReturnType<typeof validateDraftReviewState>) => Promise<boolean>} mutate */
  async function update(mutate) {
    for (let attempt = 0; attempt < 6; attempt++) {
      const { value, version } = await read();
      const before = structuredClone(value);
      if (!await mutate(value)) {
        if (JSON.stringify(before) !== JSON.stringify(value)) return draftReviewUnavailable();
        return value;
      }
      if (value.revision !== before.revision) return draftReviewUnavailable();
      value.revision++;
      const validated = validateDraftReviewState(value);
      for (const prior of before.records) {
        const next = validated.records.find(record => record.id === prior.id);
        if (!next || next.artifactRevision !== prior.artifactRevision ||
          (prior.review !== null && draftReviewHash(prior.review) !== draftReviewHash(next.review))) return draftReviewUnavailable();
      }
      try { await persistence.write(validated, version); return validated; }
      catch (error) {
        if (!error || typeof error !== "object" || !("code" in error) || error.code !== "EVERYAGENT_CONFLICT" || attempt === 5) throw error;
        await new Promise(resolve => setTimeout(resolve, 20 * (attempt + 1)));
      }
    }
    return draftReviewUnavailable();
  }
  return { read, update };
}
