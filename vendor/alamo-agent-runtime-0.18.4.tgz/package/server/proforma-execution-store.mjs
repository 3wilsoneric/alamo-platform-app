import {maintenanceHash as hash,maintenanceObject as object,maintenanceId as id,maintenanceDigest as digest,maintenanceInteger as integer} from '../shared/proforma-maintenance-contracts.mjs';
import {validateExecutionCandidate,validateExecutionDefinition} from '../shared/proforma-execution-contracts.mjs';
import {setTimeout as delay} from 'node:timers/promises';

const invalid=()=>{throw new Error('Execution configuration state is unavailable.');};
function validate(value){
  const v=object(value,['schemaVersion','revision','records']);if(v.schemaVersion!==1||!Array.isArray(v.records)||v.records.length>50||Buffer.byteLength(JSON.stringify(v))>8000000)invalid();integer(v.revision);
  const ids=new Set(),requests=new Set();let events=0;
  for(const r of v.records){
    object(r,['id','actorId','events']);id(r.id);if(ids.has(r.id)||!Array.isArray(r.events)||!r.events.length||r.events.length>100)invalid();ids.add(r.id);
    for(const [index,e] of r.events.entries()){
      object(e,['revision','requestId','commandHash','clientId','actorId','at','candidate','candidateHash','status','enabled','review']);
      id(e.requestId);id(e.clientId);digest(e.commandHash);digest(e.candidateHash);validateExecutionCandidate(e.candidate);
      if(e.revision!==index+1||e.actorId!==r.actorId||e.candidate.sourceBinding.actorId!==r.actorId||e.candidate.id!==r.id||e.candidateHash!==hash(e.candidate)||!['pending','approved','rejected'].includes(e.status)||typeof e.enabled!=='boolean'||e.enabled&&e.status!=='approved'||typeof e.at!=='string'||new Date(e.at).toISOString()!==e.at)invalid();
      if(e.status==='approved')validateExecutionDefinition({...e.candidate,enabled:e.enabled,review:e.review});else if(e.review!==null)invalid();
      const key=`${r.actorId}:${e.requestId}`;if(requests.has(key))invalid();requests.add(key);
    }
    events+=r.events.length;
  }
  if(events>1000)invalid();return v;
}
// Configuration history is retained separately from run/checkpoint state. No
// default store, eviction or source grants: the host chooses its own persistence.
export function createProFormaExecutionStore(persistence){
  async function read(){const snapshot=await persistence.read();return {...snapshot,value:validate(snapshot.value??{schemaVersion:1,revision:0,records:[]})};}
  async function update(mutate){
    for(let attempt=0;attempt<6;attempt++){
      const snapshot=await read(),value=structuredClone(snapshot.value);if(!await mutate(value)){if(hash(value)!==hash(snapshot.value))invalid();return value;}
      if(value.revision!==snapshot.value.revision)invalid();value.revision++;validate(value);
      for(const previous of snapshot.value.records){const next=value.records.find(r=>r.id===previous.id);if(!next||next.actorId!==previous.actorId||next.events.length<previous.events.length||previous.events.some((e,i)=>hash(e)!==hash(next.events[i])))invalid();}
      try{await persistence.write(value,snapshot.version);return value;}catch(error){if(!error||typeof error!=='object'||!('code' in error)||error.code!=='EVERYAGENT_CONFLICT'||attempt===5)throw error;await delay(10*(attempt+1));}
    }
    return invalid();
  }
  return {read,update};
}
