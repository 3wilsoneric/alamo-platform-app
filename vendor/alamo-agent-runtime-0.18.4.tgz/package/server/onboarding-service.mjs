import { ONBOARDING_LIMITS, onboardingId, validateOnboardingCommand } from "../shared/onboarding-contracts.mjs";
import { everyAgentActor } from "./everyagent-access.mjs";
import { createHttpError } from "./http-error-contract.mjs";
import { createOnboardingStore } from "./onboarding-store.mjs";
import { applyOnboardingEvent, onboardingCapacity, onboardingView, projectOnboardingWorkspace } from "./onboarding-workspace.mjs";
import { sameDiscoveryAccess, validateDiscoveryEvidence } from "./onboarding-discovery.mjs";

const hidden = () => createHttpError(404, "not_found", "Not found.");
function scope(auth) {
  const ownerId = everyAgentActor(auth);
  return { tenantId: String(auth.claims.tid).toLowerCase(), ownerId };
}
const owns = (record, owner) => record.tenantId === owner.tenantId && record.ownerId === owner.ownerId;
const hasDiscovery = record => record.events.some(event => event.discovery);
const unavailable = () => new Error("Onboarding source access could not be verified.");

export function createOnboardingService({ store = createOnboardingStore(), now = () => Date.now(),
  source = /** @type {{describe: (assignment: any) => Promise<ReturnType<typeof validateDiscoveryEvidence>>} | null} */ (null) } = {}) {
  async function observe(owner) {
    if (!source) throw unavailable();
    const started = now();
    const observation = validateDiscoveryEvidence(await source.describe({ userId: owner.ownerId, skillId: "assessment-review", communityIds: [] }));
    if (Date.parse(observation.grant.expiresAt) <= now() || Date.parse(observation.observedAt) < started - 5000 ||
        Date.parse(observation.observedAt) > now() + 5000) throw unavailable();
    return observation;
  }
  function inspect(record, observation) {
    // Retained history is protected too. A new grant cannot unlock old exports.
    for (const event of record.events) if (event.discovery && (!observation || !sameDiscoveryAccess(event.discovery, observation))) throw unavailable();
    const workspace = projectOnboardingWorkspace(record);
    const stale = workspace.sources.filter(item => item.discovery && item.sourceVersion !== observation?.manifest.revision).map(item => item.id);
    return { workspace, stale };
  }
  async function read(auth, id = /** @type {string | null} */ (null), format = "view") {
    const owner = scope(auth);
    if ((id !== null && !onboardingId(id)) || !["view", "export"].includes(format) || (format === "export" && !id)) {
      throw createHttpError(400, "onboarding_query_invalid", "Choose a valid onboarding workspace.");
    }
    const records = (await store.read()).value.workspaces.filter(record => owns(record, owner));
    const selected = id === null ? records : records.filter(record => record.id === id);
    if (id !== null && !selected.length) throw hidden();
    // One fresh observation per request, never an authorization cache across requests.
    const observation = selected.some(hasDiscovery) ? await observe(owner) : null;
    if (id === null) return { workspaces: records.map(record => {
      const { workspace, stale } = inspect(record, observation);
      const value = onboardingView(workspace, stale);
      return { id: value.id, companyName: value.companyName, outcome: value.outcome, revision: value.revision, readiness: value.readiness };
    }) };
    const record = records.find(item => item.id === id);
    if (!record) throw hidden();
    const projection = inspect(record, observation);
    const workspace = onboardingView(projection.workspace, projection.stale);
    return format === "export" ? { schema: "alamoagent.onboarding.v1", exportedAt: new Date(now()).toISOString(),
      tenantId: record.tenantId, ownerId: record.ownerId, workspace, history: record.events } : { workspace };
  }
  async function command(auth, input) {
    const owner = scope(auth);
    let command;
    try {
      command = validateOnboardingCommand(input);
      if (Buffer.byteLength(JSON.stringify(input)) > ONBOARDING_LIMITS.commandBytes) throw new Error("Command limit.");
    } catch { throw createHttpError(400, "onboarding_command_invalid", "Use a valid onboarding command with bounded metadata fields."); }
    const id = command.action === "create" ? command.requestId : command.workspaceId;
    const at = new Date(now()).toISOString();
    let replayed = false;
    let appliedRevision = 0;
    const state = await store.update(async state => {
      replayed = false;
      const records = state.workspaces.filter(record => owns(record, owner));
      const prior = records.flatMap(record => record.events).find(event => event.requestId === command.requestId);
      if (prior) {
        if (JSON.stringify(prior.command) !== JSON.stringify(command)) throw createHttpError(409, "onboarding_request_conflict", "This request ID was already used for different work.");
        const record = records.find(item => item.id === id);
        if (!record) throw hidden();
        inspect(record, hasDiscovery(record) ? await observe(owner) : null);
        replayed = true; appliedRevision = prior.revision; return false;
      }
      let record = records.find(item => item.id === id);
      if (command.action === "create") {
        if (state.workspaces.length >= ONBOARDING_LIMITS.workspaces) throw onboardingCapacity();
        record = { id, ...owner, events: [] }; state.workspaces.push(record);
      }
      if (!record) throw hidden();
      if (record.events.length >= ONBOARDING_LIMITS.events) throw onboardingCapacity();
      if (command.action !== "create" && command.expectedRevision !== record.events.length) {
        throw createHttpError(409, "onboarding_revision_conflict", "This workspace changed. Refresh before editing or reviewing.");
      }
      const observation = hasDiscovery(record) || command.action === "discover_pipeline" ? await observe(owner) : null;
      const stale = record.events.length ? inspect(record, observation).stale : [];
      const workspace = record.events.length ? projectOnboardingWorkspace(record) :
        { id, companyName: "", outcome: "", successCriterion: "", revision: 0, sources: [], concepts: [] };
      if (command.action === "review_concept" && command.decision === "confirmed" &&
          workspace.concepts.find(item => item.id === command.conceptId)?.mappings.some(mapping => stale.includes(mapping.sourceId))) {
        throw createHttpError(409, "onboarding_source_changed", "Pipeline's definitions changed. Refresh discovery before confirming.");
      }
      const event = { requestId: command.requestId, revision: workspace.revision + 1, actorId: owner.ownerId, at, command,
        ...(command.action === "discover_pipeline" && observation ? { discovery: observation } : {}) };
      applyOnboardingEvent(workspace, event);
      record.events.push(event); appliedRevision = event.revision;
      return true;
    });
    const record = state.workspaces.find(item => item.id === id && owns(item, owner));
    if (!record) throw hidden();
    // Recheck after persistence as well: a revoked result stays private even if a write completed.
    const projection = inspect(record, hasDiscovery(record) ? await observe(owner) : null);
    return { workspace: onboardingView(projection.workspace, projection.stale), receipt: { requestId: command.requestId, appliedRevision, replayed } };
  }
  return { read, command };
}
