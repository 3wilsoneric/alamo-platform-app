import { ASSESSOR_SANDBOX_PATH } from "../shared/assessor-sandbox.mjs";
import { conversationId } from "../shared/everyagent-conversations.mjs";
import { createHttpError } from "./http-error-contract.mjs";
import { readJsonRequestBody } from "./http-body.mjs";

export async function handleAssessorSandboxHttp(req, res, auth, sandbox) {
  const url = new URL(req.url, "https://agent.invalid");
  if (!sandbox || url.pathname !== ASSESSOR_SANDBOX_PATH) throw createHttpError(404, "not_found", "Not found.");
  if (req.method === "GET") {
    const id = url.searchParams.get("id");
    if ([...url.searchParams.keys()].some(k => k !== "id") || url.searchParams.getAll("id").length > 1 || (id !== null && !conversationId(id))) throw createHttpError(400, "sandbox_query_invalid", "Choose a valid sandbox chat.");
    res.status(200).json(await sandbox.read(auth, id)); return;
  }
  if (req.method === "POST" && !url.search) { res.status(200).json(await sandbox.command(auth, await readJsonRequestBody(req, 8192))); return; }
  res.setHeader("Allow", "GET, POST"); throw createHttpError(405, "method_not_allowed", "Method not allowed.");
}
