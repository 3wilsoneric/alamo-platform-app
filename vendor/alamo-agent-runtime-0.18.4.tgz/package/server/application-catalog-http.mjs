import { createHttpError } from "./http-error-contract.mjs";
import { AGENT_CATALOG_PATH } from "../shared/application-catalog.mjs";

export async function handleApplicationCatalogHttp(req, res, auth, service) {
  const url = new URL(req.url, "https://agent.invalid");
  if (url.pathname !== AGENT_CATALOG_PATH || !service) throw createHttpError(404, "not_found", "Not found.");
  if (url.search) throw createHttpError(400, "catalog_query_invalid", "The catalog uses your current identity and assigned scope.");
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    throw createHttpError(405, "method_not_allowed", "Method not allowed.");
  }
  res.status(200).json(await service.read(auth));
}
