import { draftReviewHash, draftReviewId } from "../shared/draft-review-contracts.mjs";
import { validateWorkContextRequest, verifyWorkContext } from "../shared/work-context-contracts.mjs";
import { validateAssessmentQualityPacket } from "../skills/assessment-review/quality.mjs";
import { ASSESSOR_CONTEXT_TEACHING, ASSESSOR_CONTEXT_PROCEDURES } from "../skills/assessment-review/work-context.mjs";
import { createDraftReviewService } from "./draft-review-service.mjs";
import { readAssessmentQualityDraft, assessmentQualityPacketRevision } from "./assessment-quality-review.mjs";

export const ASSESSOR_FOLLOW_THROUGH_POLICY = Object.freeze({ version: 1,
  stages: ["clarification", "handoff"], parentReview: "accepted_current_quality_draft",
  clarification: "source_update_and_new_quality_review_required",
  handoff: "all_projected_answers_supported_no_open_quality_questions",
  sourceWork: "unconfirmed", delivery: "not_performed", receivingOwner: "unknown" });
const policyRevision = draftReviewHash({ policy: ASSESSOR_FOLLOW_THROUGH_POLICY,
  teaching: ASSESSOR_CONTEXT_TEACHING, procedures: ASSESSOR_CONTEXT_PROCEDURES });
const contextRevision = ({ quality, packet }) => draftReviewHash({ packet: assessmentQualityPacketRevision(packet),
  parentId: quality.id, artifactRevision: quality.artifactRevision, humanReview: quality.humanReview });
const unavailable = () => new Error("Assessor follow-through is unavailable. Refresh the assessment review.");
const blockedMessages = Object.freeze({
  quality_review_required: "Review the current quality draft before preparing the next stage.",
  quality_review_rejected: "The quality draft was rejected. Prepare and review a new proposal.",
  clarification_required: "Resolve the open answer questions in Pipeline, then refresh and review the new source version.",
  no_clarification_needed: "The reviewed answers have no open quality questions. A clarification checklist is not needed.",
});
function blocked(reason) {
  if (!Object.hasOwn(blockedMessages, reason)) throw unavailable();
  return Object.assign(new Error(`Assessor follow-through blocked: ${blockedMessages[reason]}`), { code: "ASSESSOR_FOLLOW_THROUGH_BLOCKED", reason });
}

function stageId(stage) {
  if (stage !== "clarification" && stage !== "handoff") throw unavailable();
  return `assessor-${stage}`;
}

// Reconstructed from a current accepted quality artifact, never from a submitted
// checklist/summary. These activities do not send, edit, assign or sign anything.
function draft(stage, { quality, packet }) {
  const { context } = packet;
  const questions = quality.draft.reviews.filter(r => r.assessment !== "supported");
  const common = { schemaVersion: 1, policyVersion: ASSESSOR_FOLLOW_THROUGH_POLICY.version, stage, mode: "synthetic-only",
    authority: "read_investigate_draft", sourceWork: "unconfirmed", delivery: "not_performed", clinicalQuality: "not_evaluated",
    scope: context.snapshot.scope, source: context.snapshot.source, assignment: context.assignment,
    qualityReference: { id: quality.id, artifactRevision: quality.artifactRevision,
      reviewRequestId: quality.humanReview.requestId, reviewedAt: quality.humanReview.reviewedAt },
    teachingSource: structuredClone(ASSESSOR_CONTEXT_TEACHING), evidence: context.evidence, nextActions: context.nextActions };
  if (stage === "clarification") {
    if (!questions.length) throw blocked("no_clarification_needed");
    return { ...common, procedure: structuredClone(ASSESSOR_CONTEXT_PROCEDURES[0]),
      items: questions.map(review => {
        const answer = context.content.find(c => c.id === review.contentId);
        if (!answer || !review.question) throw unavailable();
        return { contentId: answer.id, label: answer.label, currentAnswer: { text: answer.text, status: answer.status, evidenceIds: answer.evidenceIds },
          question: review.question, findings: review.findings, proposedWording: review.wording,
          proposedReviewerId: context.assignment.ownerId, resolution: "source_update_required" };
      }),
      sourceUpdate: "not_performed", nextStep: "Verify and record the clarification in Pipeline, then refresh and review the updated answers." };
  }
  if (questions.length || quality.draft.handoff.openQuestions.length) throw blocked("clarification_required");
  return { ...common, procedure: structuredClone(ASSESSOR_CONTEXT_PROCEDURES[2]),
    summary: quality.draft.handoff.summary,
    reviewedAnswers: context.content.map(answer => {
      const review = quality.draft.reviews.find(r => r.contentId === answer.id);
      if (!review || review.assessment !== "supported" || answer.status !== "recorded") throw unavailable();
      return { contentId: answer.id, label: answer.label, quote: answer.text, evidenceIds: answer.evidenceIds,
        support: review.support, quality: "human_reviewed_model_proposal" };
    }),
    pending: context.requirements.filter(r => r.status !== "met"), missingContext: context.missing,
    preparingOwnerId: context.assignment.ownerId, receivingOwnerId: null, receivingAcknowledgment: "unknown",
    readiness: "human_source_verification_required", nextStep: "Verify the remaining requirements and receiving owner in Pipeline before a human sends the handoff." };
}

function project(record, stage) {
  const state = record.review === null ? `awaiting_${stage}_review` : record.review.decision === "reject" ? `${stage}_rejected`
    : stage === "clarification" ? "awaiting_source_clarification" : "handoff_draft_reviewed";
  return { id: record.id, artifactRevision: record.artifactRevision, contextRevision: record.contextRevision,
    stage, state, status: record.status, humanReview: record.review, sourceWork: "unconfirmed", draft: record.payload };
}

// One activity composition bound to one quality draft. A source revision requires
// a new quality draft and a new composition. No user response can mark a source
// question resolved; only fresh evidence plus a fresh review permits the handoff.
// readPacket must be bound to authenticated source authority by the host.
export function createAssessorFollowThrough({ qualityDraftId, ...deps }) {
  draftReviewId(qualityDraftId);
  async function readContext(input) {
    const request = validateWorkContextRequest(input);
    const quality = await readAssessmentQualityDraft(qualityDraftId, request, deps);
    if (quality.status !== "draft_reviewed" || quality.humanReview?.decision !== "accept") {
      throw blocked(quality.humanReview?.decision === "reject" ? "quality_review_rejected" : "quality_review_required");
    }
    const packet = validateAssessmentQualityPacket(await deps.readPacket(structuredClone(request)));
    verifyWorkContext(packet.context, request, deps.now());
    if (quality.contextRevision !== assessmentQualityPacketRevision(packet)) throw unavailable();
    return { quality, packet };
  }
  function service(stage) {
    return createDraftReviewService({ store: deps.store, skillId: stageId(stage), policyRevision, now: deps.now,
      readContext, contextRevision, validatePayload: (payload, context) => {
        const expected = draft(stage, context);
        if (draftReviewHash(payload) !== draftReviewHash(expected)) throw unavailable();
        return expected;
      } });
  }
  const protect = operation => async (...args) => {
    try { return await operation(...args); }
    catch (error) {
      if (error && typeof error === "object" && "code" in error && error.code === "DRAFT_REVIEW_CONFLICT") throw error;
      if (error && typeof error === "object" && "code" in error && error.code === "ASSESSOR_FOLLOW_THROUGH_BLOCKED" && "reason" in error) throw blocked(error.reason);
      throw unavailable();
    }
  };
  return {
    prepare: protect(async (stage, input) => {
      stageId(stage);
      const request = validateWorkContextRequest(input), context = await readContext(request);
      return project(await service(stage).save(request, draft(stage, context), contextRevision(context)), stage);
    }),
    read: protect(async (stage, id, request) => project(await service(stage).read(id, request), stage)),
    review: protect(async (stage, id, request, command) => project(await service(stage).review(id, request, command), stage)),
  };
}
