import { ManagedIdentityCredential } from '@azure/identity';
import { createExecutiveReportService } from './executive-report-service.mjs';
import { createExecutiveReportStore } from './executive-report-store.mjs';
import { createExecutiveReportSource } from './executive-report-source.mjs';
import { createExecutiveReportModel } from './executive-report-model.mjs';
import { reportObject, reportSubject } from '../shared/executive-report-contracts.mjs';

// Deployment configuration is the only registry. It grants no source access;
// Platform's independent grant registry still authorizes every subject and read.
export function createExecutiveReportRuntime({ env = process.env, credentialFor = id => new ManagedIdentityCredential(id), store = null, fetchImpl = fetch, execution = false } = {}) {
  if (typeof execution !== 'boolean') throw new Error('Choose an explicit report host mode.');
  if (!env.ALAMOAGENT_EXECUTIVE_REPORTS_JSON) return null;
  let config;
  try {
    config = reportObject(JSON.parse(env.ALAMOAGENT_EXECUTIVE_REPORTS_JSON), ['subjects', 'origin', 'sourceScope', 'clientId']);
    if (!Array.isArray(config.subjects) || !config.subjects.length || config.subjects.length > 10 || new Set(config.subjects).size !== config.subjects.length) throw Error();
    config.subjects.forEach(reportSubject); reportSubject(config.clientId);
    if (!/^api:\/\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/\.default$/.test(config.sourceScope)) throw Error();
    const origin = new URL(config.origin); if (origin.protocol !== 'https:' || origin.origin !== config.origin) throw Error();
  } catch { throw new Error('Configure a valid executive report connection.'); }
  const credential = credentialFor(config.clientId);
  const source = createExecutiveReportSource({ origin: config.origin, fetchImpl,
    getToken: () => credential.getToken(config.sourceScope, { abortSignal: AbortSignal.timeout(8000) }) });
  // The web API queues and reads reports; only the worker needs a provider key.
  const model = execution ? createExecutiveReportModel({ apiKey: env.OPENAI_API_KEY, projectId: env.OPENAI_PROJECT_ID,
    model: env.ALLY_MODEL, verifiedUntil: env.ALLY_CONNECTION_VERIFIED_UNTIL, fetchImpl }) : null;
  const service = createExecutiveReportService({ store: store ?? createExecutiveReportStore(), source, model, allowedSubjects: config.subjects });
  return execution ? service : { create: service.create, get: service.get, list: service.list, command: service.command };
}
