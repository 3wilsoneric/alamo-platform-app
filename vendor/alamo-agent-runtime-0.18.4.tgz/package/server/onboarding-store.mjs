import path from "node:path";
import { ONBOARDING_LIMITS } from "../shared/onboarding-contracts.mjs";
import { createEveryAgentPersistence } from "./everyagent-persistence.mjs";
import { onboardingCapacity, projectOnboardingWorkspace } from "./onboarding-workspace.mjs";

/** @typedef {{version: 1, revision: number, workspaces: import('./onboarding-workspace.mjs').WorkspaceRecord[]}} OnboardingState */
/** @param {OnboardingState} value */
function validate(value) {
  if (!value || Object.keys(value).sort().join() !== "revision,version,workspaces" || value.version !== 1 ||
      !Number.isSafeInteger(value.revision) || value.revision < 0 || !Array.isArray(value.workspaces) ||
      value.workspaces.length > ONBOARDING_LIMITS.workspaces || Buffer.byteLength(JSON.stringify(value)) > ONBOARDING_LIMITS.stateBytes) throw new Error("Onboarding state is unavailable.");
  const identities = new Set();
  const requests = new Set();
  for (const record of value.workspaces) {
    projectOnboardingWorkspace(record);
    const identity = `${record.tenantId}/${record.ownerId}/${record.id}`;
    if (identities.has(identity)) throw new Error("Onboarding state is unavailable.");
    identities.add(identity);
    for (const event of record.events) {
      const request = `${record.tenantId}/${record.ownerId}/${event.requestId}`;
      if (requests.has(request)) throw new Error("Onboarding state is unavailable.");
      requests.add(request);
    }
  }
}

export function createOnboardingStore(persistence = createEveryAgentPersistence({
  localPath: path.resolve("generated/everyagent/onboarding-v1.json"), blobPath: "everyagent/onboarding-v1.json"
})) {
  async function read() {
    const snapshot = await persistence.read();
    /** @type {OnboardingState} */
    const value = snapshot.value ?? { version: 1, revision: 0, workspaces: [] };
    validate(value);
    return { value, version: snapshot.version };
  }
  /** @param {(state: OnboardingState) => boolean | Promise<boolean>} mutate */
  async function update(mutate) {
    for (let attempt = 0; attempt < 6; attempt++) {
      const { value, version } = await read();
      if (!await mutate(value)) return value;
      value.revision++;
      if (Buffer.byteLength(JSON.stringify(value)) > ONBOARDING_LIMITS.stateBytes) throw onboardingCapacity();
      validate(value);
      try { await persistence.write(value, version); return value; }
      catch (error) {
        if (!error || typeof error !== "object" || !("code" in error) || error.code !== "EVERYAGENT_CONFLICT" || attempt === 5) throw error;
        await new Promise(resolve => setTimeout(resolve, 20 * (attempt + 1)));
      }
    }
    throw new Error("Onboarding could not be saved.");
  }
  return { read, update };
}
