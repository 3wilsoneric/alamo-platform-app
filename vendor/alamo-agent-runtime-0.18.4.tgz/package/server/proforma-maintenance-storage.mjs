import path from 'node:path';
import {createEveryAgentPersistence} from './everyagent-persistence.mjs';
import {maintenancePartition,validateMaintenanceRunKey,validateMaintenanceTrace} from '../shared/proforma-maintenance-host.mjs';
import {maintenanceDigest as digest,maintenanceHash as hash,maintenanceObject as object} from '../shared/proforma-maintenance-contracts.mjs';
import {isProductionLikeRuntime} from './runtime-environment.mjs';

/** Per-binding partitions. Old runs and evidence remain in their own records;
 * nothing is deleted or migrated from the legacy single-responsibility store. */
export function createProFormaMaintenanceStorage(input,{azure=isProductionLikeRuntime(),localRoot=path.resolve('generated'),persistenceFor=createEveryAgentPersistence}={}){
  const key=validateMaintenanceRunKey(input),prefix=maintenancePartition(key);
  const store=name=>persistenceFor({azure,blobPath:`${prefix}/${name}.json`,localPath:path.join(localRoot,prefix,`${name}.json`)});
  return {checkpoint:store('checkpoint-v1'),schedule:store('schedule-v1'),run:store(`runs/${key.id}`),
    async record(trace,at=new Date().toISOString()){
      validateMaintenanceTrace(trace);
      if(trace.bindingHash!==key.bindingHash||trace.responsibilityId!==key.responsibilityId||!Number.isFinite(Date.parse(at)))throw new Error('Assessment evidence belongs to another responsibility.');
      const evidenceId=hash({runId:key.id,trace}),target=store(`evidence/${evidenceId}`),content={schemaVersion:1,revision:1,bindingHash:key.bindingHash,runId:key.id,trace:structuredClone(trace)};
      async function existing(){const current=(await target.read()).value;if(current){const {recordedAt,...saved}=current;if(!Number.isFinite(Date.parse(recordedAt))||hash(saved)!==hash(content))throw new Error('Stored maintenance evidence is inconsistent.');}return current;}
      if(!await existing())try{await target.write({...content,recordedAt:at},null);}catch(error){if(!error||typeof error!=='object'||!('code' in error)||error.code!=='EVERYAGENT_CONFLICT'||!await existing())throw error;}
      return evidenceId;
    },
    async evidence(id){digest(id);const value=object((await store(`evidence/${id}`).read()).value,['schemaVersion','revision','bindingHash','runId','trace','recordedAt']);validateMaintenanceTrace(value.trace);if(value.schemaVersion!==1||value.revision!==1||!Number.isFinite(Date.parse(value.recordedAt))||value.bindingHash!==key.bindingHash||value.runId!==key.id||value.trace.bindingHash!==key.bindingHash||value.trace.responsibilityId!==key.responsibilityId||hash({runId:value.runId,trace:value.trace})!==id)throw new Error('Maintenance evidence is unavailable.');return value;},
  };
}
