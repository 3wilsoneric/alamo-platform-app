import { foundationObject } from "../shared/foundation-contracts.mjs";
import { assessmentQualityInput, validateAssessmentQualityReview, ASSESSMENT_QUALITY_SYSTEM,
  ASSESSMENT_QUALITY_OUTPUT_SCHEMA, ASSESSMENT_QUALITY_PROMPT_VERSION } from "../skills/assessment-review/quality.mjs";

/** @returns {never} */
export function qualityUnavailable() { throw new Error("Assessment quality review is unavailable."); }
function modelName(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value)) return qualityUnavailable();
  return value;
}
function usage(value) {
  if (value === null) return null;
  const u = foundationObject(value, ["inputTokens", "outputTokens"]);
  if (![u.inputTokens, u.outputTokens].every(n => Number.isSafeInteger(n) && Number(n) >= 0 && Number(n) <= 1_000_000)) return qualityUnavailable();
  return { inputTokens: Number(u.inputTokens), outputTokens: Number(u.outputTokens) };
}
export function validateAssessmentQualityResult(value, packet) {
  const v = foundationObject(value, ["review", "requestedModel", "responseModel", "promptVersion", "usage"]);
  if (v.promptVersion !== ASSESSMENT_QUALITY_PROMPT_VERSION) return qualityUnavailable();
  return { review: validateAssessmentQualityReview(v.review, packet), requestedModel: modelName(v.requestedModel),
    responseModel: modelName(v.responseModel), promptVersion: ASSESSMENT_QUALITY_PROMPT_VERSION, usage: usage(v.usage) };
}

// Same provider as the existing conversation adapter; one bounded call, no
// retries, action tools, redirects, source fetches or automatic model fallback.
export function createAssessmentQualityModel({ apiKey = process.env.ANTHROPIC_API_KEY,
  model = process.env.ALAMOAGENT_ASSESSMENT_MODEL || process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6", fetchImpl = fetch } = {}) {
  const requestedModel = modelName(model);
  return {
    available: Boolean(apiKey), model: requestedModel, promptVersion: ASSESSMENT_QUALITY_PROMPT_VERSION,
    async review(packet) {
      if (!apiKey) throw new Error("Assessment quality model is not configured.");
      const input = assessmentQualityInput(packet);
      let response;
      try {
        response = await fetchImpl("https://api.anthropic.com/v1/messages", {
          method: "POST", redirect: "error", signal: AbortSignal.timeout(45_000),
          headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
          body: JSON.stringify({ model: requestedModel, max_tokens: 4000, system: ASSESSMENT_QUALITY_SYSTEM,
            messages: [{ role: "user", content: JSON.stringify(input) }],
            tools: [{ name: "review", description: "Format an assessment-quality proposal with cited findings, optional wording, questions and handoff. Does not execute any action.",
              input_schema: ASSESSMENT_QUALITY_OUTPUT_SCHEMA }],
            tool_choice: { type: "tool", name: "review", disable_parallel_tool_use: true } }),
        });
        if (!response.ok || Number(response.headers.get("content-length")) > 64_000) return qualityUnavailable();
        let size = 0;
        const chunks = [];
        for await (const bytes of response.body ?? []) {
          size += bytes.length;
          if (size > 64_000) return qualityUnavailable();
          chunks.push(Buffer.from(bytes));
        }
        const payload = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        if (payload.stop_reason !== "tool_use" || payload.content?.length !== 1 || payload.content[0]?.type !== "tool_use" || payload.content[0]?.name !== "review") return qualityUnavailable();
        const counts = [payload.usage?.input_tokens, payload.usage?.output_tokens];
        return validateAssessmentQualityResult({ review: payload.content[0].input, requestedModel, responseModel: payload.model,
          promptVersion: ASSESSMENT_QUALITY_PROMPT_VERSION,
          usage: counts.every(n => Number.isSafeInteger(n) && n >= 0 && n <= 1_000_000) ? { inputTokens: counts[0], outputTokens: counts[1] } : null }, packet);
      } catch { return qualityUnavailable(); } // Never expose provider bodies or credentials.
      finally { await response?.body?.cancel().catch(() => {}); }
    },
  };
}
