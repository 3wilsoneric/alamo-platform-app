// Fixed fictional source only. No app runtime, database, remote URL or caller packet.
import { validateAssessmentQualityPacket } from "../skills/assessment-review/quality.mjs";
const packets = [
  {
    "schemaVersion": 1,
    "mode": "synthetic-only",
    "context": {
      "schemaVersion": 1,
      "snapshot": {
        "schemaVersion": 1,
        "id": "context.synthetic-assessment-001",
        "scope": {
          "companyId": "11111111-1111-4111-8111-111111111111",
          "tenantId": "22222222-2222-4222-8222-222222222222",
          "subjectId": "33333333-3333-4333-8333-333333333333"
        },
        "resourceScope": {
          "kind": "source-user",
          "ids": []
        },
        "source": {
          "application": "pipeline",
          "kind": "assessment",
          "id": "synthetic-assessment-001",
          "revision": "1"
        },
        "observedAt": "2026-10-17T12:00:00.000Z",
        "asOf": "2026-10-17T12:00:00.000Z",
        "completeness": "partial",
        "grant": {
          "application": "pipeline",
          "id": "synthetic-content-grant",
          "revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "expiresAt": "2026-10-17T13:00:00.000Z"
        }
      },
      "assignment": {
        "ownerId": "33333333-3333-4333-8333-333333333333",
        "revision": "1"
      },
      "relatedSources": [
        {
          "application": "pipeline",
          "kind": "referral",
          "id": "900001",
          "revision": "1"
        }
      ],
      "missing": [
        "full-questionnaire",
        "original-evidence",
        "work-requirements",
        "packet-version",
        "receiving-owner",
        "receiving-acknowledgment"
      ],
      "content": [
        {
          "id": "assessment_notes",
          "label": "Assessment notes",
          "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
          "status": "recorded",
          "evidenceIds": [
            "answer.assessment_notes"
          ]
        },
        {
          "id": "placement_process_questions",
          "label": "Placement questions or concerns",
          "text": null,
          "status": "unknown",
          "evidenceIds": [
            "answer.placement_process_questions"
          ]
        },
        {
          "id": "additional_information",
          "label": "Additional information",
          "text": "FICTIONAL: The receiving team requested a callback. The contact still needs verification.",
          "status": "unreviewed",
          "evidenceIds": [
            "answer.additional_information"
          ]
        }
      ],
      "evidence": [
        {
          "id": "answer.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          },
          "locator": "assessment_notes"
        },
        {
          "id": "answer.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          },
          "locator": "placement_process_questions"
        },
        {
          "id": "answer.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          },
          "locator": "additional_information"
        },
        {
          "id": "assessment.signature",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          },
          "locator": "signed_at"
        },
        {
          "id": "assessment.delivery",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          },
          "locator": "meet_client_sent_at"
        },
        {
          "id": "referral.decision",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "1"
          },
          "locator": "admission_decision"
        },
        {
          "id": "referral.admission_date",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "1"
          },
          "locator": "planned_admission_date"
        },
        {
          "id": "note.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "1"
          },
          "locator": "fictional_note_1"
        },
        {
          "id": "note.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "1"
          },
          "locator": "fictional_note_2"
        },
        {
          "id": "note.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "1"
          },
          "locator": "fictional_note_3"
        }
      ],
      "requirements": [
        {
          "id": "signature",
          "label": "Assessment signature recorded",
          "status": "unknown",
          "ownerId": "33333333-3333-4333-8333-333333333333",
          "evidenceIds": [
            "assessment.signature"
          ]
        },
        {
          "id": "decision",
          "label": "Admission decision recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.decision"
          ]
        },
        {
          "id": "admission-date",
          "label": "Planned admission date recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.admission_date"
          ]
        },
        {
          "id": "delivery",
          "label": "Source send recorded; recipient acknowledgment is separate",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "assessment.delivery"
          ]
        }
      ],
      "nextActions": [
        {
          "id": "inspect-assessment",
          "label": "Inspect the current assessment in Pipeline",
          "mode": "human",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "1"
          }
        }
      ]
    },
    "sourceExcerpts": [
      {
        "evidenceId": "note.assessment_notes",
        "contentIds": [
          "assessment_notes"
        ],
        "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.placement_process_questions",
        "contentIds": [
          "placement_process_questions"
        ],
        "text": "FICTIONAL: Placement questions have not yet been documented.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.additional_information",
        "contentIds": [
          "additional_information"
        ],
        "text": "FICTIONAL: The receiving team requested a callback. The contact still needs verification.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      }
    ]
  },
  {
    "schemaVersion": 1,
    "mode": "synthetic-only",
    "context": {
      "schemaVersion": 1,
      "snapshot": {
        "schemaVersion": 1,
        "id": "context.synthetic-assessment-001",
        "scope": {
          "companyId": "11111111-1111-4111-8111-111111111111",
          "tenantId": "22222222-2222-4222-8222-222222222222",
          "subjectId": "33333333-3333-4333-8333-333333333333"
        },
        "resourceScope": {
          "kind": "source-user",
          "ids": []
        },
        "source": {
          "application": "pipeline",
          "kind": "assessment",
          "id": "synthetic-assessment-001",
          "revision": "2"
        },
        "observedAt": "2026-10-17T12:00:00.000Z",
        "asOf": "2026-10-17T12:00:00.000Z",
        "completeness": "partial",
        "grant": {
          "application": "pipeline",
          "id": "synthetic-content-grant",
          "revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "expiresAt": "2026-10-17T13:00:00.000Z"
        }
      },
      "assignment": {
        "ownerId": "33333333-3333-4333-8333-333333333333",
        "revision": "1"
      },
      "relatedSources": [
        {
          "application": "pipeline",
          "kind": "referral",
          "id": "900001",
          "revision": "2"
        }
      ],
      "missing": [
        "full-questionnaire",
        "original-evidence",
        "work-requirements",
        "packet-version",
        "receiving-owner",
        "receiving-acknowledgment"
      ],
      "content": [
        {
          "id": "assessment_notes",
          "label": "Assessment notes",
          "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
          "status": "recorded",
          "evidenceIds": [
            "answer.assessment_notes"
          ]
        },
        {
          "id": "placement_process_questions",
          "label": "Placement questions or concerns",
          "text": "FICTIONAL: The client asked whether a morning callback is available. No callback time is confirmed.",
          "status": "recorded",
          "evidenceIds": [
            "answer.placement_process_questions"
          ]
        },
        {
          "id": "additional_information",
          "label": "Additional information",
          "text": "FICTIONAL: The receiving team requested a callback. The contact still needs verification.",
          "status": "unreviewed",
          "evidenceIds": [
            "answer.additional_information"
          ]
        }
      ],
      "evidence": [
        {
          "id": "answer.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          },
          "locator": "assessment_notes"
        },
        {
          "id": "answer.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          },
          "locator": "placement_process_questions"
        },
        {
          "id": "answer.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          },
          "locator": "additional_information"
        },
        {
          "id": "assessment.signature",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          },
          "locator": "signed_at"
        },
        {
          "id": "assessment.delivery",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          },
          "locator": "meet_client_sent_at"
        },
        {
          "id": "referral.decision",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "2"
          },
          "locator": "admission_decision"
        },
        {
          "id": "referral.admission_date",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "2"
          },
          "locator": "planned_admission_date"
        },
        {
          "id": "note.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "2"
          },
          "locator": "fictional_note_1"
        },
        {
          "id": "note.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "2"
          },
          "locator": "fictional_note_2"
        },
        {
          "id": "note.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "2"
          },
          "locator": "fictional_note_3"
        }
      ],
      "requirements": [
        {
          "id": "signature",
          "label": "Assessment signature recorded",
          "status": "unknown",
          "ownerId": "33333333-3333-4333-8333-333333333333",
          "evidenceIds": [
            "assessment.signature"
          ]
        },
        {
          "id": "decision",
          "label": "Admission decision recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.decision"
          ]
        },
        {
          "id": "admission-date",
          "label": "Planned admission date recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.admission_date"
          ]
        },
        {
          "id": "delivery",
          "label": "Source send recorded; recipient acknowledgment is separate",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "assessment.delivery"
          ]
        }
      ],
      "nextActions": [
        {
          "id": "inspect-assessment",
          "label": "Inspect the current assessment in Pipeline",
          "mode": "human",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "2"
          }
        }
      ]
    },
    "sourceExcerpts": [
      {
        "evidenceId": "note.assessment_notes",
        "contentIds": [
          "assessment_notes"
        ],
        "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.placement_process_questions",
        "contentIds": [
          "placement_process_questions"
        ],
        "text": "FICTIONAL: The client asked whether a morning callback is available. No callback time is confirmed.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.additional_information",
        "contentIds": [
          "additional_information"
        ],
        "text": "FICTIONAL: The receiving team requested a callback. The contact still needs verification.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      }
    ]
  },
  {
    "schemaVersion": 1,
    "mode": "synthetic-only",
    "context": {
      "schemaVersion": 1,
      "snapshot": {
        "schemaVersion": 1,
        "id": "context.synthetic-assessment-001",
        "scope": {
          "companyId": "11111111-1111-4111-8111-111111111111",
          "tenantId": "22222222-2222-4222-8222-222222222222",
          "subjectId": "33333333-3333-4333-8333-333333333333"
        },
        "resourceScope": {
          "kind": "source-user",
          "ids": []
        },
        "source": {
          "application": "pipeline",
          "kind": "assessment",
          "id": "synthetic-assessment-001",
          "revision": "3"
        },
        "observedAt": "2026-10-17T12:00:00.000Z",
        "asOf": "2026-10-17T12:00:00.000Z",
        "completeness": "partial",
        "grant": {
          "application": "pipeline",
          "id": "synthetic-content-grant",
          "revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          "expiresAt": "2026-10-17T13:00:00.000Z"
        }
      },
      "assignment": {
        "ownerId": "33333333-3333-4333-8333-333333333333",
        "revision": "1"
      },
      "relatedSources": [
        {
          "application": "pipeline",
          "kind": "referral",
          "id": "900001",
          "revision": "3"
        }
      ],
      "missing": [
        "full-questionnaire",
        "original-evidence",
        "work-requirements",
        "packet-version",
        "receiving-owner",
        "receiving-acknowledgment"
      ],
      "content": [
        {
          "id": "assessment_notes",
          "label": "Assessment notes",
          "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
          "status": "recorded",
          "evidenceIds": [
            "answer.assessment_notes"
          ]
        },
        {
          "id": "placement_process_questions",
          "label": "Placement questions or concerns",
          "text": "FICTIONAL: The client asked whether a morning callback is available. No callback time is confirmed.",
          "status": "recorded",
          "evidenceIds": [
            "answer.placement_process_questions"
          ]
        },
        {
          "id": "additional_information",
          "label": "Additional information",
          "text": "FICTIONAL: The receiving team requested a callback. The contact details were verified in the fictional record.",
          "status": "recorded",
          "evidenceIds": [
            "answer.additional_information"
          ]
        }
      ],
      "evidence": [
        {
          "id": "answer.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          },
          "locator": "assessment_notes"
        },
        {
          "id": "answer.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          },
          "locator": "placement_process_questions"
        },
        {
          "id": "answer.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          },
          "locator": "additional_information"
        },
        {
          "id": "assessment.signature",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          },
          "locator": "signed_at"
        },
        {
          "id": "assessment.delivery",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          },
          "locator": "meet_client_sent_at"
        },
        {
          "id": "referral.decision",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "3"
          },
          "locator": "admission_decision"
        },
        {
          "id": "referral.admission_date",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "3"
          },
          "locator": "planned_admission_date"
        },
        {
          "id": "note.assessment_notes",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "3"
          },
          "locator": "fictional_note_1"
        },
        {
          "id": "note.placement_process_questions",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "3"
          },
          "locator": "fictional_note_2"
        },
        {
          "id": "note.additional_information",
          "source": {
            "application": "pipeline",
            "kind": "referral",
            "id": "900001",
            "revision": "3"
          },
          "locator": "fictional_note_3"
        }
      ],
      "requirements": [
        {
          "id": "signature",
          "label": "Assessment signature recorded",
          "status": "unknown",
          "ownerId": "33333333-3333-4333-8333-333333333333",
          "evidenceIds": [
            "assessment.signature"
          ]
        },
        {
          "id": "decision",
          "label": "Admission decision recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.decision"
          ]
        },
        {
          "id": "admission-date",
          "label": "Planned admission date recorded",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "referral.admission_date"
          ]
        },
        {
          "id": "delivery",
          "label": "Source send recorded; recipient acknowledgment is separate",
          "status": "unknown",
          "ownerId": null,
          "evidenceIds": [
            "assessment.delivery"
          ]
        }
      ],
      "nextActions": [
        {
          "id": "inspect-assessment",
          "label": "Inspect the current assessment in Pipeline",
          "mode": "human",
          "source": {
            "application": "pipeline",
            "kind": "assessment",
            "id": "synthetic-assessment-001",
            "revision": "3"
          }
        }
      ]
    },
    "sourceExcerpts": [
      {
        "evidenceId": "note.assessment_notes",
        "contentIds": [
          "assessment_notes"
        ],
        "text": "FICTIONAL: The client reports preferring a morning call. A time has not been confirmed.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.placement_process_questions",
        "contentIds": [
          "placement_process_questions"
        ],
        "text": "FICTIONAL: The client asked whether a morning callback is available. No callback time is confirmed.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      },
      {
        "evidenceId": "note.additional_information",
        "contentIds": [
          "additional_information"
        ],
        "text": "FICTIONAL: The receiving team requested a callback. The contact details were verified in the fictional record.",
        "recordedAt": "2026-10-17T12:00:00.000Z"
      }
    ]
  }
];
export function sandboxPacket(session, now) {
  const index = ["synthetic-initial", "synthetic-partial", "synthetic-ready"].indexOf(session.scenario);
  if (index < 0) throw new Error("Unknown sandbox scenario.");
  const selected = packets[index];
  if (!selected) throw new Error("Unknown sandbox scenario.");
  const packet = structuredClone(selected), context = packet.context;
  context.snapshot.id = `context.${session.id}`;
  context.snapshot.scope = { companyId: "11111111-1111-4111-8111-111111111111", tenantId: session.tenantId, subjectId: session.userId };
  context.snapshot.observedAt = new Date(now).toISOString(); context.snapshot.asOf = context.snapshot.observedAt;
  context.snapshot.grant.expiresAt = session.expiresAt; context.snapshot.grant.id = `sandbox-${session.id}`;
  context.snapshot.source.id = `sandbox-assessment-${session.id}`; context.assignment.ownerId = session.userId;
  for (const requirement of context.requirements) if (requirement.ownerId) requirement.ownerId = session.userId;
  for (const source of context.relatedSources) source.id = `sandbox-referral-${session.id}`;
  for (const e of context.evidence) e.source.id = e.source.kind === "assessment" ? context.snapshot.source.id : `sandbox-referral-${session.id}`;
  for (const action of context.nextActions) action.source.id = action.source.kind === "assessment" ? context.snapshot.source.id : `sandbox-referral-${session.id}`;
  return validateAssessmentQualityPacket(packet);
}
