import {ManagedIdentityCredential,OnBehalfOfCredential} from '@azure/identity';
import {maintenanceHash as hash} from '../shared/proforma-maintenance-contracts.mjs';
import {everyAgentActor} from './everyagent-access.mjs';
import {createHttpError} from './http-error-contract.mjs';

const unavailable=()=>createHttpError(503,'proforma_identity_unavailable','ProForma delegated sign-in is unavailable. Reconnect your agent sign-in and retry.');
const validToken=(value,now)=>value&&typeof value.token==='string'&&value.token.length>0&&value.token.length<=16000&&!/\s/.test(value.token)&&Number.isFinite(value.expiresOnTimestamp)&&value.expiresOnTimestamp>now;
// User assertions are kept only on this request's authenticated object. They
// cannot be serialized into configurations, sessions, workflow inputs or logs.
export function createProFormaDelegatedIdentity({config,authorize,now=Date.now,
  credentialFor=options=>new OnBehalfOfCredential(options),
  managedIdentityFor=clientId=>new ManagedIdentityCredential(clientId)}){
  const requests=new WeakMap(),identity=config.identity;
  const managed=identity.credential.kind==='managed-identity'?managedIdentityFor(identity.credential.clientId):null;
  async function authenticated(req){
    const header=req.headers?.authorization,token=typeof header==='string'&&header.length<16384?/^Bearer\s+(\S+)$/i.exec(header)?.[1]:null;
    const auth=await authorize(req);
    // Keep the base authorizer's registered clients, audience and signature checks.
    // The independent engine's current owner gate is also mandatory for exchange.
    everyAgentActor(auth);
    if(!token||auth.claims.idtyp==='app'||auth.claims.tid!==identity.tenantId||![identity.clientId,`api://${identity.clientId}`].includes(auth.claims.aud)||!Number.isFinite(auth.claims.exp)||auth.claims.exp*1000<=now())throw unavailable();
    requests.set(auth,{assertion:token,claimsHash:hash(auth.claims),credential:null});return auth;
  }
  async function getToken(auth){
    try{
      const entry=requests.get(auth);everyAgentActor(auth);
      if(!entry||entry.claimsHash!==hash(auth.claims)||auth.claims.exp*1000<=now())throw unavailable();
      if(!entry.credential){
        const credentials=managed?{getAssertion:async()=>{
          const result=await managed.getToken('api://AzureADTokenExchange/.default',{abortSignal:AbortSignal.timeout(8000)});
          if(!validToken(result,now()))throw unavailable();return result.token;
        }}:{certificatePath:identity.credential.path};
        entry.credential=credentialFor({tenantId:identity.tenantId,clientId:identity.clientId,userAssertionToken:entry.assertion,...credentials,
          authorityHost:'https://login.microsoftonline.com',additionallyAllowedTenants:[]});
        entry.assertion=null;
      }
      const token=await entry.credential.getToken(config.sourceScope,{abortSignal:AbortSignal.timeout(8000)});
      if(entry.claimsHash!==hash(auth.claims)||auth.claims.exp*1000<=now()||!validToken(token,now()))throw unavailable();
      return {token:token.token,expiresOnTimestamp:Math.min(token.expiresOnTimestamp,auth.claims.exp*1000)};
    }catch{throw unavailable();}
  }
  return {authorize:authenticated,getToken};
}
