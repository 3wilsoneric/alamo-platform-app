import { randomUUID } from "node:crypto";
import { foundationObject } from "../shared/foundation-contracts.mjs";
import { draftReviewHash, draftReviewId } from "../shared/draft-review-contracts.mjs";
import { validateWorkContextRequest } from "../shared/work-context-contracts.mjs";
import { SKILL_DECISIONS, SKILL_SELECTION_REVISION, validateSkillSelection } from "./skill-selection-model.mjs";

export const SKILL_RUNNER_VERSION = "bounded-skill-runner-v1";
const stopped = reason => Object.assign(new Error("Skill run stopped."), { reason });

// Reusable one-decision/one-activity harness. pack and traceSink are trusted host
// dependencies, never supplied by an end user. No endpoint is registered here.
// A durable host must persist each event before acknowledging it. Failed sinks
// withhold the result; they cannot roll back an already saved immutable draft.
export function createSkillRunner({ pack, selector, traceSink, clock = Date.now }) {
  if (typeof traceSink !== "function") throw new Error("A scoped trace sink is required.");
  return {
    async run(value) {
      const v = foundationObject(value, ["request", "instruction", "parentArtifactId"]);
      const request = validateWorkContextRequest(v.request);
      if (typeof v.instruction !== "string" || !v.instruction.trim() || v.instruction.length > 2000) throw new Error("Invalid skill request.");
      const instruction = v.instruction, parentId = v.parentArtifactId === null ? null : draftReviewId(v.parentArtifactId);
      const definition = structuredClone(pack.definition), started = clock(), runId = randomUUID();
      const limits = definition.limits;
      let sequence = 0, modelCalls = 0, sourceReads = 0, selection = null, artifact = null, reason = null;
      let observed = null, phase = "source", traceFailed = false;
      const modelRuns = [];
      const emit = async (event, data) => {
        try {
          await traceSink({ schemaVersion: 1, runId, sequence: sequence++, event,
            scope: structuredClone(request.scope), requestRevision: draftReviewHash(request),
            runnerVersion: SKILL_RUNNER_VERSION, packRevision: pack.revision, selectionRevision: SKILL_SELECTION_REVISION,
            elapsedMs: Math.max(0, clock() - started), data: structuredClone(data) });
        } catch { traceFailed = true; throw stopped("trace_unavailable"); }
      };
      const checkTime = () => { if (clock() - started > limits.deadlineMs) throw stopped("budget_exceeded"); };
      const readPacket = async input => {
        checkTime(); if (++sourceReads > limits.sourceReads) throw stopped("budget_exceeded");
        return pack.readPacket(structuredClone(input));
      };
      const callModel = async operation => {
        checkTime(); if (++modelCalls > limits.modelCalls) throw stopped("budget_exceeded");
        const result = await operation();
        for (const name of [result.requestedModel, result.responseModel, result.promptVersion]) {
          if (typeof name !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(name)) throw new Error("Invalid model metadata.");
        }
        if (result.usage !== null) {
          const u = foundationObject(result.usage, ["inputTokens", "outputTokens"]);
          if (![u.inputTokens, u.outputTokens].every(n => Number.isSafeInteger(n) && Number(n) >= 0 && Number(n) <= 1_000_000)) throw new Error("Invalid model usage.");
        }
        modelRuns.push({ requestedModel: result.requestedModel, responseModel: result.responseModel,
          promptVersion: result.promptVersion, usage: result.usage });
        checkTime(); return result;
      };
      await emit("started", { instructionRevision: draftReviewHash(instruction), parentId, limits });
      try {
        observed = await pack.observe(request, parentId, readPacket);
        await emit("observed", { contextRevision: observed.revision, state: observed.state, eligible: observed.eligible });
        phase = "selection";
        const input = { mode: definition.mode, authority: definition.authority, instruction, state: observed.state,
          skills: definition.skills.map(skill => ({ ...skill, eligible: observed.eligible.includes(skill.id) })) };
        selection = validateSkillSelection(await callModel(() => selector.select(structuredClone(input))), [...definition.skills.map(s => s.id), ...SKILL_DECISIONS]);
        await emit("selected", { choice: selection.choice });
        phase = "source";
        const fresh = await pack.observe(request, parentId, readPacket);
        if (fresh.revision !== observed.revision) throw stopped("context_changed");
        checkTime();
        if (SKILL_DECISIONS.includes(selection.choice)) reason = selection.choice;
        else if (!fresh.eligible.includes(selection.choice)) reason = "ineligible_skill";
        else {
          phase = "activity";
          await emit("activity_started", { skillId: selection.choice });
          // Bind all activity reads to the observed packet, including retries.
          const boundRead = async input => {
            const packet = await readPacket(input);
            // Pack observes this exact read result without trusting model claims.
            const state = await pack.observe(request, parentId, async () => structuredClone(packet));
            if (state.revision !== observed.revision) throw stopped("context_changed");
            return packet;
          };
          artifact = await pack.execute(selection.choice, request, parentId, boundRead, callModel);
          phase = "source";
          if ((await pack.observe(request, parentId, readPacket)).revision !== observed.revision) throw stopped("context_changed");
          checkTime();
        }
      } catch (error) {
        if (traceFailed) throw stopped("trace_unavailable");
        reason = error && typeof error === "object" && "reason" in error && ["budget_exceeded", "context_changed"].includes(String(error.reason))
          ? String(error.reason) : phase === "selection" ? "selection_unavailable" : phase === "source" ? "context_unavailable" : "activity_unavailable";
        artifact = null;
      }
      const status = artifact ? "draft_prepared" : "stopped";
      const result = { runId, status, reason, choice: selection?.choice ?? null, artifact,
        sourceWork: "unconfirmed", delivery: "not_performed" };
      await emit("completed", { status, reason, choice: result.choice, artifactId: artifact?.id ?? null,
        artifactRevision: artifact?.artifactRevision ?? null, modelCalls, sourceReads, modelRuns,
        usageComplete: modelRuns.length === modelCalls && modelRuns.every(m => m.usage !== null),
        sourceWork: "unconfirmed", delivery: "not_performed" });
      return result;
    },
  };
}
