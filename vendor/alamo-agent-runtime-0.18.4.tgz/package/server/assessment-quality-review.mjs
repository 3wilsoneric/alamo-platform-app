import { createHash } from "node:crypto";
import { foundationObject } from "../shared/foundation-contracts.mjs";
import { draftReviewHash } from "../shared/draft-review-contracts.mjs";
import { createDraftReviewService } from "./draft-review-service.mjs";
import { validateWorkContextRequest, verifyWorkContext } from "../shared/work-context-contracts.mjs";
import { validateAssessmentQualityPacket, assessmentQualityDraft, ASSESSMENT_QUALITY_PROMPT_VERSION,
  ASSESSMENT_QUALITY_SYSTEM, ASSESSMENT_QUALITY_OUTPUT_SCHEMA } from "../skills/assessment-review/quality.mjs";
import { ASSESSOR_CONTEXT_TEACHING, ASSESSOR_CONTEXT_PROCEDURES } from "../skills/assessment-review/work-context.mjs";
import { workContextRevision } from "./assessor-work-context.mjs";
import { qualityUnavailable, validateAssessmentQualityResult } from "./assessment-quality-model.mjs";

const hash = value => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const policyRevision = hash({ promptVersion: ASSESSMENT_QUALITY_PROMPT_VERSION, prompt: ASSESSMENT_QUALITY_SYSTEM,
  schema: ASSESSMENT_QUALITY_OUTPUT_SCHEMA, teaching: ASSESSOR_CONTEXT_TEACHING, procedures: ASSESSOR_CONTEXT_PROCEDURES });
export const assessmentQualityPacketRevision = packet => hash({ policyRevision, context: workContextRevision(packet.context), sourceExcerpts: packet.sourceExcerpts });
const packetRevision = assessmentQualityPacketRevision;

// Activity seam only. No HTTP registration, schedule, live reader or default
// store. Compose with createDraftReviewStore for durable storage. The reader
// must own source authorization, not trust request IDs.
async function read(request, deps) {
  try {
    const packet = validateAssessmentQualityPacket(await deps.readPacket(structuredClone(request)));
    verifyWorkContext(packet.context, request, deps.now());
    return packet;
  } catch { return qualityUnavailable(); }
}
function reviews(deps) {
  return createDraftReviewService({ store: deps.store, skillId: "assessment-answer-quality", policyRevision, now: deps.now,
    readContext: request => read(request, deps), contextRevision: packetRevision,
    validatePayload: (value, packet) => {
      const v = foundationObject(value, ["result", "draft"]);
      const result = validateAssessmentQualityResult(v.result, packet), draft = assessmentQualityDraft(result.review, packet);
      if (draftReviewHash(v.draft) !== draftReviewHash(draft)) return qualityUnavailable();
      return { result, draft };
    } });
}
function project(record) {
  const { review: _review, ...modelRun } = record.payload.result;
  return { id: record.id, contextRevision: record.contextRevision, artifactRevision: record.artifactRevision,
    modelRun, draft: record.payload.draft, humanReview: record.review, status: record.status, sourceWork: record.sourceWork };
}

export async function prepareAssessmentQualityDraft(value, deps) {
  try {
    const request = validateWorkContextRequest(value), packet = await read(request, deps);
    const revision = packetRevision(packet);
    // Model receives a copy: a provider cannot mutate the source snapshot used for binding.
    const result = validateAssessmentQualityResult(await deps.model.review(structuredClone(packet)), packet);
    if (revision !== packetRevision(await read(request, deps))) return qualityUnavailable();
    return project(await reviews(deps).save(request, { result, draft: assessmentQualityDraft(result.review, packet) }, revision));
  } catch { return qualityUnavailable(); }
}

export async function readAssessmentQualityDraft(id, value, deps) {
  try {
    return project(await reviews(deps).read(id, value));
  } catch { return qualityUnavailable(); }
}

// The command must name the displayed artifact revision and a stable request ID.
// Receipt persistence is separate from any source-app action or human handoff.
export async function reviewAssessmentQualityDraft(id, command, value, deps) {
  try { return project(await reviews(deps).review(id, value, command)); }
  catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "DRAFT_REVIEW_CONFLICT") throw error;
    return qualityUnavailable();
  }
}
