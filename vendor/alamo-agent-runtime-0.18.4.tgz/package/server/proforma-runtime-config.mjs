import path from 'node:path';
import {maintenanceObject as object,maintenanceId as id,maintenanceDigest as digest} from '../shared/proforma-maintenance-contracts.mjs';
import {validateAutomationBinding} from '../shared/proforma-automation-contracts.mjs';
import {EVERYAGENT_TENANT,EVERYAGENT_USERS} from '../shared/everyagent-identity.mjs';

/** @typedef {{schemaVersion:1,id:string,origin:string,scope:{tenantId:string,workspace:'workflow'},actorId:string,documentIds:string[],purpose:string,policyVersion:string}} SourceBinding */
/** @typedef {{schemaVersion:1,identity:{tenantId:string,clientId:string,credential:{kind:'certificate',path:string}|{kind:'managed-identity',clientId:string}},sourceScope:string,bindings:SourceBinding[],models:{quality:string,selection:string},evaluationDigest:string}} RuntimeConfig */
/** @returns {never} */
const invalid=()=>{throw new Error('Configure a valid ProForma execution registry and delegated identity.');};
// Deployment-owned metadata only. Credentials, tokens and source records are
// forbidden here; reviewing a mapping cannot alter this connection registry.
/** @returns {RuntimeConfig|null} */
export function readProFormaRuntimeConfig(env=process.env){
  if(env.ALAMOAGENT_PROFORMA_EXECUTION_JSON===undefined)return null;
  try{
    if(env.ALAMOAGENT_ASSESSOR_SANDBOX!=='true'||env.ALAMOAGENT_DEPLOYMENT_KIND!=='sandbox')return invalid();
    const raw=env.ALAMOAGENT_PROFORMA_EXECUTION_JSON;if(typeof raw!=='string'||Buffer.byteLength(raw)>128000)return invalid();
    const v=object(JSON.parse(raw),['schemaVersion','identity','sourceScope','bindings','models','evaluationDigest']);
    if(v.schemaVersion!==1)return invalid();
    const identity=object(v.identity,['tenantId','clientId','credential']);id(identity.clientId);
    if(identity.tenantId!==EVERYAGENT_TENANT||env.ALAMOAGENT_ENTRA_TENANT_ID!==identity.tenantId||![identity.clientId,`api://${identity.clientId}`].includes(env.ALAMOAGENT_ENTRA_API_AUDIENCE))return invalid();
    if(identity.credential?.kind==='certificate'){
      const c=object(identity.credential,['kind','path']);if(typeof c.path!=='string'||!path.isAbsolute(c.path)||c.path.length>4096||c.path.includes('\0'))return invalid();
    }else if(identity.credential?.kind==='managed-identity'){
      const c=object(identity.credential,['kind','clientId']);id(c.clientId);
    }else return invalid();
    if(typeof v.sourceScope!=='string'||!/^api:\/\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/(?:access_as_user|\.default)$/.test(v.sourceScope)||v.sourceScope.startsWith(`api://${identity.clientId}/`))return invalid();
    object(v.models,['quality','selection']);for(const model of Object.values(v.models))if(typeof model!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(model))return invalid();digest(v.evaluationDigest);
    if(!Array.isArray(v.bindings)||!v.bindings.length||v.bindings.length>50)return invalid();
    const bindings=/** @type {SourceBinding[]} */(v.bindings.map(validateAutomationBinding)),ids=new Set(),documents=new Set();
    for(const b of bindings){
      if(ids.has(b.id)||b.scope.tenantId!==identity.tenantId||!EVERYAGENT_USERS.some(user=>b.actorId===`entra:${identity.tenantId}:${user}`))return invalid();ids.add(b.id);
      for(const doc of b.documentIds){const key=`${b.actorId}:${doc}`;if(documents.has(key))return invalid();documents.add(key);}
    }
    return structuredClone(/** @type {RuntimeConfig} */({...v,bindings}));
  }catch{return invalid();}
}
