import { draftReviewHash } from "../shared/draft-review-contracts.mjs";
import { validateWorkflowActor, validateWorkflowRead, validateWorkflowGrant, validateWorkflowFeed, WORKFLOW_HISTORY_LIMITS, workflowUnavailable } from "../shared/workflow-history-contracts.mjs";
import { projectWorkflowHistory, projectRoleView } from "./workflow-evidence-projection.mjs";
import { validateWorkflowBriefPacket } from "../shared/workflow-brief-contracts.mjs";

// Unbound reference service for a governed foundation adapter. actor, authorize
// and readFeed must be supplied by a trusted host, never chat/model input. There
// is no default adapter, URL input, HTTP registration, durable cache or source write.
export function createWorkflowRoleService({ actor, authorize, readFeed, now = Date.now }) {
  const identity = validateWorkflowActor(actor);
  if (typeof authorize !== "function" || typeof readFeed !== "function") throw new Error("Explicit workflow source adapters are required.");
  async function collect(input, packet) {
      try {
        const { operation } = validateWorkflowRead(input);
        const grant = validateWorkflowGrant(await authorize(structuredClone(identity), operation), identity, operation, now());
        const feed = validateWorkflowFeed(await readFeed(structuredClone(identity), structuredClone(grant)), now());
        if (feed.companyId !== identity.companyId || feed.tenantId !== identity.tenantId || feed.revision !== grant.datasetRevision) return workflowUnavailable();
        if (feed.coverage !== "complete" || now() - Date.parse(feed.completeThrough) > WORKFLOW_HISTORY_LIMITS.freshnessMs) return workflowUnavailable();
        const records = projectWorkflowHistory(feed);
        if (operation === "assessor_work" && grant.caseIds.some(id => !records.some(r => r.caseId === id))) return workflowUnavailable();
        const result = projectRoleView(records, grant, operation, feed);
        const current = validateWorkflowGrant(await authorize(structuredClone(identity), operation), identity, operation, now());
        if (draftReviewHash(grant) !== draftReviewHash(current) || now() - Date.parse(feed.completeThrough) > WORKFLOW_HISTORY_LIMITS.freshnessMs) return workflowUnavailable();
        if (!packet) return result;
        return validateWorkflowBriefPacket({ schemaVersion: 1, mode: "synthetic-only", snapshot: {
          schemaVersion: 1, id: `workflow-${operation}`, scope: identity, resourceScope: { kind: "source-user", ids: [] },
          source: { application: "pipeline", kind: "workflow-view", id: operation, revision: draftReviewHash(result) },
          observedAt: feed.observedAt, asOf: feed.completeThrough, completeness: "complete",
          grant: { application: "pipeline", id: current.id, revision: current.revision, expiresAt: current.expiresAt },
        }, view: result }, now());
      } catch { return workflowUnavailable(); }
  }
  return { read: input => collect(input, false), readPacket: input => collect(input, true) };
}
