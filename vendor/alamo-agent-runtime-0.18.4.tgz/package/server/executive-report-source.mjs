import { createSourceTransport } from './everyagent-source-client.mjs';
import { EXECUTIVE_REPORT_SOURCE_PATH, reportSubject, reportId, reportJson, reportHash, validateReportScope } from '../shared/executive-report-contracts.mjs';

export function createExecutiveReportSource({ origin, getToken, fetchImpl = fetch, now = Date.now }) {
  const transport = createSourceTransport({ origin, getToken, fetchImpl, now, endpoint: EXECUTIVE_REPORT_SOURCE_PATH, maximumBytes: 200_000, timeoutMs: 40_000 });
  async function request(operation, subjectId, scope, step = null) {
    reportSubject(subjectId); validateReportScope(scope);
    const input = { version: 1, operation, subjectId, scope, step };
    const result = await transport(input);
    if (result.version !== 1 || result.requestHash !== reportHash(input) || result.subjectId !== subjectId || !result.grant || typeof result.grant.detail !== 'boolean' ||
        Date.parse(result.grant.expiresAt) <= now() || !Number.isFinite(Date.parse(result.grant.expiresAt))) throw new Error('Report source authority could not be verified.');
    reportId(result.grant.revision); reportJson(result, 200_000);
    return result;
  }
  return {
    async authorize(subject, scope, step) { return (await request('authorize', subject, scope, step)).grant; },
    async catalog(subject, scope) {
      const result = await request('catalog', subject, scope);
      if (!Array.isArray(result.catalog) || !result.catalog.length || result.catalog.length > 40 ||
          new Set(result.catalog.map(c => c.id)).size !== result.catalog.length || result.catalog.some(c => !/^[a-z][a-z0-9-]{0,79}$/.test(c.id) || typeof c.title !== 'string' || !c.inputSchema)) throw new Error('Report source catalog is unavailable.');
      return result.catalog;
    },
    async read(subject, scope, step) { const result = await request('read', subject, scope, step); if (result.evidence?.grantRevision !== result.grant.revision) throw new Error('Report source grant changed.'); return result.evidence; }
  };
}
