import { EXECUTIVE_REPORT_PATH, reportObject, reportId, reportSubject, validateReportCreate, validateReportCommand } from '../shared/executive-report-contracts.mjs';
import { readJsonRequestBody } from './http-body.mjs';
import { createHttpError, HttpError } from './http-error-contract.mjs';

export async function handleExecutiveReportHttp(req, res, auth, service) {
  if (!service) throw createHttpError(404, 'not_found', 'Not found.');
  const url = new URL(req.url, 'https://agent.invalid');
  if (url.pathname !== EXECUTIVE_REPORT_PATH) throw createHttpError(404, 'not_found', 'Not found.');
  const invalid = () => createHttpError(400, 'report_request_invalid', 'Choose a valid report and scope.');
  if (req.method === 'GET') {
    const keys = [...url.searchParams.keys()];
    if (keys.some(k => !['ownerId', 'id', 'version'].includes(k)) || new Set(keys).size !== keys.length) throw invalid();
    if (!keys.length) { res.status(200).json({ reports: await service.list(auth) }); return; }
    let ownerId, id, version;
    try {
      ownerId = reportSubject(url.searchParams.get('ownerId')); id = reportId(url.searchParams.get('id'));
      const raw = url.searchParams.get('version'); version = raw === null ? null : Number(raw);
      if (raw !== null && (!/^[1-9]\d*$/.test(raw) || !Number.isSafeInteger(version))) throw invalid();
    } catch { throw invalid(); }
    res.status(200).json(await service.get(auth, ownerId, id, version)); return;
  }
  if (req.method === 'POST' && !url.search) {
    const input = await readJsonRequestBody(req, 16_000);
    let command;
    try { command = reportObject(input, ['operation', 'input']); if (!['create', 'command'].includes(command.operation)) throw invalid();
      command.input = command.operation === 'create' ? validateReportCreate(command.input) : validateReportCommand(command.input); }
    catch { throw invalid(); }
    try { res.status(command.operation === 'create' ? 202 : 200).json(await service[command.operation](auth, command.input)); }
    catch (error) { if (error instanceof HttpError) throw error; if (error instanceof Error && /Invalid (?:executive report|foundation) contract/.test(error.message)) throw invalid(); throw error; }
    return;
  }
  res.setHeader('Allow', 'GET, POST'); throw createHttpError(405, 'method_not_allowed', 'Method not allowed.');
}
