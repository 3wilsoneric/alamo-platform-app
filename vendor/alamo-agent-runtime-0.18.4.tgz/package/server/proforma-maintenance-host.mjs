import {randomUUID} from 'node:crypto';
import {maintenanceHash as hash,maintenanceObject as object,maintenanceInteger as integer,maintenanceDigest as digest,maintenanceId as id,maintenanceText as text} from '../shared/proforma-maintenance-contracts.mjs';
import {validateMaintenanceDefinition,maintenanceDefinitionHash,maintenanceRunKey,validateMaintenanceRunKey} from '../shared/proforma-maintenance-host.mjs';
import {createProFormaMaintenanceStorage} from './proforma-maintenance-storage.mjs';
import {createProFormaMaintenanceConsumer} from './proforma-maintenance-consumer.mjs';
import {createProFormaMaintenanceAssessor} from './proforma-maintenance-model.mjs';

const LEASE_MS=90000,DEADLINE_MS=600000,ACTIVITY_BUDGET_MS=120000;
const terminal=status=>['completed','failed','blocked','canceled'].includes(status);
const stop=code=>Object.assign(new Error(`Maintenance run is ${code}.`),{code:`MAINTENANCE_${code.toUpperCase()}`});
const conflict=e=>e&&typeof e==='object'&&'code' in e&&e.code==='EVERYAGENT_CONFLICT';
const codeOf=e=>e&&typeof e==='object'&&'code' in e?String(e.code):'';
/** Server-owned definitions must come from authenticated review/activation state.
 * No model response, source prose, browser field or timer can approve a binding. */
export function createProFormaMaintenanceHost({definitions,sourceFor,modelFor,authorizeControl,storageFor=createProFormaMaintenanceStorage,now=Date.now}){
  if(![definitions,sourceFor,modelFor,authorizeControl,storageFor].every(f=>typeof f==='function'))throw new Error('Explicit maintenance configuration, source identity, model, storage and control authority are required.');
  const scheduleInitial=key=>({schemaVersion:1,kind:'proforma.maintenance-schedule',bindingHash:key.bindingHash,revision:0,active:null,nextCheckAt:0,lastRunId:null});
  const runInitial=key=>({schemaVersion:1,kind:'proforma.maintenance-run',bindingHash:key.bindingHash,revision:0,key,status:'queued',createdAt:now(),updatedAt:now(),attempts:0,lease:null,result:null,evidenceIds:[],issue:null});
  function validate(value,key,kind){
    const {integrity,...v}=value;if(integrity!==hash(v)||v.schemaVersion!==1||v.kind!==kind||v.bindingHash!==key.bindingHash)throw new Error('Maintenance storage integrity failed.');integer(v.revision);
    if(kind==='proforma.maintenance-schedule'){
      object(v,['schemaVersion','kind','bindingHash','revision','active','nextCheckAt','lastRunId']);integer(v.nextCheckAt);if(v.lastRunId!==null)digest(v.lastRunId);
      if(v.active!==null){const k=validateMaintenanceRunKey(v.active);if(k.bindingHash!==key.bindingHash||k.tenantId!==key.tenantId||k.responsibilityId!==key.responsibilityId)throw new Error('Maintenance schedule belongs to another partition.');}
    }else{
      object(v,['schemaVersion','kind','bindingHash','revision','key','status','createdAt','updatedAt','attempts','lease','result','evidenceIds','issue']);if(hash(v.key)!==hash(key)||!['queued','running','completed','failed','blocked','canceled'].includes(v.status))throw new Error('Invalid maintenance run.');
      for(const k of ['createdAt','updatedAt','attempts'])integer(v[k]);
      if(v.lease){object(v.lease,['token','until']);digest(v.lease.token);integer(v.lease.until);}
      if((v.status==='running')!==!!v.lease)throw new Error('Maintenance run lease is inconsistent.');
      if(v.issue!==null)text(v.issue,300);
      if(v.result!==null){object(v.result,['status','cursor','streamId','assessed','skipped','canExecute']);if(!['caught_up','more_work'].includes(v.result.status)||v.result.canExecute!==false||v.status!=='completed')throw new Error('Invalid maintenance outcome.');integer(v.result.cursor);for(const k of ['assessed','skipped'])if(v.result[k]!==null)integer(v.result[k]);else if(v.result.status!=='more_work')throw new Error('Missing maintenance counts.');if(v.result.streamId!==null)id(v.result.streamId);}
      if(!Array.isArray(v.evidenceIds)||v.evidenceIds.length>1000||new Set(v.evidenceIds).size!==v.evidenceIds.length)throw new Error('Maintenance run evidence exceeds its limit.');v.evidenceIds.forEach(digest);
    }
    return v;
  }
  async function read(store,key,initial){const snapshot=await store.read();return {...snapshot,value:snapshot.value?validate(snapshot.value,key,initial(key).kind):initial(key)};}
  async function update(store,key,initial,change){
    for(let attempt=0;attempt<5;attempt++){
      const current=await read(store,key,initial),v=structuredClone(current.value);if(await change(v)===false)return current.value;
      v.revision++;const next={...v,integrity:hash(v)};validate(next,key,v.kind);
      try{await store.write(next,current.version);return v;}catch(error){if(!conflict(error)||attempt===4)throw error;}
    }
    throw new Error('Maintenance update did not commit.');
  }
  async function configurations(){const values=await definitions();if(!Array.isArray(values)||values.length>50)throw new Error('Configure at most 50 maintenance responsibilities.');const result=values.map(validateMaintenanceDefinition),ids=result.map(d=>`${d.binding.scope.tenantId}:${d.binding.id}`);if(new Set(ids).size!==ids.length)throw new Error('Duplicate maintenance responsibility.');return result;}
  async function current(key,active=true){
    const d=(await configurations()).find(d=>d.binding.scope.tenantId===key.tenantId&&d.binding.id===key.responsibilityId);
    if(!d||hash(d.binding)!==key.bindingHash||active&&(!d.enabled||maintenanceDefinitionHash(d)!==key.definitionHash))throw stop('canceled');return d;
  }
  const summary=run=>({key:run.key,status:run.status,attempts:run.attempts,createdAt:run.createdAt,updatedAt:run.updatedAt,result:run.result,evidenceIds:run.evidenceIds,issue:run.issue,canExecute:false});
  /** @param {any} key @param {string} status @param {any} result @param {string|null} token */
  async function finish(key,status,result=null,token=null,intervalMs=900000){
    const storage=storageFor(key);const run=await update(storage.run,key,runInitial,v=>{
      if(terminal(v.status))return false;
      if(token&&v.lease?.token!==token)throw stop('lease_lost');
      if(!token&&status==='failed'&&v.lease?.until>now())return false;
      Object.assign(v,{status,lease:null,result,updatedAt:now(),issue:status==='completed'?null:`Maintenance ${status}; retained work and checkpoints are unchanged.`});return true;
    });
    if(terminal(run.status))await update(storage.schedule,key,scheduleInitial,s=>{if(s.active?.id!==key.id)return false;s.active=null;s.lastRunId=key.id;s.nextCheckAt=now()+(result?.status==='more_work'?60000:intervalMs);return true;});
    return summary(run);
  }
  async function prepare(){
    const tasks=[];
    for(const definition of await configurations()){
      const seed=maintenanceRunKey(definition.binding,maintenanceDefinitionHash(definition),hash(randomUUID())),storage=storageFor(seed);
      const schedule=await update(storage.schedule,seed,scheduleInitial,s=>{if(!definition.enabled||s.active||s.nextCheckAt>now())return false;s.active=seed;return true;});
      if(!schedule.active)continue;const key=schedule.active,target=storageFor(key);
      const run=await update(target.run,key,runInitial,v=>v.revision===0);
      if(terminal(run.status)){await finish(key,run.status,run.result,null,definition.intervalMs);continue;}
      if(!definition.enabled||key.definitionHash!==maintenanceDefinitionHash(definition)){await finish(key,'canceled',null,null,definition.intervalMs);continue;}
      if(now()-run.createdAt>=DEADLINE_MS){await finish(key,'failed',null,null,definition.intervalMs);continue;}
      try{await sourceFor(definition.binding).authorize();const model=modelFor(definition.binding);if(!model.available||model.policyVersion!==definition.binding.policyVersion)throw stop('blocked');await current(key);}
      catch(error){await finish(key,codeOf(error)==='MAINTENANCE_CANCELED'?'canceled':'blocked',null,null,definition.intervalMs);continue;}
      tasks.push(key);
    }
    return tasks;
  }
  async function execute(input){
    const key=validateMaintenanceRunKey(input),storage=storageFor(key),token=hash(randomUUID()),attemptStarted=now();let definition;
    if(!(await storage.run.read()).value)throw stop('unavailable');
    try{definition=await current(key);}catch(error){if(codeOf(error)==='MAINTENANCE_CANCELED')return finish(key,'canceled');throw error;}
    const schedule=(await read(storage.schedule,key,scheduleInitial)).value;
    if(schedule.active?.id!==key.id){const prior=await storage.run.read();if(!prior.value)throw stop('unavailable');return summary(validate(prior.value,key,'proforma.maintenance-run'));}
    const claimed=await update(storage.run,key,runInitial,v=>{if(terminal(v.status))return false;if(v.lease?.until>now())throw stop('busy');Object.assign(v,{status:'running',attempts:v.attempts+1,lease:{token,until:now()+LEASE_MS},updatedAt:now(),issue:null});return true;});
    if(terminal(claimed.status))return summary(claimed);
    async function guard(){
      await current(key);const s=(await read(storage.schedule,key,scheduleInitial)).value;if(s.active?.id!==key.id)throw stop('canceled');
      await update(storage.run,key,runInitial,v=>{if(terminal(v.status))throw stop(v.status);if(v.lease?.token!==token||v.lease.until<=now())throw stop('lease_lost');if(now()-v.createdAt>=DEADLINE_MS)throw stop('deadline');v.lease.until=now()+LEASE_MS;v.updatedAt=now();return true;});
      if(now()-attemptStarted>=ACTIVITY_BUDGET_MS)throw stop('budget');
    }
    try{
      await guard();const source=sourceFor(definition.binding),wrapped={};
      for(const name of ['authorize','feed','context','command'])wrapped[name]=async(...args)=>{await guard();let result;try{result=await source[name](...args);}catch(error){if(name==='authorize')throw stop('blocked');throw error;}await guard();return result;};
      const model=modelFor(definition.binding);if(!model.available||model.policyVersion!==definition.binding.policyVersion)throw stop('blocked');
      const assess=createProFormaMaintenanceAssessor({binding:definition.binding,model,record:async trace=>{await guard();const id=await storage.record(trace,new Date(now()).toISOString());await update(storage.run,key,runInitial,v=>{if(v.lease?.token!==token||terminal(v.status))throw stop('lease_lost');if(!v.evidenceIds.includes(id))v.evidenceIds.push(id);return true;});await guard();}});
      const checkpoint={read:async()=>{await guard();return storage.checkpoint.read();},write:async(value,version)=>{await guard();await storage.checkpoint.write(value,version);await guard();}};
      const consumer=createProFormaMaintenanceConsumer({binding:definition.binding,source:wrapped,persistence:checkpoint,assess:async input=>{await guard();const result=await assess(input);await guard();return result;},now:()=>new Date(now()).toISOString()});
      const result=await consumer.runOnce({maxOperations:definition.maxOperations});await guard();return finish(key,'completed',result,token,definition.intervalMs);
    }catch(error){
      const code=codeOf(error);
      if(code==='MAINTENANCE_LEASE_LOST')throw error;
      if(code==='MAINTENANCE_BUDGET'){
        // Yield before the existing worker's five-minute activity timeout. The
        // consumer may have an exact pending command; a successor recovers it.
        const state=(await storage.checkpoint.read()).value;
        if(state){const {integrity,...value}=state;if(integrity!==hash(value)||value.schemaVersion!==1||value.bindingHash!==key.bindingHash)throw new Error('Maintenance checkpoint integrity failed.');}
        return finish(key,'completed',{status:'more_work',cursor:state?.cursor??0,streamId:state?.streamId??null,assessed:null,skipped:null,canExecute:false},token,definition.intervalMs);
      }
      if(['MAINTENANCE_CANCELED','MAINTENANCE_BLOCKED','MAINTENANCE_DEADLINE'].includes(code))return finish(key,code==='MAINTENANCE_BLOCKED'?'blocked':code==='MAINTENANCE_DEADLINE'?'failed':'canceled',null,token,definition.intervalMs);
      await update(storage.run,key,runInitial,v=>{if(v.lease?.token!==token||terminal(v.status))return false;v.lease=null;v.status='queued';v.issue='Maintenance attempt failed; its exact checkpoint is retained for retry.';v.updatedAt=now();return true;});
      throw new Error('Maintenance attempt failed; retry the retained checkpoint.');
    }
  }
  async function known(input){const key=validateMaintenanceRunKey(input),snapshot=await storageFor(key).run.read();if(!snapshot.value)throw stop('unavailable');validate(snapshot.value,key,'proforma.maintenance-run');return key;}
  async function controlled(input,caller){const key=validateMaintenanceRunKey(input),definition=await current(key,false);await authorizeControl(caller,definition.binding);await sourceFor(definition.binding).authorize();return known(key);}
  return {prepare,execute,async fail(input){const key=await known(input);let definition;try{definition=await current(key,false);}catch(error){if(codeOf(error)==='MAINTENANCE_CANCELED')return finish(key,'canceled');throw error;}return finish(key,'failed',null,null,definition.intervalMs);},
    async cancel(input,caller){const key=await controlled(input,caller),definition=await current(key,false);return finish(key,'canceled',null,null,definition.intervalMs);},
    async status(input,caller){const key=await controlled(input,caller),snapshot=await storageFor(key).run.read();if(!snapshot.value)throw stop('unavailable');return summary(validate(snapshot.value,key,'proforma.maintenance-run'));},
    async evidence(input,id,caller){const key=await controlled(input,caller),run=(await read(storageFor(key).run,key,runInitial)).value;if(!run.evidenceIds.includes(id))throw stop('unavailable');return storageFor(key).evidence(id);},
  };
}
