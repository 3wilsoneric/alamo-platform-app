import { draftReviewHash } from "../shared/draft-review-contracts.mjs";
import { workflowUnavailable } from "../shared/workflow-history-contracts.mjs";

import { WORKFLOW_TREND_POLICY } from "../shared/workflow-brief-contracts.mjs";
export { WORKFLOW_TREND_POLICY };
const minutes = (a, b) => (Date.parse(b) - Date.parse(a)) / 60000;

// This is a reference projection at the governed-source boundary, not an agent
// warehouse. Its input must already be validated complete source history.
export function projectWorkflowHistory(feed) {
  /** @type {Map<string, any>} */ const byId = new Map();
  for (const e of feed.events) {
    const previous = byId.get(e.id);
    if (previous && draftReviewHash(previous) !== draftReviewHash(e)) return workflowUnavailable();
    byId.set(e.id, e);
  }
  /** @type {Map<string, any[]>} */ const grouped = new Map();
  for (const e of byId.values()) { if (!grouped.has(e.caseId)) grouped.set(e.caseId, []); grouped.get(e.caseId)?.push(e); }
  const records = [];
  for (const [caseId, all] of grouped) {
    all.sort((a, b) => a.sourceRevision - b.sourceRevision);
    if (all.some((e, i) => e.sourceRevision !== i + 1) || all[0]?.kind !== "case_opened") return workflowUnavailable();
    const replaced = new Set();
    for (const e of all) if (e.supersedes !== null) {
      const old = byId.get(e.supersedes);
      if (!old || old.caseId !== caseId || old.kind !== e.kind || old.sourceRevision >= e.sourceRevision ||
          old.occurredAt !== e.occurredAt || old.ingestedAt > e.ingestedAt || old.data.attemptId !== e.data.attemptId || replaced.has(old.id)) return workflowUnavailable();
      replaced.add(old.id);
    }
    const events = all.filter(e => !replaced.has(e.id)).sort((a, b) => a.occurredAt.localeCompare(b.occurredAt) || a.sourceRevision - b.sourceRevision);
    if (events[0]?.kind !== "case_opened") return workflowUnavailable();
    const opening = events[0];
    /** @type {Map<string, any>} */ const blockers = new Map();
    /** @type {Map<string, any>} */ const attempts = new Map();
    let ownerId = opening.data.ownerId;
    const assignmentHistory = [{ ownerId, at: opening.occurredAt, eventId: opening.id }];
    for (const e of events.slice(1)) {
      if (e.kind === "case_opened") return workflowUnavailable();
      if (e.kind === "assignment_changed") { ownerId = e.data.ownerId; assignmentHistory.push({ ownerId, at: e.occurredAt, eventId: e.id }); }
      else if (e.kind === "blocker_opened") {
        if (blockers.has(e.data.blockerId)) return workflowUnavailable();
        blockers.set(e.data.blockerId, { ...e.data, openedAt: e.occurredAt, resolvedAt: null, evidenceIds: [e.id] });
      } else if (e.kind === "blocker_resolved") {
        const b = blockers.get(e.data.blockerId);
        if (!b || b.resolvedAt !== null) return workflowUnavailable();
        b.resolvedAt = e.occurredAt; b.evidenceIds.push(e.id);
      } else if (e.kind === "handoff_recorded") {
        if (attempts.has(e.data.attemptId)) return workflowUnavailable();
        attempts.set(e.data.attemptId, { id: e.data.attemptId, result: e.data.result, at: e.occurredAt, acknowledgment: "unknown", evidenceIds: [e.id] });
      } else if (e.kind === "handoff_acknowledged") {
        const a = attempts.get(e.data.attemptId);
        if (!a || a.result !== "sent" || a.acknowledgment !== "unknown") return workflowUnavailable();
        a.acknowledgment = "recorded"; a.evidenceIds.push(e.id);
      }
    }
    const sent = [...attempts.values()].filter(a => a.result === "sent");
    records.push({ caseId, ...opening.data, ownerId, openedAt: opening.occurredAt, assignmentHistory,
      blockers: [...blockers.values()], attempts: [...attempts.values()], firstSentAt: sent[0]?.at ?? null,
      evidenceIds: all.map(e => e.id), revision: draftReviewHash(all.map(draftReviewHash)) });
  }
  return records.sort((a, b) => a.caseId.localeCompare(b.caseId));
}

function state(record, asOf) {
  const open = record.blockers.filter(b => b.resolvedAt === null);
  const last = record.attempts.at(-1);
  const issues = open.map(b => ({ code: b.category, since: b.openedAt, evidenceIds: b.evidenceIds }));
  if (last?.result === "failed") issues.push({ code: "handoff_failed", since: last.at, evidenceIds: last.evidenceIds });
  if (last?.result === "sent" && last.acknowledgment === "unknown") issues.push({ code: "acknowledgment_unknown", since: last.at, evidenceIds: last.evidenceIds });
  return { open, issues, latestHandoff: last ? { result: last.result, acknowledgment: last.acknowledgment } : { result: "not_recorded", acknowledgment: "unknown" },
    elapsedMinutes: minutes(record.openedAt, asOf) };
}
const inScope = (r, g) => g.teamIds.includes(r.teamId) && g.communityIds.includes(r.communityId);

export function projectRoleView(records, grant, operation, feed) {
  const scoped = records.filter(r => inScope(r, grant));
  if (operation === "workflow_trend") return trend(scoped, feed);
  const selected = operation === "assessor_work" ? scoped.filter(r => r.ownerId === grant.subjectId && grant.caseIds.includes(r.caseId)) : scoped;
  const items = selected.map(r => {
    const s = state(r, feed.completeThrough);
    const common = { caseId: r.caseId, ownerId: r.ownerId, teamId: r.teamId, communityId: r.communityId, sourceRevision: r.revision,
      elapsedMinutes: s.elapsedMinutes, issues: s.issues, latestHandoff: s.latestHandoff, sourceEvidenceIds: r.evidenceIds };
    if (operation === "team_exceptions") return common;
    return { ...common, summary: r.summary,
      preparation: s.open.length ? s.open.map(b => ({ kind: "clarification_draft", question: b.question, evidenceIds: b.evidenceIds,
        nextStep: "Verify the information and record the resolution in Pipeline.", sourceUpdate: "not_performed" })) :
        [{ kind: "next_step", question: null, evidenceIds: r.evidenceIds, nextStep: s.latestHandoff.result === "sent" ?
          s.latestHandoff.acknowledgment === "recorded" ? "Receiving acknowledgment is recorded. Check remaining source requirements before treating the case as complete." :
            "Verify the receiving team's acknowledgment; a recorded send does not establish receipt." : s.latestHandoff.result === "failed" ?
            "Inspect the failed handoff in Pipeline; confirm the recipient and explicitly retry through the owning app." :
            "Review the current assessment and remaining source requirements before preparing a handoff.", sourceUpdate: "not_performed" }],
      relationships: [{ subject: r.caseId, predicate: "assigned_to", object: r.ownerId }, ...s.open.map(b => ({ subject: r.caseId, predicate: "blocked_by", object: b.blockerId }))] };
  });
  return { kind: operation, cases: operation === "team_exceptions" ? items.filter(r => r.issues.length) : items,
    coverage: { authorizedCases: selected.length, source: "complete" }, asOf: feed.completeThrough,
    authority: "read_investigate_draft", sourceMutation: false };
}

function trend(records, feed) {
  const periods = WORKFLOW_TREND_POLICY.periods.map(period => {
    const cohort = records.filter(r => r.openedAt >= period.from && r.openedAt < period.through);
    const periodStatus = period.through <= feed.completeThrough ? "closed" : "provisional";
    // Whole-cell suppression: no complementary totals, rates or partial statistics
    // are emitted for small cohorts. These fixed queries are not a general privacy budget.
    if (cohort.length < WORKFLOW_TREND_POLICY.minimumCohort) return { period: period.id, from: period.from, through: period.through, periodStatus, status: "suppressed", measures: null };
    const sent = cohort.filter(r => r.firstSentAt !== null), durations = sent.map(r => minutes(r.openedAt, r.firstSentAt)).sort((a, b) => a - b);
    const median = durations.length ? (durations[Math.floor((durations.length - 1) / 2)] + durations[Math.floor(durations.length / 2)]) / 2 : null;
    return { period: period.id, from: period.from, through: period.through, periodStatus, status: "available",
      measures: { cases: cohort.length, casesWithRecordedSend: sent.length, pendingRecordedSend: cohort.length - sent.length,
        casesWithBlocker: cohort.filter(r => r.blockers.length).length, blockerDenominator: cohort.length,
        casesWithUnresolvedBlockers: cohort.filter(r => r.blockers.some(b => b.resolvedAt === null)).length,
        casesWithUnknownAcknowledgment: cohort.filter(r => r.attempts.some(a => a.result === "sent" && a.acknowledgment === "unknown")).length,
        medianMinutesToFirstRecordedSend: sent.length >= WORKFLOW_TREND_POLICY.minimumCohort ? median : null,
        durationStatus: sent.length >= WORKFLOW_TREND_POLICY.minimumCohort ? "available" : "suppressed",
        sentCaseDenominator: sent.length } };
  });
  return { kind: "workflow_trend", metric: structuredClone(WORKFLOW_TREND_POLICY), periods,
    lineage: { application: "pipeline", asOf: feed.completeThrough, coverage: "complete", queryRevision: draftReviewHash(WORKFLOW_TREND_POLICY) },
    recordDrilldown: "not_authorized", causalConclusion: "not_established", sourceMutation: false };
}
