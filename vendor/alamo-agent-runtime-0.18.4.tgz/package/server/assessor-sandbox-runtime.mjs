import path from "node:path";
import { createAssessorSandboxService } from "./assessor-sandbox.mjs";
import { createAssessorSandboxStore } from "./assessor-sandbox-store.mjs";
import { createEveryAgentPersistence } from "./everyagent-persistence.mjs";
import { createDraftReviewStore } from "./draft-review-store.mjs";
import { createAssessmentQualityModel } from "./assessment-quality-model.mjs";
import { createSkillSelectionModel } from "./skill-selection-model.mjs";

/** @param {{enabled?:string|undefined,deploymentKind?:string|undefined,clientIds:string[],processExecution?:any,model?:any,selector?:any}} options */
export function createAssessorSandboxRuntime({ enabled, deploymentKind, clientIds, processExecution=null,model=null,selector=null }) {
  if (enabled !== undefined && enabled !== "false" && enabled !== "true") throw new Error("Invalid assessor sandbox setting.");
  if (enabled !== "true") return null;
  if (deploymentKind !== "sandbox" || !clientIds.length) throw new Error("Assessor sandbox requires an explicit sandbox host and registered chat clients.");
  return createAssessorSandboxService({
    store: createAssessorSandboxStore(createEveryAgentPersistence({ localPath: path.resolve("generated/everyagent/assessor-sandbox-v1.json"), blobPath: "everyagent/assessor-sandbox-v1.json" })),
    drafts: createDraftReviewStore(createEveryAgentPersistence({ localPath: path.resolve("generated/everyagent/assessor-sandbox-drafts-v1.json"), blobPath: "everyagent/assessor-sandbox-drafts-v1.json" })),
    model: model??createAssessmentQualityModel(), selector: selector??createSkillSelectionModel(), clientIds,processExecution,
  });
}
