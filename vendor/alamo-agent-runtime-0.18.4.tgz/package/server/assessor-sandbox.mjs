import { randomUUID } from "node:crypto";
import { everyAgentActor } from "./everyagent-access.mjs";
import { createHttpError } from "./http-error-contract.mjs";
import { validateConversationCommand } from "../shared/everyagent-conversations.mjs";
import { foundationObject } from "../shared/foundation-contracts.mjs";
import { draftReviewHash, draftReviewId, validateDraftReviewCommand } from "../shared/draft-review-contracts.mjs";
import { validateWorkContextRequest, verifyWorkContext } from "../shared/work-context-contracts.mjs";
import { createSkillRunner } from "./skill-runner.mjs";
import { createAssessorSkillPack } from "./assessor-skill-pack.mjs";
import { readAssessmentQualityDraft, reviewAssessmentQualityDraft } from "./assessment-quality-review.mjs";
import { createAssessorFollowThrough } from "./assessor-follow-through.mjs";
import { sandboxPacket } from "./assessor-sandbox-fixture.mjs";
import {PROCESS_CONFIGURATION_ACTIONS} from './proforma-execution-configuration.mjs';

const hidden = () => createHttpError(404, "not_found", "Sandbox access is unavailable.");
const conflict = () => createHttpError(409, "conversation_changed", "This chat changed. Refresh before continuing.");
const paragraph = text => ({ kind: "answer", text, sourceIds: [] });
const stopText = {
  clarify_request: "What would you like prepared: an answer-quality review, clarification questions, or a handoff draft?",
  decline_action: "This sandbox can prepare drafts. Sending, signing, committing source records and accepting reviews through chat are unavailable.",
  wait_for_review: "Review the saved quality proposal before preparing the next stage.",
  wait_for_source: "The fictional source has not changed. A chat message cannot resolve its open questions.",
};

/** @param {{store:any,drafts:any,model:any,selector:any,clientIds:string[],now?:()=>number,processExecution?:any}} options */
export function createAssessorSandboxService({ store, drafts, model, selector, clientIds, now = Date.now, processExecution=null }) {
  const clients = new Set(clientIds);
  function actor(auth) {
    const userId = everyAgentActor(auth), clientId = String(auth.claims.azp ?? "").toLowerCase();
    if (!clients.has(clientId) || !Number.isFinite(auth.claims.exp) || auth.claims.exp * 1000 <= now()) throw hidden();
    return { userId, clientId, tenantId: auth.claims.tid };
  }
  function authorized(auth, session) {
    const a = actor(auth);
    if (!session || a.userId !== session.userId || a.tenantId !== session.tenantId || a.clientId !== session.clientId || Date.parse(session.expiresAt) <= now()) throw hidden();
    return session;
  }
  async function sessionFor(auth, id) {
    draftReviewId(id); actor(auth);
    const session=authorized(auth, (await store.read()).value.sessions.find(s => s.id === id));
    if(session.processBinding){if(!processExecution||model.model!==session.processBinding.models.quality||selector.model!==session.processBinding.models.selection)throw hidden();await processExecution.assertCurrent(auth,session.processBinding);}
    return session;
  }
  const requestFor = session => {
    const context = sandboxPacket(session, now()).context;
    return { scope: context.snapshot.scope, resourceScope: context.snapshot.resourceScope, source: context.snapshot.source };
  };
  function dependencies(auth, session, activeTurn = null) {
    const boundModel=session.processBinding?{...model,review:async packet=>{const result=await model.review(packet);if(result.requestedModel!==session.processBinding.models.quality)throw hidden();return result;}}:model;
    return { store: drafts, model:boundModel, now, readPacket: async input => {
      const current = await sessionFor(auth, session.id);
      if (activeTurn) {
        const turn = current.turns.find(t => t.id === activeTurn);
        if (!turn || turn.status !== "working" || turn.deadline <= now()) throw hidden();
      }
      const request = validateWorkContextRequest(input), expected = requestFor(current);
      if (draftReviewHash(request) !== draftReviewHash(expected)) throw hidden();
      const packet = sandboxPacket(current, now()); verifyWorkContext(packet.context, request, now()); return packet;
    } };
  }
  async function artifactFor(auth, session, turn) {
    const result = turn.result;
    if (!result?.artifactId || turn.status !== "complete") return null;
    const deps = dependencies(auth, session), request = requestFor(session);
    if (result.choice === "assessment-answer-quality") return readAssessmentQualityDraft(result.artifactId, request, deps);
    if (!turn.parentId || !["assessor-clarification", "assessor-handoff"].includes(result.choice)) throw hidden();
    return createAssessorFollowThrough({ qualityDraftId: turn.parentId, ...deps }).read(result.choice === "assessor-clarification" ? "clarification" : "handoff", result.artifactId, request);
  }
  async function expire() {
    await store.update(state => {
      let changed = false;
      for (const s of state.sessions) for (const t of s.turns) if (t.status === "working" && t.deadline <= now()) { t.status = "interrupted"; s.version++; changed = true; }
      return changed;
    });
  }
  async function read(auth, id = /** @type {string | null} */ (null)) {
    const a = actor(auth); await expire();
    if (id === null) {
      const candidates = (await store.read()).value.sessions.filter(s => s.userId === a.userId && s.clientId === a.clientId && s.tenantId === a.tenantId && Date.parse(s.expiresAt) > now());
      const sessions=[];for(const s of candidates){if(s.processBinding){try{await sessionFor(auth,s.id);}catch{continue;}}sessions.push(s);}
      return { modelAvailable: Boolean(model.available && selector.available), conversations: sessions.map(s => ({ id: s.id, title: `Fictional Pipeline · ${s.scenario.replace("synthetic-", "")}`, createdAt: s.createdAt, locked: false })) };
    }
    const session = await sessionFor(auth, id), turns = [];
    for (const t of session.turns) {
      const artifact = await artifactFor(auth, session, t);
      const texts = artifact ? formatDraft(t.result.choice, artifact.draft) : t.result ? [stopText[t.result.reason] ?? "The run stopped without a usable draft. Refresh before trying again."] : [];
      turns.push({ id: t.id, text: t.text, status: t.status, createdAt: t.createdAt,
        ...(t.status === "complete" ? { answer: { paragraphs: texts.map(paragraph) } } : {}),
        ...(artifact ? { draftReview: { artifactId: artifact.id, artifactRevision: artifact.artifactRevision, decision: artifact.humanReview?.decision ?? null } } : {}),
        ...(t.events.length ? { trace: { runId: t.events[0].runId, events: t.events } } : {}) });
    }
    await sessionFor(auth, id);
    return { id, version: session.version, createdAt: session.createdAt, scope: [{ skillId: "assessment-review", communityIds: [] }], workId: session.scenario, turns,
      ...(session.processBinding?{processBinding:structuredClone(session.processBinding),processOutcome:{sourceWork:'unconfirmed',delivery:'not_performed',humanSteps:session.processBinding.stepBindings.filter(s=>s.stage==='human').map(s=>s.stepIndex)}}:{}) };
  }
  /** @param {any} auth @param {any} input @param {any} processBinding */
  async function create(auth, input, processBinding=null) {
    const a = actor(auth);
    if(processBinding){if(!processExecution||model.model!==processBinding.models.quality||selector.model!==processBinding.models.selection)throw hidden();await processExecution.assertCurrent(auth,processBinding);}
    if (input.skillIds.length !== 1 || input.skillIds[0] !== "assessment-review" || !["synthetic-initial", "synthetic-partial", "synthetic-ready"].includes(input.workId)) throw createHttpError(400, "sandbox_case_invalid", "Choose a fictional Pipeline example.");
    const requestHash = draftReviewHash(processBinding?{input,processBinding}:input), candidate = { ...a, id: randomUUID(), requestId: input.requestId, requestHash,
      scenario: input.workId, createdAt: new Date(now()).toISOString(), expiresAt: new Date(now() + 3600000).toISOString(), version: 0, qualityDraftId: null, turns: [],...(processBinding?{processBinding:structuredClone(processBinding)}:{}) };
    const state = await store.update(value => {
      actor(auth);
      const prior = value.sessions.find(s => s.userId === a.userId && s.clientId === a.clientId && s.requestId === input.requestId);
      if (prior) { authorized(auth, prior); if (prior.requestHash !== requestHash) throw conflict(); return false; }
      if (value.sessions.length >= 10) throw createHttpError(409, "conversation_capacity", "The sandbox session limit has been reached.");
      value.sessions.push(candidate); return true;
    });
    return read(auth, state.sessions.find(s => s.userId === a.userId && s.clientId === a.clientId && s.requestId === input.requestId).id);
  }
  async function send(auth, input) {
    await expire();
    const session = await sessionFor(auth, input.conversationId);
    if (input.text.length > 2000) throw createHttpError(400, "sandbox_message_invalid", "Keep sandbox requests under 2,000 characters.");
    const requestHash = draftReviewHash({ conversationId: input.conversationId, text: input.text });
    const prior = session.turns.find(t => t.id === input.requestId);
    if (prior) { if (prior.requestHash !== requestHash) throw conflict(); return read(auth, session.id); }
    if (!model.available || !selector.available) throw createHttpError(503, "conversation_model_unavailable", "Sandbox models are not configured.");
    let claimed = false;
    const state = await store.update(value => {
      claimed = false;
      const current = authorized(auth, value.sessions.find(s => s.id === session.id));
      const prior = current.turns.find(t => t.id === input.requestId);
      if (prior) { if (prior.requestHash !== requestHash) throw conflict(); return false; }
      if (current.version !== input.expectedVersion || current.turns.some(t => t.status === "working")) throw conflict();
      if (current.turns.length >= 20) throw createHttpError(409, "conversation_capacity", "The sandbox chat limit has been reached.");
      const all = value.sessions.filter(s => s.userId === current.userId).flatMap(s => s.turns);
      if (all.filter(t => t.status === "working").length >= 2 || all.length >= 50) throw createHttpError(429, "conversation_budget", "The sandbox run limit has been reached.");
      current.turns.push({ id: input.requestId, requestHash, text: input.text, createdAt: new Date(now()).toISOString(), deadline: now() + 120000,
        parentId: current.qualityDraftId, status: "working", events: [], result: null });
      current.version++; claimed = true; return true;
    });
    if (!claimed) return read(auth, session.id);
    const turn = state.sessions.find(s => s.id === session.id).turns.find(t => t.id === input.requestId);
    const mutateTurn = async mutate => {await sessionFor(auth,session.id);return store.update(value => {
      const current = authorized(auth, value.sessions.find(s => s.id === session.id)), t = current.turns.find(t => t.id === input.requestId);
      if (t.status !== "working" || t.deadline <= now()) throw conflict();
      const changed = mutate(t, current); if (changed) current.version++; return changed;
    });};
    try {
      const deps = dependencies(auth, session, turn.id), request = requestFor(session);
      const boundSelector=session.processBinding?{select:async input=>{const result=await selector.select(input);if(result.requestedModel!==session.processBinding.models.selection)throw hidden();return result;}}:selector;
      const runner = createSkillRunner({ pack: createAssessorSkillPack(deps), selector:boundSelector, clock: now, traceSink: async event => {
        await mutateTurn(t => {
          if (draftReviewHash(event.scope) !== draftReviewHash(request.scope) || event.requestRevision !== draftReviewHash(request)) throw hidden();
          if (event.sequence < t.events.length) { if (draftReviewHash(t.events[event.sequence]) !== draftReviewHash(event)) throw conflict(); return false; }
          if (event.sequence !== t.events.length || (t.events.length && t.events[0].runId !== event.runId)) throw conflict();
          t.events.push(event); return true;
        });
      } });
      const result = await runner.run({ request, instruction: input.text, parentArtifactId: turn.parentId });
      await mutateTurn((t, current) => {
        if (t.events.at(-1)?.event !== "completed" || t.events.at(-1)?.runId !== result.runId) throw conflict();
        t.result = { runId: result.runId, choice: result.choice, status: result.status, reason: result.reason, artifactId: result.artifact?.id ?? null };
        t.status = "complete";
        if (result.artifact && result.choice === "assessment-answer-quality") current.qualityDraftId = result.artifact.id;
        return true;
      });
    } catch {
      await store.update(value => {
        const current = authorized(auth, value.sessions.find(s => s.id === session.id)), t = current.turns.find(t => t.id === input.requestId);
        if (t.status !== "working") return false;
        t.status = t.deadline <= now() ? "interrupted" : "failed"; current.version++; return true;
      });
    }
    return read(auth, session.id);
  }
  async function review(auth, raw) {
    const v = foundationObject(raw, ["action", "conversationId", "turnId", "requestId", "expectedArtifactRevision", "decision"]);
    const id = draftReviewId(v.conversationId), turnId = draftReviewId(v.turnId);
    const command = validateDraftReviewCommand({ requestId: v.requestId, expectedArtifactRevision: v.expectedArtifactRevision, decision: v.decision });
    const session = await sessionFor(auth, id), turn = session.turns.find(t => t.id === turnId);
    if (!turn || turn.status !== "complete" || !turn.result?.artifactId || session.turns.some(t => t.status === "working")) throw conflict();
    const artifact = await artifactFor(auth, session, turn);
    if (!artifact) throw hidden();
    const deps = dependencies(auth, session), request = requestFor(session);
    try {
      if (turn.result.choice === "assessment-answer-quality") await reviewAssessmentQualityDraft(artifact.id, command, request, deps);
      else await createAssessorFollowThrough({ qualityDraftId: turn.parentId, ...deps }).review(turn.result.choice === "assessor-clarification" ? "clarification" : "handoff", artifact.id, request, command);
    } catch (error) {
      if (error && typeof error === "object" && "code" in error && error.code === "DRAFT_REVIEW_CONFLICT") throw conflict();
      throw error;
    }
    return read(auth, id);
  }
  return { read, async command(auth, raw) {
    actor(auth);
    if(PROCESS_CONFIGURATION_ACTIONS.includes(raw?.action)){
      if(typeof processExecution?.configurationCommand!=='function')throw hidden();
      return processExecution.configurationCommand(auth,raw);
    }
    if(raw?.action==='preview_process'||raw?.action==='create_from_process'){
      if(!processExecution)throw hidden();let v;
      try{v=foundationObject(raw,raw.action==='preview_process'?['action','executionId']:['action','requestId','executionId','expectedPlanHash']);draftReviewId(v.executionId);if(v.action==='create_from_process')draftReviewId(v.requestId);}
      catch{throw createHttpError(400,'process_command_invalid','Choose a valid reviewed process binding.');}
      if(v.action==='preview_process')return processExecution.preview(auth,{executionId:v.executionId});
      const binding=await processExecution.bind(auth,{executionId:v.executionId,expectedPlanHash:v.expectedPlanHash});
      return create(auth,{action:'create',requestId:v.requestId,skillIds:['assessment-review'],workId:'synthetic-ready'},binding);
    }
    if (raw?.action === "review_draft") return review(auth, raw);
    let input;
    try { input = validateConversationCommand(raw); } catch { throw createHttpError(400, "conversation_command_invalid", "Choose a valid sandbox action."); }
    if (input.action === "create") return create(auth, input);
    if (input.action === "send") return send(auth, input);
    const canceledState = await store.update(value => {
      const current = authorized(auth, value.sessions.find(s => s.id === input.conversationId)), turn = current.turns.find(t => t.id === input.turnId);
      if (!turn) throw hidden(); if (turn.status !== "working") return false;
      turn.status = "canceled"; current.version++; return true;
    });
    return { canceled: canceledState.sessions.find(s => s.id === input.conversationId).turns.find(t => t.id === input.turnId).status === "canceled" };
  } };
}

function formatDraft(choice, draft) {
  const lines = ["Fictional Pipeline example. Draft only; no source records were changed or messages sent."];
  if (choice === "assessment-answer-quality") {
    for (const r of draft.reviews) {
      const label = r.contentId.replaceAll("_", " ");
      lines.push(`${label[0].toUpperCase()}${label.slice(1)}: ${r.assessment.replaceAll("_", " ")}.`);
      for (const f of r.findings) lines.push(f.explanation);
      if (r.wording) lines.push(`Proposed wording: ${r.wording.text}`);
      if (r.question) lines.push(`Question: ${r.question}`);
      for (const c of [...r.support, ...r.findings.flatMap(f => f.citations)]) lines.push(`${c.evidenceId.startsWith("answer.") ? "Current answer" : "Source excerpt"}: “${c.quote}”`);
    }
  } else if (choice === "assessor-clarification") {
    for (const item of draft.items) lines.push(`${item.label}: ${item.question}`);
    lines.push(draft.nextStep);
  } else {
    for (const item of draft.summary) lines.push(item.text);
    lines.push(`Pending requirements: ${draft.pending.map(r => r.label ?? r.id).join(", ") || "none supplied"}.`);
    lines.push("Receiving owner and acknowledgment remain unknown. Human source verification is still required.");
  }
  return lines;
}
