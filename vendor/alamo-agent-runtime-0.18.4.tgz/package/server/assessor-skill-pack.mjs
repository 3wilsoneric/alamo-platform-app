import { draftReviewHash, draftReviewId } from "../shared/draft-review-contracts.mjs";
import { validateAssessmentQualityPacket } from "../skills/assessment-review/quality.mjs";
import { verifyWorkContext } from "../shared/work-context-contracts.mjs";
import { assessorSkillPack, ASSESSOR_PACK_REVISION } from "../skills/assessment-review/pack.mjs";
import { prepareAssessmentQualityDraft, readAssessmentQualityDraft, assessmentQualityPacketRevision } from "./assessment-quality-review.mjs";
import { createAssessorFollowThrough, ASSESSOR_FOLLOW_THROUGH_POLICY } from "./assessor-follow-through.mjs";

// Trusted host binding. No registry discovery, URL execution, source write tool,
// default content reader or inherited metadata capability.
export function createAssessorSkillPack(deps) {
  return {
    definition: structuredClone(assessorSkillPack), revision: draftReviewHash({ pack: ASSESSOR_PACK_REVISION, followThrough: ASSESSOR_FOLLOW_THROUGH_POLICY }),
    async observe(request, parentId, readPacket) {
      if (parentId !== null) draftReviewId(parentId);
      const packet = validateAssessmentQualityPacket(await readPacket(request));
      verifyWorkContext(packet.context, request, deps.now());
      const packetRevision = assessmentQualityPacketRevision(packet);
      const quality = parentId === null ? null : await readAssessmentQualityDraft(parentId, request, { ...deps, readPacket });
      if (quality && quality.contextRevision !== packetRevision) throw new Error("Quality source changed.");
      const status = !quality ? "none" : !quality.humanReview ? "pending" : quality.humanReview.decision === "accept" ? "accepted" : "rejected";
      const questions = quality?.draft.reviews.filter(r => r.assessment !== "supported").length ?? null;
      const state = { quality: status, openQuestions: questions, sourceWork: "unconfirmed", delivery: "not_performed", receivingOwner: "unknown" };
      const eligible = ["assessment-answer-quality"];
      if (status === "accepted") eligible.push(questions ? "assessor-clarification" : "assessor-handoff");
      return { state, eligible, packetRevision,
        revision: draftReviewHash({ packetRevision, parentId, artifact: quality?.artifactRevision ?? null, review: quality?.humanReview ?? null }) };
    },
    readPacket: deps.readPacket,
    async execute(choice, request, parentId, readPacket, callModel) {
      const bounded = { ...deps, readPacket, model: { review: packet => callModel(() => deps.model.review(packet)) } };
      if (choice === "assessment-answer-quality") return prepareAssessmentQualityDraft(request, bounded);
      if (parentId === null || !["assessor-clarification", "assessor-handoff"].includes(choice)) throw new Error("Unknown activity.");
      return createAssessorFollowThrough({ qualityDraftId: parentId, ...bounded }).prepare(choice === "assessor-clarification" ? "clarification" : "handoff", request);
    },
  };
}
