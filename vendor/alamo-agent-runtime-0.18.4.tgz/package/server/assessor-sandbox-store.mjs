import { foundationObject } from "../shared/foundation-contracts.mjs";
import { draftReviewHash, draftReviewId, draftReviewJson } from "../shared/draft-review-contracts.mjs";
import {validateExecutionReference} from '../shared/proforma-execution-contracts.mjs';

const invalid = () => { throw new Error("Sandbox state is unavailable."); };
function validate(value) {
  const v = foundationObject(value, ["version", "revision", "sessions"]);
  if (v.version !== 1 || !Number.isSafeInteger(v.revision) || Number(v.revision) < 0 || !Array.isArray(v.sessions) || v.sessions.length > 10) return invalid();
  const ids = new Set();
  for (const s of v.sessions) {
    foundationObject(s, ["id", "userId", "tenantId", "clientId", "requestId", "requestHash", "scenario", "createdAt", "expiresAt", "version", "qualityDraftId", "turns",...(Object.hasOwn(s,'processBinding')?['processBinding']:[])]);
    draftReviewId(s.id); draftReviewId(s.userId); draftReviewId(s.tenantId); draftReviewId(s.clientId); draftReviewId(s.requestId);
    if(s.processBinding!==undefined){const p=validateExecutionReference(s.processBinding);if(p.actorId!==`entra:${s.tenantId}:${s.userId}`||p.scope.tenantId!==s.tenantId||s.scenario!=='synthetic-ready')return invalid();}
    if (ids.has(s.id) || !Number.isSafeInteger(s.version) || s.version < 0 || !Array.isArray(s.turns) || s.turns.length > 20 || !["synthetic-initial", "synthetic-partial", "synthetic-ready"].includes(s.scenario)) return invalid();
    if (!Number.isFinite(Date.parse(s.createdAt)) || !Number.isFinite(Date.parse(s.expiresAt))) return invalid();
    ids.add(s.id); if (s.qualityDraftId !== null) draftReviewId(s.qualityDraftId);
    const turns = new Set();
    for (const t of s.turns) {
      foundationObject(t, ["id", "requestHash", "text", "createdAt", "deadline", "parentId", "status", "events", "result"]);
      draftReviewId(t.id); if (t.parentId !== null) draftReviewId(t.parentId);
      if (turns.has(t.id) || typeof t.text !== "string" || t.text.length > 2000 || !Number.isFinite(t.deadline) || !["working", "complete", "failed", "interrupted", "canceled"].includes(t.status) || !Array.isArray(t.events) || t.events.length > 5) return invalid();
      turns.add(t.id);
      for (const [i, event] of t.events.entries()) {
        draftReviewId(event.runId);
        if (event.sequence !== i || (i && event.runId !== t.events[0].runId) || !["started", "observed", "selected", "activity_started", "completed"].includes(event.event)) return invalid();
        if (event.scope.subjectId !== s.userId || event.scope.tenantId !== s.tenantId) return invalid();
        draftReviewJson(event);
      }
      if (t.result !== null) draftReviewJson(t.result);
    }
    draftReviewJson(s);
  }
  if (Buffer.byteLength(JSON.stringify(value)) > 2_000_000) return invalid();
  return /** @type {{version:number,revision:number,sessions:any[]}} */ (value);
}

// Separate sandbox collection, using the existing file-lock/Blob-ETag adapter.
// No default persistence: the host must explicitly choose isolated storage.
export function createAssessorSandboxStore(persistence) {
  async function read() {
    const snapshot = await persistence.read();
    return { value: validate(snapshot.value ?? { version: 1, revision: 0, sessions: [] }), version: snapshot.version };
  }
  async function update(mutate) {
    for (let attempt = 0; attempt < 6; attempt++) {
      const { value, version } = await read(), before = structuredClone(value);
      const changed = await mutate(value);
      if (!changed) { if (JSON.stringify(before) !== JSON.stringify(value)) return invalid(); return value; }
      if (value.revision !== before.revision) return invalid();
      value.revision++; validate(value);
      for (const old of before.sessions) {
        const current = value.sessions.find(s => s.id === old.id);
        if (!current || current.version < old.version) return invalid();
        for (const key of ["id", "userId", "tenantId", "clientId", "requestId", "requestHash", "scenario", "createdAt", "expiresAt"]) if (current[key] !== old[key]) return invalid();
        if(draftReviewHash(current.processBinding??null)!==draftReviewHash(old.processBinding??null))return invalid();
        for (const prior of old.turns) {
          const next = current.turns.find(t => t.id === prior.id);
          if (!next || next.events.length < prior.events.length) return invalid();
          for (const key of ["id", "requestHash", "text", "createdAt", "deadline", "parentId"]) if (next[key] !== prior[key]) return invalid();
          if (prior.status !== "working" && draftReviewHash(next) !== draftReviewHash(prior)) return invalid();
          if (prior.events.some((e, i) => draftReviewHash(e) !== draftReviewHash(next.events[i]))) return invalid();
        }
      }
      try { await persistence.write(value, version); return value; }
      catch (error) {
        if (!error || typeof error !== "object" || !("code" in error) || error.code !== "EVERYAGENT_CONFLICT" || attempt === 5) throw error;
        await new Promise(resolve => setTimeout(resolve, 20 * (attempt + 1)));
      }
    }
    return invalid();
  }
  return { read, update };
}
