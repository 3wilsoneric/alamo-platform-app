import { createHash } from "node:crypto";
import { validateWorkContextRequest, verifyWorkContext, workContextInvalid } from "../shared/work-context-contracts.mjs";
import { draftAssessorSupport } from "../skills/assessment-review/work-context.mjs";

// Future activity functions, deliberately not registered with HTTP or the worker.
// The mandatory reader owns authorization; there is no default live adapter.
const digest = value => createHash("sha256").update(JSON.stringify(value)).digest("hex");
export function workContextRevision(context) {
  const { snapshot, ...rest } = context;
  // Observation time can advance on reread. Content, source/grant/assignment
  // revisions, expiry, coverage and scope must still match byte-for-byte.
  const { observedAt: _observedAt, asOf: _asOf, ...stable } = snapshot;
  return digest({ snapshot: stable, ...rest });
}
function artifact(context) {
  return { schemaVersion: 1, contextRevision: workContextRevision(context), draft: draftAssessorSupport(context) };
}
async function read(request, deps) {
  if (typeof deps?.readContext !== "function" || typeof deps?.now !== "function") return workContextInvalid();
  try { return verifyWorkContext(await deps.readContext(request), request, deps.now()); }
  catch { return workContextInvalid(); } // no source/private error text escapes
}
export async function prepareAssessorWork(value, deps) {
  const request = validateWorkContextRequest(value);
  const context = await read(request, deps);
  const candidate = artifact(context);
  const current = await read(request, deps);
  if (candidate.contextRevision !== workContextRevision(current)) return workContextInvalid();
  return candidate;
}
export async function readAssessorDraft(candidate, value, deps) {
  const request = validateWorkContextRequest(value);
  const current = artifact(await read(request, deps));
  // Reconstructing also rejects altered text, invented citations or a changed
  // policy version. A context hash alone would not protect draft contents.
  if (JSON.stringify(candidate) !== JSON.stringify(current)) return workContextInvalid();
  return current;
}
export async function reviewAssessorDraft(candidate, decision, value, deps) {
  if (!["accept", "reject"].includes(decision)) return workContextInvalid();
  const reviewed = await readAssessorDraft(candidate, value, deps);
  return { ...reviewed, humanReview: { decision, subjectId: reviewed.draft.scope.subjectId,
    reviewedAt: new Date(deps.now()).toISOString() },
    status: decision === "accept" ? "draft_reviewed" : "draft_rejected", sourceWork: "unconfirmed" };
}
