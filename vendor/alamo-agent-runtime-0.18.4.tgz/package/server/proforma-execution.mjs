import {maintenanceHash as hash,maintenanceObject as object,maintenanceId as id,maintenanceDigest as digest} from '../shared/proforma-maintenance-contracts.mjs';
import {validateAutomationDefinition} from '../shared/proforma-automation-contracts.mjs';
import {validateExecutionDefinition,validateExecutionReference,executionDefinitionHash,PROFORMA_REFERRAL_CAPABILITY} from '../shared/proforma-execution-contracts.mjs';
import {ASSESSOR_PACK_REVISION} from '../skills/assessment-review/pack.mjs';
import {ASSESSOR_FOLLOW_THROUGH_POLICY} from './assessor-follow-through.mjs';
import {SKILL_RUNNER_VERSION} from './skill-runner.mjs';
import {SKILL_SELECTION_REVISION} from './skill-selection-model.mjs';
import {everyAgentActor} from './everyagent-access.mjs';
import {createHttpError} from './http-error-contract.mjs';

export const proformaReferralCapability=Object.freeze({id:PROFORMA_REFERRAL_CAPABILITY,
  revision:hash({pack:ASSESSOR_PACK_REVISION,followThrough:ASSESSOR_FOLLOW_THROUGH_POLICY,runner:SKILL_RUNNER_VERSION,selection:SKILL_SELECTION_REVISION}),
  mode:'synthetic-only',authority:'read_investigate_draft',
  phases:['Prepare a current answer-quality draft.','A person reviews that exact draft.','Prepare clarification questions or a handoff draft from the reviewed answers.','A person reviews the resulting draft.'],
  sourceWork:'unconfirmed',delivery:'not_performed',receivingAcceptance:'source-required'});
const unavailable=()=>createHttpError(409,'process_execution_unavailable','The reviewed process binding is unavailable or changed. Refresh its plan.');

// This factory consumes server-owned, separately reviewed execution mappings.
// Source prose, document approval and browser input cannot register capabilities.
// It augments the existing sandbox/skill runner; it is not a second executor.
export function createProFormaExecution({definitions,sourceFor}){
  if(typeof definitions!=='function'||typeof sourceFor!=='function')throw new Error('Explicit process execution configuration and source identity are required.');
  async function configured(auth,executionId){
    const user=everyAgentActor(auth);id(executionId);const raw=await definitions(auth);
    if(!Array.isArray(raw)||raw.length>50)throw unavailable();const values=raw.map(validateExecutionDefinition);
    if(new Set(values.map(v=>v.id)).size!==values.length)throw unavailable();
    const d=values.find(v=>v.id===executionId),actorId=`entra:${auth.claims.tid}:${user}`;
    if(!d||!d.enabled||d.sourceBinding.actorId!==actorId||d.sourceBinding.scope.tenantId!==auth.claims.tid||d.capability.revision!==proformaReferralCapability.revision)throw unavailable();return d;
  }
  async function inspect(auth,executionId){
    const d=await configured(auth,executionId),expected={documentId:d.source.documentId,publicationId:d.source.publicationId,fingerprint:d.source.fingerprint};
    const envelope=validateAutomationDefinition(await sourceFor(d.sourceBinding,auth).read(expected),d.sourceBinding,expected);
    const macro=envelope.definition.requests.find(r=>r.id===d.source.macroId);
    if(envelope.definitionHash!==d.source.definitionHash||!macro||hash(macro)!==d.source.macroHash||d.stepBindings.length!==macro.request.steps.length)throw unavailable();
    if(executionDefinitionHash(await configured(auth,executionId))!==executionDefinitionHash(d))throw unavailable();
    const plan={schemaVersion:1,kind:'proforma.execution-plan',executionId:d.id,configurationHash:executionDefinitionHash(d),scope:d.sourceBinding.scope,actorId:d.sourceBinding.actorId,
      source:d.source,macro:macro.request,stepBindings:d.stepBindings,capability:proformaReferralCapability,models:d.models,evaluationDigest:d.evaluationDigest,review:{actorId:d.review.actorId,at:d.review.at}};
    const planHash=hash(plan),reference=validateExecutionReference({schemaVersion:1,kind:'proforma.execution-reference',mode:'synthetic-only',executionId:d.id,configurationHash:plan.configurationHash,planHash,scope:plan.scope,actorId:plan.actorId,source:plan.source,capability:d.capability,models:d.models,evaluationDigest:d.evaluationDigest,stepBindings:plan.stepBindings,review:plan.review,macroTitle:macro.request.name});
    return {plan,planHash,reference};
  }
  const protect=operation=>async(...args)=>{try{return await operation(...args);}catch{throw unavailable();}};
  return {
    preview:protect(async(auth,input)=>{const v=object(input,['executionId']);return inspect(auth,id(v.executionId));}),
    bind:protect(async(auth,input)=>{const v=object(input,['executionId','expectedPlanHash']);digest(v.expectedPlanHash);const result=await inspect(auth,v.executionId);if(result.planHash!==v.expectedPlanHash)throw unavailable();return result.reference;}),
    assertCurrent:protect(async(auth,input)=>{const reference=validateExecutionReference(input),result=await inspect(auth,reference.executionId);if(hash(reference)!==hash(result.reference))throw unavailable();return result.reference;}),
  };
}
