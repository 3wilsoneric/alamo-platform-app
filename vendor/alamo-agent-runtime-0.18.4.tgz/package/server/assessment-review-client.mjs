import { createHash } from "node:crypto";
import { createSourceTransport } from "./everyagent-source-client.mjs";
import { ASSESSMENT_REVIEW_PATH, assessmentReviewRequest, validateAssessmentReviewPage } from "../shared/assessment-review-contracts.mjs";
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
import { everyAgentFingerprint } from "./everyagent-adapters.mjs";
import { PIPELINE_METADATA_MAX_BYTES, metadataFields, validatePipelineManifest } from "../shared/pipeline-metadata-contracts.mjs";

const sameGrant = (a, b) => a.application === b.application && a.id === b.id && a.revision === b.revision;
const unavailable = () => new Error("Pipeline access could not be verified. Previous results are retained.");

export function assessmentReviewEntry(row, observedAt) {
  const a = row.assessment;
  const notes = [];
  const declined = row.decision === "declined" || row.workflowStatus === "declined";
  if (declined && !row.reasonCodePresent && !row.reasonNotePresent) notes.push("Declined without a documented decision reason; verify the source decision. An early decline can be legitimate.");
  if (row.assessmentState === "absent" && !["closed", "admitted", "declined"].includes(row.workflowStatus)) notes.push("No canonical assessment is recorded; check the next assessment step.");
  if (row.assessmentState === "legacy_unavailable") notes.push("A legacy assessment exists; its review data is unavailable through this connector.");
  if (a) {
    if (!a.signedAt && !declined) notes.push("Assessment is unsigned; follow up on the current workflow step.");
    if (a.signedAt && a.authorship.state === "verified" && a.authorship.distinctFields <= 2) notes.push(`Signed with ${a.authorship.distinctFields} distinct answer fields authored by the assigned assessor after the latest import or revision baseline; inspect the source evidence. This is not an effort or misconduct finding.`);
    if (a.authorship.state === "unknown") notes.push(`Authorship history is incomplete; ${a.authorship.observedDistinctFields} distinct authored fields are verified in the available events. The total is unknown.`);
    if (a.signedAt && a.sendStatus === "unconfirmed") notes.push("Signed; Meet the Client delivery is unconfirmed. Verify delivery in Pipeline.");
    notes.push(`Provenance: ${a.provenance}.`);
    if (a.completion.state === "unsupported_version") notes.push("Completion unavailable: the recorded questionnaire version is unsupported.");
    else notes.push(`Completion: ${a.completion.complete}/${a.completion.total}; narrative presence: ${a.completion.narrativePresent}/${a.completion.narrativeTotal}.${a.completion.state === "current_rules_only" ? " Evaluated under current rules; the historical questionnaire version is unknown." : ""}`);
    if (a.authorship.state === "verified" && a.authorship.distinctFields > 2) notes.push(`${a.authorship.distinctFields} distinct answer fields authored by the assigned assessor after the latest import or revision baseline.`);
  }
  return { key: `referral-${row.referralId}`, fingerprint: everyAgentFingerprint(row), communityIds: [],
    title: `Referral #${row.referralId}: assessment review`, summary: `Workflow: ${row.workflowStatus}; decision: ${row.decision}. ${notes.join(" ")}`,
    evidence: [{ id: `pipeline-referral-${row.referralId}`, kind: "referral", label: `Open referral #${row.referralId}`,
      href: `https://alamo-pipeline.com/?view=referrals&screen=packet&referralId=${row.referralId}&workspaceView=workflow`, observedAt }], relationships: [] };
}

export function createAssessmentReviewClient(config) {
  if (config.application !== "pipeline") throw unavailable();
  const request = createSourceTransport({ ...config, endpoint: config.endpoint ?? ASSESSMENT_REVIEW_PATH });
  const metadataRequest = createSourceTransport({ ...config, endpoint: config.endpoint ?? ASSESSMENT_REVIEW_PATH, maximumBytes: PIPELINE_METADATA_MAX_BYTES });
  const now = config.now ?? (() => Date.now());
  async function call(assignment, operation, cursor = null) {
    try {
      const input = assessmentReviewRequest(assignment, operation, cursor);
      const envelope = await request(input);
      if (JSON.stringify(Object.fromEntries(Object.keys(input).map(key => [key, envelope[key]]))) !== JSON.stringify(input)) throw unavailable();
      const grant = validateAgentSourceGrant(envelope.grant);
      if (grant.application !== "pipeline" || Date.parse(grant.expiresAt) <= now()) throw unavailable();
      return { grant, page: operation === "read" ? validateAssessmentReviewPage(envelope.page) : null };
    } catch { throw unavailable(); }
  }
  async function authorize(assignment, expected = /** @type {ReturnType<typeof validateAgentSourceGrant> | null} */ (null)) {
    const { grant } = await call(assignment, "authorize");
    if (expected && !sameGrant(grant, expected)) throw unavailable();
    return grant;
  }
  async function read(assignment) {
    let cursor = null, grant = null, total = null;
    const seen = new Set(), entries = [], rulesVersions = new Set();
    let sourceCheckedAt = null;
    const started = now();
    for (let index = 0; index < 20; index++) {
      if (now() - started > 90_000) throw unavailable();
      const result = await call(assignment, "read", cursor), page = result.page;
      if (grant && (!sameGrant(grant, result.grant) || total !== page.total)) throw unavailable();
      grant = result.grant; total = page.total;
      if (Date.parse(page.asOf) > now() + 5000 || Date.parse(page.startedAt) < started - 5000) throw unavailable();
      sourceCheckedAt ??= page.startedAt; // Earliest observation; pages are live reads, not one database snapshot.
      for (const row of page.records) {
        if (seen.has(row.referralId)) throw unavailable();
        if (row.assessment) rulesVersions.add(row.assessment.completion.rulesVersion);
        seen.add(row.referralId); entries.push(assessmentReviewEntry(row, page.asOf));
      }
      if (!page.nextCursor) {
        if (entries.length !== total) throw unavailable();
        await authorize(assignment, grant);
        return { connection: "connected", issue: null, sourceCheckedAt, sourceGrant: grant, entries,
          coverage: { version: 1, recordsExpected: total, recordsReviewed: entries.length, pageCount: index + 1,
            startedAt: sourceCheckedAt, finishedAt: new Date(now()).toISOString(), rulesVersions: [...rulesVersions].sort() } };
      }
      if (!page.records.length || page.nextCursor === cursor || page.nextCursor !== `${grant.revision}:${entries.length}`) throw unavailable();
      cursor = page.nextCursor;
    }
    throw unavailable();
  }
  async function describe(assignment) {
    try {
      const started = now(), input = assessmentReviewRequest(assignment, "describe");
      const envelope = await metadataRequest(input);
      if (!metadataFields(envelope, [...Object.keys(input), "grant", "metadata"]) ||
          JSON.stringify(Object.fromEntries(Object.keys(input).map(key => [key, envelope[key]]))) !== JSON.stringify(input) ||
          !metadataFields(envelope.grant, ["application", "id", "revision", "expiresAt"]) ||
          !metadataFields(envelope.metadata, ["observedAt", "manifest"])) throw unavailable();
      const grant = validateAgentSourceGrant(envelope.grant);
      const { observedAt } = envelope.metadata;
      if (grant.application !== "pipeline" || Date.parse(grant.expiresAt) <= now() || typeof observedAt !== "string" ||
          !Number.isFinite(Date.parse(observedAt)) || Date.parse(observedAt) < started - 5000 || Date.parse(observedAt) > now() + 5000) throw unavailable();
      const manifest = validatePipelineManifest(envelope.metadata.manifest);
      const { revision, ...body } = manifest;
      if (createHash("sha256").update(JSON.stringify(body)).digest("hex") !== revision) throw unavailable();
      await authorize(assignment, grant);
      return { reference: new URL(config.endpoint ?? ASSESSMENT_REVIEW_PATH, config.origin).href, observedAt, manifest, grant };
    } catch { throw unavailable(); }
  }
  return { authorize, read, describe };
}
