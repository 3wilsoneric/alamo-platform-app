import { draftReviewHash } from "../shared/draft-review-contracts.mjs";
import { verifyWorkflowBriefPacket, WORKFLOW_BRIEF_OPERATIONS } from "../shared/workflow-brief-contracts.mjs";
import { workflowUnavailable } from "../shared/workflow-history-contracts.mjs";
import { createDraftReviewService } from "./draft-review-service.mjs";
import { workflowBriefPackDefinition, WORKFLOW_BRIEF_POLICY, prepareWorkflowBriefPayload } from "../skills/workflow-briefs/pack.mjs";

// Trusted host binds one capability, authenticated identity and governed reader.
// The model cannot switch role/scope or reach history. No HTTP/worker registration.
export function createWorkflowBriefSkillPack({ operation, readPacket, store, now }) {
  if (!WORKFLOW_BRIEF_OPERATIONS.includes(operation) || typeof readPacket !== "function" || typeof now !== "function" || !store) return workflowUnavailable();
  const definition = workflowBriefPackDefinition(operation), skillId = definition.skills[0].id;
  const checked = reader => async request => verifyWorkflowBriefPacket(await reader(structuredClone(request)), request, operation, now());
  function drafts(reader) {
    return createDraftReviewService({ store, skillId, policyRevision: WORKFLOW_BRIEF_POLICY, now,
      readContext: checked(reader), contextRevision: draftReviewHash,
      validatePayload(payload, packet) {
        const expected = prepareWorkflowBriefPayload(packet);
        if (draftReviewHash(payload) !== draftReviewHash(expected)) return workflowUnavailable();
        return expected;
      } });
  }
  return {
    definition, revision: draftReviewHash({ definition, policy: WORKFLOW_BRIEF_POLICY }), readPacket: checked(readPacket),
    async observe(request, parentId, reader) {
      if (parentId !== null) return workflowUnavailable();
      const packet = await checked(reader)(request);
      // No case IDs, owners, narratives, counts or raw history go to selection or traces.
      return { state: { task: operation, evidence: "current_complete", preparation: "ready", review: "required", sourceWork: "unconfirmed" },
        eligible: [skillId], revision: draftReviewHash(packet) };
    },
    async execute(choice, request, parentId, reader) {
      if (parentId !== null || choice !== skillId) return workflowUnavailable();
      const packet = await checked(reader)(request);
      return drafts(reader).save(request, prepareWorkflowBriefPayload(packet), draftReviewHash(packet));
    },
    readDraft: (id, request) => drafts(readPacket).read(id, request),
    reviewDraft: (id, request, command) => drafts(readPacket).review(id, request, command),
  };
}
