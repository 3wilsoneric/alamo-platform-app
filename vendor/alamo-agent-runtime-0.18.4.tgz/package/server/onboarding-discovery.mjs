import { createHash } from "node:crypto";
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
import { ASSESSMENT_REVIEW_PATH } from "../shared/assessment-review-contracts.mjs";
import { metadataFields, PIPELINE_METADATA_MAX_BYTES, validatePipelineManifest } from "../shared/pipeline-metadata-contracts.mjs";

export function validateDiscoveryEvidence(value) {
  const invalid = () => { throw new Error("Invalid onboarding discovery evidence."); };
  if (!metadataFields(value, ["reference", "observedAt", "manifest", "grant"]) ||
      Buffer.byteLength(JSON.stringify(value)) > PIPELINE_METADATA_MAX_BYTES || typeof value.reference !== "string" || value.reference.length > 1000 ||
      typeof value.observedAt !== "string" || value.observedAt.length > 40 || !Number.isFinite(Date.parse(value.observedAt)) ||
      !metadataFields(value.grant, ["application", "id", "revision", "expiresAt"])) invalid();
  const url = new URL(value.reference);
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || url.pathname !== ASSESSMENT_REVIEW_PATH) invalid();
  const manifest = validatePipelineManifest(value.manifest), grant = validateAgentSourceGrant(value.grant);
  const { revision, ...body } = manifest;
  if (createHash("sha256").update(JSON.stringify(body)).digest("hex") !== revision || grant.application !== "pipeline") invalid();
  return { reference: url.href, observedAt: value.observedAt, manifest, grant };
}

export function sameDiscoveryAccess(a, b) {
  return a.reference === b.reference && a.grant.application === b.grant.application && a.grant.id === b.grant.id &&
    a.grant.revision === b.grant.revision;
}
