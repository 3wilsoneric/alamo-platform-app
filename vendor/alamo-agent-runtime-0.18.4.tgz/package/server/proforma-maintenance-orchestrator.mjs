import {RetryOptions} from 'durable-functions';
import {validateMaintenanceRunKey} from '../shared/proforma-maintenance-host.mjs';

// Replay contains identifiers and compact outcomes only. Source authorization,
// model calls, checkpoints and evidence stay in the fenced activity host.
/** @type {import('durable-functions').OrchestrationHandler} */
export const proformaMaintenanceV1=function*(context){
  const key=validateMaintenanceRunKey(context.df.getInput());
  // The retry window spans the 90-second activity lease so a crashed worker can
  // be replaced, while the host independently enforces its ten-minute deadline.
  const retry=new RetryOptions(30000,5);retry.backoffCoefficient=1;retry.maxRetryIntervalInMilliseconds=30000;
  try{
    context.df.setCustomStatus({phase:'assess'});
    const outcome=yield context.df.callActivityWithRetry('proformaMaintenanceRunV1',retry,key);
    context.df.setCustomStatus({phase:outcome.status});return outcome;
  }catch{
    context.df.setCustomStatus({phase:'failed'});
    return yield context.df.callActivityWithRetry('proformaMaintenanceFailV1',retry,key);
  }
};
