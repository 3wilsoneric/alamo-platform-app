import { randomUUID } from "node:crypto";
import { foundationKey } from "../shared/foundation-contracts.mjs";
import { validateWorkContextRequest } from "../shared/work-context-contracts.mjs";
import { draftReviewHash, draftReviewId, draftReviewDigest, draftReviewUnavailable, draftReviewConflict,
  validateDraftReviewRecord, validateDraftReviewCommand } from "../shared/draft-review-contracts.mjs";

const equal = (a, b) => draftReviewHash(a) === draftReviewHash(b);
const view = record => ({ ...structuredClone(record), status: record.review === null ? "awaiting_human_review" :
  record.review.decision === "accept" ? "draft_reviewed" : "draft_rejected", sourceWork: "unconfirmed" });

// Trusted activity composition only: no HTTP binding or default source. The
// host-bound readContext MUST authorize the authenticated subject and verify
// scope/freshness on every call. Request fields are selectors, never authority.
export function createDraftReviewService({ store, skillId, policyRevision, readContext, contextRevision, validatePayload, now }) {
  foundationKey(skillId); draftReviewDigest(policyRevision);
  async function inspect(record, request, context) {
    if (!equal(record.request, request) || record.skillId !== skillId || record.policyRevision !== policyRevision ||
      record.contextRevision !== draftReviewDigest(contextRevision(context)) ||
      !equal(record.payload, validatePayload(structuredClone(record.payload), context))) return draftReviewUnavailable();
  }
  async function current(record, request) {
    await inspect(record, request, await readContext(structuredClone(request)));
  }
  function find(state, id, request) {
    const record = state.records.find(r => r.id === id && equal(r.request, request) && r.skillId === skillId);
    if (!record) return draftReviewUnavailable();
    return record;
  }
  async function read(id, input) {
    draftReviewId(id);
    const request = validateWorkContextRequest(input);
    const context = await readContext(structuredClone(request));
    const record = find((await store.read()).value, id, request);
    await inspect(record, request, context);
    await current(record, request);
    return view(record);
  }
  async function save(input, payload, expectedContextRevision) {
    const request = validateWorkContextRequest(input);
    const context = await readContext(structuredClone(request));
    if (draftReviewDigest(contextRevision(context)) !== draftReviewDigest(expectedContextRevision)) return draftReviewUnavailable();
    const artifact = { schemaVersion: 1, id: randomUUID(), createdAt: new Date(now()).toISOString(), request,
      skillId, policyRevision, contextRevision: expectedContextRevision, payload: validatePayload(structuredClone(payload), context) };
    const record = validateDraftReviewRecord({ ...artifact, artifactRevision: draftReviewHash(artifact), review: null });
    await store.update(async state => {
      if (state.records.some(r => r.id === record.id)) return draftReviewUnavailable();
      // This callback runs again after CAS conflicts: never reuse authorization.
      await current(record, request);
      state.records.push(structuredClone(record));
      return true;
    });
    return read(record.id, request);
  }
  async function review(id, input, rawCommand) {
    draftReviewId(id);
    const request = validateWorkContextRequest(input), command = validateDraftReviewCommand(rawCommand);
    // Check access before loading retained data, then again inside every CAS attempt.
    await readContext(structuredClone(request));
    await store.update(async state => {
      const record = find(state, id, request);
      await current(record, request);
      if (record.artifactRevision !== command.expectedArtifactRevision) throw draftReviewConflict();
      const prior = state.records.find(r => equal(r.request.scope, request.scope) && r.review?.requestId === command.requestId);
      if (prior) {
        if (prior.id !== id || prior.review.decision !== command.decision) throw draftReviewConflict();
        return false;
      }
      // A review is final for this immutable draft. A revision requires a new
      // draft and explicit review, never silently inherits an earlier decision.
      if (record.review !== null) throw draftReviewConflict();
      record.review = { requestId: command.requestId, artifactRevision: record.artifactRevision, decision: command.decision,
        subjectId: request.scope.subjectId, reviewedAt: new Date(now()).toISOString() };
      return true;
    });
    // A change between storage and this check can retain a historical review,
    // but cannot return it as currently authorized or as source completion.
    return read(id, request);
  }
  const protect = operation => async (...args) => {
    try { return await operation(...args); }
    catch (error) {
      if (error && typeof error === "object" && "code" in error && error.code === "DRAFT_REVIEW_CONFLICT") throw draftReviewConflict();
      return draftReviewUnavailable();
    }
  };
  return { save: protect(save), read: protect(read), review: protect(review) };
}
