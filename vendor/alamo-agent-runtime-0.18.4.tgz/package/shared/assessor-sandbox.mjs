export const ASSESSOR_SANDBOX_PATH = "/api/agent/v1/assessor-sandbox";
export const ASSESSOR_SANDBOX_CASES = [
  { id: "synthetic-initial", label: "Two questions remaining" },
  { id: "synthetic-partial", label: "One question remaining" },
  { id: "synthetic-ready", label: "Answers ready for review" },
];

// Uses the host's existing authenticated transport. The browser supplies only
// fixed scenario selectors, never source packets, grants, identities or URLs.
export function createAssessorSandboxClient(requestJson) {
  const command = input => requestJson(ASSESSOR_SANDBOX_PATH, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
  return {
    list: signal => requestJson(ASSESSOR_SANDBOX_PATH, { signal, cache: "no-store" }),
    read: (id, signal) => requestJson(`${ASSESSOR_SANDBOX_PATH}?id=${encodeURIComponent(id)}`, { signal, cache: "no-store" }),
    command,
    previewProcess: executionId=>command({action:'preview_process',executionId}),
    createFromProcess: input=>command({action:'create_from_process',...input}),
    discoverProcess: source=>command({action:'discover_process',source}),
    readProcessConfiguration: executionId=>command({action:'read_process_configuration',executionId}),
    reviewDraft: input => command({ action: "review_draft", ...input }),
  };
}
