const invalid = () => { throw new Error("Invalid Pipeline capability metadata."); };
export const PIPELINE_METADATA_MAX_BYTES = 16_384;
export const PIPELINE_ONBOARDING_SOURCE = "pipeline-assessment-contract";
export const metadataFields = (value, keys) => Boolean(value && typeof value === "object" && !Array.isArray(value) &&
  Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key)));
const digest = value => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
const text = (value, limit) => typeof value === "string" && value === value.trim() && value.length > 0 && value.length <= limit && !/[\x00-\x1f\x7f]/.test(value);

/** Validates only reviewed capability metadata; no record values or arbitrary tools. */
export function validatePipelineManifest(value) {
  if (!metadataFields(value, ["version", "application", "capability", "title", "steward", "questionnaireRulesVersion", "concepts", "revision"]) ||
      value.version !== 1 || value.application !== "pipeline" || value.capability !== "assessment-review" ||
      !text(value.title, 160) || !text(value.steward, 160) || !digest(value.questionnaireRulesVersion) || !digest(value.revision) ||
      !Array.isArray(value.concepts) || !value.concepts.length || value.concepts.length > 10) invalid();
  const concepts = value.concepts.map(concept => {
    if (!metadataFields(concept, ["id", "label", "locator", "definition"]) || typeof concept.id !== "string" || !/^[a-z][a-z0-9-]{0,39}$/.test(concept.id) ||
        !text(concept.label, 160) || !text(concept.definition, 1000) || typeof concept.locator !== "string" ||
        !/^(decision|assessmentState|assessment\.(signedAt|authorship|completion|sendStatus))$/.test(concept.locator)) invalid();
    return { id: concept.id, label: concept.label, locator: concept.locator, definition: concept.definition };
  });
  if (new Set(concepts.map(concept => concept.id)).size !== concepts.length || new Set(concepts.map(concept => concept.locator)).size !== concepts.length) invalid();
  return { version: 1, application: "pipeline", capability: "assessment-review", title: value.title, steward: value.steward,
    questionnaireRulesVersion: value.questionnaireRulesVersion, concepts, revision: value.revision };
}
