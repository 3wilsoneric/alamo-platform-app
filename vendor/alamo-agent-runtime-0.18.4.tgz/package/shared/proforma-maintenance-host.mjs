import {maintenanceObject as object,maintenanceHash as hash,maintenanceId as id,maintenanceDigest as digest,maintenanceInteger as integer,maintenanceText as text,validateMaintenanceBinding} from './proforma-maintenance-contracts.mjs';
export const maintenanceDefinitionHash=value=>hash({binding:value.binding,intervalMs:value.intervalMs,maxOperations:value.maxOperations,evaluation:value.evaluation});
export function validateMaintenanceDefinition(input){
  const v=object(input,['binding','enabled','intervalMs','maxOperations','evaluation','approval']);const binding=validateMaintenanceBinding(v.binding);
  integer(v.intervalMs,86400000);integer(v.maxOperations,100);
  if(typeof v.enabled!=='boolean'||v.intervalMs<900000||v.maxOperations<1)throw new Error('Invalid maintenance schedule.');
  const e=object(v.evaluation,['policyVersion','digest','status','reviewedBy','reviewedAt']);digest(e.policyVersion);digest(e.digest);
  if(e.policyVersion!==binding.policyVersion||e.status!=='approved'||e.reviewedBy!==binding.actorId||!Number.isFinite(Date.parse(e.reviewedAt)))throw new Error('Maintenance needs current evaluated-policy approval.');
  const a=object(v.approval,['definitionHash','actorId','at']);digest(a.definitionHash);
  if(a.definitionHash!==maintenanceDefinitionHash(v)||a.actorId!==binding.actorId||!Number.isFinite(Date.parse(a.at)))throw new Error('Maintenance needs an exact owner-reviewed definition.');
  return structuredClone(v);
}
export function maintenanceRunKey(binding,definitionHash,runId){return validateMaintenanceRunKey({tenantId:binding.scope.tenantId,responsibilityId:binding.id,bindingHash:hash(binding),definitionHash,id:runId});}
export function validateMaintenanceRunKey(input){
  const k=object(input,['tenantId','responsibilityId','bindingHash','definitionHash','id']);id(k.tenantId);id(k.responsibilityId);digest(k.bindingHash);digest(k.definitionHash);digest(k.id);return structuredClone(k);
}
export function maintenancePartition(input){const k=validateMaintenanceRunKey(input);return `everyagent/proforma-maintenance/${k.tenantId}/${k.responsibilityId}/${k.bindingHash}`;}
export function isMaintenanceBlobPath(value){return /^everyagent\/proforma-maintenance\/[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}\/[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}\/[a-f0-9]{64}\/(?:checkpoint-v1|schedule-v1|runs\/[a-f0-9]{64}|evidence\/[a-f0-9]{64})\.json$/.test(value);}
export function validateMaintenanceTrace(input){
  const v=object(input,['schemaVersion','kind','responsibilityId','bindingHash','processId','sourceVersion','signalId','inputHash','policyVersion','promptVersion','requestedModel','status','decisionHash','responseModel','usage']);
  if(v.schemaVersion!==1||v.kind!=='proforma.maintenance-assessment'||!['validated','failed'].includes(v.status)||typeof v.processId!=='string'||!v.processId.startsWith('draft:'))throw new Error('Invalid maintenance evidence.');
  id(v.responsibilityId);id(v.processId.slice(6));for(const field of ['bindingHash','sourceVersion','signalId','inputHash','policyVersion'])digest(v[field]);
  for(const field of ['promptVersion','requestedModel']){text(v[field],160);if(!/^[a-zA-Z0-9._:-]+$/.test(v[field]))throw new Error('Invalid maintenance provenance.');}
  if(v.status==='failed'){
    if(v.decisionHash!==null||v.responseModel!==null||v.usage!==null)throw new Error('Failed assessment cannot retain a validated decision.');
  }else{
    digest(v.decisionHash);text(v.responseModel,160);if(!/^[a-zA-Z0-9._:-]+$/.test(v.responseModel))throw new Error('Invalid maintenance provenance.');
    if(v.usage!==null){object(v.usage,['inputTokens','outputTokens']);integer(v.usage.inputTokens,1000000);integer(v.usage.outputTokens,1000000);}
  }
  return structuredClone(v);
}
