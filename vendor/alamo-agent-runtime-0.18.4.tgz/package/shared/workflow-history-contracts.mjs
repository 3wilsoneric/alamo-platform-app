import { createHash } from "node:crypto";
import { foundationObject, foundationList, foundationUnique, foundationKey } from "./foundation-contracts.mjs";
import { draftReviewHash, draftReviewId, draftReviewDigest } from "./draft-review-contracts.mjs";

export const WORKFLOW_OPERATIONS = Object.freeze(["assessor_work", "team_exceptions", "workflow_trend"]);
export const WORKFLOW_HISTORY_LIMITS = Object.freeze({ events: 500, bytes: 1_048_576, freshnessMs: 900_000 });
export const workflowUnavailable = () => { throw new Error("Workflow evidence is unavailable."); };
const exact = foundationObject;
export function workflowStamp(value) {
  if (typeof value !== "string" || value.length !== 24 || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) return workflowUnavailable();
  return value;
}
function text(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 2000) return workflowUnavailable();
  return value;
}
function choice(value, allowed) { if (!allowed.includes(value)) return workflowUnavailable(); return value; }
function keys(value) { return foundationUnique(foundationList(value, foundationKey, 50, 1), id => id).sort(); }
const integer = value => { if (!Number.isSafeInteger(value) || value < 1 || value > 10000) return workflowUnavailable(); return value; };

export function validateWorkflowEvent(value) {
  const v = exact(value, ["schemaVersion", "id", "caseId", "sourceRevision", "occurredAt", "ingestedAt", "producer", "origin", "kind", "supersedes", "data"]);
  if (v.schemaVersion !== 1 || v.producer !== "pipeline") return workflowUnavailable();
  const kind = choice(v.kind, ["case_opened", "assignment_changed", "blocker_opened", "blocker_resolved", "handoff_recorded", "handoff_acknowledged"]);
  let data;
  if (kind === "case_opened") {
    const d = exact(v.data, ["ownerId", "teamId", "communityId", "summary"]);
    data = { ownerId: draftReviewId(d.ownerId), teamId: foundationKey(d.teamId), communityId: foundationKey(d.communityId), summary: text(d.summary) };
  } else if (kind === "assignment_changed") {
    const d = exact(v.data, ["ownerId"]); data = { ownerId: draftReviewId(d.ownerId) };
  } else if (kind === "blocker_opened") {
    const d = exact(v.data, ["blockerId", "category", "question"]);
    data = { blockerId: foundationKey(d.blockerId), category: choice(d.category, ["receiving_contact", "answer_evidence", "placement_question"]), question: text(d.question) };
  } else if (kind === "blocker_resolved") {
    const d = exact(v.data, ["blockerId"]); data = { blockerId: foundationKey(d.blockerId) };
  } else if (kind === "handoff_recorded") {
    const d = exact(v.data, ["attemptId", "result"]); data = { attemptId: foundationKey(d.attemptId), result: choice(d.result, ["sent", "failed"]) };
  } else {
    const d = exact(v.data, ["attemptId"]); data = { attemptId: foundationKey(d.attemptId) };
  }
  const occurredAt = workflowStamp(v.occurredAt), ingestedAt = workflowStamp(v.ingestedAt);
  if (ingestedAt < occurredAt || (v.supersedes !== null && kind !== "handoff_recorded")) return workflowUnavailable();
  return { schemaVersion: 1, id: foundationKey(v.id), caseId: foundationKey(v.caseId), sourceRevision: integer(v.sourceRevision),
    occurredAt, ingestedAt, producer: "pipeline", origin: choice(v.origin, ["human", "import", "agent"]), kind,
    supersedes: v.supersedes === null ? null : foundationKey(v.supersedes), data };
}

// Hash the normalized envelope and bounded event digests. No credential/signature
// semantics: the trusted source adapter must establish authenticity and coverage.
export function workflowFeedRevision(value) {
  return createHash("sha256").update(JSON.stringify({ schemaVersion: value.schemaVersion, mode: value.mode,
    companyId: value.companyId, tenantId: value.tenantId, observedAt: value.observedAt,
    completeThrough: value.completeThrough, coverage: value.coverage,
    events: value.events.map(draftReviewHash).sort() })).digest("hex");
}
export function validateWorkflowFeed(value, now) {
  if (!Number.isSafeInteger(now) || now < 0) return workflowUnavailable();
  const v = exact(value, ["schemaVersion", "mode", "companyId", "tenantId", "observedAt", "completeThrough", "coverage", "events", "revision"]);
  if (v.schemaVersion !== 1 || v.mode !== "synthetic-only" || Buffer.byteLength(JSON.stringify(v)) > WORKFLOW_HISTORY_LIMITS.bytes) return workflowUnavailable();
  const observedAt = workflowStamp(v.observedAt), completeThrough = workflowStamp(v.completeThrough);
  if (completeThrough > observedAt || Date.parse(observedAt) > now) return workflowUnavailable();
  const events = foundationList(v.events, validateWorkflowEvent, WORKFLOW_HISTORY_LIMITS.events);
  if (events.some(e => e.ingestedAt > observedAt || e.occurredAt > completeThrough)) return workflowUnavailable();
  const feed = { schemaVersion: 1, mode: "synthetic-only", companyId: draftReviewId(v.companyId), tenantId: draftReviewId(v.tenantId),
    observedAt, completeThrough, coverage: choice(v.coverage, ["complete", "partial"]), events, revision: draftReviewDigest(v.revision) };
  if (workflowFeedRevision(feed) !== feed.revision) return workflowUnavailable();
  return feed;
}

export function validateWorkflowActor(value) {
  const v = exact(value, ["companyId", "tenantId", "subjectId"]);
  return { companyId: draftReviewId(v.companyId), tenantId: draftReviewId(v.tenantId), subjectId: draftReviewId(v.subjectId) };
}
export function validateWorkflowGrant(value, actor, operation, now) {
  if (!Number.isSafeInteger(now) || now < 0) return workflowUnavailable();
  const v = exact(value, ["id", "revision", "companyId", "tenantId", "subjectId", "expiresAt", "operations", "teamIds", "communityIds", "caseIds", "datasetRevision"]);
  for (const field of ["companyId", "tenantId", "subjectId"]) if (v[field] !== actor[field]) return workflowUnavailable();
  const operations = foundationUnique(foundationList(v.operations, item => choice(item, WORKFLOW_OPERATIONS), 3, 1), x => x).sort();
  if (!operations.includes(operation) || Date.parse(workflowStamp(v.expiresAt)) <= now) return workflowUnavailable();
  const caseIds = foundationUnique(foundationList(v.caseIds, foundationKey, 100), x => x).sort();
  return { id: foundationKey(v.id), revision: draftReviewDigest(v.revision), ...actor, expiresAt: String(v.expiresAt), operations,
    teamIds: keys(v.teamIds), communityIds: keys(v.communityIds), caseIds, datasetRevision: draftReviewDigest(v.datasetRevision) };
}
export function validateWorkflowRead(value) {
  const v = exact(value, ["operation"]);
  return { operation: choice(v.operation, WORKFLOW_OPERATIONS) };
}
