import { createHash } from 'node:crypto';

export const PROFORMA_MAINTENANCE_PATH = '/api/platform/workflow/v1';
export const maintenanceHash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
/** @returns {never} */
export function invalidMaintenance(message = 'Invalid ProForma maintenance contract.') { throw new Error(message); }
/** @returns {Record<string, any>} */
export function maintenanceObject(value, required, optional = []) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || required.some(key => !Object.hasOwn(value, key)) || Object.keys(value).some(key => ![...required, ...optional].includes(key))) return invalidMaintenance();
  return value;
}
export function maintenanceText(value, max = 2000, empty = false) {
  if (typeof value !== 'string' || value.length > max || (!empty && !value.trim()) || [...value].some(char => char.charCodeAt(0) === 127 || char.charCodeAt(0) < 32 && ![9, 10, 13].includes(char.charCodeAt(0)))) return invalidMaintenance();
  return value;
}
export function maintenanceInteger(value, max = Number.MAX_SAFE_INTEGER) {
  if (!Number.isSafeInteger(value) || value < 0 || value > max) return invalidMaintenance();
  return Number(value);
}
export function maintenanceDigest(value) {
  if (typeof value !== 'string' || !/^[a-f0-9]{64}$/.test(value)) return invalidMaintenance();
  return value;
}
export function maintenanceId(value) {
  if (typeof value !== 'string' || !/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value)) return invalidMaintenance();
  return value;
}
function list(value, max) { if (!Array.isArray(value) || value.length > max) return invalidMaintenance(); return value; }
function same(a, b) { if (maintenanceHash(a) !== maintenanceHash(b)) return invalidMaintenance(); }
export function validateMaintenanceBinding(input) {
  const v = maintenanceObject(input, ['schemaVersion', 'id', 'origin', 'scope', 'actorId', 'processIds', 'purpose', 'policyVersion']);
  const url = new URL(v.origin), scope = maintenanceObject(v.scope, ['tenantId', 'workspace']);
  if (v.schemaVersion !== 1 || url.protocol !== 'https:' || url.origin !== v.origin || scope.workspace !== 'workflow') return invalidMaintenance();
  maintenanceId(v.id); maintenanceId(scope.tenantId); maintenanceDigest(v.policyVersion); maintenanceText(v.purpose);
  if (!new RegExp(`^entra:${scope.tenantId}:[a-f0-9-]{36}$`).test(v.actorId)) return invalidMaintenance();
  maintenanceId(v.actorId.split(':')[2]);
  const ids = list(v.processIds, 50);
  if (!ids.length || new Set(ids).size !== ids.length || ids.some(id => typeof id !== 'string' || !/^draft:[a-f0-9-]{36}$/.test(id))) return invalidMaintenance();
  ids.forEach(id => maintenanceId(id.slice(6)));
  return structuredClone(v);
}
export function validateMaintenanceSession(input, binding, permission) {
  const v = maintenanceObject(input, ['mode', 'storage', 'actor', 'scope', 'permissions']);
  if (v.mode !== 'platform-owner-pilot' || v.actor?.id !== binding.actorId || !Array.isArray(v.permissions) || !v.permissions.includes('read') || !v.permissions.includes(permission)) return invalidMaintenance('ProForma access is unavailable for this responsibility.');
  same(v.scope, binding.scope);
}
function citation(input) {
  const v = maintenanceObject(input, ['nodeId', 'snapshotId', 'fingerprint', 'pointer'], ['draftId', 'revision']);
  maintenanceText(v.nodeId, 220); maintenanceText(v.snapshotId, 200); maintenanceDigest(v.fingerprint); maintenanceText(v.pointer, 1000);
  if (v.draftId !== undefined) { maintenanceId(v.draftId); maintenanceInteger(v.revision); }
  return v;
}
export function validateMaintenanceSource(input) {
  const v = maintenanceObject(input, ['processId', 'title', 'fingerprint', 'status', 'source', 'publications', 'version'], ['applicationSources']);
  maintenanceText(v.processId, 220); maintenanceText(v.title, 500, true); maintenanceText(v.status, 80); maintenanceDigest(v.fingerprint); citation(v.source);
  if (v.source.nodeId !== v.processId) return invalidMaintenance();
  for (const p of list(v.publications, 1000)) {
    maintenanceObject(p, ['id', 'status', 'fingerprint', 'contentHash']);
    maintenanceText(p.id, 100); maintenanceText(p.status, 80); maintenanceDigest(p.fingerprint); maintenanceDigest(p.contentHash);
  }
  if (v.applicationSources !== undefined) {
    const ids = new Set();
    for (const source of list(v.applicationSources, 16)) {
      maintenanceObject(source, ['nodeId', 'title', 'fingerprint', 'status', 'authority', 'excerpt', 'excerptHash', 'location', 'citation', 'via']);
      maintenanceText(source.nodeId, 220); maintenanceText(source.title, 160); maintenanceText(source.status, 80); maintenanceDigest(source.fingerprint); citation(source.citation);
      maintenanceText(source.excerpt, 6000); maintenanceDigest(source.excerptHash);
      if (ids.has(source.nodeId) || source.authority !== 'source-code-not-policy' || source.citation.nodeId !== source.nodeId || source.citation.fingerprint !== source.fingerprint || createHash('sha256').update(source.excerpt).digest('hex') !== source.excerptHash) return invalidMaintenance();
      ids.add(source.nodeId);
      const loc = maintenanceObject(source.location, ['repository', 'commit', 'path', 'fileHash', 'startLine', 'endLine']);
      maintenanceText(loc.repository, 100); maintenanceText(loc.path, 500); maintenanceDigest(loc.fileHash); maintenanceInteger(loc.startLine); maintenanceInteger(loc.endLine);
      if (!/^[a-f0-9]{40}$/.test(loc.commit) || loc.startLine < 1 || loc.endLine < loc.startLine) return invalidMaintenance();
      let from = v.processId;
      const via = list(source.via, 4);
      if (!via.length) return invalidMaintenance();
      for (const edge of via) {
        maintenanceObject(edge, ['from', 'to', 'predicate', 'status', 'grounding']);
        for (const key of ['from', 'to', 'predicate', 'status', 'grounding']) maintenanceText(edge[key], 220);
        if (edge.from !== from || !['documents_workflow', 'related_to', 'governed_by', 'teaches', 'depends_on_source'].includes(edge.predicate) || ['rejected', 'withdrawn'].includes(edge.status)) return invalidMaintenance();
        from = edge.to;
      }
      if (from !== source.nodeId) return invalidMaintenance();
    }
  }
  same(v.version, maintenanceHash({ processId: v.processId, fingerprint: v.fingerprint, status: v.status, publications: v.publications,
    ...(v.applicationSources?.length ? { applicationSources: v.applicationSources.map(({ nodeId, fingerprint, excerptHash, via }) => ({ nodeId, fingerprint, excerptHash, via })) } : {}) }));
  return v;
}
export function maintenanceApplicationChanges(event) {
  if (!event.before || !event.after) return [];
  const before = new Map((event.before.applicationSources ?? []).map(source => [source.nodeId, source]));
  const after = new Map((event.after.applicationSources ?? []).map(source => [source.nodeId, source]));
  return [...new Set([...before.keys(), ...after.keys()])].sort().flatMap(nodeId => {
    const old = before.get(nodeId) ?? null, current = after.get(nodeId) ?? null;
    if (old?.fingerprint === current?.fingerprint) return [];
    return [{ signalId: event.id, nodeId, beforeFingerprint: old?.fingerprint ?? null, afterFingerprint: current?.fingerprint ?? null, before: old, after: current }];
  });
}
function envelope(v, kind, binding) {
  if (v.schemaVersion !== 1 || v.kind !== kind || v.producer !== 'ProForma' || v.canExecute !== false) return invalidMaintenance();
  same(v.scope, binding.scope);
}
export function validateMaintenanceFeed(input, binding, after, streamId) {
  const v = maintenanceObject(input, ['schemaVersion', 'kind', 'producer', 'scope', 'streamId', 'revision', 'events', 'cursor', 'hasMore', 'pendingChanges', 'canExecute']);
  envelope(v, 'proforma.maintenance-feed', binding); maintenanceInteger(v.revision); maintenanceInteger(v.cursor, 1000);
  if (typeof v.hasMore !== 'boolean' || typeof v.pendingChanges !== 'boolean' || streamId && v.streamId !== streamId) return invalidMaintenance();
  if (v.streamId !== null) maintenanceId(v.streamId);
  for (const [index, e] of list(v.events, 100).entries()) {
    maintenanceObject(e, ['schemaVersion', 'streamId', 'sequence', 'kind', 'processId', 'before', 'after', 'observedAt', 'id']);
    if (e.schemaVersion !== 1 || e.streamId !== v.streamId || e.sequence !== after + index + 1 || !['process.observed', 'process.changed', 'process.unavailable'].includes(e.kind) || !Number.isFinite(Date.parse(e.observedAt))) return invalidMaintenance();
    if (e.before) validateMaintenanceSource(e.before);
    if (e.after) validateMaintenanceSource(e.after);
    if (e.before?.processId && e.before.processId !== e.processId || e.after?.processId && e.after.processId !== e.processId || e.kind === 'process.unavailable' && (e.after !== null || !e.before) || e.kind === 'process.observed' && (e.before !== null || !e.after) || e.kind === 'process.changed' && (!e.before || !e.after || e.before.version === e.after.version)) return invalidMaintenance();
    same(e.id, maintenanceHash(Object.fromEntries(Object.entries(e).filter(([key]) => key !== 'id'))));
  }
  if (v.cursor !== after + v.events.length || v.hasMore && !v.events.length || v.streamId === null && (v.cursor || v.hasMore)) return invalidMaintenance();
  return structuredClone(v);
}
const fields = ['description', 'trigger', 'handoff', 'exceptions', 'completionCriteria', 'prerequisites', 'ownerRole', 'audience', 'applicability'];
const stepFields = ['action', 'role', 'system', 'expectedResult'];
function processPaths(input, steps) {
  const v = maintenanceObject(input,['schemaVersion','entryStepId','transitions']), ids = new Set(steps.map(s => s.id));
  if (v.schemaVersion !== 1 || (ids.size ? !ids.has(v.entryStepId) : v.entryStepId !== null)) return invalidMaintenance();
  const paths = list(v.transitions,500).map(p => {
    maintenanceObject(p,['id','fromStepId','toStepId','condition','terminal','handoff']); maintenanceText(p.id,220); maintenanceText(p.condition,20000,true);
    if (!ids.has(p.fromStepId) || p.toStepId !== null && !ids.has(p.toStepId) || ![null,'complete','stop'].includes(p.terminal) || (p.toStepId === null) !== (p.terminal !== null)) return invalidMaintenance();
    if (p.handoff !== null) { maintenanceObject(p.handoff,['role','acceptance']); maintenanceText(p.handoff.role,20000,true); maintenanceText(p.handoff.acceptance,20000,true); }
    return structuredClone(p);
  });
  if (new Set(paths.map(p => p.id)).size !== paths.length) return invalidMaintenance();
  return {schemaVersion:1,entryStepId:v.entryStepId,transitions:paths};
}
export function validateMaintenanceContext(input, binding, processId) {
  const v = maintenanceObject(input, ['schemaVersion', 'kind', 'producer', 'scope', 'streamId', 'source', 'definition', 'work', 'assessments', 'canExecute']);
  envelope(v, 'proforma.maintenance-context', binding); validateMaintenanceSource(v.source);
  const d = maintenanceObject(v.definition, ['schemaVersion', 'kind', 'process', 'source', 'knowledge', 'automation', 'notice']);
  const p = d.process;
  if (v.source.processId !== processId || d.kind !== 'proforma.process-snapshot' || d.schemaVersion !== 1 || d.automation?.canExecute !== false || p?.id !== processId || p.fingerprint !== v.source.fingerprint) return invalidMaintenance();
  same(d.source, v.source.source); same(p.source, v.source.source);
  for (const field of fields) maintenanceText(p[field], 20000, true);
  for (const step of list(p.steps, 200)) { maintenanceText(step.id, 220); for (const field of stepFields) maintenanceText(step[field], 20000, true); }
  if (new Set(p.steps.map(s => s.id)).size !== p.steps.length) return invalidMaintenance();
  if (!['explicit','sequence'].includes(p.flowOrigin)) return invalidMaintenance();
  const flow = processPaths(p.flow,p.steps), gaps = list(p.gaps,500).map(gap => maintenanceText(gap,20000));
  const connections = list(p.connections,1000).map(link => {
    maintenanceObject(link,['id','nodeId','title','type','targetFingerprint','predicate','status','grounding','freshness']);
    for (const field of ['id','nodeId','title','type','predicate','status','grounding','freshness']) maintenanceText(link[field],500,true);
    maintenanceDigest(link.targetFingerprint); return structuredClone(link);
  });
  list(v.work, 1000); list(v.assessments, 20);
  // The assessor receives only process text and source-owned work summaries.
  // Other snapshot fields (including proposed automation) are not executable input.
  return { source: structuredClone(v.source), streamId: v.streamId,
    process: { id: p.id, title: p.title, ...Object.fromEntries(fields.map(f => [f, p[f]])), steps: p.steps.map(s => ({ id: s.id, ...Object.fromEntries(stepFields.map(f => [f, s[f]])) })), flow,flowOrigin:p.flowOrigin,gaps,connections },
    work: v.work.map(w => { maintenanceObject(w, ['id','title','detail','status','evidenceHash']); return { id:maintenanceText(w.id,220),title:maintenanceText(w.title,500),detail:maintenanceText(w.detail,20000,true),status:maintenanceText(w.status,80),evidenceHash:maintenanceDigest(w.evidenceHash) }; }),
    assessments: v.assessments.map(a => { maintenanceObject(a,['id','actor','at','sourceVersion','outcome','reason','resultId']); return { id:maintenanceId(a.id),sourceVersion:maintenanceDigest(a.sourceVersion),outcome:maintenanceText(a.outcome,40),reason:maintenanceText(a.reason),resultId:a.resultId }; }) };
}
export function maintenanceAssessment(context, event, decision) {
  const v = maintenanceObject(decision, ['outcome', 'reason'], ['proposal']);
  const base = { schemaVersion: 1, streamId: event.streamId, signalIds: [event.id], processId: event.processId, sourceVersion: context.source.version, outcome: v.outcome, reason: maintenanceText(v.reason) };
  if (event.after?.version !== context.source.version || context.source.processId !== event.processId || context.streamId !== event.streamId) return invalidMaintenance('ProForma evidence changed.');
  if (v.outcome === 'no_change' && !Object.hasOwn(v, 'proposal')) return base;
  if (v.outcome !== 'propose_revision') return invalidMaintenance();
  const proposal = maintenanceObject(v.proposal, ['title', 'changes']); maintenanceText(proposal.title,160);
  const changes = list(proposal.changes,12); if (!changes.length) return invalidMaintenance();
  for (const change of changes) {
    maintenanceObject(change,['instruction','evidence'],['sourceEvidence']); maintenanceText(change.instruction);
    const e = maintenanceObject(change.evidence,['field','stepId','quote','start']); maintenanceText(e.quote,1000); maintenanceInteger(e.start);
    const target = e.stepId === null ? context.process : context.process.steps.find(s => s.id === e.stepId);
    if (!(e.stepId === null ? fields : stepFields).includes(e.field) || !target || target[e.field].slice(e.start,e.start+e.quote.length) !== e.quote) return invalidMaintenance('A proposed revision needs an exact current source quote.');
    if (change.sourceEvidence !== undefined) {
      const references = list(change.sourceEvidence, 4), available = maintenanceApplicationChanges(event), seen = new Set();
      if (!references.length) return invalidMaintenance();
      for (const reference of references) {
        maintenanceObject(reference, ['signalId', 'nodeId', 'beforeFingerprint', 'afterFingerprint']);
        const comparison = available.find(item => item.nodeId === reference.nodeId);
        if (!comparison || reference.signalId !== event.id || reference.beforeFingerprint !== comparison.beforeFingerprint || reference.afterFingerprint !== comparison.afterFingerprint || seen.has(reference.nodeId)) return invalidMaintenance('Choose a changed application source from this observation.');
        seen.add(reference.nodeId);
      }
    }
  }
  return { ...base, proposal: structuredClone(proposal) };
}
export function validateMaintenanceCommand(input) {
  const v = maintenanceObject(input, ['id','action','expectedRevision'], ['assessment']);
  maintenanceId(v.id); maintenanceInteger(v.expectedRevision);
  if (!['reconcile','assess_changes'].includes(v.action) || (v.action === 'reconcile' ? v.assessment !== undefined : !v.assessment)) return invalidMaintenance();
  return structuredClone(v);
}
export function validateMaintenanceReceipt(input, binding, command) {
  const v = maintenanceObject(input, ['schemaVersion','kind','producer','scope','revision','receipt','canExecute']);
  envelope(v,'proforma.maintenance-receipt',binding); maintenanceInteger(v.revision);
  const r = maintenanceObject(v.receipt,['id','payloadHash','actorId','action','resultId','at','revision']);
  if (r.id !== command.id || r.payloadHash !== maintenanceHash(command) || r.actorId !== binding.actorId || r.action !== command.action || r.revision > v.revision || r.revision !== command.expectedRevision + 1 || !Number.isFinite(Date.parse(r.at))) return invalidMaintenance();
  const expectedResult = command.action === 'assess_changes' && command.assessment.outcome === 'propose_revision' ? `maintenance:${maintenanceHash(command.assessment.processId)}` : null;
  if (r.resultId !== expectedResult) return invalidMaintenance();
  return structuredClone(v);
}
