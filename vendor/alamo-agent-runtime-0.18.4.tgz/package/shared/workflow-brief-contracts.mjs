import { foundationObject, foundationList, foundationUnique, foundationKey, validateFoundationEvidence } from "./foundation-contracts.mjs";
import { draftReviewHash, draftReviewId, draftReviewDigest } from "./draft-review-contracts.mjs";
import { validateWorkContextRequest } from "./work-context-contracts.mjs";
import { workflowStamp, workflowUnavailable, WORKFLOW_HISTORY_LIMITS } from "./workflow-history-contracts.mjs";

export const WORKFLOW_TREND_POLICY = Object.freeze({ id: "pipeline-first-handoff", version: 1, minimumCohort: 3,
  periods: [
    { id: "earlier", from: "2026-10-12T00:00:00.000Z", through: "2026-10-15T00:00:00.000Z" },
    { id: "later", from: "2026-10-15T00:00:00.000Z", through: "2026-10-18T00:00:00.000Z" },
  ],
  cohort: "Cases opened in each half-open UTC interval, within the current source-granted team and community scope.",
  duration: "Elapsed minutes from case_opened to the first source-recorded successful handoff. Completed-case statistic; pending cases are counted separately.",
  blocker: "Cases with at least one blocker_opened / all cases in that opening cohort. Resolution does not erase the historical blocker.",
  limits: "Fictional fixed cohorts. No staff ranking, clinical outcome, active-work estimate, causal attribution or receiving acknowledgment inferred from sent status." });

export const WORKFLOW_BRIEF_OPERATIONS = Object.freeze(["team_exceptions", "workflow_trend"]);
const exact = foundationObject;
const equal = (a, b) => draftReviewHash(a) === draftReviewHash(b);
function count(value, max = 500) {
  if (!Number.isSafeInteger(value) || value < 0 || value > max) return workflowUnavailable();
  return value;
}
function minutes(value) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 100_000_000) return workflowUnavailable();
  return value;
}
function choice(value, options) { if (!options.includes(value)) return workflowUnavailable(); return value; }
const refs = value => foundationUnique(foundationList(value, foundationKey, 500, 1), x => x);

// Exact allowlists at the source-to-agent boundary. Aggregate readers never
// receive a raw event, case identifier, owner identifier or private narrative.
export function validateWorkflowBriefView(value) {
  if (value?.kind === "team_exceptions") {
    const v = exact(value, ["kind", "cases", "coverage", "asOf", "authority", "sourceMutation"]);
    const coverage = exact(v.coverage, ["authorizedCases", "source"]), asOf = workflowStamp(v.asOf);
    if (coverage.source !== "complete" || v.authority !== "read_investigate_draft" || v.sourceMutation !== false) return workflowUnavailable();
    const authorizedCases = Number(count(coverage.authorizedCases));
    const cases = foundationUnique(foundationList(v.cases, item => {
      const c = exact(item, ["caseId", "ownerId", "teamId", "communityId", "sourceRevision", "elapsedMinutes", "issues", "latestHandoff", "sourceEvidenceIds"]);
      const sourceEvidenceIds = refs(c.sourceEvidenceIds);
      const issues = foundationList(c.issues, item => {
        const i = exact(item, ["code", "since", "evidenceIds"]), evidenceIds = refs(i.evidenceIds), since = workflowStamp(i.since);
        if (since > asOf || evidenceIds.some(id => !sourceEvidenceIds.includes(id))) return workflowUnavailable();
        return { code: choice(i.code, ["receiving_contact", "answer_evidence", "placement_question", "handoff_failed", "acknowledgment_unknown"]), since, evidenceIds };
      }, 500, 1);
      const h = exact(c.latestHandoff, ["result", "acknowledgment"]);
      const latestHandoff = { result: choice(h.result, ["sent", "failed", "not_recorded"]), acknowledgment: choice(h.acknowledgment, ["recorded", "unknown"]) };
      if (latestHandoff.result !== "sent" && latestHandoff.acknowledgment === "recorded") return workflowUnavailable();
      return { caseId: foundationKey(c.caseId), ownerId: draftReviewId(c.ownerId), teamId: foundationKey(c.teamId), communityId: foundationKey(c.communityId),
        sourceRevision: draftReviewDigest(c.sourceRevision), elapsedMinutes: minutes(c.elapsedMinutes), issues, latestHandoff, sourceEvidenceIds };
    }, 500), c => c.caseId);
    if (cases.length > authorizedCases) return workflowUnavailable();
    return { kind: "team_exceptions", cases, coverage: { authorizedCases, source: "complete" }, asOf,
      authority: "read_investigate_draft", sourceMutation: false };
  }
  const v = exact(value, ["kind", "metric", "periods", "lineage", "recordDrilldown", "causalConclusion", "sourceMutation"]);
  if (v.kind !== "workflow_trend" || !equal(v.metric, WORKFLOW_TREND_POLICY) || v.recordDrilldown !== "not_authorized" ||
      v.causalConclusion !== "not_established" || v.sourceMutation !== false) return workflowUnavailable();
  const l = exact(v.lineage, ["application", "asOf", "coverage", "queryRevision"]), asOf = workflowStamp(l.asOf);
  if (l.application !== "pipeline" || l.coverage !== "complete" || l.queryRevision !== draftReviewHash(WORKFLOW_TREND_POLICY)) return workflowUnavailable();
  const periods = foundationList(v.periods, (item) => {
    const p = exact(item, ["period", "from", "through", "periodStatus", "status", "measures"]);
    const expected = WORKFLOW_TREND_POLICY.periods.find(x => x.id === p.period);
    if (!expected || p.from !== expected.from || p.through !== expected.through || p.periodStatus !== (p.through <= asOf ? "closed" : "provisional")) return workflowUnavailable();
    choice(p.status, ["available", "suppressed"]);
    const period = { period: expected.id, from: expected.from, through: expected.through, periodStatus: p.periodStatus, status: p.status };
    if (p.status === "suppressed") { if (p.measures !== null) return workflowUnavailable(); return { ...period, measures: null }; }
    /** @type {Record<string, any>} */
    const m = exact(p.measures, ["cases", "casesWithRecordedSend", "pendingRecordedSend", "casesWithBlocker", "blockerDenominator", "casesWithUnresolvedBlockers",
      "casesWithUnknownAcknowledgment", "medianMinutesToFirstRecordedSend", "durationStatus", "sentCaseDenominator"]);
    for (const key of ["cases", "casesWithRecordedSend", "pendingRecordedSend", "casesWithBlocker", "blockerDenominator", "casesWithUnresolvedBlockers", "casesWithUnknownAcknowledgment", "sentCaseDenominator"]) count(m[key]);
    if (m.cases < WORKFLOW_TREND_POLICY.minimumCohort || m.casesWithRecordedSend + m.pendingRecordedSend !== m.cases ||
      m.blockerDenominator !== m.cases || m.sentCaseDenominator !== m.casesWithRecordedSend || m.casesWithBlocker > m.cases ||
      m.casesWithUnresolvedBlockers > m.casesWithBlocker || m.casesWithUnknownAcknowledgment > m.casesWithRecordedSend) return workflowUnavailable();
    const available = m.sentCaseDenominator >= WORKFLOW_TREND_POLICY.minimumCohort;
    if (m.durationStatus !== (available ? "available" : "suppressed") || (!available && m.medianMinutesToFirstRecordedSend !== null)) return workflowUnavailable();
    if (available) minutes(m.medianMinutesToFirstRecordedSend);
    return { ...period, measures: m };
  }, 2, 2);
  if (!equal(periods.map(p => p.period), WORKFLOW_TREND_POLICY.periods.map(p => p.id))) return workflowUnavailable();
  return { kind: "workflow_trend", metric: structuredClone(WORKFLOW_TREND_POLICY), periods,
    lineage: { application: "pipeline", asOf, coverage: "complete", queryRevision: l.queryRevision },
    recordDrilldown: "not_authorized", causalConclusion: "not_established", sourceMutation: false };
}

export function validateWorkflowBriefPacket(value, now) {
  const v = exact(value, ["schemaVersion", "mode", "snapshot", "view"]);
  if (v.schemaVersion !== 1 || v.mode !== "synthetic-only" || !Number.isSafeInteger(now) || now < 0 || Buffer.byteLength(JSON.stringify(v)) > 524288) return workflowUnavailable();
  const snapshot = validateFoundationEvidence(v.snapshot), view = validateWorkflowBriefView(v.view);
  const asOf = workflowStamp(view.kind === "team_exceptions" ? view.asOf : view.lineage?.asOf);
  if (snapshot.source.application !== "pipeline" || snapshot.source.kind !== "workflow-view" || snapshot.source.id !== view.kind ||
    snapshot.source.revision !== draftReviewHash(view) || snapshot.id !== `workflow-${view.kind}` || snapshot.completeness !== "complete" ||
    snapshot.resourceScope.kind !== "source-user" || snapshot.resourceScope.ids.length || snapshot.asOf !== asOf ||
    Date.parse(snapshot.observedAt) > now || now - Date.parse(asOf) > WORKFLOW_HISTORY_LIMITS.freshnessMs ||
    Date.parse(snapshot.grant.expiresAt) <= now) return workflowUnavailable();
  return { schemaVersion: 1, mode: "synthetic-only", snapshot, view };
}

export function verifyWorkflowBriefPacket(value, input, operation, now) {
  const packet = validateWorkflowBriefPacket(value, now), request = validateWorkContextRequest(input);
  const s = packet.snapshot;
  if (packet.view.kind !== operation || !equal(request, { scope: s.scope, resourceScope: s.resourceScope, source: s.source })) return workflowUnavailable();
  return packet;
}
