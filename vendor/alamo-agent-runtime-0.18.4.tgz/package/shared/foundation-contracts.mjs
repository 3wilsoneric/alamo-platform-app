/**
 * Foundation definition contracts, schema v1. Pure validation: these documents
 * are not deployment configuration, authenticated claims or completion proof.
 * No validator fetches a source, registers a tool or changes production access.
 */
export const FOUNDATION_SCHEMA_VERSION = 1;

/** @returns {never} */
export function foundationInvalid() { throw new Error("Invalid foundation contract."); }
/** @param {unknown} value @param {string[]} names @returns {Record<string, unknown>} */
export function foundationObject(value, names) {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
      Reflect.ownKeys(value).length !== names.length || names.some(name => !Object.hasOwn(value, name)) ||
      Object.values(Object.getOwnPropertyDescriptors(value)).some(d => !d.enumerable || !("value" in d))) return foundationInvalid();
  return /** @type {Record<string, unknown>} */ (value);
}
/** @param {unknown} value @param {number} maximum */
function text(value, maximum) {
  if (typeof value !== "string" || !value || value !== value.trim() || value.length > maximum || /[\x00-\x1f\x7f]/.test(value)) return foundationInvalid();
  return value;
}
/** @param {unknown} value */
export function foundationKey(value) {
  const result = text(value, 128);
  if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/.test(result)) return foundationInvalid();
  return result;
}
/** @param {unknown} value */
function opaque(value) {
  const result = text(value, 128);
  if (!/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(result)) return foundationInvalid();
  return result;
}
/** @param {unknown} value */
function uuid(value) {
  const result = text(value, 36);
  if (!/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(result)) return foundationInvalid();
  return result;
}
/** @param {unknown} value @param {number} minimum @param {number} maximum */
function integer(value, minimum, maximum) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) return foundationInvalid();
  return value;
}
/** @param {unknown} value */
function revision(value) { return integer(value, 1, Number.MAX_SAFE_INTEGER); }
/** @param {unknown} value */
function version(value) {
  if (value !== FOUNDATION_SCHEMA_VERSION) return foundationInvalid();
  return FOUNDATION_SCHEMA_VERSION;
}
/** @template {string} T @param {unknown} value @param {T[]} choices @returns {T} */
function choice(value, choices) {
  if (typeof value !== "string" || !choices.includes(/** @type {T} */ (value))) return foundationInvalid();
  return /** @type {T} */ (value);
}
/** @template T @param {unknown} value @param {(item: unknown) => T} validate @param {number} maximum @param {number} [minimum] @returns {T[]} */
export function foundationList(value, validate, maximum, minimum = 0) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length < minimum || value.length > maximum ||
      Reflect.ownKeys(value).length !== value.length + 1) return foundationInvalid();
  const result = [];
  for (let index = 0; index < value.length; index++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, index);
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return foundationInvalid();
    result.push(validate(descriptor.value));
  }
  return result;
}
/** @template T @param {T[]} values @param {(item: T) => string} key @returns {T[]} */
export function foundationUnique(values, key) {
  if (new Set(values.map(key)).size !== values.length) return foundationInvalid();
  return values;
}
/** @param {unknown} value */
function keys(value, maximum, minimum = 0) { return foundationUnique(foundationList(value, foundationKey, maximum, minimum), item => item); }
/** @param {unknown} value */
function stamp(value) {
  const result = text(value, 24);
  if (!Number.isFinite(Date.parse(result)) || new Date(result).toISOString() !== result) return foundationInvalid();
  return result;
}
/** @param {unknown} value */
function digest(value) {
  const result = text(value, 64);
  if (!/^[a-f0-9]{64}$/.test(result)) return foundationInvalid();
  return result;
}
/** @param {unknown} value */
export function validateFoundationScope(value) {
  const v = foundationObject(value, ["companyId", "tenantId", "subjectId"]);
  return { companyId: uuid(v.companyId), tenantId: uuid(v.tenantId), subjectId: uuid(v.subjectId) };
}
/** @param {unknown} value */
export function validateFoundationResourceScope(value) {
  const v = foundationObject(value, ["kind", "ids"]);
  const kind = choice(v.kind, ["community", "organization", "source-user"]);
  const ids = foundationUnique(foundationList(v.ids, opaque, 20), item => item).sort();
  if (kind === "community" ? !ids.length : ids.length !== 0) return foundationInvalid();
  return { kind, ids };
}
/** @param {unknown} value */
function skillReference(value) {
  const v = foundationObject(value, ["id", "version"]);
  return { id: foundationKey(v.id), version: revision(v.version) };
}
/** @param {unknown} value */
function applicationReference(value) {
  const v = foundationObject(value, ["id", "revision"]);
  return { id: foundationKey(v.id), revision: revision(v.revision) };
}
/** @param {unknown} value */
export function validateCompanyDefinition(value) {
  const v = foundationObject(value, ["schemaVersion", "companyId", "tenantId", "revision", "name", "subjects", "applications", "skills"]);
  return { schemaVersion: version(v.schemaVersion), companyId: uuid(v.companyId), tenantId: uuid(v.tenantId),
    revision: revision(v.revision), name: text(v.name, 100),
    subjects: foundationUnique(foundationList(v.subjects, uuid, 100, 1), item => item),
    applications: foundationUnique(foundationList(v.applications, applicationReference, 20), item => item.id),
    skills: foundationUnique(foundationList(v.skills, skillReference, 100), item => item.id) };
}
/** @param {unknown} value */
function capability(value) {
  const v = foundationObject(value, ["id", "version", "operation", "scope", "protocol", "resourceKinds"]);
  const protocol = foundationObject(v.protocol, ["id", "version"]);
  const protocolId = choice(protocol.id, ["agent-summary", "assessment-review", "workflow-knowledge"]);
  const protocolVersion = integer(protocol.version, 1, 2);
  if (protocolVersion !== (protocolId === "assessment-review" ? 2 : 1)) return foundationInvalid();
  if (v.operation !== "read") return foundationInvalid();
  const scope = choice(v.scope, ["community", "organization", "source-user"]);
  if ((protocolId !== "agent-summary") !== (scope === "source-user")) return foundationInvalid();
  return { id: foundationKey(v.id), version: revision(v.version), operation: /** @type {const} */ ("read"), scope,
    protocol: { id: protocolId, version: protocolVersion }, resourceKinds: keys(v.resourceKinds, 20, 1) };
}
/** @param {unknown} value */
export function validateApplicationManifest(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "revision", "name", "capabilities"]);
  return { schemaVersion: version(v.schemaVersion), id: foundationKey(v.id), revision: revision(v.revision), name: text(v.name, 100),
    capabilities: foundationUnique(foundationList(v.capabilities, capability, 50), item => item.id) };
}
/** @param {unknown} value */
export function validateFoundationSkill(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "version", "application", "capability", "capabilityVersion", "scope", "completion", "limits", "evaluation"]);
  const completion = foundationObject(v.completion, ["kind", "checkIds"]);
  const limits = foundationObject(v.limits, ["maxRecords", "deadlineSeconds", "maxEvidenceAgeSeconds"]);
  const checks = keys(completion.checkIds, 20, 1);
  if (!["source_grant_current", "evidence_saved"].every(id => checks.includes(id))) return foundationInvalid();
  const kind = choice(completion.kind, ["evidence-collection", "review-scan"]);
  if (kind === "review-scan" && !checks.includes("all_authorized_records_reviewed")) return foundationInvalid();
  return { schemaVersion: version(v.schemaVersion), id: foundationKey(v.id), version: revision(v.version),
    application: foundationKey(v.application), capability: foundationKey(v.capability), capabilityVersion: revision(v.capabilityVersion),
    scope: choice(v.scope, ["community", "organization", "source-user"]), completion: { kind, checkIds: checks },
    limits: { maxRecords: integer(limits.maxRecords, 1, 500), deadlineSeconds: integer(limits.deadlineSeconds, 1, 86400),
      maxEvidenceAgeSeconds: integer(limits.maxEvidenceAgeSeconds, 1, 604800) }, evaluation: skillReference(v.evaluation) };
}
/** @param {unknown} value */
export function validateFoundationResponsibility(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "revision", "scope", "skill", "resourceScope", "trigger", "state"]);
  const trigger = foundationObject(v.trigger, ["kind"]);
  if (trigger.kind !== "manual") return foundationInvalid();
  return { schemaVersion: version(v.schemaVersion), id: opaque(v.id), revision: revision(v.revision), scope: validateFoundationScope(v.scope),
    skill: skillReference(v.skill), resourceScope: validateFoundationResourceScope(v.resourceScope),
    trigger: { kind: /** @type {const} */ ("manual") }, state: choice(v.state, ["draft", "paused"]) };
}
/** @param {unknown} value */
export function validateFoundationSourceReference(value) {
  const v = foundationObject(value, ["application", "kind", "id", "revision"]);
  return { application: foundationKey(v.application), kind: foundationKey(v.kind), id: opaque(v.id),
    revision: v.revision === null ? null : opaque(v.revision) };
}
/** @param {unknown} value */
export function validateFoundationEvidence(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "scope", "resourceScope", "source", "observedAt", "asOf", "completeness", "grant"]);
  const grant = foundationObject(v.grant, ["application", "id", "revision", "expiresAt"]);
  const source = validateFoundationSourceReference(v.source);
  const observedAt = stamp(v.observedAt), asOf = v.asOf === null ? null : stamp(v.asOf);
  if (grant.application !== source.application || (asOf && asOf > observedAt)) return foundationInvalid();
  return { schemaVersion: version(v.schemaVersion), id: opaque(v.id), scope: validateFoundationScope(v.scope),
    resourceScope: validateFoundationResourceScope(v.resourceScope), source, observedAt, asOf,
    completeness: choice(v.completeness, ["complete", "partial", "unknown"]),
    grant: { application: source.application, id: opaque(grant.id), revision: digest(grant.revision), expiresAt: stamp(grant.expiresAt) } };
}
/** @param {unknown} value */
export function validateFoundationOutcome(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "runId", "correlationId", "causationId", "responsibility", "scope", "skill", "producer", "occurredAt", "status",
    "reasonCode", "kind", "checks", "evidenceIds", "coverage", "sourceMutation", "publication"]);
  const responsibility = foundationObject(v.responsibility, ["id", "revision"]);
  if (v.producer !== "alamoagent" || v.sourceMutation !== false || v.publication !== "not-published") return foundationInvalid();
  const id = opaque(v.id), causationId = v.causationId === null ? null : opaque(v.causationId);
  if (causationId === id) return foundationInvalid();
  const status = choice(v.status, ["completed", "blocked", "failed", "canceled"]);
  const reasonCode = v.reasonCode === null ? null : foundationKey(v.reasonCode);
  if ((status === "completed") !== (reasonCode === null)) return foundationInvalid();
  const checks = foundationUnique(foundationList(v.checks, item => {
    const check = foundationObject(item, ["id", "status"]);
    return { id: foundationKey(check.id), status: choice(check.status, ["passed", "failed", "unknown"]) };
  }, 20), item => item.id);
  let coverage = null;
  if (v.coverage !== null) {
    const c = foundationObject(v.coverage, ["expected", "reviewed"]);
    coverage = { expected: integer(c.expected, 0, 500), reviewed: integer(c.reviewed, 0, 500) };
    if (coverage.reviewed > coverage.expected) return foundationInvalid();
  }
  const kind = choice(v.kind, ["evidence-collection", "review-scan"]);
  const evidenceIds = foundationUnique(foundationList(v.evidenceIds, opaque, 500), item => item);
  if (kind === "evidence-collection" && coverage !== null) return foundationInvalid();
  if (status === "completed" && (!checks.length || !evidenceIds.length || checks.some(check => check.status !== "passed") ||
      (kind === "review-scan" && (!coverage || coverage.expected !== coverage.reviewed)))) return foundationInvalid();
  return { schemaVersion: version(v.schemaVersion), id, runId: opaque(v.runId), correlationId: opaque(v.correlationId), causationId,
    responsibility: { id: opaque(responsibility.id), revision: revision(responsibility.revision) }, scope: validateFoundationScope(v.scope),
    skill: skillReference(v.skill), producer: /** @type {const} */ ("alamoagent"), occurredAt: stamp(v.occurredAt), status, reasonCode,
    kind, checks, evidenceIds, coverage,
    sourceMutation: /** @type {const} */ (false), publication: /** @type {const} */ ("not-published") };
}
