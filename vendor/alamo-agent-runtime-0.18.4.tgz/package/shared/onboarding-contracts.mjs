export const ONBOARDING_API_PATH = "/api/agent/v1/onboarding";
export const ONBOARDING_LIMITS = Object.freeze({ workspaces: 20, events: 120, sources: 20, concepts: 40, mappings: 10,
  commandBytes: 8192, stateBytes: 4 * 1024 * 1024 });
export const onboardingId = value => typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value);

/** @typedef {{sourceId: string, sourceRevision: number, locator: string}} SourceMapping */
/** @typedef {{action: 'create', requestId: string, companyName: string, outcome: string, successCriterion: string}} CreateWorkspace */
/** @typedef {{requestId: string, workspaceId: string, expectedRevision: number}} RevisionCommand */
/** @typedef {RevisionCommand & {action: 'register_source', sourceId: string, title: string, application: string, reference: string, sourceVersion: string, steward: string}} RegisterSource */
/** @typedef {RevisionCommand & {action: 'propose_concept', conceptId: string, label: string, definition: string, mappings: SourceMapping[]}} ProposeConcept */
/** @typedef {RevisionCommand & {action: 'review_concept', conceptId: string, decision: 'confirmed' | 'rejected', note: string}} ReviewConcept */
/** @typedef {RevisionCommand & {action: 'discover_pipeline'}} DiscoverPipeline */
/** @typedef {CreateWorkspace | RegisterSource | ProposeConcept | ReviewConcept | DiscoverPipeline} OnboardingCommand */

const invalid = () => { throw new Error("Invalid onboarding command."); };
function exact(value, fields) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== fields.length ||
      fields.some(key => !Object.hasOwn(value, key))) invalid();
}
function text(value, maximum) {
  if (typeof value !== "string" || !value.trim() || value.length > maximum || /[\x00-\x1f\x7f]/.test(value)) invalid();
  return value.trim();
}
function key(value) {
  if (typeof value !== "string" || !/^[a-z][a-z0-9-]{0,63}$/.test(value)) invalid();
  return value;
}
function reference(value) {
  const result = text(value, 1000);
  let url;
  try { url = new URL(result); } catch { return invalid(); }
  // References are metadata, never fetch instructions or credential containers.
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) invalid();
  return url.href;
}

/** @returns {OnboardingCommand} */
export function validateOnboardingCommand(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || !onboardingId(value.requestId)) invalid();
  if (value.action === "create") {
    exact(value, ["action", "requestId", "companyName", "outcome", "successCriterion"]);
    return { action: "create", requestId: value.requestId, companyName: text(value.companyName, 160),
      outcome: text(value.outcome, 800), successCriterion: text(value.successCriterion, 800) };
  }
  if (!onboardingId(value.workspaceId) || !Number.isSafeInteger(value.expectedRevision) || value.expectedRevision < 1) invalid();
  const base = { requestId: value.requestId, workspaceId: value.workspaceId, expectedRevision: value.expectedRevision };
  const fields = ["action", "requestId", "workspaceId", "expectedRevision"];
  if (value.action === "discover_pipeline") {
    exact(value, fields);
    return { action: "discover_pipeline", ...base };
  }
  if (value.action === "register_source") {
    exact(value, [...fields, "sourceId", "title", "application", "reference", "sourceVersion", "steward"]);
    return { action: "register_source", ...base, sourceId: key(value.sourceId), title: text(value.title, 160),
      application: key(value.application), reference: reference(value.reference), sourceVersion: text(value.sourceVersion, 160),
      steward: text(value.steward, 160) };
  }
  if (value.action === "propose_concept") {
    exact(value, [...fields, "conceptId", "label", "definition", "mappings"]);
    if (!Array.isArray(value.mappings) || value.mappings.length > ONBOARDING_LIMITS.mappings) invalid();
    const mappings = value.mappings.map(mapping => {
      exact(mapping, ["sourceId", "sourceRevision", "locator"]);
      if (!Number.isSafeInteger(mapping.sourceRevision) || mapping.sourceRevision < 1) invalid();
      return { sourceId: key(mapping.sourceId), sourceRevision: mapping.sourceRevision, locator: text(mapping.locator, 240) };
    });
    if (new Set(mappings.map(mapping => JSON.stringify(mapping))).size !== mappings.length) invalid();
    return { action: "propose_concept", ...base, conceptId: key(value.conceptId), label: text(value.label, 160),
      definition: text(value.definition, 1600), mappings };
  }
  if (value.action === "review_concept") {
    exact(value, [...fields, "conceptId", "decision", "note"]);
    if (!["confirmed", "rejected"].includes(value.decision)) invalid();
    return { action: "review_concept", ...base, conceptId: key(value.conceptId), decision: value.decision, note: text(value.note, 800) };
  }
  return invalid();
}

export function createOnboardingClient(requestJson) {
  return {
    list: () => requestJson(ONBOARDING_API_PATH, { cache: "no-store" }),
    read: id => requestJson(`${ONBOARDING_API_PATH}?id=${encodeURIComponent(id)}`, { cache: "no-store" }),
    export: id => requestJson(`${ONBOARDING_API_PATH}?id=${encodeURIComponent(id)}&format=export`, { cache: "no-store" }),
    command: value => requestJson(ONBOARDING_API_PATH, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(value) })
  };
}
