const invalid = () => { throw new Error("Invalid Pipeline assessment projection."); };
const uuid = value => typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value);
const stamp = value => value === null || (typeof value === "string" && /^\d{4}-\d\d-\d\dT[\d:.]+Z$/.test(value) && Number.isFinite(Date.parse(value)));
const count = value => Number.isSafeInteger(value) && value >= 0 && value <= 1000;
const digest = value => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
const fields = (value, names) => value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === names.length && Object.keys(value).every(key => names.includes(key));
export const ASSESSMENT_REVIEW_PATH = "/api/integrations/agent/assessment-review/v2";
export function assessmentReviewRequest(assignment, operation, cursor = null) {
  if (!uuid(assignment.userId) || assignment.skillId !== "assessment-review" || !Array.isArray(assignment.communityIds) || assignment.communityIds.length || !["read", "authorize", "describe"].includes(operation) ||
      (operation !== "read" && cursor !== null)) invalid();
  return { version: 2, operation, subjectId: assignment.userId, skillId: assignment.skillId, communityIds: [], cursor };
}

export function validateAssessmentReviewPage(page) {
  if (!fields(page, ["startedAt", "asOf", "total", "nextCursor", "records"]) || !page.startedAt || !page.asOf || !stamp(page.startedAt) || !stamp(page.asOf)
    || Date.parse(page.startedAt) > Date.parse(page.asOf) || !Number.isSafeInteger(page.total) || page.total < 0 || page.total > 500
    || !(page.nextCursor === null || (typeof page.nextCursor === "string" && /^[a-f0-9]{64}:\d{1,4}$/.test(page.nextCursor)))
    || !Array.isArray(page.records) || page.records.length > 25) invalid();
  const workflowStates = ["unknown", "intake_unassigned", "intake_documents_needed", "profile_incomplete", "ready_to_schedule", "assessment_scheduled", "assessment_in_progress", "waiting_for_information", "assessment_ready_to_sign", "assessment_signed", "recommendation_submitted", "changes_requested", "decision_pending", "approved_for_placement", "accepted", "admitted", "declined", "closed"];
  for (const row of page.records) {
    if (!fields(row, ["referralId", "referralVersion", "assignedAssessorId", "workflowStatus", "sourceUpdatedAt", "decision", "reasonCodePresent", "reasonNotePresent", "assessment", "assessmentState"])
      || typeof row.referralId !== "string" || !/^[1-9]\d{0,11}$/.test(row.referralId) || !Number.isSafeInteger(row.referralVersion) || row.referralVersion < 1
      || !uuid(row.assignedAssessorId) || !workflowStates.includes(row.workflowStatus) || !row.sourceUpdatedAt || !stamp(row.sourceUpdatedAt)
      || !["accepted", "declined", "unknown"].includes(row.decision) || typeof row.reasonCodePresent !== "boolean" || typeof row.reasonNotePresent !== "boolean"
      || !["available", "legacy_unavailable", "absent"].includes(row.assessmentState) || (row.assessmentState === "available") !== (row.assessment !== null)) invalid();
    const a = row.assessment;
    if (a === null) continue;
    if (!fields(a, ["id", "revision", "assessorId", "status", "draftAt", "startedAt", "signedAt", "updatedAt", "sendStatus", "sentAt", "provenance", "authorship", "completion"])
      || typeof a.id !== "string" || !/^asm_[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(a.id) || !Number.isSafeInteger(a.revision) || a.revision < 1
      || a.assessorId !== row.assignedAssessorId || !["draft", "needs_review", "complete"].includes(a.status)
      || ![a.draftAt, a.startedAt, a.signedAt, a.updatedAt, a.sentAt].every(stamp) || !a.draftAt || !a.updatedAt
      || !["sent", "unconfirmed"].includes(a.sendStatus) || (a.sendStatus === "sent") !== (a.sentAt !== null)
      || !["mixed", "imported", "manual", "unknown"].includes(a.provenance)) invalid();
    const u = a.authorship, c = a.completion;
    if (!fields(u, ["state", "distinctFields", "observedDistinctFields", "lastAuthoredAt", "auditThrough"]) || !["verified", "unknown"].includes(u.state)
      || !count(u.observedDistinctFields) || !stamp(u.lastAuthoredAt) || !stamp(u.auditThrough)
      || (u.state === "verified" ? !count(u.distinctFields) || u.distinctFields !== u.observedDistinctFields : u.distinctFields !== null)) invalid();
    if (!fields(c, ["state", "questionnaireVersion", "rulesVersion", "complete", "total", "narrativePresent", "narrativeTotal"])
      || !["verified", "current_rules_only", "unsupported_version"].includes(c.state) || !digest(c.rulesVersion)
      || !(c.questionnaireVersion === null || digest(c.questionnaireVersion))
      || (c.state === "verified" && c.questionnaireVersion !== c.rulesVersion)
      || (c.state === "current_rules_only" && c.questionnaireVersion !== null)
      || (c.state === "unsupported_version" && (!c.questionnaireVersion || c.questionnaireVersion === c.rulesVersion))) invalid();
    if (c.state === "unsupported_version") {
      if ([c.complete, c.total, c.narrativePresent, c.narrativeTotal].some(value => value !== null)) invalid();
    } else if (![c.complete, c.total, c.narrativePresent, c.narrativeTotal].every(count) || c.complete > c.total || c.narrativePresent > c.narrativeTotal) invalid();
  }
  return page;
}
