import { foundationObject, foundationList } from "./foundation-contracts.mjs";
import { draftReviewDigest, draftReviewHash, draftReviewId } from "./draft-review-contracts.mjs";

function boundedText(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 2000) throw new Error("Invalid improvement feedback.");
  return value;
}
function validateReport(report) {
  if (report?.schemaVersion !== 1 || report.mode !== "synthetic-only" || report.evaluation !== "live_model" || report.fullSuite !== true ||
      !Number.isInteger(report.trials) || report.trials < 2 || report.trials > 3 || !["failed", "awaiting_human_review"].includes(report.status)) {
    throw new Error("A completed full repeated live evaluation is required.");
  }
  draftReviewDigest(report.harnessRevision); draftReviewDigest(report.suiteRevision);
  boundedText(report.runId); boundedText(report.model); boundedText(report.rubricVersion);
  if (!Array.isArray(report.cases) || report.cases.length < 1 || report.cases.length > 300) throw new Error("Invalid evaluation cases.");
  const seen = new Set(), counts = new Map();
  for (const c of report.cases) {
    boundedText(c.id);
    if (!Number.isInteger(c.trial) || c.trial < 1 || c.trial > report.trials || !["passed", "failed"].includes(c.status) || !Array.isArray(c.runs)) throw new Error("Incomplete evaluation trial.");
    const key = `${c.id}/${c.trial}`; if (seen.has(key)) throw new Error("Duplicate evaluation trial."); seen.add(key);
    counts.set(c.id, (counts.get(c.id) ?? 0) + 1);
    for (const run of c.runs) draftReviewId(run.runId);
  }
  if ([...counts.values()].some(n => n !== report.trials)) throw new Error("Missing evaluation trial.");
  if ((report.status === "awaiting_human_review") !== report.cases.every(c => c.status === "passed")) throw new Error("Inconsistent evaluation status.");
  return report;
}

// Offline engineering review material, not an activation or permission service.
// Feedback reviewer IDs are attribution supplied by the author, not authenticated
// signatures. Neither editable reports nor a passing comparison can grant access.
export function prepareSkillCandidateReview({ baseline, candidate, feedback }) {
  validateReport(baseline); validateReport(candidate);
  if (baseline.harnessRevision === candidate.harnessRevision) throw new Error("Candidate must identify a changed harness revision.");
  for (const key of ["suiteRevision", "rubricVersion", "model", "trials"]) {
    if (baseline[key] !== candidate[key]) throw new Error("Baseline and candidate evaluations are not comparable.");
  }
  const beforeKeys = baseline.cases.map(c => `${c.id}/${c.trial}`).sort(), afterKeys = candidate.cases.map(c => `${c.id}/${c.trial}`).sort();
  if (JSON.stringify(beforeKeys) !== JSON.stringify(afterKeys)) throw new Error("Candidate case coverage changed.");
  const records = foundationList(feedback, item => {
    const f = foundationObject(item, ["id", "evalRunId", "caseId", "trial", "traceRunId", "reviewerId", "category", "observation", "proposedChange"]);
    const traceRunId = draftReviewId(f.traceRunId);
    const sourceCase = baseline.cases.find(c => c.id === f.caseId && c.trial === f.trial);
    if (f.evalRunId !== baseline.runId || !sourceCase?.runs.some(r => r.runId === traceRunId)) throw new Error("Feedback must reference an actual baseline case and trace.");
    if (!["selection", "evidence", "wording", "workflow", "efficiency", "control"].includes(String(f.category))) throw new Error("Unknown feedback category.");
    return { id: draftReviewId(f.id), evalRunId: baseline.runId, caseId: sourceCase.id, trial: sourceCase.trial, traceRunId,
      reviewerId: boundedText(f.reviewerId), category: String(f.category), observation: boundedText(f.observation), proposedChange: boundedText(f.proposedChange) };
  }, 50, 1);
  if (new Set(records.map(f => f.id)).size !== records.length) throw new Error("Duplicate feedback.");
  const comparisons = [...new Set(baseline.cases.map(c => c.id))].map(id => {
    const passed = report => report.cases.filter(c => c.id === id && c.status === "passed").length;
    return { id, baselinePassed: passed(baseline), candidatePassed: passed(candidate), trials: baseline.trials, regression: passed(candidate) < passed(baseline) };
  });
  const blocked = comparisons.some(c => c.regression || c.candidatePassed !== c.trials);
  return { schemaVersion: 1, baseline: { runId: baseline.runId, harnessRevision: baseline.harnessRevision },
    candidate: { runId: candidate.runId, harnessRevision: candidate.harnessRevision, parentRevision: baseline.harnessRevision },
    suiteRevision: baseline.suiteRevision, rubricVersion: baseline.rubricVersion,
    feedback: records, feedbackRevision: draftReviewHash(records), comparisons,
    recommendation: blocked ? "repair_and_reevaluate" : "request_human_review",
    humanApproval: "required", activation: "not_performed", releaseReady: false,
    limits: "Comparable synthetic regressions and attributed feedback only. Human semantic grading, independent cases and authorized host release remain separate gates." };
}
