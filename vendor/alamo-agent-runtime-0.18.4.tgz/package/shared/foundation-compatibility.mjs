import { EVERYAGENT_SKILLS } from "./everyagent-catalog.mjs";
import { validateAgentSourceRequest } from "./everyagent-source-contracts.mjs";
import { assessmentReviewRequest } from "./assessment-review-contracts.mjs";
import { ASSESSMENT_REVIEW_RESPONSIBILITY } from "../skills/assessment-review/responsibility.mjs";
import { validateFoundationBundle } from "./foundation-conformance.mjs";

/** @returns {never} */
const incompatible = () => { throw new Error("Foundation definition is not compatible with the current source contract."); };
/**
 * Compare declarations with the checked-in registry. No migration, connection,
 * authentication, grant creation or claim of source readiness occurs here.
 * @param {unknown} value
 */
export function describeFoundationCompatibility(value) {
  const bundle = validateFoundationBundle(value);
  return bundle.company.skills.map(ref => {
    const skill = bundle.catalog.skills.find(item => item.id === ref.id && item.version === ref.version);
    const legacy = EVERYAGENT_SKILLS.find(item => item.id === ref.id && item.version === ref.version);
    if (!skill || !legacy || skill.application !== legacy.sourceApplication || skill.capability !== legacy.capability ||
        skill.scope !== legacy.scope || skill.capabilityVersion !== 1) return incompatible();
    const capability = bundle.catalog.applications.find(app => app.id === skill.application)?.capabilities.find(item => item.id === skill.capability);
    const protocolVersion = legacy.sourceProtocol ?? 1;
    if (!capability || capability.protocol.version !== protocolVersion ||
        capability.protocol.id !== (protocolVersion === 2 ? "assessment-review" : "agent-summary")) return incompatible();
    if (skill.id === "assessment-review") {
      const policy = ASSESSMENT_REVIEW_RESPONSIBILITY;
      if (skill.completion.kind !== "review-scan" || skill.completion.checkIds.length !== policy.completionChecks.length ||
          policy.completionChecks.some(id => !skill.completion.checkIds.includes(id)) || skill.limits.maxRecords > policy.maximumRecords ||
          skill.limits.deadlineSeconds > policy.deadlineMinutes * 60) return incompatible();
    } else if (skill.completion.kind !== "evidence-collection") return incompatible();
    return { skillId: skill.id, application: skill.application, protocolVersion,
      status: /** @type {const} */ ("declaration-compatible"),
      completionMapping: skill.id === "assessment-review" ? "existing-receipt-needs-explicit-company-binding" : "new-producer-required",
      requiresCompanySourceBinding: true, productionActivation: false };
  });
}
/**
 * Produce an offline wire-format EXAMPLE for the existing request validators.
 * Legacy wire protocols do not carry companyId. A future runtime adapter must
 * separately verify the company/tenant/source binding and current source grant.
 * This function is never used by the API, worker or transport to authorize work.
 * @param {unknown} value @param {string} responsibilityId
 */
export function buildLegacyReadExample(value, responsibilityId) {
  const bundle = validateFoundationBundle(value);
  const compatibility = describeFoundationCompatibility(bundle);
  const responsibility = bundle.responsibilities.find(item => item.id === responsibilityId);
  const entry = compatibility.find(item => item.skillId === responsibility?.skill.id);
  if (!responsibility || !entry) return incompatible();
  const assignment = { userId: responsibility.scope.subjectId, skillId: responsibility.skill.id, communityIds: responsibility.resourceScope.ids };
  const request = entry.protocolVersion === 2 ? assessmentReviewRequest(assignment, "read") :
    validateAgentSourceRequest({ version: 1, operation: "read", subjectId: assignment.userId, skillId: assignment.skillId, communityIds: assignment.communityIds });
  return { companyId: responsibility.scope.companyId, tenantId: responsibility.scope.tenantId,
    application: entry.application, request, authorization: /** @type {const} */ ("not-established") };
}
