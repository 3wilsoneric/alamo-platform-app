import { foundationObject, foundationKey } from "./foundation-contracts.mjs";
import { draftReviewId, draftReviewDigest, draftReviewHash } from "./draft-review-contracts.mjs";
import { validateWorkflowFeed, workflowUnavailable } from "./workflow-history-contracts.mjs";

// A bounded synthetic export contract, not a producer credential or a claim that
// Pipeline's existing partial audit observations constitute complete history.
export function validateWorkflowPublisher(value) {
  const v = foundationObject(value, ["application", "datasetId", "companyId", "tenantId"]);
  if (v.application !== "pipeline") return workflowUnavailable();
  return { application: "pipeline", datasetId: foundationKey(v.datasetId),
    companyId: draftReviewId(v.companyId), tenantId: draftReviewId(v.tenantId) };
}

export function workflowPublicationRevision(value) {
  return draftReviewHash({ schemaVersion: value.schemaVersion, publisher: value.publisher,
    sequence: value.sequence, previousRevision: value.previousRevision, feedRevision: value.feed.revision });
}

export function validateWorkflowPublication(value, now) {
  const v = foundationObject(value, ["schemaVersion", "publisher", "sequence", "previousRevision", "feed", "revision"]);
  if (v.schemaVersion !== 1 || !Number.isSafeInteger(v.sequence) || Number(v.sequence) < 1) return workflowUnavailable();
  const publisher = validateWorkflowPublisher(v.publisher), feed = validateWorkflowFeed(v.feed, now);
  const previousRevision = v.previousRevision === null ? null : draftReviewDigest(v.previousRevision);
  if ((v.sequence === 1) !== (previousRevision === null) || feed.coverage !== "complete" ||
      feed.companyId !== publisher.companyId || feed.tenantId !== publisher.tenantId) return workflowUnavailable();
  const publication = { schemaVersion: 1, publisher, sequence: Number(v.sequence), previousRevision, feed, revision: draftReviewDigest(v.revision) };
  if (publication.revision !== workflowPublicationRevision(publication)) return workflowUnavailable();
  return publication;
}
