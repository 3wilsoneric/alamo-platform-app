import { foundationObject, foundationList, foundationUnique, foundationKey,
  validateFoundationScope, validateFoundationResourceScope, validateFoundationSourceReference,
  validateFoundationEvidence } from "./foundation-contracts.mjs";

export const WORK_CONTEXT_VERSION = 1;
/** @returns {never} */
export function workContextInvalid() { throw new Error("Work context could not be verified."); }
function text(value, maximum = 200) {
  if (typeof value !== "string" || !value.trim() || value.length > maximum || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value)) return workContextInvalid();
  return value;
}
function id(value) {
  const result = text(value, 128);
  if (!/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(result)) return workContextInvalid();
  return result;
}
function choice(value, choices) { if (!choices.includes(value)) return workContextInvalid(); return value; }
function refs(value) { return foundationUnique(foundationList(value, id, 32), item => item); }
function source(value) {
  const result = validateFoundationSourceReference(value);
  if (result.revision === null) return workContextInvalid();
  return result;
}
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);

// A validated request describes scope; it is NOT authenticated authority. The
// source adapter must obtain that authority from its trusted host, not the model.
export function validateWorkContextRequest(value) {
  const v = foundationObject(value, ["scope", "resourceScope", "source"]);
  return { scope: validateFoundationScope(v.scope), resourceScope: validateFoundationResourceScope(v.resourceScope), source: source(v.source) };
}

/** Parse a bounded source-owned snapshot. Never fetches, grants access or writes. */
export function validateWorkContext(value) {
  const v = foundationObject(value, ["schemaVersion", "snapshot", "assignment", "relatedSources", "missing", "content", "evidence", "requirements", "nextActions"]);
  if (v.schemaVersion !== WORK_CONTEXT_VERSION) return workContextInvalid();
  const snapshot = validateFoundationEvidence(v.snapshot);
  if (!snapshot.source.revision || !snapshot.asOf) return workContextInvalid();
  const a = foundationObject(v.assignment, ["ownerId", "revision"]);
  const assignment = { ownerId: id(a.ownerId), revision: id(a.revision) };
  const relatedSources = foundationUnique(foundationList(v.relatedSources, source, 10), item => `${item.application}:${item.kind}:${item.id}`);
  if (relatedSources.some(item => item.application !== snapshot.source.application ||
    (item.kind === snapshot.source.kind && item.id === snapshot.source.id))) return workContextInvalid();
  const sources = [snapshot.source, ...relatedSources];
  const evidence = foundationUnique(foundationList(v.evidence, item => {
    const e = foundationObject(item, ["id", "source", "locator"]);
    const reference = source(e.source);
    if (!sources.some(candidate => equal(candidate, reference))) return workContextInvalid();
    return { id: id(e.id), source: reference, locator: foundationKey(e.locator) };
  }, 40), item => item.id);
  function evidenceRefs(value) {
    const result = refs(value);
    if (result.some(ref => !evidence.some(item => item.id === ref))) return workContextInvalid();
    return result;
  }
  const content = foundationUnique(foundationList(v.content, item => {
    const c = foundationObject(item, ["id", "label", "text", "status", "evidenceIds"]);
    const status = choice(c.status, ["recorded", "unknown", "unreviewed", "conflicting"]);
    const evidenceIds = evidenceRefs(c.evidenceIds);
    if ((status === "unknown") !== (c.text === null) || (status !== "unknown" && !evidenceIds.length)) return workContextInvalid();
    return { id: foundationKey(c.id), label: text(c.label), text: c.text === null ? null : text(c.text, 2048), status, evidenceIds };
  }, 20), item => item.id);
  const requirements = foundationUnique(foundationList(v.requirements, item => {
    const r = foundationObject(item, ["id", "label", "status", "ownerId", "evidenceIds"]);
    const status = choice(r.status, ["met", "open", "unknown"]), evidenceIds = evidenceRefs(r.evidenceIds);
    if (status !== "unknown" && !evidenceIds.length) return workContextInvalid();
    return { id: foundationKey(r.id), label: text(r.label), status, ownerId: r.ownerId === null ? null : id(r.ownerId), evidenceIds };
  }, 20), item => item.id);
  const nextActions = foundationUnique(foundationList(v.nextActions, item => {
    const n = foundationObject(item, ["id", "label", "mode", "source"]);
    const reference = source(n.source);
    if (n.mode !== "human" || !sources.some(candidate => equal(candidate, reference))) return workContextInvalid();
    return { id: foundationKey(n.id), label: text(n.label), mode: "human", source: reference };
  }, 10), item => item.id);
  const missing = foundationUnique(foundationList(v.missing, foundationKey, 20), item => item);
  if ((snapshot.completeness === "complete") !== (missing.length === 0)) return workContextInvalid();
  const result = { schemaVersion: WORK_CONTEXT_VERSION, snapshot, assignment, relatedSources, missing, content, evidence, requirements, nextActions };
  if (Buffer.byteLength(JSON.stringify(result), "utf8") > 65_536) return workContextInvalid();
  return result;
}

// Pure scope/freshness checks supplement, and cannot replace, source authorization.
export function verifyWorkContext(value, request, now) {
  const context = validateWorkContext(value), input = validateWorkContextRequest(request), s = context.snapshot;
  if (!s.asOf || !Number.isFinite(now) || !equal(s.scope, input.scope) || !equal(s.resourceScope, input.resourceScope) || !equal(s.source, input.source) ||
    Date.parse(s.observedAt) > now || Date.parse(s.asOf) > now || now - Date.parse(s.observedAt) > 60_000 || now - Date.parse(s.asOf) > 60_000 ||
    Date.parse(s.grant.expiresAt) <= now) return workContextInvalid();
  return context;
}
