import { maintenanceObject as object, maintenanceText as text, maintenanceInteger as integer, maintenanceId as id, maintenanceDigest as digest, maintenanceHash as hash, validateMaintenanceBinding } from './proforma-maintenance-contracts.mjs';

/** @returns {never} */
const invalid = () => { throw new Error('Invalid ProForma automation definition.'); };
const list = (value, max) => { if (!Array.isArray(value) || value.length > max) return invalid(); return value; };
const unique = values => { if (new Set(values).size !== values.length) return invalid(); };
const same = (a,b) => { if (hash(a)!==hash(b)) return invalid(); };
export const AUTOMATION_BINDINGS = { status:'unresolved',execution:null,permissions:null,staffAssignments:null,humanDecisions:'preserve',receivingAcceptance:'source-required' };
export function validateAutomationBinding(input) {
  const v=object(input,['schemaVersion','id','origin','scope','actorId','documentIds','purpose','policyVersion']);
  const documentIds=list(v.documentIds,50).map(id);
  const {processIds,...binding}=validateMaintenanceBinding({...Object.fromEntries(Object.entries(v).filter(([k])=>k!=='documentIds')),processIds:documentIds.map(x=>`draft:${x}`)});
  return {...binding,documentIds:processIds.map(x=>x.slice(6))};
}
function content(input) {
  const c=object(input,['title','kind','audience','purpose','sourceReference','body'],['sop']);
  if (!['procedure','policy','tutorial'].includes(c.kind)) return invalid();
  for(const f of ['title','audience','purpose','sourceReference','body'])text(c[f],100000,true);
  if(c.sop){
    const s=object(c.sop,['schemaVersion','trigger','applicability','ownerRole','prerequisites','completionCriteria','exceptions','handoff','sourceNotes','steps'],['flow']);
    if(![1,2].includes(s.schemaVersion)||s.schemaVersion===2&&!s.flow||s.schemaVersion===1&&s.flow) return invalid();
    for(const f of ['trigger','applicability','ownerRole','prerequisites','completionCriteria','exceptions','handoff','sourceNotes'])text(s[f],100000,true);
    const steps=list(s.steps,200);unique(steps.map(step=>id(step.id)));
    for(const step of steps){object(step,['id','action','expectedResult','role','system','evidenceReference'],['captureStepId']);for(const f of ['action','expectedResult','role','system','evidenceReference'])text(step[f],100000,true);if(step.captureStepId!==undefined)text(step.captureStepId,220);}
    if(s.flow){
      const f=object(s.flow,['schemaVersion','entryStepId','transitions']),ids=new Set(steps.map(x=>x.id));
      if(f.schemaVersion!==1||(ids.size?!ids.has(f.entryStepId):f.entryStepId!==null))return invalid();
      const paths=list(f.transitions,500);unique(paths.map(p=>id(p.id)));
      for(const p of paths){object(p,['id','fromStepId','toStepId','condition','terminal','handoff']);text(p.condition,20000,true);
        if(!ids.has(p.fromStepId)||p.toStepId!==null&&!ids.has(p.toStepId)||![null,'complete','stop'].includes(p.terminal)||(p.toStepId===null)!==(p.terminal!==null))return invalid();
        if(p.handoff!==null){object(p.handoff,['role','acceptance']);text(p.handoff.role,20000,true);text(p.handoff.acceptance,20000,true);}
      }
    }
  }
  return c;
}
export function validateAutomationDefinition(input,binding,expected) {
  const v=object(input,['schemaVersion','kind','producer','scope','actorId','definition','definitionHash','canExecute']);
  if(v.schemaVersion!==1||v.kind!=='proforma.automation-definition'||v.producer!=='ProForma'||v.canExecute!==false||v.actorId!==binding.actorId)return invalid();
  same(v.scope,binding.scope);
  const d=object(v.definition,['source','content','requests','dependencies','dependencyCheck','bindings']);
  const s=object(d.source,['publicationId','documentId','contentRevision','publicationRevision','contentHash','fingerprint','catalogSnapshotId']);
  id(s.publicationId);id(s.documentId);integer(s.contentRevision);integer(s.publicationRevision);digest(s.contentHash);digest(s.fingerprint);text(s.catalogSnapshotId,200);
  if(!binding.documentIds.includes(s.documentId)||s.documentId!==expected.documentId||s.publicationId!==expected.publicationId||s.fingerprint!==expected.fingerprint||s.contentRevision>s.publicationRevision)return invalid();
  same(hash(content(d.content)),s.contentHash);same(hash(d),digest(v.definitionHash));same(d.bindings,AUTOMATION_BINDINGS);
  const requests=list(d.requests,200);unique(requests.map(r=>id(r.id)));
  for(const r of requests){object(r,['id','authoredAgainstRevision','status','requiresRevalidation','request']);integer(r.authoredAgainstRevision);
    if(r.status!=='proposed'||r.requiresRevalidation!==true||r.authoredAgainstRevision>=s.publicationRevision)return invalid();
    const a=object(r.request,['name','intent','inputs','steps','stopConditions']);text(a.name,160);text(a.intent,2000);
    for(const f of ['inputs','stopConditions'])list(a[f],20).forEach(x=>text(x,500));
    if(!list(a.steps,20).length)return invalid();for(const step of a.steps){object(step,['instruction','system','expectedResult']);text(step.instruction,2000);text(step.system,160,true);text(step.expectedResult,2000,true);}
  }
  const dependencies=list(d.dependencies,512),documents=new Set([s.publicationId]);
  for(const link of dependencies){object(link,['publicationId','connectionId','predicate','status','targetId','fingerprint','evidence','targetPublicationId','targetStatus']);
    id(link.publicationId);id(link.connectionId);text(link.predicate,80);text(link.targetId,220);digest(link.fingerprint);text(link.targetStatus,80);
    if(link.status!=='approved')return invalid();
    if(link.targetPublicationId!==null){id(link.targetPublicationId);documents.add(link.targetPublicationId);}
    const e=object(link.evidence,[],['sourceId','digest','pointer','draftId','revision','valueHash']);
    for(const key of ['sourceId','digest','pointer'])if(e[key]!==undefined)text(e[key],1000);
    if(e.valueHash!==undefined)digest(e.valueHash);
    if(e.draftId!==undefined){id(e.draftId);integer(e.revision);if(!link.targetPublicationId)return invalid();}
  }
  unique(dependencies.map(l=>`${l.publicationId}:${l.connectionId}`));
  const check=object(d.dependencyCheck,['status','checkedDocuments','checkedConnections','limits']);
  same(check.limits,{depth:32,documents:128,connections:512});
  if(check.status!=='current'||check.checkedDocuments!==documents.size||check.checkedConnections!==dependencies.length||dependencies.some(l=>!documents.has(l.publicationId)))return invalid();
  return structuredClone(v);
}
