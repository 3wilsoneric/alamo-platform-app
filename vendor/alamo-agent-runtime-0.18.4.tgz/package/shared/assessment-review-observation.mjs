/**
 * A receipt for the agent's review scan, never a claim that Pipeline work was
 * resolved. It contains references and counts only. Validation checks structure;
 * the authenticated producer and existing source checks establish authority.
 * @typedef {{
 * version: 1, id: string, type: 'assessment_review.completed', producer: 'alamoagent',
 * tenantId: string, actor: {kind: 'agent', onBehalfOf: string}, runId: string,
 * skill: {id: 'assessment-review', version: number, workflowVersion: number, assignmentVersion: number},
 * occurredAt: string,
 * source: {application: 'pipeline', grantId: string, grantRevision: string, observedFrom: string, observedThrough: string},
 * definitions: {workspaceId: string, bindingRevision: string, rulesRevision: string},
 * outcome: {code: 'review_completed', recordsReviewed: number, pageCount: number, sourceMutation: false},
 * evidence: {resultDigest: string, workCount: number, workIdsDigest: string}
 * }} AssessmentReviewObservation
 */

const invalid = () => { throw new Error("Invalid assessment review observation."); };
const uuid = value => typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value);
const hash = (value, size) => typeof value === "string" && value.length === size && /^[a-f0-9]+$/.test(value);
const integer = (value, minimum, maximum) => Number.isSafeInteger(value) && value >= minimum && value <= maximum;
const stamp = value => typeof value === "string" && value.length === 24 &&
  Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
function exact(value, names) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== names.length ||
      names.some(key => !Object.hasOwn(value, key))) invalid();
}

/** @returns {AssessmentReviewObservation} */
export function validateAssessmentReviewObservation(value) {
  exact(value, ["version", "id", "type", "producer", "tenantId", "actor", "runId", "skill", "occurredAt", "source", "definitions", "outcome", "evidence"]);
  exact(value.actor, ["kind", "onBehalfOf"]);
  exact(value.skill, ["id", "version", "workflowVersion", "assignmentVersion"]);
  exact(value.source, ["application", "grantId", "grantRevision", "observedFrom", "observedThrough"]);
  exact(value.definitions, ["workspaceId", "bindingRevision", "rulesRevision"]);
  exact(value.outcome, ["code", "recordsReviewed", "pageCount", "sourceMutation"]);
  exact(value.evidence, ["resultDigest", "workCount", "workIdsDigest"]);
  if (value.version !== 1 || !hash(value.id, 64) || value.type !== "assessment_review.completed" ||
      value.producer !== "alamoagent" || !uuid(value.tenantId) || value.actor.kind !== "agent" || !uuid(value.actor.onBehalfOf) ||
      !hash(value.runId, 32) || value.skill.id !== "assessment-review" ||
      ![value.skill.version, value.skill.workflowVersion, value.skill.assignmentVersion].every(item => integer(item, 1, Number.MAX_SAFE_INTEGER)) ||
      !stamp(value.occurredAt) || value.source.application !== "pipeline" || typeof value.source.grantId !== "string" ||
      !/^[a-z0-9-]{1,80}$/.test(value.source.grantId) || !hash(value.source.grantRevision, 64) ||
      !stamp(value.source.observedFrom) || !stamp(value.source.observedThrough) ||
      Date.parse(value.source.observedFrom) > Date.parse(value.source.observedThrough) ||
      Date.parse(value.source.observedThrough) > Date.parse(value.occurredAt) + 5000 ||
      !uuid(value.definitions.workspaceId) || !hash(value.definitions.bindingRevision, 64) || !hash(value.definitions.rulesRevision, 64) ||
      value.outcome.code !== "review_completed" || value.outcome.sourceMutation !== false ||
      !integer(value.outcome.recordsReviewed, 0, 500) || !integer(value.outcome.pageCount, 1, 20) ||
      !hash(value.evidence.resultDigest, 32) || value.evidence.workCount !== value.outcome.recordsReviewed ||
      !hash(value.evidence.workIdsDigest, 64)) invalid();
  return structuredClone(value);
}
