import { FOUNDATION_SCHEMA_VERSION, foundationInvalid, foundationObject, foundationList, foundationUnique,
  validateCompanyDefinition, validateApplicationManifest, validateFoundationSkill, validateFoundationResponsibility,
  validateFoundationEvidence, validateFoundationOutcome } from "./foundation-contracts.mjs";

/** Cross-reference validation only; a consistent definition is not an access grant. @param {unknown} value */
export function validateFoundationCatalog(value) {
  const v = foundationObject(value, ["schemaVersion", "applications", "skills"]);
  if (v.schemaVersion !== FOUNDATION_SCHEMA_VERSION) return foundationInvalid();
  const applications = foundationUnique(foundationList(v.applications, validateApplicationManifest, 20, 1), app => app.id);
  const skills = foundationUnique(foundationList(v.skills, validateFoundationSkill, 100), skill => skill.id);
  for (const skill of skills) {
    const app = applications.find(item => item.id === skill.application);
    const capability = app?.capabilities.find(item => item.id === skill.capability && item.version === skill.capabilityVersion);
    if (!capability || capability.scope !== skill.scope) return foundationInvalid();
  }
  return { schemaVersion: FOUNDATION_SCHEMA_VERSION, applications, skills };
}
/** @param {unknown} value */
export function validateFoundationBundle(value) {
  const v = foundationObject(value, ["schemaVersion", "catalog", "company", "responsibilities"]);
  if (v.schemaVersion !== FOUNDATION_SCHEMA_VERSION) return foundationInvalid();
  const catalog = validateFoundationCatalog(v.catalog), company = validateCompanyDefinition(v.company);
  for (const ref of company.applications) {
    if (!catalog.applications.some(app => app.id === ref.id && app.revision === ref.revision)) return foundationInvalid();
  }
  for (const ref of company.skills) {
    const skill = catalog.skills.find(item => item.id === ref.id && item.version === ref.version);
    if (!skill || !company.applications.some(app => app.id === skill.application)) return foundationInvalid();
  }
  const responsibilities = foundationUnique(foundationList(v.responsibilities, validateFoundationResponsibility, 100), item => item.id);
  for (const responsibility of responsibilities) {
    const scope = responsibility.scope;
    if (scope.companyId !== company.companyId || scope.tenantId !== company.tenantId || !company.subjects.includes(scope.subjectId) ||
        !company.skills.some(skill => skill.id === responsibility.skill.id && skill.version === responsibility.skill.version)) return foundationInvalid();
    const skill = catalog.skills.find(item => item.id === responsibility.skill.id);
    if (!skill || skill.scope !== responsibility.resourceScope.kind) return foundationInvalid();
  }
  return { schemaVersion: FOUNDATION_SCHEMA_VERSION, catalog, company, responsibilities };
}

/**
 * Validate a declared outcome against its pinned definition and evidence metadata.
 * Passing this function does NOT authenticate the producer, recheck source access,
 * establish source truth, activate paused work, or publish a completion receipt.
 * @param {unknown} value
 */
export function validateFoundationOutcomeCase(value) {
  const v = foundationObject(value, ["schemaVersion", "bundle", "outcome", "evidence"]);
  if (v.schemaVersion !== FOUNDATION_SCHEMA_VERSION) return foundationInvalid();
  const bundle = validateFoundationBundle(v.bundle), outcome = validateFoundationOutcome(v.outcome);
  const evidence = foundationUnique(foundationList(v.evidence, validateFoundationEvidence, 500), item => item.id);
  const responsibility = bundle.responsibilities.find(item => item.id === outcome.responsibility.id && item.revision === outcome.responsibility.revision);
  if (!responsibility || !sameScope(responsibility.scope, outcome.scope) || outcome.skill.id !== responsibility.skill.id ||
      outcome.skill.version !== responsibility.skill.version) return foundationInvalid();
  const skill = bundle.catalog.skills.find(item => item.id === outcome.skill.id && item.version === outcome.skill.version);
  if (!skill || outcome.kind !== skill.completion.kind) return foundationInvalid();
  const capability = bundle.catalog.applications.find(app => app.id === skill.application)?.capabilities.find(item => item.id === skill.capability);
  if (!capability || outcome.evidenceIds.length !== evidence.length || outcome.evidenceIds.some(id => !evidence.some(item => item.id === id)) ||
      outcome.checks.some(check => !skill.completion.checkIds.includes(check.id))) return foundationInvalid();
  if (outcome.kind === "evidence-collection" && outcome.coverage !== null) return foundationInvalid();
  if (outcome.coverage && outcome.coverage.expected > skill.limits.maxRecords) return foundationInvalid();
  const grants = new Set();
  const sources = new Set();
  for (const item of evidence) {
    if (!sameScope(item.scope, outcome.scope) || item.source.application !== skill.application ||
        !capability.resourceKinds.includes(item.source.kind) || item.resourceScope.kind !== responsibility.resourceScope.kind ||
        item.resourceScope.ids.some(id => !responsibility.resourceScope.ids.includes(id)) || item.observedAt > outcome.occurredAt) return foundationInvalid();
    grants.add(JSON.stringify([item.grant.application, item.grant.id, item.grant.revision]));
    const sourceKey = JSON.stringify([item.source.application, item.source.kind, item.source.id, item.source.revision]);
    if (sources.has(sourceKey)) return foundationInvalid();
    sources.add(sourceKey);
  }
  if (grants.size > 1) return foundationInvalid();
  if (outcome.status === "completed") {
    if (!evidence.length || outcome.checks.length !== skill.completion.checkIds.length || outcome.checks.some(check => check.status !== "passed") ||
        (outcome.kind === "review-scan" && (!outcome.coverage || outcome.coverage.expected !== outcome.coverage.reviewed))) return foundationInvalid();
    const covered = new Set(evidence.flatMap(item => item.resourceScope.ids));
    if (responsibility.resourceScope.ids.some(id => !covered.has(id))) return foundationInvalid();
    for (const item of evidence) {
      if (item.completeness !== "complete" || item.source.revision === null || item.asOf === null || item.grant.expiresAt <= outcome.occurredAt ||
          Date.parse(outcome.occurredAt) - Date.parse(item.asOf) > skill.limits.maxEvidenceAgeSeconds * 1000) return foundationInvalid();
    }
  }
  return { schemaVersion: FOUNDATION_SCHEMA_VERSION, bundle, outcome, evidence };
}
/** @param {ReturnType<typeof validateFoundationResponsibility>['scope']} a @param {ReturnType<typeof validateFoundationResponsibility>['scope']} b */
function sameScope(a, b) { return a.companyId === b.companyId && a.tenantId === b.tenantId && a.subjectId === b.subjectId; }
