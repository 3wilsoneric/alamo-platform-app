import { createHash } from "node:crypto";
import { foundationObject, foundationList, foundationUnique, foundationKey } from "./foundation-contracts.mjs";
import { validateWorkContextRequest } from "./work-context-contracts.mjs";

export const DRAFT_REVIEW_LIMITS = Object.freeze({ records: 100, payloadBytes: 131_072, stateBytes: 4_194_304 });
/** @returns {never} */
export function draftReviewUnavailable() { throw new Error("Draft review is unavailable."); }
export const draftReviewConflict = () => Object.assign(new Error("Draft review changed. Refresh before reviewing."), { code: "DRAFT_REVIEW_CONFLICT" });
export function draftReviewId(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(value)) return draftReviewUnavailable();
  return value;
}
export function draftReviewDigest(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) return draftReviewUnavailable();
  return value;
}
function stamp(value) {
  if (typeof value !== "string" || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) return draftReviewUnavailable();
  return value;
}

// Bounded canonical JSON: no coercion, getters, prototypes, sparse arrays or
// unbounded recursion. Hashes bind bytes/versions; they are not signatures.
export function draftReviewJson(value) {
  let nodes = 0;
  function visit(item, depth) {
    if (++nodes > 20_000 || depth > 24) return draftReviewUnavailable();
    if (item === null || typeof item === "boolean") return item;
    if (typeof item === "string") {
      if (item.length > DRAFT_REVIEW_LIMITS.payloadBytes) return draftReviewUnavailable();
      return item;
    }
    if (typeof item === "number" && Number.isFinite(item) && !Object.is(item, -0)) return item;
    if (Array.isArray(item)) return foundationList(item, child => visit(child, depth + 1), 1000);
    if (!item || typeof item !== "object") return draftReviewUnavailable();
    const keys = Object.keys(item).sort();
    if (keys.length > 1000 || keys.some(key => key.length > 200 || ["__proto__", "prototype", "constructor"].includes(key))) return draftReviewUnavailable();
    const object = foundationObject(item, keys);
    return Object.fromEntries(keys.map(key => [key, visit(object[key], depth + 1)]));
  }
  const result = visit(value, 0);
  if (Buffer.byteLength(JSON.stringify(result)) > DRAFT_REVIEW_LIMITS.payloadBytes) return draftReviewUnavailable();
  return result;
}
export const draftReviewHash = value => createHash("sha256").update(JSON.stringify(draftReviewJson(value))).digest("hex");

export function validateDraftReviewCommand(value) {
  const v = foundationObject(value, ["requestId", "expectedArtifactRevision", "decision"]);
  if (v.decision !== "accept" && v.decision !== "reject") return draftReviewUnavailable();
  return { requestId: draftReviewId(v.requestId), expectedArtifactRevision: draftReviewDigest(v.expectedArtifactRevision), decision: v.decision };
}

export function validateDraftReviewRecord(value) {
  const v = foundationObject(value, ["schemaVersion", "id", "createdAt", "request", "skillId", "policyRevision", "contextRevision", "payload", "artifactRevision", "review"]);
  if (v.schemaVersion !== 1) return draftReviewUnavailable();
  const payload = draftReviewJson(v.payload);
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return draftReviewUnavailable();
  const artifact = { schemaVersion: 1, id: draftReviewId(v.id), createdAt: stamp(v.createdAt), request: validateWorkContextRequest(v.request),
    skillId: foundationKey(v.skillId), policyRevision: draftReviewDigest(v.policyRevision), contextRevision: draftReviewDigest(v.contextRevision), payload };
  const artifactRevision = draftReviewDigest(v.artifactRevision);
  if (draftReviewHash(artifact) !== artifactRevision) return draftReviewUnavailable();
  let review = null;
  if (v.review !== null) {
    const r = foundationObject(v.review, ["requestId", "artifactRevision", "decision", "subjectId", "reviewedAt"]);
    const command = validateDraftReviewCommand({ requestId: r.requestId, expectedArtifactRevision: r.artifactRevision, decision: r.decision });
    if (command.expectedArtifactRevision !== artifactRevision || r.subjectId !== artifact.request.scope.subjectId) return draftReviewUnavailable();
    const reviewedAt = stamp(r.reviewedAt);
    if (reviewedAt < artifact.createdAt) return draftReviewUnavailable();
    review = { requestId: command.requestId, artifactRevision, decision: command.decision, subjectId: artifact.request.scope.subjectId, reviewedAt };
  }
  return { ...artifact, artifactRevision, review };
}

export function validateDraftReviewState(value) {
  const v = foundationObject(value, ["version", "revision", "records"]);
  if (v.version !== 1 || typeof v.revision !== "number" || !Number.isSafeInteger(v.revision) || v.revision < 0) return draftReviewUnavailable();
  const records = foundationUnique(foundationList(v.records, validateDraftReviewRecord, DRAFT_REVIEW_LIMITS.records), r => r.id);
  foundationUnique(records.filter(r => r.review), r => `${draftReviewHash(r.request.scope)}/${r.review?.requestId}`);
  const result = { version: 1, revision: v.revision, records };
  if (Buffer.byteLength(JSON.stringify(result)) > DRAFT_REVIEW_LIMITS.stateBytes) return draftReviewUnavailable();
  return result;
}
