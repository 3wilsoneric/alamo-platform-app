import {maintenanceObject as object,maintenanceText as text,maintenanceId as id,maintenanceDigest as digest,maintenanceInteger as integer,maintenanceHash as hash} from './proforma-maintenance-contracts.mjs';
import {validateAutomationBinding} from './proforma-automation-contracts.mjs';

export const PROFORMA_REFERRAL_CAPABILITY='assessor-referral-handoff-draft-v1';
export const EXECUTION_STAGES=['assessment-answer-quality','assessor-clarification','assessor-handoff','human'];
export const executionDefinitionHash=v=>hash({sourceBinding:v.sourceBinding,source:v.source,capability:v.capability,models:v.models,evaluationDigest:v.evaluationDigest,stepBindings:v.stepBindings});
function models(input){const v=object(input,['quality','selection']);for(const m of Object.values(v))if(typeof m!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(m))throw new Error('Invalid execution model policy.');return v;}
function source(input){const v=object(input,['documentId','publicationId','fingerprint','definitionHash','macroId','macroHash']);for(const k of ['documentId','publicationId','macroId'])id(v[k]);for(const k of ['fingerprint','definitionHash','macroHash'])digest(v[k]);return v;}
function capability(input){const v=object(input,['id','revision']);if(v.id!==PROFORMA_REFERRAL_CAPABILITY)throw new Error('Unsupported process capability.');digest(v.revision);return v;}
function steps(input){
  if(!Array.isArray(input)||!input.length||input.length>20)throw new Error('Map every proposed macro step.');
  for(const [index,v] of input.entries()){object(v,['stepIndex','stage']);integer(v.stepIndex,19);if(v.stepIndex!==index||!EXECUTION_STAGES.includes(v.stage))throw new Error('Invalid macro step binding.');}
  if(!input.some(s=>s.stage==='assessor-handoff'))throw new Error('This capability requires a handoff-draft step.');return input;
}
function stamp(value){if(typeof value!=='string'||!Number.isFinite(Date.parse(value))||new Date(value).toISOString()!==value)throw new Error('Invalid execution review timestamp.');}
export function validateExecutionDefinition(input){
  const v=object(input,['schemaVersion','id','enabled','sourceBinding','source','capability','models','evaluationDigest','stepBindings','review']);models(v.models);digest(v.evaluationDigest);
  validateExecutionCandidate(Object.fromEntries(Object.entries(v).filter(([key])=>!['enabled','review'].includes(key))));
  if(typeof v.enabled!=='boolean')throw new Error('Invalid execution definition.');
  const r=object(v.review,['actorId','definitionHash','at']);digest(r.definitionHash);stamp(r.at);
  if(r.actorId!==v.sourceBinding.actorId||r.definitionHash!==executionDefinitionHash(v)||!v.sourceBinding.documentIds.includes(v.source.documentId))throw new Error('An exact execution mapping requires separate owner review.');
  return structuredClone(v);
}
export function validateExecutionCandidate(input){
  const v=object(input,['schemaVersion','id','sourceBinding','source','capability','models','evaluationDigest','stepBindings']);
  if(v.schemaVersion!==1)throw new Error('Invalid execution candidate.');id(v.id);validateAutomationBinding(v.sourceBinding);source(v.source);capability(v.capability);models(v.models);digest(v.evaluationDigest);steps(v.stepBindings);
  if(!v.sourceBinding.documentIds.includes(v.source.documentId))throw new Error('Guide is outside the source binding.');return structuredClone(v);
}
export function validateExecutionReference(input){
  const v=object(input,['schemaVersion','kind','mode','executionId','configurationHash','planHash','scope','actorId','source','capability','models','evaluationDigest','stepBindings','review','macroTitle']);models(v.models);digest(v.evaluationDigest);
  if(v.schemaVersion!==1||v.kind!=='proforma.execution-reference'||v.mode!=='synthetic-only')throw new Error('Invalid process execution reference.');
  id(v.executionId);digest(v.configurationHash);digest(v.planHash);const scope=object(v.scope,['tenantId','workspace']);id(scope.tenantId);
  if(scope.workspace!=='workflow'||typeof v.actorId!=='string'||!v.actorId.startsWith(`entra:${scope.tenantId}:`))throw new Error('Invalid execution scope.');id(v.actorId.slice(`entra:${scope.tenantId}:`.length));
  source(v.source);capability(v.capability);steps(v.stepBindings);text(v.macroTitle,160);
  const r=object(v.review,['actorId','at']);stamp(r.at);if(r.actorId!==v.actorId)throw new Error('Execution review actor changed.');
  return structuredClone(v);
}
