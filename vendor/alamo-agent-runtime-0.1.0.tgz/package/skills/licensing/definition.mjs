import { LICENSING_COMMUNITIES } from "../../shared/licensing-communities.mjs";

export default Object.freeze({ id: "licensing", version: 1, sourceApplication: "platform", title: "Licensing", application: "platform", applicationName: "Alamo Platform",
    capability: "licensing.published-reports.read", responsibility: "Watch state licensing reports",
    description: "Collect changes from the state-report library and keep source-linked reports ready to review.",
    cadence: "Library checked every 15 minutes · state collection Mon & Wed, 9 a.m. Pacific",
    scope: "community", communities: LICENSING_COMMUNITIES.map(({ facilityId, name }) => ({ id: facilityId, name })),
    href: "/analytics/agent?skill=licensing", actions: ["read", "summarize", "review"] });
