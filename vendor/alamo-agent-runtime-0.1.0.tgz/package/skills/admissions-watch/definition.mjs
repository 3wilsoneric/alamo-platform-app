export default Object.freeze({ id: "admissions-watch", version: 1, sourceApplication: "platform", title: "Admissions watch", application: "pipeline", applicationName: "Pipeline",
    capability: "pipeline.admissions-summary.read", responsibility: "Watch admissions activity",
    description: "Watch published referral totals and follow-up counts from Pipeline. Open the admissions board for details.",
    cadence: "Published summary checked every 15 minutes", scope: "organization", communities: [],
    href: "/admissions", actions: ["read", "summarize", "review"] });
