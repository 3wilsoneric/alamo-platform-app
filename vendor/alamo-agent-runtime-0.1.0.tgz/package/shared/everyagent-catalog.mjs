import licensing from "../skills/licensing/definition.mjs";
import admissionsWatch from "../skills/admissions-watch/definition.mjs";
import { hasLicensingAccess } from "./licensing-access.mjs";
import { hasEveryAgentAccess } from "./everyagent-identity.mjs";
export { EVERYAGENT_TENANT, EVERYAGENT_USERS } from "./everyagent-identity.mjs";

// Each skill binds to an app in reviewed code. Deployment settings cannot
// redirect an existing skill's authority or old evidence to another app.
export const EVERYAGENT_SKILLS = Object.freeze([licensing, admissionsWatch]);
export function everyAgentSkillsFor(claims) {
  if (!hasEveryAgentAccess(claims)) return [];
  return EVERYAGENT_SKILLS.filter(skill => skill.id !== "licensing" || hasLicensingAccess(claims));
}
