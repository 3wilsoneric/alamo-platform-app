export function validateAgentSourceRequest(value: any): {
    version: number;
    operation: any;
    subjectId: any;
    skillId: any;
    communityIds: any[];
};
export function validateAgentSourceGrant(value: any): {
    application: any;
    id: any;
    revision: any;
    expiresAt: any;
};
export const AGENT_SOURCE_PATH: "/api/platform/agent-source/v1";
export const AGENT_SOURCE_MAX_BYTES: 2200000;
