export function resolveEveryAgentLink(href: any): {
    application: string;
    href: string;
};
export function portableEveryAgentEvidence(evidence: any, revision?: null): any;
