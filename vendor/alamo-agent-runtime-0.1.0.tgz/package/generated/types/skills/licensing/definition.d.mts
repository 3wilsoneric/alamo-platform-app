declare const _default: Readonly<{
    id: "licensing";
    version: 1;
    sourceApplication: "platform";
    title: "Licensing";
    application: "platform";
    applicationName: "Alamo Platform";
    capability: "licensing.published-reports.read";
    responsibility: "Watch state licensing reports";
    description: "Collect changes from the state-report library and keep source-linked reports ready to review.";
    cadence: "Library checked every 15 minutes · state collection Mon & Wed, 9 a.m. Pacific";
    scope: "community";
    communities: {
        id: string;
        name: string;
    }[];
    href: "/analytics/agent?skill=licensing";
    actions: string[];
}>;
export default _default;
