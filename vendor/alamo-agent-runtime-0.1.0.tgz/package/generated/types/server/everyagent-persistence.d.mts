export function createEveryAgentPersistence({ localPath, azure, blobPath }?: {
    localPath?: string | undefined;
    azure?: boolean | undefined;
    blobPath?: string | undefined;
}): {
    read(): Promise<{
        value: any;
        version: string | null;
    }>;
    write(value: any, version: any): Promise<void>;
};
