export function createEveryAgentWorkflowService({ store, adapters, sourceAccess, now }?: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    adapters?: {} | undefined;
    sourceAccess?: ((assignment: any, receipt?: any) => Promise<any>) | null | undefined;
    now?: (() => number) | undefined;
}): {
    prepare: () => Promise<any>;
    collect: (id: any) => Promise<{
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | null>;
    validate: (id: any, result: any) => Promise<{
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        sourceGrant?: never;
    } | {
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | null>;
    publish: (id: any, result: any) => Promise<{
        id: any;
        status: any;
    }>;
    fail: (id: any) => Promise<{
        id: any;
        status: any;
    }>;
    visible: (state: any, userId: any, assignments: any) => any;
    command: (userId: any, input: any) => Promise<void>;
};
