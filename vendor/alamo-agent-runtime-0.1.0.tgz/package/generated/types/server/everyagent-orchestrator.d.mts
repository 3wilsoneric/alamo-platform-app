/** @type {import("durable-functions").OrchestrationHandler} */
export const everyAgentMonitorV1: import("durable-functions").OrchestrationHandler;
