export function validateEveryAgentWorkflowResult(value: any, assignment: any): {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    sourceGrant?: never;
} | {
    connection: any;
    issue: any;
    sourceCheckedAt: any;
    entries: {
        key: any;
        fingerprint: any;
        communityIds: any[];
        title: any;
        summary: any;
        evidence: any;
        relationships: any;
    }[];
    sourceGrant: {
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    };
};
