export function readJsonRequestBody(req: any, maximumBytes?: number): Promise<any>;
export function readValidatedJsonRequest(req: any, validate: any, maximumBytes?: number): Promise<any>;
