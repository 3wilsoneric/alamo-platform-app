export function createEveryAgentRequestHandler({ authorize, service, conversations, paths }: {
    authorize: any;
    service: any;
    conversations?: any;
    paths?: string[] | undefined;
}): (req: any, res: any) => Promise<void>;
