export function createEveryAgentService({ store, adapters, now, portableLinks, sourceAccess }?: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    adapters?: {} | undefined;
    now?: (() => number) | undefined;
    portableLinks?: boolean | undefined;
    sourceAccess?: ((assignment: any, receipt?: any) => Promise<any>) | null | undefined;
}): {
    overview: (auth: any, attempt?: number) => Promise<{
        version: number;
        emailEnabled: boolean;
        workerEnabled: boolean;
        skills: import("../shared/everyagent-catalog.mjs").EveryAgentSkill[];
        responsibilities: any[];
        work: any;
        runs: any;
        tasks: any;
        working: any;
    }>;
    command: (auth: any, raw: any) => Promise<{
        version: number;
        emailEnabled: boolean;
        workerEnabled: boolean;
        skills: import("../shared/everyagent-catalog.mjs").EveryAgentSkill[];
        responsibilities: any[];
        work: any;
        runs: any;
        tasks: any;
        working: any;
    }>;
    tick: () => Promise<void>;
};
