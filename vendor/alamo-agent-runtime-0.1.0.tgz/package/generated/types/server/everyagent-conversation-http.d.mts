export function handleConversationHttp(req: any, res: any, auth: any, service: any): Promise<void>;
