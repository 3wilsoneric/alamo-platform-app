export function createEveryAgentHttpServer({ authorize, service, conversations, webRoot, origins }: {
    authorize: any;
    service: any;
    conversations?: any;
    webRoot?: string | undefined;
    origins?: string[] | undefined;
}): import("node:http").Server<typeof import("node:http").IncomingMessage, typeof import("node:http").ServerResponse>;
