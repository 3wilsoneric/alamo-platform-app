export function validateConversationAnswer(value: any, evidence: any): {
    paragraphs: any;
};
export function createConversationModel({ apiKey, model, fetchImpl }?: {
    apiKey?: string | undefined;
    model?: string | undefined;
    fetchImpl?: typeof fetch | undefined;
}): {
    available: boolean;
    model: string;
    promptVersion: string;
    answer({ text, history, evidence }: {
        text: any;
        history: any;
        evidence: any;
    }): Promise<{
        model: string;
        promptVersion: string;
        usage: {
            inputTokens: any;
            outputTokens: any;
        } | null;
        paragraphs: any;
    }>;
};
