export function registerEveryAgentFunctions({ service, schedule }: {
    service: any;
    schedule?: string | undefined;
}): void;
