export function createConversationService({ store, workStore, source, model, clientIds, now }: {
    store?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    workStore?: {
        read: () => Promise<{
            value: any;
            version: string | null;
        }>;
        update: (mutate: any) => Promise<any>;
    } | undefined;
    source: any;
    model?: {
        available: boolean;
        model: string;
        promptVersion: string;
        answer({ text, history, evidence }: {
            text: any;
            history: any;
            evidence: any;
        }): Promise<{
            model: string;
            promptVersion: string;
            usage: {
                inputTokens: any;
                outputTokens: any;
            } | null;
            paragraphs: any;
        }>;
    } | undefined;
    clientIds?: string[] | undefined;
    now?: (() => number) | undefined;
}): {
    read: (auth: any, id?: string | null) => Promise<{
        id: any;
        version: any;
        createdAt: any;
        scope: any;
        workId: any;
        turns: any;
    } | {
        modelAvailable: boolean;
        conversations: any[];
    }>;
    command: (auth: any, raw: any) => Promise<{
        id: any;
        version: any;
        createdAt: any;
        scope: any;
        workId: any;
        turns: any;
    } | {
        modelAvailable: boolean;
        conversations: any[];
    } | {
        canceled: boolean;
    }>;
};
