export function createEveryAgentWeb(root: any, origins?: any[]): (req: any, res: any) => Promise<boolean>;
