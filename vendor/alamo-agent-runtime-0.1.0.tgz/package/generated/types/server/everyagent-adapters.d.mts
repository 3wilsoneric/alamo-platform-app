export function everyAgentFingerprint(value: any): string;
export function createEveryAgentAdapters({ licensing, updates, pipeline }: {
    licensing: any;
    updates: any;
    pipeline: any;
}): {
    licensing(): Promise<{
        connection: string;
        issue: string;
        sourceCheckedAt: any;
        entries: never[];
    } | {
        connection: string;
        issue: null;
        sourceCheckedAt: any;
        entries: any;
    }>;
    "admissions-watch"(): Promise<{
        connection: string;
        issue: string;
        sourceCheckedAt: any;
        entries: never[];
    } | {
        connection: string;
        issue: null;
        sourceCheckedAt: any;
        entries: {
            key: string;
            fingerprint: string;
            communityIds: never[];
            title: string;
            summary: string;
            evidence: {
                id: string;
                kind: string;
                label: string;
                href: string;
                observedAt: any;
            }[];
            relationships: {
                from: string;
                relation: string;
                to: string;
            }[];
        }[];
    }>;
};
