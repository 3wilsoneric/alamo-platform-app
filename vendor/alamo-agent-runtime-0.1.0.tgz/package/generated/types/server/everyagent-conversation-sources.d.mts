export function createConversationSources({ workStore, source }: {
    workStore: any;
    source: any;
}): {
    authorize: (chat: any) => Promise<any>;
    collect: (chat: any) => Promise<{
        evidence: {
            id: string;
            skillId: any;
            title: any;
            text: any;
            observedAt: any;
            links: any;
        }[];
        receipts: {
            assignment: any;
            grant: any;
        }[];
    }>;
    recheck: (chat: any, receipts: any) => Promise<void>;
};
