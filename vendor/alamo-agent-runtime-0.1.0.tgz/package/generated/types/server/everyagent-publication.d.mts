export function publishEveryAgentResult(state: any, assignment: any, result: any, started: any, finished: any, runId?: `${string}-${string}-${string}-${string}-${string}`): void;
