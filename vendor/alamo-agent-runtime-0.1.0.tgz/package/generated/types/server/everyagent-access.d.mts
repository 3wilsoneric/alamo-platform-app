export function everyAgentActor(auth: any): string;
export function freshAssignment(userId: any, skill: any): {
    userId: any;
    skillId: any;
    version: number;
    paused: boolean;
    communityIds: any;
    lastChecked: null;
    sourceCheckedAt: null;
    nextCheck: null;
    connection: string;
    issue: null;
    cursor: null;
};
export function scopeAllows(item: any, assignment: any): any;
export function allowedAssignment(assignment: any): boolean;
export function grantFor(userId: any): import("../shared/everyagent-catalog.mjs").EveryAgentSkill[];
