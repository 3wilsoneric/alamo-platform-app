export function createEveryAgentSourceClient({ origin, getToken, fetchImpl, now, application, endpoint }: {
    origin: any;
    getToken: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
    application?: string | undefined;
    endpoint?: string | undefined;
}): {
    authorize: (assignment: any, expected?: ReturnType<typeof validateAgentSourceGrant> | null) => Promise<{
        application: any;
        id: any;
        revision: any;
        expiresAt: any;
    }>;
    read: (assignment: any) => Promise<{
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
    } | {
        sourceGrant: {
            application: any;
            id: any;
            revision: any;
            expiresAt: any;
        };
        connection: any;
        issue: any;
        sourceCheckedAt: any;
        entries: {
            key: any;
            fingerprint: any;
            communityIds: any[];
            title: any;
            summary: any;
            evidence: any;
            relationships: any;
        }[];
    }>;
    adapters: {
        licensing: (assignment: any) => Promise<{
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
        }>;
        "admissions-watch": (assignment: any) => Promise<{
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
        } | {
            sourceGrant: {
                application: any;
                id: any;
                revision: any;
                expiresAt: any;
            };
            connection: any;
            issue: any;
            sourceCheckedAt: any;
            entries: {
                key: any;
                fingerprint: any;
                communityIds: any[];
                title: any;
                summary: any;
                evidence: any;
                relationships: any;
            }[];
        }>;
    };
};
import { validateAgentSourceGrant } from "../shared/everyagent-source-contracts.mjs";
