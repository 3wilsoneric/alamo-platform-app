export function isProductionLikeRuntime(): boolean;
export function getBoundedNumberEnv(name: any, fallback: any, minimum: any, maximum: any): any;
export function getBoundedIntegerEnv(name: any, fallback: any, minimum: any, maximum: any): any;
