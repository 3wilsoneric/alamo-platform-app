export function createEveryAgentAuthorizer({ tenantId, audience, clientIds, scope, keySet }: {
    tenantId: any;
    audience: any;
    clientIds: any;
    scope?: string | undefined;
    keySet?: null | undefined;
}): (req: any) => Promise<{
    authenticated: boolean;
    mode: string;
    claims: import("jose").JWTPayload;
}>;
