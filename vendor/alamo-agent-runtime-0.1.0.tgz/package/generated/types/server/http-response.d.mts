export function appendResponseVaryHeader(res: any, value: any): void;
export function applyProtectedApiHeaders(res: any): void;
