/** @param {number} statusCode @param {string} code @param {string} message @param {unknown} [details] */
export function createHttpError(statusCode: number, code: string, message: string, details?: unknown): HttpError;
export class HttpError extends Error {
    /** @param {number} statusCode @param {string} code @param {string} message @param {unknown} [details] */
    constructor(statusCode: number, code: string, message: string, details?: unknown);
    statusCode: number;
    code: string;
    details: unknown;
}
