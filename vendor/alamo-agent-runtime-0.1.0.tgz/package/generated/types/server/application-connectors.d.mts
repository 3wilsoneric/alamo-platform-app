export function createApplicationConnectors({ connectors, skills }: {
    connectors: any;
    skills?: readonly import("../shared/everyagent-catalog.mjs").EveryAgentSkill[] | undefined;
}): {
    authorize: (assignment: any, receipt?: undefined) => any;
    adapters: {
        [k: string]: (assignment: any) => any;
    };
};
