export function createConversationStore(persistence?: {
    read(): Promise<{
        value: any;
        version: string | null;
    }>;
    write(value: any, version: any): Promise<void>;
}): {
    read: () => Promise<{
        value: any;
        version: string | null;
    }>;
    update: (mutate: any) => Promise<any>;
};
