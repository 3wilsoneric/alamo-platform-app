import { execFileSync } from "node:child_process";
import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { core, api, worker } from "./runtime-files.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
export async function prepareAgentPackage(kind, { destination = path.join(root, `generated/everyagent-${kind}`), webRoot = "" } = {}) {
  if (!["service", "worker"].includes(kind)) throw new Error("Choose an agent deployment unit.");
  destination = path.resolve(destination);
  if (destination === root || root.startsWith(destination + path.sep)) throw new Error("Choose a generated output directory.");
  const files = [...core, ...(kind === "service" ? api : worker)];
  const source = JSON.parse(await readFile(path.join(root, "package.json"), "utf8"));
  const lock = JSON.parse(await readFile(path.join(root, "npm-shrinkwrap.json"), "utf8"));
  const names = ["@azure/identity", "@azure/storage-blob", ...(kind === "service" ? ["jose"] : ["@azure/functions", "durable-functions"])];
  const dependencies = Object.fromEntries(names.map(name => [name, lock.packages[`node_modules/${name}`].version]));
  const pkg = { name: `alamoagent-${kind}`, version: source.version, private: true, type: "module", engines: source.engines,
    ...(kind === "service" ? { scripts: { start: "node server/everyagent-server.mjs" } } :
      { main: "server/everyagent-worker.mjs", overrides: source.overrides }), dependencies };
  await rm(destination, { recursive: true, force: true });
  for (const file of files) {
    await mkdir(path.dirname(path.join(destination, file)), { recursive: true });
    await cp(path.join(root, file), path.join(destination, file));
  }
  await writeFile(path.join(destination, "package.json"), JSON.stringify(pkg, null, 2) + "\n");
  lock.name = pkg.name; lock.version = pkg.version;
  lock.packages[""] = { name: pkg.name, version: pkg.version, engines: pkg.engines, dependencies };
  await writeFile(path.join(destination, "package-lock.json"), JSON.stringify(lock, null, 2) + "\n");
  execFileSync("npm", ["install", "--package-lock-only", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: destination, stdio: "pipe", timeout: 120_000 });
  const pruned = JSON.parse(await readFile(path.join(destination, "package-lock.json"), "utf8"));
  for (const [name, dependency] of Object.entries(pruned.packages)) {
    if (name && (dependency.version !== lock.packages[name]?.version || dependency.integrity !== lock.packages[name]?.integrity)) throw new Error("The package changed a reviewed dependency.");
  }
  if (kind === "worker") await cp(path.join(root, "scripts/azure/everyagent-host.json"), path.join(destination, "host.json"));
  else {
    if (webRoot) await cp(webRoot, path.join(destination, "web"), { recursive: true });
    await writeFile(path.join(destination, "Dockerfile"), `FROM node:22-bookworm-slim\nWORKDIR /app\nCOPY package*.json ./\nRUN npm ci --omit=dev --ignore-scripts --no-audit --no-fund\nCOPY server ./server\nCOPY shared ./shared\nCOPY skills ./skills\n${webRoot ? "COPY web ./web\nENV ALAMOAGENT_WEB_ROOT=/app/web\n" : ""}ENV NODE_ENV=production\nUSER node\nEXPOSE 8080\nCMD ["node", "server/everyagent-server.mjs"]\n`);
  }
  console.log(`Built ${kind}: ${files.length} runtime files; ${names.length} direct dependencies; ${destination}`);
}
