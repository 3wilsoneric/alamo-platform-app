export const core = [
  "server/everyagent-access.mjs", "server/everyagent-adapters.mjs", "server/everyagent-persistence.mjs",
  "server/everyagent-publication.mjs", "server/everyagent-store.mjs", "server/everyagent-workflow-service.mjs",
  "server/everyagent-workflow-validation.mjs", "server/http-error-contract.mjs", "server/runtime-environment.mjs",
  "server/application-connectors.mjs", "skills/licensing/definition.mjs", "skills/admissions-watch/definition.mjs",
  "server/everyagent-source-client.mjs", "server/everyagent-source-runtime.mjs",
  "shared/everyagent-catalog.mjs", "shared/everyagent-contracts.mjs", "shared/everyagent-identity.mjs",
  "shared/licensing-access.mjs", "shared/licensing-communities.mjs", "shared/everyagent-links.mjs", "shared/everyagent-source-contracts.mjs"
];
export const api = ["server/everyagent-auth.mjs", "server/everyagent-host.mjs", "server/everyagent-http.mjs", "server/everyagent-server.mjs",
  "server/everyagent-service.mjs", "server/http-body.mjs", "server/http-response.mjs", "shared/everyagent-client.mjs",
  "server/everyagent-web.mjs", "server/everyagent-conversations.mjs", "server/everyagent-conversation-http.mjs",
  "server/everyagent-conversation-model.mjs", "server/everyagent-conversation-sources.mjs", "server/everyagent-conversation-store.mjs",
  "shared/everyagent-conversations.mjs"];
export const worker = ["server/everyagent-functions.mjs", "server/everyagent-orchestrator.mjs", "server/everyagent-worker.mjs"];
