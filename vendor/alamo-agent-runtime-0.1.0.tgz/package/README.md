# AlamoAgent engine

Edit the agent here. This is an independent source project for the API, skills,
application connectors, workflows and conversation policy. It builds without a
Platform checkout or a browser UI. The latest priority is connecting the engine
to applications and doing useful work through their APIs.

## Where to edit

| Change | Source |
|---|---|
| A skill's purpose, source application and scope | [skills/licensing/definition.mjs](skills/licensing/definition.mjs), [skills/admissions-watch/definition.mjs](skills/admissions-watch/definition.mjs) |
| Register a reviewed skill | [shared/everyagent-catalog.mjs](shared/everyagent-catalog.mjs) |
| Route skills to source apps | [server/application-connectors.mjs](server/application-connectors.mjs) |
| Connector identity and deployment configuration | [server/everyagent-source-runtime.mjs](server/everyagent-source-runtime.mjs) |
| API request/response and grant protocol | [shared/everyagent-source-contracts.mjs](shared/everyagent-source-contracts.mjs), [server/everyagent-source-client.mjs](server/everyagent-source-client.mjs) |
| Durable execution, retries and cancellation | [server/everyagent-workflow-service.mjs](server/everyagent-workflow-service.mjs), [server/everyagent-orchestrator.mjs](server/everyagent-orchestrator.mjs) |
| Conversation behavior and budgets | [server/everyagent-conversations.mjs](server/everyagent-conversations.mjs) |
| Model instructions and structured answers | [server/everyagent-conversation-model.mjs](server/everyagent-conversation-model.mjs) |
| Scope-aware evidence retrieval | [server/everyagent-conversation-sources.mjs](server/everyagent-conversation-sources.mjs) |
| Current decisions, learning/eval roadmap and limits | [docs/build-spec.md](docs/build-spec.md) |

## Work locally

```sh
npm ci --ignore-scripts
npm test
npm run build:api
npm run build:worker
npm run check:package
```

Tests use synthetic identities, two local HTTP source applications and temporary
state. They make no live model calls and create no cloud resources. The package
check installs the API outside this checkout, boots its production entry point,
and checks health, authentication, configuration guards and clean shutdown.

`npm start` is the real API entry. It requires production storage, Entra and
connector configuration; see [.env.example](.env.example). The Functions worker
is a separate deployment. This repo does not turn on a local auth bypass.

## Connect an application

Read [docs/connectors.md](docs/connectors.md). The agent connects to a bounded API
owned by each application. That app authorizes the workload, user and resources.
It keeps its business rules, database and transactions. The agent owns task state,
skills and orchestration. An embedded UI is an optional client of the agent API.

The current real connector implementation lives in Platform and exposes Licensing
summaries and a protected Admissions aggregate. Direct Pipeline assessment,
Workforce and AlamoHealth connectors are not implemented here yet. Memory/graph,
reviewed learning and write tools remain planned; no capability is implied by
adding an app name or configuration entry.

## Update Platform's compatibility package

```sh
npm test
npm run pack:runtime
```

The resulting `generated/alamo-agent-runtime-0.1.0.tgz` is an internal distribution,
not a second source tree. Copy a reviewed, versioned archive into Platform's
`vendor/`, update its dependency and lock, and run its integration checks. Bump
the package version for subsequent releases; never silently replace a deployed
version. Production uses locked package bytes and does not need this sibling
directory to exist. Nothing is published to npm or GitHub by these commands.

Platform's old `everyagent-*` files are compatibility exports. Its source API,
source grants, UI and domain adapters remain Platform-owned. Common utility and
public resource-directory snapshots were extracted at `a1daade`; source apps are
still authoritative for current authorization and resource membership.

Eric-only rollout; no emails; Andrew's Wilson branding stays inactive. Local
verification is not production deployment. The build spec records remaining work.
