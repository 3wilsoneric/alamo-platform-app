import { ManagedIdentityCredential } from "@azure/identity";
import { createApplicationConnectors } from "./application-connectors.mjs";
import { AGENT_SOURCE_PATH } from "../shared/everyagent-source-contracts.mjs";

// The worker's identity is distinct from the Platform source/grant-store
// identity. Credentials live only here, never in tasks or orchestration inputs.
export function createEveryAgentSourceRuntime({ env = process.env, credentialFor = clientId => new ManagedIdentityCredential(clientId) } = {}) {
  let configs;
  if (env.ALAMOAGENT_CONNECTORS_JSON !== undefined) {
    try {
      if (env.ALAMOAGENT_CONNECTORS_JSON.length > 32_000) throw new Error();
      configs = JSON.parse(env.ALAMOAGENT_CONNECTORS_JSON);
    } catch { throw new Error("Configure a valid application connector registry."); }
  } else {
    configs = [{ application: "platform", origin: env.ALAMOAGENT_PLATFORM_ORIGIN, endpoint: AGENT_SOURCE_PATH,
      scope: env.ALAMOAGENT_PLATFORM_SCOPE, clientId: env.ALAMOAGENT_CONNECTOR_CLIENT_ID }];
  }
  if (!Array.isArray(configs) || configs.length > 32) throw new Error("Configure application connectors.");
  const uuid = "[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}";
  return createApplicationConnectors({ connectors: configs.map(config => {
    if (!config || typeof config !== "object" || Object.keys(config).some(key => !["application", "origin", "endpoint", "scope", "clientId"].includes(key)) ||
        !config.origin || !config.endpoint || !new RegExp(`^api://${uuid}/\\.default$`).test(config.scope ?? "") || !new RegExp(`^${uuid}$`).test(config.clientId ?? "")) {
      throw new Error("Configure the agent Platform connector or application registry with an origin, API path, resource scope and workload identity.");
    }
    const credential = credentialFor(config.clientId);
    return { application: config.application, origin: config.origin, endpoint: config.endpoint,
      getToken: () => credential.getToken(config.scope, { abortSignal: AbortSignal.timeout(5000) }) };
  }) });
}
