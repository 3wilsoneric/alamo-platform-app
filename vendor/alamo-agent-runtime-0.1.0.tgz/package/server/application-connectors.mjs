import { EVERYAGENT_SKILLS } from "../shared/everyagent-catalog.mjs";
import { createEveryAgentSourceClient } from "./everyagent-source-client.mjs";

// Both API and worker use this router. A request cannot choose a URL, token
// audience, alternate source or a broader skill. Missing apps fail closed.
export function createApplicationConnectors({ connectors, skills = EVERYAGENT_SKILLS }) {
  if (!Array.isArray(connectors) || connectors.length > 32) throw new Error("Configure application connectors.");
  const clients = new Map();
  const bindings = new Map();
  for (const skill of skills) {
    if (bindings.has(skill.id) || !/^[a-z][a-z0-9-]{0,63}$/.test(skill.sourceApplication)) throw new Error("Invalid skill source binding.");
    bindings.set(skill.id, skill.sourceApplication);
  }
  for (const config of connectors) {
    if (!config || clients.has(config.application) || ![...bindings.values()].includes(config.application)) throw new Error("Unknown or duplicate application connector.");
    clients.set(config.application, createEveryAgentSourceClient(config));
  }
  function clientFor(assignment) {
    const client = clients.get(bindings.get(assignment.skillId));
    if (!client) throw new Error("This skill's application is not connected.");
    return client;
  }
  const authorize = (assignment, receipt = undefined) => clientFor(assignment).authorize(assignment, receipt);
  const adapters = Object.fromEntries(skills.map(skill => [skill.id, assignment => {
    if (assignment.skillId !== skill.id) throw new Error("The assignment does not match this skill.");
    return clientFor(assignment).read(assignment);
  }]));
  return { authorize, adapters };
}
