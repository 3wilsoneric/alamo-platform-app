export function createExecutiveReportRuntime({ env, credentialFor, store, fetchImpl }?: {
    env?: NodeJS.ProcessEnv | undefined;
    credentialFor?: ((id: any) => ManagedIdentityCredential) | undefined;
    store?: null | undefined;
    fetchImpl?: typeof fetch | undefined;
}): {
    create: (auth: any, input: any) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    }>;
    get: (auth: any, ownerId: any, id: any, version?: null) => Promise<{
        selectedVersion: any;
        canEdit: boolean;
        scope: any;
        objective: any;
        status: any;
        error: any;
        artifact: any;
        view: any;
        readers: any;
        sourceProgress: any;
        versions: any;
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        completedSources: any;
        totalSources: any;
    }>;
    list: (auth: any) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    }[]>;
    command: (auth: any, input: any) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    }>;
    pending: () => Promise<{
        ownerId: any;
        id: any;
        runId: any;
        attempt: any;
    }[]>;
    advance: ({ ownerId, id, runId, attempt }: {
        ownerId: any;
        id: any;
        runId?: null | undefined;
        attempt?: null | undefined;
    }) => Promise<{
        id: any;
        ownerId: any;
        title: any;
        createdAt: any;
        updatedAt: any;
        version: any;
        revision: any;
        status: any;
        completedSources: any;
        totalSources: any;
    } | {
        status: any;
        claimed: boolean;
    }>;
    pause: ({ ownerId, id, runId, attempt }: {
        ownerId: any;
        id: any;
        runId: any;
        attempt: any;
    }) => Promise<void>;
} | null;
import { ManagedIdentityCredential } from '@azure/identity';
