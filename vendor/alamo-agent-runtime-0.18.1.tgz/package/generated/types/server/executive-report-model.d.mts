export function createExecutiveReportModel({ apiKey, projectId, model, verifiedUntil, fetchImpl, now }: {
    apiKey: any;
    projectId: any;
    model: any;
    verifiedUntil: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
}): {
    plan(context: any): Promise<{
        plan: {
            steps: any;
            gaps: any;
        };
        metadata: {
            requestedModel: any;
            responseModel: any;
            promptVersion: string;
            inputTokens: any;
            outputTokens: any;
            latencyMs: number;
        };
    }>;
    synthesize(context: any): Promise<any>;
};
export const EXECUTIVE_REPORT_PROMPT: "executive-report-v1";
