import { newQuickJSWASMModule } from 'quickjs-emscripten';
import { reportHash, reportText, validateReportEvidence } from '../shared/executive-report-contracts.mjs';

// Only source-issued pagination metadata can establish a complete population.
// A model's claim, arbitrary JSON or a mixture of revisions cannot do so.
function completePageInputs(sources, evidence) {
  const groups = new Map(), complete = new Set();
  for (const source of sources) {
    const data = source.data;
    if (evidence.find(item => item.sourceId === source.id)?.value.capability !== 'platform-data' ||
      data?.version !== 'ally-platform-data-v1' || data.populationCoverage !== 'complete' ||
      data.query?.operation !== 'rows' || typeof data.revision !== 'string' || !/^[a-f0-9]{64}$/.test(data.revision) ||
      !Number.isSafeInteger(data.offset) || data.offset < 0 ||
      !Number.isSafeInteger(data.totalRows) || data.totalRows < 0 ||
      !Array.isArray(data.rows) || data.returnedRows !== data.rows.length) continue;
    const end = data.offset + data.rows.length;
    if (end > data.totalRows || data.hasMore !== (end < data.totalRows) ||
      data.nextOffset !== (data.hasMore ? end : null) || data.hasMore && !data.rows.length) continue;
    const group = groups.get(data.revision) ?? [];
    group.push({id:source.id,start:data.offset,end,total:data.totalRows});
    groups.set(data.revision,group);
  }
  for (const group of groups.values()) {
    group.sort((a,b)=>a.start-b.start);
    let end = 0;
    const total = group[0].total;
    if (group.every(page=>{
      if (page.total !== total || page.start !== end) return false;
      end = page.end; return true;
    }) && end === total) for (const page of group) complete.add(page.id);
  }
  return complete;
}

// A fresh WASM interpreter for each analysis. No host callbacks, module loader,
// network, files, environment, secrets or database clients enter the context.
// Computation proves execution over named inputs, not the semantic correctness
// of model-authored analysis. Preserve code and input revisions for review.
export async function computeAnalysis({ code, title, sourceIds }, evidence, scope, observedAt) {
  reportText(code, 12_000); reportText(title, 120);
  if (!Array.isArray(sourceIds) || !sourceIds.length || sourceIds.length > 24 || new Set(sourceIds).size !== sourceIds.length) throw Error('Choose the evidence inputs for this calculation.');
  const sources = sourceIds.map(id => {
    const item = evidence.find(item => item.sourceId === id);
    if (!item || item.value.status !== 'verified') throw Error('A computation input is unavailable.');
    let data; try { data = JSON.parse(item.value.answer); } catch { data = item.value.answer; }
    return { id, data, scope:item.value.scope, period:item.value.period, observedAt:item.value.observedAt, coverage:item.value.coverage ?? 'complete', revision:item.value.revision };
  });
  const encoded = JSON.stringify(sources);
  if (Buffer.byteLength(encoded) > 384_000) throw Error('Select a smaller analysis input or aggregate it at the source.');
  const wasm = await newQuickJSWASMModule(), runtime = wasm.newRuntime();
  runtime.setMemoryLimit(32 * 1024 * 1024); runtime.setMaxStackSize(256 * 1024);
  const deadline = Date.now() + 1500; runtime.setInterruptHandler(() => Date.now() > deadline);
  const vm = runtime.newContext();
  let output;
  try {
    const script = `(() => { 'use strict'; const NativeDate=Date; globalThis.Date=class extends NativeDate { constructor(...args){super(...(args.length?args:[0]));} static now(){return 0;} }; Math.random=()=>{throw Error('Randomness is unavailable');}; const sources=JSON.parse(${JSON.stringify(encoded)}); return JSON.stringify((function(){${code}\n})()); })()`;
    const evaluated = vm.evalCode(script, 'analysis.js');
    if (evaluated.error) {
      let diagnostic='';
      try { const error=vm.dump(evaluated.error); diagnostic=typeof error?.message==='string' ? error.message.slice(0,240) : ''; }
      finally { evaluated.error.dispose(); }
      throw Error(`Analysis failed or exceeded its execution limit.${diagnostic?' '+diagnostic:' Check the code and inputs.'}`);
    }
    try {
      if (vm.typeof(evaluated.value) !== 'string') throw Error('Return a JSON object with result and optional dataset.');
      const value = vm.getString(evaluated.value);
      if (Buffer.byteLength(value) > 16_000) throw Error('Analysis output is too large. Return a summary or bounded table.');
      output = JSON.parse(value);
    } finally { evaluated.value.dispose(); }
  } finally { vm.dispose(); runtime.dispose(); }
  if (!output || typeof output !== 'object' || Array.isArray(output) || !Object.hasOwn(output,'result') || Object.keys(output).some(key=>!['result','dataset'].includes(key))) throw Error('Return result, with an optional native dataset.');
  const proof = {code, sources:sources.map(({id,revision})=>({id,revision}))};
  const completePages = completePageInputs(sources,evidence);
  const revision = reportHash({proof,output});
  const step = {id:`analysis-${revision.slice(0,12)}`,capability:'computed-analysis',input:proof};
  const value = validateReportEvidence({capability:step.capability,inputHash:reportHash(proof),scope,revision,
    grantRevision:reportHash(sources.map(s=>evidence.find(e=>e.sourceId===s.id).value.grantRevision)),requiresDetail:sources.some(s=>evidence.find(e=>e.sourceId===s.id).value.requiresDetail),
    observedAt,period:'Input sources retain their individual periods',grain:'Model-authored computation over cited evidence',status:'verified',title,
    answer:JSON.stringify({result:output.result,inputs:sources.map(({id,period,observedAt,coverage})=>({id,period,observedAt,coverage}))}),
    note:'Computed from the cited inputs. The retained program proves execution, not the interpretation, causal claims or completeness of its input population.',
    coverage:sources.some(s=>s.coverage==='partial' && !completePages.has(s.id))?'partial':'complete',...(output.dataset?{dataset:output.dataset}:{})},step,scope);
  return {sourceId:step.id,value,proof};
}
