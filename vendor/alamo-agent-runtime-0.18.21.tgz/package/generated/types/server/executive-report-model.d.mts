export function createExecutiveReportModel({ apiKey, projectId, model, verifiedUntil, fetchImpl, now, spend }: {
    apiKey: any;
    projectId: any;
    model: any;
    verifiedUntil: any;
    fetchImpl?: typeof fetch | undefined;
    now?: (() => number) | undefined;
    spend?: {
        reserve(inputTokens: any, maxOutputTokens: any): Promise<(usage: any) => Promise<void>>;
    } | null | undefined;
}): {
    investigate(context: any, controls: any): Promise<any>;
    cacheIdentity: string;
    plan(context: any): Promise<{
        plan: {
            steps: any;
            gaps: any;
        };
        reusePreviousEvidence: boolean;
        metadata: {
            requestedModel: any;
            responseModel: any;
            promptVersion: string;
            inputTokens: any;
            outputTokens: any;
            latencyMs: number;
        };
    }>;
    synthesize(context: any): Promise<any>;
};
export const EXECUTIVE_REPORT_PROMPT: "executive-agent-workspace-v9";
